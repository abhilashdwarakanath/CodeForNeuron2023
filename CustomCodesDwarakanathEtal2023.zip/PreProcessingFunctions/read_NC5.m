function Samples = read_NC5(filename,min_record,max_record)
% min_record/max_recorod in samples

%load('NSX_TimeStamps');

if ~exist('min_record','var'),     min_record = 1; end  %start acquiring at min_record samples
if ~exist('max_record','var'),     max_record = 1000*30000; end  %stop acquiring at max_record samples


f1=fopen(filename,'r','l');
fseek(f1,(min_record-1)*2,'bof');
Samples=fread(f1,(max_record-min_record+1),'int16=>double');
Samples = Samples/4; 
fclose(f1);
