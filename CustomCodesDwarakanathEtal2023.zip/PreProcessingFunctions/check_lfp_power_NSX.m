function [outfile,chan_struct,chnum] = check_lfp_power_NSX(channel,limsy,notch,parall,save_fig,db_thr,dura,que_macro,fpass_l,fpass_h,direc_resus_base,direc_raw,resus_folder,record,show_img)
% HGR FEB 2013
% computes the power spectrum and finds the frequencies with large
% deviations that can be rejected with notches.

% channel = 101;
% % limsy = [-40 40]; % the limits on the y axis in dB. If this variable is
% not passed, they will be computed automatically
% db_thr sets the offset to compute the threshold for notch candidates
% notch = 0 -> original only, notch = 1 -> original + notch cascade
% dura sets half the duration (in min) of the recording to be analised (it takes half at the beginning and half at the end). use 'all' to analise the wholke recording
% tic
if ~exist('parall','var'),     parall = 0; end
if ~exist('save_fig','var'),     save_fig = 0; end
if ~exist('db_thr','var'),     db_thr = 2.5; end        
if ~exist('notch','var'),     notch = 0; end              
if ~exist('que_macro','var'),     que_macro = 'NN'; end
if ~exist('fpass_l','var'),    fpass_l = 2; end
if ~exist('fpass_h','var'),     fpass_h = 3000; end
if ~exist('record','var'),     record = 1; end
if ~exist('show_img','var'),     show_img = 1; end
if ~exist('direc_resus_base','var'),     direc_resus_base = pwd; end
if ~exist('direc_raw','var'),     direc_raw = pwd; end
% if ~exist('dura','var'),        dura='all';  end
if ~exist('dura','var'),        dura=7.5;  end
% % if ~exist('q1','var'),          q1=125;  end    % the smaller the q0 factor, the wider the notch rejection band with larger attenuation
% % if ~exist('q2','var'),          q2=600;  end
% % if ~exist('q3','var'),          q3=1000;  end
span_smooth = 21;
chan_struct = [];
% % fq1=300;
% % fq2=1000;
close all
fstop_l = 0.5;
fstop_h = fpass_h*1.3;
Rp=0.07;
Rs=20;
fmaxplot = fpass_h;
fsplit_thr = 90;
fmin_thr = 45;
abre_notch = 3;
Q_corr_thr = 20;
Q_corr = 0.75;

numfig = ceil(10000*rand(1));
figure(numfig)
% if exist('Maximize_pure','file')==2 && parall~=1
%     set(gcf, 'PaperUnits', 'inches');
%     set(gcf, 'PaperType', 'A4');
%     set(gcf, 'PaperPositionMode', 'auto');
%     Maximize_pure(numfig)
% else
%     set(gcf,'papertype','usletter','paperorientation','portrait','paperunits','inches')
%     set(gcf,'paperposition',[.25 .25 10.5 7.8])
% end

if show_img==0
    set(numfig, 'Visible', 'off') 
end

if ~exist('resus_folder','var')
    direc_resus = direc_resus_base;
    resus_folder = direc_resus(find(direc_resus==filesep,1,'last')+1:end);
else
    direc_resus = fullfile(direc_resus_base,resus_folder);
end

if exist(fullfile(direc_raw,'sites.mat'),'file')
    load(fullfile(direc_raw,'sites.mat'));
end

switch notch
    case 0
        filetocheck_end = ['_lfp_' num2str(fpass_l) '_' num2str(fpass_h)];
        if parall~=1
            if ~exist(fullfile(direc_resus,'harmons_per_channel.mat'),'file'), 
                save(fullfile(direc_resus,'harmons_per_channel'),'resus_folder');
            else
                save(fullfile(direc_resus,'harmons_per_channel'),'resus_folder','-append');
            end
        end
    case 1
% %         filetocheck_end = ['_lfp_' num2str(fpass_l) '_' num2str(fpass_h) '_q1' num2str(q1) '_q2' num2str(q2) '_q3' num2str(q3)];
        filetocheck_end = ['_lfp_' num2str(fpass_l) '_' num2str(fpass_h) '_qsauto'];
        if ~exist(fullfile(direc_resus,'harmons_per_channel.mat'),'file')
            disp('harmons_per_channel.mat cannot be found. You should run first the code with parameter notch = 0 so it can compute the potential notch frequencies')
            return
        else
            load(fullfile(direc_resus,'harmons_per_channel.mat'))
        end
    otherwise
        disp('check notch value')
end

load(fullfile(direc_raw,'NSX_TimeStamps'));
    
sr_orig = 30000;
lts = length(TimeStamps);
if ~strcmp(dura,'all')
    t_half = dura*60; % in seconds
    samples_half = floor(min(t_half*sr_orig,lts/2));
    dura = [num2str(2*samples_half/sr_orig,'%4.2f') 's'];
%     tsmin = [TimeStamps(1) TimeStamps(lts-samples_half+1)];
%     tsmax = [TimeStamps(samples_half) TimeStamps(lts)];   
    tinfind = [1 lts-samples_half+1];
    tsupind = [samples_half lts];
else
%     tsmin = [TimeStamps(1) TimeStamps(floor(lts/4)+1) TimeStamps(floor(lts/2)+1) TimeStamps(floor(3*lts/4)+1)];
%     tsmax = [TimeStamps(floor(lts/4)) TimeStamps(floor(lts/2)) TimeStamps(floor(3*lts/4)) TimeStamps(lts)];
	tinfind = [1, floor(lts/4)+1, floor(lts/2)+1, floor(3*lts/4)+1];
    tsupind = [floor(lts/4), floor(lts/2), floor(3*lts/4), lts];
end
clear TimeStamps;

for i=1:length(channel);
%     tic
    clf(numfig)
    chnum=channel(i);
    if exist('sites','var')
        que_macro = sites(ceil(chnum/8),:);
    end
    disp([resus_folder '_' num2str(chnum)])
    %lfp_orig=zeros(1,sum(tsupind-tinfind+1)-1);
    lfp_orig = [];
    %from=0;
    for j=1:length(tinfind)
        %% Abhi's edit - Fixed indexing issues by using horizontal concatenation
        a = [];
        a = Get_lfp_NSX_pure_piece(chnum,sr_orig,tinfind(j),tsupind(j),fpass_l,fpass_h,fstop_l,fstop_h,Rp,Rs,direc_raw);
        lfp_orig = [lfp_orig a];
        %lfp_orig(from+1:from+1+tsupind(j)-tinfind(j)) = Get_lfp_NSX_pure_piece(chnum,sr_orig,tinfind(j),tsupind(j),fpass_l,fpass_h,fstop_l,fstop_h,Rp,Rs,direc_raw);
        %from = from+1+tsupind(j)-tinfind(j);
    end 
    
    Ntot_orig=length(lfp_orig);
%     para_largo = ceil(log(sr_orig)/log(2));   %resol aprox de 1 hz (con rectangular, resuelve hasta 0.88*sr/N). con wintool, el ancho que aparece es igual a (sr*K/L)/(fs/2), siendo K la constante de proporcionalida que cambia con la ventana
    para_largo = ceil(log(sr_orig)/log(2))+1;   %resol aprox de 0.5 hz (con rectangular, resuelve hasta 0.88*sr/N). con wintool, el ancho que aparece es igual a (sr*K/L)/(fs/2), siendo K la constante de proporcionalida que cambia con la ventana
    N = 2^para_largo;  
    M = floor(Ntot_orig/N);
    n=N;
%     fx=(-n/2: (n-1)/2)*sr_orig/n;
    fx_one=0:sr_orig/n:fmaxplot*1.05;
    fx_inds_split = find(fx_one<fsplit_thr,1,'last');
    fx_inds_start = find(fx_one<fmin_thr,1,'last');
    fx_inds_fmaxplot = find(fx_one>fmaxplot,1);
    
%     Xbarhan_orig = zeros(1,n);
    Xbarhan_orig_one = zeros(1,n/2+1);
    for jj=1:M
%         [Pbarhan] = periodogram(lfp_orig((jj-1)*N+1:jj*N),barthannwin(N),'twosided',n,sr_orig); % K aprox 1.375
%         Xbarhan_orig = Xbarhan_orig + Pbarhan';
        [Pbarhan_one] = periodogram(lfp_orig((jj-1)*N+1:jj*N),barthannwin(N),'onesided',n,sr_orig); % K aprox 1.375
        Xbarhan_orig_one = Xbarhan_orig_one + Pbarhan_one';
    end    
%     Pbarhan_new = fftshift(Xbarhan_orig/M);
    Pbarhan_new = Xbarhan_orig_one(1:length(fx_one))/M;
    Pbarhan_slideavg = smooth(Pbarhan_new,span_smooth,'rloess')';
    Pbarhan_slideavg = [smooth(Pbarhan_new(1:fx_inds_split),span_smooth,'rloess')' Pbarhan_slideavg(fx_inds_split+1:end)];
    % Abhi's edit - Plot in the log scale instead of linear
    Pbarhan_thr = 10*log10(Pbarhan_slideavg)+db_thr;
    h1 = semilogx(fx_one,10*log10(Pbarhan_new),'b','LineWidth',1.5);
    hold on
    semilogx(fx_one,Pbarhan_thr,'g','LineWidth',1.5)
    
    fini=2;
    fmid=300;
    power_fit = log10(Pbarhan_new(find(fx_one>fini,1):find(fx_one>fmid,1)));
    freqs_fit = log10(fx_one(find(fx_one>fini,1):find(fx_one>fmid,1)));
        
    p_all1 = polyfit(freqs_fit,power_fit,1);
    k1=p_all1(1);
    loga=p_all1(2);
    model = k1*freqs_fit+loga;
    [r2_all1 ~] = rsquare(power_fit,model);

    fend=3000;
    power_fit = log10(Pbarhan_new(find(fx_one>fmid,1):find(fx_one>fend,1)));
    freqs_fit = log10(fx_one(find(fx_one>fmid,1):find(fx_one>fend,1)));
        
    p_all2 = polyfit(freqs_fit,power_fit,1);
    k2=p_all2(1);
    loga=p_all2(2);
    model = k2*freqs_fit+loga;
    [r2_all2 ~] = rsquare(power_fit,model);    
   
    if notch==0
        pasa = 10*log10(Pbarhan_new(fx_inds_start:fx_inds_fmaxplot)) > Pbarhan_thr(fx_inds_start:fx_inds_fmaxplot);    
        ons = find(diff(pasa)==1);
        offs = find(diff(pasa)==-1);
        if pasa(1)==1
            offs = offs(2:end);
            disp(['Power already above threshold at ' num2str(fmin_thr) ' Hz']);
        end
        if length(ons)==length(offs)+1
            offs = [offs,length(pasa)];
        end

        anchos=max(fx_one(fx_inds_start+offs)-fx_one(fx_inds_start+ons),1);
        agrega_on = [];
        agrega_off = [];
        cuales = find(anchos/abre_notch>1);
        tocados = 0;
        for ss=1:length(cuales)
            tem = linspace(ons(cuales(ss)),offs(cuales(ss)),floor(anchos(cuales(ss))/abre_notch)+2);
            agrega_on = [agrega_on floor(tem(2:end-1))];            
            offs(cuales(ss)) = floor(tem(2));
            agrega_off = [agrega_off floor(tem(3:end))];
            tocados  = tocados + length(tem)-2;
        end
        cant_notch_orig = length(ons);
        ons = [ons agrega_on];
        offs = [offs agrega_off];
        
        anchos=max(fx_one(fx_inds_start+offs)-fx_one(fx_inds_start+ons),1);
        notch_freqs = zeros(1,length(ons)); 
        max_dev= zeros(1,length(ons));         
        for gg=1:length(ons)
            inds = fx_inds_start+ons(gg):fx_inds_start+offs(gg)-1;
            arriba = 10*log10(Pbarhan_new(inds))-Pbarhan_thr(inds);            
            max_dev(gg) = max(arriba);
            [~,j] = sort(abs(fx_one(inds)-(arriba/sum(arriba))*fx_one(inds)'));
            [~,I] = max(Pbarhan_new(inds(j(1:min(2,length(j))))));            
            notch_freqs(gg) = fx_one(fx_inds_start+ons(gg)+j(I)-1);
        end
        
        qs=notch_freqs./anchos;
        qs(max_dev>Q_corr_thr) = qs(max_dev>Q_corr_thr)*Q_corr;
        correct_qs = notch_freqs(max_dev>Q_corr_thr);
    else    
        que_armon=eval(['channel_' num2str(chnum) '.freqs']); 
        if isempty(que_armon)
            lfp_notch=lfp_orig;    
        else
            qs_new = eval(['channel_' num2str(chnum) '.qs']);
            cant_notches = length(que_armon);        
            Z = zeros(2*cant_notches,1);
            P = zeros(2*cant_notches,1);
            wo = (que_armon(1)/(sr_orig/2)); bw = wo/qs_new(1);  %bw = wo/q1;
            [b_notch,a_notch] = iirnotch(wo,bw); % Note type flag 'notch'
            [Z(1:2),P(1:2),K]=tf2zpk(b_notch,a_notch);
    % %         q=q1;
            for kk=2:cant_notches
    % %             if que_armon(kk) > fq2
    % %                 q = q3;
    % %             elseif que_armon(kk) > fq1
    % %                 q = q2;
    % %             end
    % %             wo = que_armon(kk)/(sr_orig/2);  bw = wo/q; %bw = wo/q0;
                wo = que_armon(kk)/(sr_orig/2);  bw = wo/qs_new(kk); %bw = wo/q0;
                [b_notch,a_notch] = iirnotch(wo,bw);
                [Z(2*kk-1:2*kk),P(2*kk-1:2*kk),k_notch]=tf2zpk(b_notch,a_notch);
                K = K * k_notch;    
            end
            [S,G] = zp2sos(Z,P,K);       % Convert to SOS
    %         toc

% %             lfp_notch=zeros(size(lfp_orig));
% %             for j=1:4
% %                 tinfind=(j-1)*ceil(Ntot_orig/4)+1;
% %                 tsupind=min(j*ceil(Ntot_orig/4),Ntot_orig); 
% % %                 lfp_notch = [lfp_notch filtfilt(S,G,lfp_orig(tinfind:tsupind))];       % se puede suavizar la condicion de borde? la otra es buscar de partir donde haya respuestas largas para que el efecto no joda tanto
% %                 lfp_notch(tinfind:tsupind) = filtfilt(S,G,lfp_orig(tinfind:tsupind));       % se puede suavizar la condicion de borde? la otra es buscar de partir donde haya respuestas largas para que el efecto no joda tanto
% %             end
            lfp_notch=filtfilt(S,G,lfp_orig);    
    %         toc
        end
%         Xbarhan_notch = zeros(1,n);
        Xbarhan_notch = zeros(1,n/2+1);
        for jj=1:M
%             [Pbarhan_notch] = periodogram(lfp_notch((jj-1)*N+1:jj*N),barthannwin(N),'twosided',n,sr_orig); % K aprox 1.375
%             Xbarhan_notch = Xbarhan_notch + Pbarhan_notch';
            [Pbarhan_notch] = periodogram(lfp_notch((jj-1)*N+1:jj*N),barthannwin(N),'onesided',n,sr_orig); % K aprox 1.375
            Xbarhan_notch = Xbarhan_notch + Pbarhan_notch';
        end    
        h2 = plot(fx_one,10*log10(Xbarhan_notch(1:length(fx_one))/M),'r','LineWidth',1.5);    
    end
    xlim([0 fmaxplot])
    grid minor
    if ~exist('limsy','var') || isempty(limsy)
        limy = ylim;
        limites = 'auto';
    else
        limy = limsy;
        ylim(limy)
        limites = 'same';
    end
    y_cross = limy(2) - 0.1*(limy(2)-limy(1));
    if notch == 0
        eval(['channel_' num2str(chnum) '.freqs = notch_freqs;']);
        eval(['channel_' num2str(chnum) '.qs = qs;']);
        eval(['channel_' num2str(chnum) '.cant_notch_orig = cant_notch_orig;']);   
        eval(['channel_' num2str(chnum) '.Q_corr_thr = Q_corr_thr;']);   
        eval(['channel_' num2str(chnum) '.Q_corr = Q_corr;']);   
        eval(['channel_' num2str(chnum) '.correct_qs = correct_qs;']);   
        eval(['channel_' num2str(chnum) '.db_thr = db_thr;']);
        eval(['channel_' num2str(chnum) '.fmin_thr = fmin_thr;']);
        eval(['channel_' num2str(chnum) '.fsplit_thr = fsplit_thr;']);
        eval(['channel_' num2str(chnum) '.dura = dura;']);
        if parall==1
            eval(['chan_struct = channel_' num2str(chnum) ';']);
        else
            save(fullfile(direc_resus,'harmons_per_channel'),eval(['''channel_' num2str(chnum) '''']),'-append')
        end
    end
    if ~isempty(eval(['channel_' num2str(chnum)]))
        plot(eval(['channel_' num2str(chnum) '.freqs(1:channel_' num2str(chnum) '.cant_notch_orig)']),y_cross*ones(1,eval(['channel_' num2str(chnum) '.cant_notch_orig'])),'rx','MarkerSize',12,'LineWidth',2)
        plot(eval(['channel_' num2str(chnum) '.correct_qs']),y_cross*ones(1,eval(['length(channel_' num2str(chnum) '.correct_qs)'])),'r*','MarkerSize',12,'LineWidth',2)
        plot(eval(['channel_' num2str(chnum) '.freqs(channel_' num2str(chnum) '.cant_notch_orig+1:end)']),y_cross*ones(1,eval(['length(channel_' num2str(chnum) '.freqs) - channel_' num2str(chnum) '.cant_notch_orig'])),'kx','MarkerSize',12,'LineWidth',2)
    end
    line([fpass_l fpass_l],[limy(1) limy(2)],'Color','m','LineStyle',':','LineWidth',1.5)
%     line([4 4],[limy(1) limy(2)],'Color','m','LineStyle','-.','LineWidth',1.5)
%     line([8 8],[limy(1) limy(2)],'Color','m','LineStyle','-.','LineWidth',1.5)
% %     if notch>0
% %         line([fq1 fq1],[limy(1) limy(2)],'Color','c','LineStyle','-.','LineWidth',1.5)
% %         line([fq2 fq2],[limy(1) limy(2)],'Color','c','LineStyle','-.','LineWidth',1.5)
% %     end
    line([fmin_thr fmin_thr],[limy(1) limy(2)],'Color','m','LineStyle','-.','LineWidth',1.5)
%     line([76 76],[limy(1) limy(2)],'Color','k','LineStyle','-.','LineWidth',1.5)
%     line([180 180],[limy(1) limy(2)],'Color','k','LineStyle','-.','LineWidth',1.5)
    xlabel('Frequency (Hz)','fontsize',12)
    ylabel('Power Spectrum (dB/Hz)','fontsize',12)
    set(gca,'fontsize',12)
    
    %annotation(numfig,'textbox',[0.73 0.7 0.1 0.1],'String',{'Power fit (1st order loglog)',[num2str(fini) '-' num2str(fmid) ' Hz: \alpha = ' num2str(k1,'%1.2f') ' (r^2 = ' num2str(r2_all1,'%1.2f') ')'],[num2str(fmid) '-' num2str(fend) ' Hz: \alpha = ' num2str(k2,'%1.2f') ' (r^2 = ' num2str(r2_all2,'%1.2f') ')']},'FontSize',12,'BackgroundColor',[1 1 1]);
    
    switch notch
        case 0
%             legend('Original data')
            titletext = ['Spectrum of Ch ' num2str(chnum) ' (' que_macro(~isspace(que_macro)) '), session ' resus_folder ' (' num2str(M) ' averaged periodograms of length ' num2str(N) ', bartlett-hanning window). sr original = ' num2str(round(sr_orig)) ' Hz. ' num2str(length(eval(['channel_' num2str(chnum) '.freqs']))) ' candidate notches after ' num2str(fmin_thr) ' Hz. ' num2str(length(cuales)) ' notches where split into ' num2str(tocados)];
        case 1
            legend([h1 h2],'Original data','Original data + notch','location','east')
            titletext = ['Spectrum of Ch ' num2str(chnum) ' (' que_macro(~isspace(que_macro)) '), session ' resus_folder ' (' num2str(M) ' averaged periodograms of length ' num2str(N) ', bartlett-hanning window). sr original = ' num2str(round(sr_orig)) ' Hz'];
    end
        
    title(titletext,'fontsize',12);   

    if record
        if ~exist(fullfile(direc_resus_base,'spectra'),'dir')
            mkdir(direc_resus_base,'spectra');
        end
%         print('-dpng', fullfile(direc_resus_base,'spectra',['spectrum_' resus_folder '_ch' num2str(chnum) '_' limites filetocheck_end '_dura' dura '_abrenotch' num2str(abre_notch) '_dbthr' num2str(db_thr) '.png']))
        outfile = fullfile(direc_resus_base,'spectra',['spectrum_' resus_folder '_ch' num2str(chnum) '_' limites filetocheck_end '_dura' dura '_abrenotch' num2str(abre_notch) '_dbthr' num2str(db_thr)]);
        
        if save_fig==1
            saveas(numfig,[outfile '.fig'],'fig');
        else
            if parall==1
                X = hardcopy(numfig,outfile,'-dOpenGL','-r180');
%                 disp(['ch' chan_name ' opengl ' num2str(size(X)) '\n'])
%                 imwrite(X,[fig_name '_paral.jpg'],'jpg');
            end                        
            if exist('Maximize_pure','file')==2
                set(numfig, 'PaperUnits', 'inches', 'PaperType', 'A4', 'PaperPositionMode', 'auto');
                Maximize_pure(numfig)
            else
                set(numfig, 'PaperUnits', 'inches', 'PaperType', 'A4', 'PaperPositionMode', 'auto','Units','normalized', 'OuterPosition',[0 0 1 1]);
            end
            print(numfig,'-dpng',[outfile '.png']);
        end  
%         if parall==1
%             saveas(numfig, [outfile '.fig'],'fig')
%         else
%             saveas(numfig, [outfile '.png'],'png')
%         end
% %         if notch==0
% %             saveas(gcf,fullfile(direc_resus_base,'spectra',['spectrum_' limites filetocheck_end '_' resus_folder '_ch' num2str(chnum)]),'fig')
% %         end
    end    
%     toc
end
% toc

function [r2 rmse] = rsquare(y,f,varargin)
% Compute coefficient of determination of data fit model and RMSE
%
% [r2 rmse] = rsquare(y,f)
% [r2 rmse] = rsquare(y,f,c)
%
% RSQUARE computes the coefficient of determination (R-square) value from
% actual data Y and model data F. The code uses a general version of 
% R-square, based on comparing the variability of the estimation errors 
% with the variability of the original values. RSQUARE also outputs the
% root mean squared error (RMSE) for the user's convenience.
%
% Note: RSQUARE ignores comparisons involving NaN values.
% 
% INPUTS
%   Y       : Actual data
%   F       : Model fit
%
% OPTION
%   C       : Constant term in model
%             R-square may be a questionable measure of fit when no
%             constant term is included in the model.
%   [DEFAULT] TRUE : Use traditional R-square computation
%            FALSE : Uses alternate R-square computation for model
%                    without constant term [R2 = 1 - NORM(Y-F)/NORM(Y)]
%
% OUTPUT 
%   R2      : Coefficient of determination
%   RMSE    : Root mean squared error
%
% EXAMPLE
%   x = 0:0.1:10;
%   y = 2.*x + 1 + randn(size(x));
%   p = polyfit(x,y,1);
%   f = polyval(p,x);
%   [r2 rmse] = rsquare(y,f);
%   figure; plot(x,y,'b-');
%   hold on; plot(x,f,'r-');
%   title(strcat(['R2 = ' num2str(r2) '; RMSE = ' num2str(rmse)]))
%   
% Jered R Wells
% 11/17/11
% jered [dot] wells [at] duke [dot] edu
%
% v1.2 (02/14/2012)
%
% Thanks to John D'Errico for useful comments and insight which has helped
% to improve this code. His code POLYFITN was consulted in the inclusion of
% the C-option (REF. File ID: #34765).

if isempty(varargin); c = true; 
elseif length(varargin)>1; error 'Too many input arguments';
elseif ~islogical(varargin{1}); error 'C must be logical (TRUE||FALSE)'
else c = varargin{1}; 
end

% Compare inputs
if ~all(size(y)==size(f)); error 'Y and F must be the same size'; end

% Check for NaN
tmp = ~or(isnan(y),isnan(f));
y = y(tmp);
f = f(tmp);

if c; r2 = max(0,1 - sum((y(:)-f(:)).^2)/sum((y(:)-mean(y(:))).^2));
else r2 = 1 - sum((y(:)-f(:)).^2)/sum((y(:)).^2);
    if r2<0
    % http://web.maths.unsw.edu.au/~adelle/Garvan/Assays/GoodnessOfFit.html
        warning('Consider adding a constant term to your model') %#ok<WNTAG>
        r2 = 0;
    end
end

rmse = sqrt(mean((y(:) - f(:)).^2));

function [xf] = Get_lfp_NSX_pure_piece(channel,sr,tinfind,tsupind,fpass_l,fpass_h,fstop_l,fstop_h,Rp,Rs,direc_raw)

if ~exist('direc_raw','var'),     direc_raw = pwd; end
if ~exist('Rp','var'),    Rp = 0.07; end
if ~exist('Rs','var'),    Rs = 20; end

[orden_pass, Wnorm_pass] = ellipord([fpass_l*2/sr fpass_h*2/sr],[fstop_l*2/sr fstop_h*2/sr],Rp,Rs);
[z_pass,p_pass,k_pass] = ellip(orden_pass,Rp,Rs,Wnorm_pass);
[s_pass,g_pass] = zp2sos(z_pass,p_pass,k_pass);

k=channel;
        
filename=sprintf('NSX%d.NC5',k);

Samples = read_NC5(fullfile(direc_raw,filename),tinfind,tsupind);


x=double(Samples(:))';
clear Samples;

xf=filtfilt(s_pass,g_pass,x);
