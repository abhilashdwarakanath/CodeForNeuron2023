function loop_plot_best_responses_s_NSXfiles_profile(chaux,muonly,rankfirst,ranklast_def,effect_rows_2,phase)
% Function plot_best_responses(channel, cluster)
% Plots the best max_stims responses of a channel ch and cluster i and histogram
% of all responses.
% MJI, Nov 2010 The response profile is ranked
% HGR Dec 2012
% muonly 'y' for class mu only (even if do_clustering has been run)
% change in rank to allow less than max_stims stimuli with the default max_stims is used 
% warning off to avoid v6 warnings plots look messy without this)

warning off
if nargin==0
    if exist('channels.mat','file'),  load channels; else channels = [1:64]; end
    chaux=channels;
end

if ~exist('muonly','var') || isempty(muonly), muonly='n'; end
if ~exist('rankfirst','var') || isempty(rankfirst), rankfirst=1; end
if ~exist('ranklast_def','var') || isempty(ranklast_def), ranklast_def=15; end
if ~exist('effect_rows_2','var') || isempty(effect_rows_2), effect_rows_2=0; end
if ~exist('phase','var') || isempty(phase),
    grapes_name = 'grapes.mat';
    load stimulus
else
    grapes_name = ['grapes_' phase '.mat'];
    if strcmp(phase,'prescr') || strcmp(phase,'posscr')
        load stimulus;
    else
        load(['stimulus_' phase '.mat']);
    end
end
    
load(grapes_name)
time_pre_ms = time_pre/1000;
time_pos_ms = time_pos/1000;

% if length(which_case)>4 && strcmp(which_case(1:4),'rsvp') && ~isnan(str2double(which_case(5)))
%     which_case = ['rsvp_' num2str(ISI(str2double(which_case(5))),'%1.2f')];
% end
    
% flag1=0;
if exist('sites.mat','file'); %flag1=1;
    load sites; 
else
    sites = NaN*ones(10,1);
end
tmin = 100;     %in ms.
tmax = 1000;    %in ms.
tmin_baseline = -1000;     %in ms.
tmax_baseline = -100;    %in ms.
colo = 'b';
% pic_num= [ 1:10 41:50   81:90];
% rast_num=[11:20 51:60  91:100];
% hist_num=[21:30 61:70 101:110];

%     pic_num=  [ 1:5  16:20 31:35 46:50];
%     rast_num= [ 6:10 21:25 36:40 51:55]';
%     hist_num= [11:15 26:30 41:45 56:60];
    
% if isempty(which_case),
if effect_rows_2==30
    pic_num=  [ 1:5  21:25];
    rast_num= [[6 11];[7 12];[8 13];[9 14];[10 15];20+[6 11];20+[7 12];20+[8 13];20+[9 14];20+[10 15]];
    hist_num= [16:20 36:40];
    max_stims = 10;
    lineheight = 0.4;
    linesep = 0.7;
elseif effect_rows_2==10
    pic_num=  [ 1:5  21:25];
    rast_num= [[6 11];[7 12];[8 13];[9 14];[10 15];20+[6 11];20+[7 12];20+[8 13];20+[9 14];20+[10 15]];
    hist_num= [16:20 36:40];
    max_stims = 10;
    lineheight = 1;
    linesep = 1.2;
elseif effect_rows_2==0
    pic_num=  [ 1:5  16:20 31:35 46:50];
    rast_num= [ 6:10 21:25 36:40 51:55]';
    hist_num= [11:15 26:30 41:45 56:60];
    max_stims = 15;
    lineheight = 0.3;
    linesep = 0.5;
end    
rows = 12;    
cols = 5;

col='brgcmybrgcmy';

figure(12345);
clusters_to_plot = ['class1 '; 'class2 ';'class3 ';'class4 ';'class5 ';'class6 ';'class7 ';'class8 ';'class9 ';'class10';'class11';'mu     '];
% if exist('Maximize_pure','file')==2
%     set(12345, 'PaperUnits', 'inches', 'PaperType', 'A4', 'PaperPositionMode', 'auto');
%     Maximize_pure(12345)
% else
%     set(12345,'papertype','usletter','paperorientation','portrait','paperunits','inches')
%     set(12345,'paperposition',[.25 .25 10.5 7.8])
% end

for ic=1:length(chaux),
    ch=chaux(ic);
    eval(['texto = char(fieldnames(chan' num2str(ch) '.details));']);
    ncl = length(find(texto(:,1)=='c'));
    flag2=0;
    if strcmp(muonly,'y')
        ncl=1;flag2=1;%plot multi unit
    end
    for icl=1:ncl
        if flag2, icl=size(clusters_to_plot,1);end        
%         if flag2, icl=8;end
        clf;
        eval(['active_cluster = chan' num2str(ch) '.' clusters_to_plot(icl,:) ';']);
        lstim = length(active_cluster.stim);
        ranklast = min(ranklast_def,lstim);
        for st =1:lstim
            eval(['spikes1 = active_cluster.stim{' num2str(st) '};'])
            ntrials(st) = size(spikes1,1);
            clear fr_aux; clear baseline_aux;
            for trial=1:ntrials(st)
                fr_aux(trial) = length(find(spikes1(trial,:) >= tmin & spikes1(trial,:) <= tmax));
                baseline_aux(trial) = length(find(spikes1(trial,:) >= tmin_baseline & spikes1(trial,:) <= tmax_baseline));
            end
            fr(st) = median(fr_aux);
            baseline(st) = median(baseline_aux);
        end
        [fr_sorted, ind] = sort(fr);
        
        limits = 0;
        for i=1:min(ranklast-rankfirst+1,max_stims)
            %st = ind(end-i+1);
            st = ind(end-i-(rankfirst-2));
            %pictures
            subplot(rows,cols,pic_num(i),'align')
            imagename=[stimulus(st).name];
            flag=1;
            if findstr('.jp',lower(imagename)), 
                eval('A=imread(imagename,''jpg'');','flag=0;');
                if flag, image(A); set(gca,'PlotBoxAspectRatio',[1 1 1]); 
                else 
                    t=findstr('.jp',lower(imagename));
                    xlim([-time_pre_ms time_pos_ms]);
                    text(500,0.5,imagename(1:t(1)-1),...
                        'fontsize',6,'HorizontalAlignment','center','interpreter','none');
                end
            else
                if exist(imagename,'file')
                    [y,Fs,bits]=wavread(imagename);
                    plot([0:1/Fs:(length(y)-1)/Fs]*1000,y(:,1));
                    xlim([-time_pre_ms time_pos_ms]);
                    t=findstr('.wav',imagename);
                    text(500,0.5,imagename(1:t(1)-1),...
                        'fontsize',6,'HorizontalAlignment','center','interpreter','none');
                else
                    xlim([-time_pre_ms time_pos_ms]);
                    text(500,0.5,lower(imagename),...
                        'fontsize',6,'HorizontalAlignment','center','interpreter','none');
                end
            end
            
            set(gca,'xtick',[],'ytick',[]);box off;
            if i==3,
%                 title(pwd,'interpreter','none');
%                 if ~exist('phase','var') || isempty(phase),                
%                     title(sprintf('%s, %s Best responses. Channel %2d, %s, %s',pwd,which_case,ch,clusters_to_plot(icl,:),sites(ceil(ch/8),:)));
%                 else
%                     title(sprintf('%s.  %s-movie scr.  Channel %2d, %s, %s',pwd,phase,ch,clusters_to_plot(icl,:),sites(ceil(ch/8),:)));
%                 end
                title(sprintf('%s, %s %s responses. Channel %2d, %s, %s',pwd,exp_type,phase,ch,clusters_to_plot(icl,:),sites(ceil(ch/8),:)),'interpreter','none');                
            end
            ylabel(num2str(ind(end-i-(rankfirst-2))),'rotation',0,'fontsize',8,'FontWeight','bold');
            %rasters
%             subplot(rows,cols,rast_num(i),'v6');
            subplot(rows,cols,rast_num(i,:),'align');
            hold on;
            a=0;
            eval(['spikes1 = active_cluster.stim{' num2str(st) '};'])
            for ii=1:size(spikes1,1)
                %%
%                 if strcmp(which_case,'all')
%                     if stimulus(st).isprobe(ii)
%                         if stimulus(st).isprobe_ok(ii)
%                             colo = 'r';
%                         else
%                             colo = 'k';
%                         end
%                         line([0 0],[a a-lineheight],'color',colo,'linewidth',2);
%                     else
%                         colo = 'b';
%                     end
%                 else
%                     colo = 'b';
%                 end                
                t = spikes1(ii,spikes1(ii,:)~=10000);
                if ~isempty(t)
                    for j=1:length(t)
                        line([t(j) t(j)],[a a-lineheight],'color',colo);
                    end
                end
                %%
%                 t = spikes1(ii,spikes1(ii,:)~=10000);
%                 if ~isempty(t)
%                     for j=1:length(t)
%                         line([t(j) t(j)],[a a-0.3]);
%                     end
%                 end
                a=a-linesep;
            end
            set(gca,'YLim',[a 1]);
            set(gca,'XLim',[-time_pre_ms time_pos_ms]);  
            set(gca,'FontSize',7);
            axis off
            
            %histograms
            subplot(rows,cols,hist_num(i),'align');
            hold on;
            spikes1 = active_cluster.stim{st};
            lst=size(spikes1,1);
            spikes1=sort(spikes1(:));
            spikes1=spikes1(spikes1~=10000);
            if ~isempty(spikes1), 
                [N]=histc(spikes1,-time_pre_ms:100:time_pos_ms);     %2sec post-stimulus
                N = N *10/lst;        % in Hz.
                %bar(X(1:end-1),N(1:end-1),'r');
                bar(-time_pre_ms:100:time_pos_ms,N,'histc');
                aux = max(get(gca,'YLim'));
                limits = max(aux,limits);
            end
            xlim([-time_pre_ms time_pos_ms])                  %2sec post-stimulus
            if (i>9)&&(i<=max_stims)
                set(gca,'fontsize',7);
                set(gca,'xtick',[-time_pre_ms 0 time_pos_ms/2 time_pos_ms]);
            else
                axis off
            end
            box off
        end
        
%         for i =1:max_stims
        for i =1:min(ranklast-rankfirst+1+1,max_stims)            
            subplot(rows,cols,hist_num(i),'align');
            if limits~=0,
                set(gca,'YLim',[0 limits]);
                line([0 0],[0 limits],'linestyle',':')
                line([1000 1000],[0 limits],'linestyle',':')       %%%%%%%%%%%%%%%%%%%%%%
            end
        end
        
        % Histogram plot
        %accessory calculations
        fr_sd=std(fr_sorted);
        baseline_sd=std(baseline);
        norm_rand=random('Normal',mean(baseline),baseline_sd,lstim,1);
        norm_rand_0=random('Normal',0,baseline_sd,lstim,1);
        [sorted_norm_rand_0 ind2]=sort(norm_rand_0);
        base  = mean(baseline);
        base4 = mean(baseline) + 5 * std(baseline);
        base4neg = mean(baseline) - 2 * std(baseline);
        subplot(4,6,19:23,'align');
        %bar(fr);
        bar(fr_sorted(end:-1:1)-mean(baseline));
        hold on
        plot([1:lstim],sorted_norm_rand_0(end:-1:1),'r-','LineWidth',2)
        xlim([0.5 length(stimulus)+0.5]);set(gca,'xgrid','on');
        %line([1 lstim],[base base],'color','r')
        %line([1 lstim],[base4 base4],'color',[.5 .5 .5])
        %line([1 lstim],[base4neg base4neg],'color',[.5 .5 .5])
        line([1 lstim],[5 * std(baseline) 5 * std(baseline)],'color',[.5 .5 .5])
        subplot(4,6,24,'align');
        

        if icl==size(clusters_to_plot,1),
            q=load(sprintf('NSX%d_spikes.mat',ch));
            q.sp=-q.spikes;
            spklen=size(q.sp,2);
            %plot(1:spklen,t,'b');
            hold on; plot(mean(q.sp),'k');
            plot(mean(t)+std(q.sp),'k');
            plot(mean(q.sp)-std(q.sp),'k');
            ns=size(q.sp,1);
        else
            %q=load(sprintf('times_CSC%d.mat',ch));
            q=load(sprintf('times_NSX%d%s',ch,'.mat'));
            q.sp=-q.spikes(q.cluster_class(:,1)==icl,:);
            %plot(q.sp','color',col(icl));
            hold on; plot(mean(q.sp),'color',col(icl));
            plot(mean(q.sp)+std(q.sp),'color',col(icl));
            plot(mean(q.sp)-std(q.sp),'color',col(icl));
            ns=sum(q.cluster_class(:,1)==icl);
        end
        xlim([1 64]);
%         title(num2str(ns),'fontsize',8,'FontWeight','bold');
        handle=title(num2str(ns),'fontsize',8,'FontWeight','bold');

        set(gca,'xtick',[5 20 62],'xticklabel',{'-0.5','0','1.4'},'fontsize',8);
        ylim_max=max(max(mean(q.sp)+std(q.sp)),max(mean(q.sp)-std(q.sp)))+25;
        ylim_min=min(min(mean(q.sp)+std(q.sp)),min(mean(q.sp)-std(q.sp)))-25;
        try
            ylim([ylim_min ylim_max])
        catch
            disp('problem with ylim')
        end
        v=get(handle,'Position');
        set(handle,'Position',[v(1) 0.8*v(2) v(3)]);

        clear q
        %set(gca,'xtick',[1 20 64],'xticklabel',{'-0.7','0','1.6'},'fontsize',8);
        %        print(gcf,'-djpeg',sprintf('best_resp_ch%2d_%s',ch,clusters_to_plot(icl,:)));
%          if (nargin < 3)
%              print(gcf,'-dpng',sprintf('prof_best_resp_ch%2d_%s',ch,clusters_to_plot(icl,:)));
%          else

%         if ~exist('phase','var') || isempty(phase),
%             print(gcf,'-dpng',sprintf('prof_resp_ch%2d_%s_rank%2d_to_%2d_%s',ch,clusters_to_plot(icl,:),rankfirst,ranklast,which_case));
%         else
%             print(gcf,'-dpng',sprintf('prof_resp_ch%2d_%s_rank%2d_to_%2d_%s',ch,clusters_to_plot(icl,:),rankfirst,ranklast,phase));
%         end
        print(gcf,'-dpng',sprintf('prof_resp_ch%2d_%s_rank%2d_to_%2d_%s_%s.png',ch,clusters_to_plot(icl,:),rankfirst,ranklast,exp_type,phase));        
%         end 
     end
end
close(12345);
warning on