function [spontaneousEvents]= markEventsGUI(params,recfiles,ss,es,events_samples,tagsNeeded,directories)

%% Read the NC5 file from the channel & the NSx file

cd(directories.PFC)
signal = read_NC5(recfiles,ss,es);

cd(directories.PFC)
load('NSx_TimeStamps.mat')

ssmics = (ss/30)*1000;
esmics = (es/30)*1000;

a = find(TimeStamps>=double(ssmics)&TimeStamps<=double(esmics));

TimeStamps = TimeStamps(a(1):a(end));

cd(directories.taskdir);

% Define colours

colors = [1.0000         0         0
    0.0345    0.5862         0
    1.0000    0.1034    0.7241
         0    0.3448         0
    0.5172    0.5172    1.0000
    0.6207    0.3103    0.2759
         0    1.0000    0.7586
         0    0.5172    0.5862
    0.5862    0.8276    0.3103
    0.9655    0.6207    0.8621
    0.9655    0.0690    0.3793
    0.5517    0.6552    0.4828
    0.9655    0.5172    0.0345
    0.5172    0.4483         0
    0.6207    0.7586    1.0000
    0.4483    0.3793    0.4828
    0.6207         0         0
    0.0690    0.6552    0.3793
    0.8276    0.6552    0.6552
    0.8276    0.3103    0.5172
    0.4138         0    0.7586
    0.1724    0.3793    0.2759
         0    0.5862    0.9655
    0.0345    0.2414    0.3103
    0.6552    0.3448    0.0345
    0.4483    0.3793    0.2414
         0    1.0000         0];

%% Run the conditions and integrate the GUI in there

for i = 1:4
for j = 1:length(events_samples.beginObs{i})
    
    events = [];
    
    % Get the times and convert them to 1kHz microseconds
    
    events = [events; double(cell2mat(1)) double(cell2mat(events_samples.beginObs{i}(j))/30)*1000];
    events = [events; double(cell2mat(2)) double(cell2mat(events_samples.stimON{i}(j))/30)*1000];
    events = [events; double(cell2mat(3)) double(cell2mat(events_samples.maskON{i}(j))/30)*1000];
    events = [events; double(cell2mat(4)) double(cell2mat(events_samples.endObs{i}(j))/30)*1000];
    
    % Extract trial and write the temporary NC5 file
    
    TimeStamps2 = TimeStamps;
    trial = signal(events(1,2)/1000:events(4,2)/1000)*4;
    inds(1) = find(TimeStamps2==(events(1,2)));
    inds(2) = find(TimeStamps2==(events(4,2)));
    TimeStamps = TimeStamps2(inds(1):inds(2));
    lts = length(TimeStamps);
    save('NSx_TimeStamps.mat','TimeStamps','lts','sr','nchan','-v7.3');
    fid = fopen(['NSX130.NC5'],'w');
    fwrite(fid,trial,'int16');
    fclose(fid);
    session = tagsNeeded{1};
    times_audio = events(:,2);
    save('finalevents_audio.mat','events','times_audio','session','colors','-v7.3');
    av_gui
    load('finalevents_audio.mat');
    events(:,2) = (events(:,2)*(params.fs/1000))/1000;
    spontaneousEvents{i}{j} = events;
    
end
end


