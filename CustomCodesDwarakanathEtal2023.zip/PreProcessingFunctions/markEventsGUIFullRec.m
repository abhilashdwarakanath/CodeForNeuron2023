function markEventsGUIFullRec(params,events_samples,tagsNeeded,directories)

% Abhilash D. MPIBC 2016/17 for Fanis AG.

%% Load stuff and check stuff
cd(directories.taskdirPFC)
load('NSx_TimeStamps.mat')
% if sr < params.fs
%     cd(directories.taskdir)
%     copyfile([directories.PFC '\NSx_TimeStamps.mat'],'NSx_TimeStamps.mat');
% else
%     TimeStamps = TimeStamps/30;
%     lts = ceil(ltr/30);
%     sr = sr/30;
%     save('NSx_TimeStamps.mat','TimeStamps','lts','sr','nchan','v7.3');
% end

%% Colours lol

% Define colours

colors = [1.0000         0         0
    0.0345    0.5862         0
    1.0000    0.1034    0.7241
         0    0.3448         0
    0.5172    0.5172    1.0000
    0.6207    0.3103    0.2759
         0    1.0000    0.7586
         0    0.5172    0.5862
    0.5862    0.8276    0.3103
    0.9655    0.6207    0.8621
    0.9655    0.0690    0.3793
    0.5517    0.6552    0.4828
    0.9655    0.5172    0.0345
    0.5172    0.4483         0
    0.6207    0.7586    1.0000
    0.4483    0.3793    0.4828
    0.6207         0         0
    0.0690    0.6552    0.3793
    0.8276    0.6552    0.6552
    0.8276    0.3103    0.5172
    0.4138         0    0.7586
    0.1724    0.3793    0.2759
         0    0.5862    0.9655
    0.0345    0.2414    0.3103
    0.6552    0.3448    0.0345
    0.4483    0.3793    0.2414
         0    1.0000         0];
     
%% Create events structure

events = [];
            for i = 1:8
                if i <=4 % check if BR
                    for j = 1:length(events_samples.beginObs{i})
                        events = [events; 1 double((events_samples.beginObs{i}{j}(1)/30)*1000)];
                        events = [events; 2 double((events_samples.stimON{i}{j}(1)/30)*1000)];
                        events = [events; 3 double((events_samples.maskON{i}{j}(1)/30)*1000)];
                        events = [events; 4 double((events_samples.endObs{i}{j}(1)/30)*1000)];
                    end
                elseif mod(i,2)~=0 % Check if 90start (in reality 270)
                    for j = 1:length(events_samples.beginObs{i})
                        events = [events; 1 double((events_samples.beginObs{i}{j}(1)/30)*1000)];
                        events = [events; 2 double((events_samples.stimON{i}{j}(1)/30)*1000)];
                        for masks = 1:length(events_samples.maskON{i}{j})
                            if masks == 1
                                events = [events; 3 double((events_samples.maskON{i}{j}(1)/30)*1000)];
                            elseif mod(masks,2)==0 % starting with 90, alternate would be 90
                                events = [events; 6 double((events_samples.maskON{i}{j}(masks)/30)*1000)];
                            elseif mod(masks,2)~=0
                                events = [events; 5 double((events_samples.maskON{i}{j}(masks)/30)*1000)];
                            end
                        end
                        events = [events; 4 double((events_samples.endObs{i}{j}(1)/30)*1000)];
                    end
                elseif mod(i,2)==0 % Start with 270 (in reality 90)
                    for j = 1:length(events_samples.beginObs{i})
                        events = [events; 1 double((events_samples.beginObs{i}{j}(1)/30)*1000)];
                        events = [events; 2 double((events_samples.stimON{i}{j}(1)/30)*1000)];
                        for masks = 1:length(events_samples.maskON{i}{j})
                            if masks == 1
                                events = [events; 3 double((events_samples.maskON{i}{j}(1)/30)*1000)];
                            elseif mod(masks,2)==0 % Starting with 270, every alternate would be 270
                                events = [events; 5 double((events_samples.maskON{i}{j}(masks)/30)*1000)];
                            elseif mod(masks,2)~=0
                                events = [events; 6 double((events_samples.maskON{i}{j}(masks)/30)*1000)];
                            end
                        end
                        events = [events; 4 double((events_samples.endObs{i}{j}(1)/30)*1000)];
                    end
                end
            end

[~,idx] = sort(events(:,2)); % Sort the times in ascending order so automatically all trials will be sorted by presentation time
events(:,1) = events(idx,1);
events(:,2) = events(idx,2);

trlCount = 0;

for nEvts = 1:size(events,1)
    if events(nEvts,1) == 1
        trlCount = trlCount+1;
        events(nEvts,1) = trlCount+1000;
    end
end

times_audio = events(:,2);

%% Save the events file

session = tagsNeeded(1);
cd(directories.taskdirPFC)
save('finalevents_audio.mat','events','times_audio','session','colors','-v7.3');

%% start the GUI
cd(directories.taskdirPFC)
av_gui