function check_lfp_power_NSX_parall(channels,limsy,notchfilter,show_img)
close all
tic
out = cell(length(channels),1);
chs_harm = cell(length(channels),1);
chnum = zeros(size(channels));
direc_resus = pwd;
switch notchfilter
    case 0
        resus_folder = direc_resus(find(direc_resus==filesep,1,'last')+1:end);
        if ~exist(fullfile(direc_resus,'harmons_per_channel.mat'),'file'), 
            %save(fullfile(direc_resus,'harmons_per_channel'),'resus_folder');
        else
            %save(fullfile(direc_resus,'harmons_per_channel'),'resus_folder','-append');
        end
    case 1
        if ~exist(fullfile(direc_resus,'harmons_per_channel.mat'),'file')
            disp('harmons_per_channel.mat cannot be found. You should run first the code with parameter notch = 0 so it can compute the potential notch frequencies')
            return
        end
    otherwise
        disp('check notch value')
end
% mpz=matlabpool('size');
% if mpz == 0
%     matlabpool open     % to start the pooling engine for parallel processing
% end
% try
%     parfor i = 1:length(channels)
%         [out{i},chs_harm{i},chnum(i)] = check_lfp_power_NSX(channels(i),limsy,notchfilter,1,1);
%     end;
%     if mpz == 0
%        matlabpool close
%     end
%     disp('computations DONE. creating figures ...\n')
%     for k=1:length(out)
%         if notchfilter==0
%             eval(['channel_' num2str(chnum(k)) ' = chs_harm{k};']);
%             save(fullfile(direc_resus,'harmons_per_channel'),eval(['''channel_' num2str(chnum(k)) '''']),'-append')
%         end
%         figFileName=[out{k},'.fig'];
% %         hand = open(figFileName);
%         if show_img==0
%             hand = openfig(figFileName,'reuse','invisible');
%         else
%             hand = openfig(figFileName,'reuse'); 
%         end
%         if exist('Maximize_pure','file')==2
%             set(gcf, 'PaperUnits', 'inches', 'PaperType', 'A4', 'PaperPositionMode', 'auto');
%             Maximize_pure(hand)
%         else
%             set(gcf,'papertype','usletter','paperorientation','portrait','paperunits','inches','paperposition',[.25 .25 10.5 7.8])
%         end
% %         if show_img==0
% %             set(hand, 'Visible', 'off') 
% %         end
%         printFileName=[out{k},'.png'];
%         print('-dpng',printFileName)
%         delete(figFileName);
%         close(hand)
%     end
%     toc
% catch
%     if mpz == 0
%        matlabpool close
%     end
%     rethrow(lasterror)

    for i = 1:length(channels)
        [out{i},chs_harm{i},chnum(i)] = check_lfp_power_NSX(channels(i),limsy,notchfilter,1,1);
    end;

    disp('computations DONE. creating figures ...\n')
    for k=1:length(out)
        if notchfilter==0
            eval(['channel_' num2str(chnum(k)) ' = chs_harm{k};']);
%            save(fullfile(direc_resus,'harmons_per_channel'),eval(['''channel_' num2str(chnum(k)) '''']),'-append')
        end
        figFileName=[out{k},'.fig'];
%         hand = open(figFileName);
        if show_img==0
            hand = openfig(figFileName,'reuse','invisible');
        else
            hand = openfig(figFileName,'reuse'); 
        end
        % Abhi's edit to stop it from crying over figure handles
%         if exist('Maximize_pure','file')==2
%             set(gcf, 'PaperUnits', 'inches', 'PaperType', 'A4', 'PaperPositionMode', 'auto');
%             Maximize_pure(hand)
%         else
%             set(gcf,'papertype','usletter','paperorientation','portrait','paperunits','inches','paperposition',[.25 .25 10.5 7.8])
%         end
%         if show_img==0
%             set(hand, 'Visible', 'off') 
%         end
        printFileName=[out{k},'.png'];
        print('-dpng',printFileName)
        delete(figFileName);
        close(hand)
    end
    toc

end
