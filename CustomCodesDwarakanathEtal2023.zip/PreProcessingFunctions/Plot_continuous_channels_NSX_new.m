function [outfile,title_out,outdata,eje] = Plot_continuous_channels_NSX_new(params,channels,notchfilter,parall,auto,tmin,rec_length,do_spec_diff)
% Plots the continuous data and does a first detection of spikes for each
% channel. 
% HGR FEB 2013
% notchfilter indicates if the cascade of notches will be passed to the
% data before detection. If set to 1, it needs "check_lfp_power_NSX" to be
% run first (so that the notch frequencies can be computed)
% auto = 1 for automatic limits in the y asis
% tmin (starting delay in secs)
% rec_length (length of the signal to be plotted in secs)
% If the channels are arranged in a 2 by n matrix, it uses the signals from
% the difference between the channels on each column. If it is a row vector it
% uses the signals from the individual channels. do_spec_diff = 1 will also
% plot the power spectrum of the differential signal

% tic
if ~exist('parall','var'),     parall = 1; end
if ~exist('do_spec_diff','var'),     do_spec_diff = 0; end
if ~exist('notchfilter','var'),     notchfilter = 0; end
if ~exist('auto','var'),     auto = 0; end
if ~exist('tmin','var'),     tmin = 1; end  %start ploting at tmin secs
if ~exist('rec_length','var'),     rec_length = 10; end      %seconds to plot for each channel
whichtype = 'spk';
% whichtype = 'lfp';

if strcmp(whichtype,'lfp')
    handles.par.detect_fmin = 0.1;
    handles.par.detect_fmax = 250;
    auto = 1;
elseif strcmp(whichtype,'spk')
    handles.par.detect_fmin = 250;
    handles.par.detect_fmax = 3000;
end

close all
print2file =1;                              %for saving printouts.
% Vmin = 150;
% for_text = 40;
Vmin = 40;
for_text = 10;
dec_plot = 3;                        %decimation factor. Not working properly with dec different from 1
w_pre=20;                       %number of pre-event data points stored
w_post=44;                      %number of post-event data points stored
handles.par.notchfilter = notchfilter;
detect = 'both';              %'pos','neg','both'
%Read TimeStamps
load('NSX_TimeStamps');

if size(channels,1)==2
    diff_chs = 1;
else
    diff_chs = 0;
end
max_subplots = min(8/(diff_chs+1),size(channels,2));

% % if parall==1
% %     deci_plot=5;
% % else
% %     deci_plot=1;
% % end
outdata = [];

%sr and lts read from NSX_TimeStamps
min_ref_per=1.5;                                    %detector dead time (in ms)
handles.par.sr = sr;

% sr_decplot = sr/dec_plot;
% ref = floor(min_ref_per*sr_dec/1000);                  %number of counts corresponding the dead time
ref = floor(min_ref_per*sr/1000);                  %number of counts corresponding the dead time
handles.par.ref = ref;

if lts<sr * tmin
    disp('tmin is smaller than the recording length')
else
    min_record = sr * tmin;
end
max_record = floor(min(lts,min_record + sr * rec_length));
tmax = max_record/sr;

fig_num = ceil(10000*rand(1));

figure(fig_num)
if exist('Maximize_pure','file')==2 && parall~=1
    set(fig_num, 'PaperUnits', 'inches', 'PaperType', 'A4','PaperPositionMode', 'auto', 'Visible', 'off') 
    %Maximize_pure(fig_num)    
else
    set(gcf,'papertype','usletter','paperorientation','portrait','paperunits','inches')
    set(gcf,'paperposition',[.25 .25 10.5 7.8])
end
direc_resus_base = pwd;
disp([direc_resus_base(find(direc_resus_base==filesep,1,'last')+1:end) '_notch' num2str(notchfilter)]);
    
if exist('sites.mat','file')
    load('sites.mat')
end

cont=1; cont1=0;
factor_thr=5;
% set(0, 'currentfigure', f);  %# for figures
% set(f, 'currentaxes', axs);  %# for axes with handle axs on figure f
clf(fig_num)
ch = [];
for k= 1:size(channels,2)
    % LOAD NSX DATA
    channel1=channels(1,k);
    ch = [ch channel1];
    filename1=sprintf('NSX%d.NC5',channel1);
    Samples = read_NC5(filename1,min_record,max_record);
    if diff_chs
        channel2=channels(2,k);
        ch = [ch channel2];        
        filename2=sprintf('NSX%d.NC5',channel2);
        Samples2 = read_NC5(filename2,min_record,max_record);
    end
%                 figure(1)
%                 Maximize_pure(1)
%                 do_power(Samples,sr,3000,'b',1)
    if(handles.par.notchfilter~=0)
        [Samples,cant_notches1l,cant_notches1h,~,~] = mete_notches(Samples,sr,channel1,handles.par.detect_fmin,direc_resus_base); 
%             hold on
%             do_power(Samples,sr,3000,'r',0)
    end
%             xlim([0 3000])
%             ylim([-20 40])
%             grid minor
%             close(1)
    if diff_chs
        if(handles.par.notchfilter~=0)
            [Samples2,cant_notches2l,cant_notches2h,~,~] = mete_notches(Samples2,sr,channel2,handles.par.detect_fmin,direc_resus_base);        
        end
        Samples = Samples - Samples2;
        if do_spec_diff
            figure(2)
            set(gcf,'Color',[1 1 1])        
            set(gcf, 'PaperPositionMode', 'auto');
%             if exist('Maximize_pure','file')
%             Maximize_pure(2);
%             end
            do_power(Samples,sr,3000,'b',1)
            xlim([0 3000])
%             ylim([-20 40])
            ylim([-40 40])
            grid minor
            if exist('spectra','dir')
                saveas(2,['spectra\spectrum_ch' num2str(channel1) '-ch' num2str(channel2) '_withnotches' num2str(notchfilter)],'png');
            else
                saveas(2,['spectrum_ch' num2str(channel1) '-ch' num2str(channel2) '_withnotches' num2str(notchfilter)],'png');
            end
            close(2)
        end
    end
        
    % HIGH-PASS FILTER OF THE DATA
    % Abhi'S edit - Using the same filter here as I use in my getSpikes.m
    %[b,a]=ellip(2,0.1,40,[handles.par.detect_fmin handles.par.detect_fmax]*2/(sr));
    [~,Wp] = cheb1ord(params.passband,params.stopband,params.passripple,params.stopatten);
    [b,a] = cheby1(params.filterorder,params.passripple,Wp);
    xd=filtfilt(b,a,Samples);
%     xd = xf(1:dec:end);
%     xd = xf;
%     clear Samples xf;
    clear Samples;
    
    % GET THRESHOLD AND NUMBER OF SPIKES BETWEEN 0 AND TMAX
    thr = factor_thr * median(abs(xd))/0.6745;
    thrmax = 10 * thr;     %thrmax for artifact removal is based on sorted settings.
    
    nspk = 0;
    xaux = find((abs(xd(w_pre+2:end-w_post-2)) > abs(thr)) & (abs(xd(w_pre+2:end-w_post-2)) < abs(thrmax))) +w_pre+1;
    
%     xaux0 = 0;
%     for i=1:length(xaux)
%         if xaux(i) >= xaux0 + ref
%             [maxi iaux]=max(abs(xd(xaux(i):xaux(i)+floor(ref/2)-1)));    %introduces alignment
%             nspk = nspk + 1;
%             index(nspk) = iaux + xaux(i) -1;
%             xaux0 = index(nspk);
%         end
%     end  
    
    nspk=nnz(diff(xaux)>ref)+1;
   
    % MAKES PLOT
    subplot(max_subplots,1,cont)
    box off; hold on
    Vlim = Vmin;
    xd=xd(1:dec_plot:end);
    eje = linspace(tmin,tmax,length(xd));
    if parall==1
        outdata = [outdata ; xd];
        line(eje,xd) % Abhi's edit
    else
        line(eje,xd)
    end
    switch detect
        case 'pos'
            line([tmin tmax],[thr thr],'color','r')
            if ~auto
                ylim([-Vlim 2*Vlim])
            end
        case 'neg'
            line([tmin tmax],[-thr -thr],'color','r')
            if ~auto
                ylim([-2*Vlim Vlim])
            end
        case 'both'
            line([tmin tmax],[thr thr],'color','r')
            line([tmin tmax],[-thr -thr],'color','r')
            if ~auto
                ylim([-2*Vlim 2*Vlim])
            end
    end
    if diff_chs
        ylabel(['Ch.' num2str(channel1) ' - Ch.' num2str(channel2)])
    else
        ylabel(['Ch.' num2str(channel1)])        
    end    
    cont=cont+1;
    if (nspk > ceil(rec_length/20) && nspk < rec_length * 60) ;
        if diff_chs
            ylabel(['Ch.' num2str(channel1) ' - Ch.' num2str(channel2)],'fontsize',10,'fontweight','bold')
        else
            ylabel(['Ch.' num2str(channel1)],'fontsize',10,'fontweight','bold')
        end
    end
    if notchfilter==0
        text((tmax-tmin)/2+tmin+5,for_text+max(ylim),[num2str(nspk) '  spikes.'],'fontsize',10)
%         text((tmax-tmin)/2+tmin+5,for_text+max(ylim),[num2str(nspk) '  spikes orig.' num2str(nspk2) '  spikes new.'],'fontsize',10)
    elseif ~exist('cant_notches2','var') 
        text((tmax-tmin)/3+tmin,for_text+max(ylim),[num2str(nspk) '  spikes. ' num2str(cant_notches1l) ' and ' num2str(cant_notches1h) ' notches applied below and above ' num2str(handles.par.detect_fmin) ' Hz'],'fontsize',10)
    else
        text((tmax-tmin)/3+tmin,for_text+max(ylim),[num2str(nspk) '  spikes. ' num2str(cant_notches1l) ' and ' num2str(cant_notches1h) ' notches applied below and above ' num2str(handles.par.detect_fmin) ' Hz in Ch ' num2str(channel1) '. ' num2str(cant_notches2l) ' and ' num2str(cant_notches2h) ' notches applied below and above ' num2str(handles.par.detect_fmin) ' Hz in Ch ' num2str(channel2)],'fontsize',10)
    end
    set(gca,'Xlim',[tmin tmax],'Xtick',linspace(tmin,tmax,7))
    if(~mod(cont-1,max_subplots))
        cont=1;
        cont1=cont1+1;
        if exist('sites','var') && sum(diff(ceil(ch/8)))==0
            macro = sites(ceil(ch(1)/8),:);
            disp([macro ' - ' num2str(ch)]);
            title_out = [pwd '.     ' macro '.        fmin = ' num2str(handles.par.detect_fmin) '. fmax = ' num2str(handles.par.detect_fmax)];
        else
            disp(num2str(ch));
            title_out = [pwd '.        fmin = ' num2str(handles.par.detect_fmin) '. fmax = ' num2str(handles.par.detect_fmax)];
        end   
        mtit(title_out,'fontsize',10,'interpreter','none','xoff',0,'yoff',0.025);

        if print2file==1;
            if exist('sites','var') && sum(diff(ceil(ch/8)))==0                               
%                 outfile=sprintf('%s_%s','fig2print_KCLmacro',macro);
                outfile=sprintf('%s_%s_withnotches%d_diffchs%d_%s','fig2print_KCLmacro',macro,notchfilter,diff_chs,whichtype);
            else
%                 outfile=sprintf('%s_%s','fig2print_KCLmacro',num2str(cont1));
                outfile=sprintf('%s_%s_withnotches%d_diffchs%d_%s','fig2print_KCLmacro',num2str(cont1),notchfilter,diff_chs,whichtype);
            end
%             saveas(fig_num,fullfile(pwd,[outfile '_withnotches' num2str(notchfilter) '_diffchs' num2str(diff_chs)]),'png');
            if parall==1
                saveas(fig_num,fullfile(pwd,outfile),'fig');
            else
                saveas(fig_num,fullfile(pwd,outfile),'png');
            end
        end
        ch = [];
        clf
    end
    clear xd;    
end
close(fig_num)
% toc

function do_power(lfp_orig,sr_orig,fmaxplot,color,with_thr)
span_smooth = 21;       %in Hz it is span_smooth*sr_orig/(number of FFT points)
fsplit_thr = 90;
db_thr = 2.5;
Ntot_orig=length(lfp_orig);
para_largo = ceil(log(sr_orig)/log(2))+1;   %resol aprox de 0.5 hz (con rectangular, resuelve hasta 0.88*sr/N). con wintool, el ancho que aparece es igual a (sr*K/L)/(fs/2), siendo K la constante de proporcionalida que cambia con la ventana
N = 2^para_largo;  
M = floor(Ntot_orig/N);
n=N;
fx_one=0:sr_orig/n:fmaxplot*1.05;

Xbarhan_orig_one = zeros(1,n/2+1);
for jj=1:M
    [Pbarhan_one] = periodogram(lfp_orig((jj-1)*N+1:jj*N),barthannwin(N),'onesided',n,sr_orig); % K aprox 1.375
    Xbarhan_orig_one = Xbarhan_orig_one + Pbarhan_one';
end    
Pbarhan_new = Xbarhan_orig_one(1:length(fx_one))/M;
plot(fx_one,10*log10(Pbarhan_new),color,'LineWidth',1.5);

fini=2;
fmid=300;
power_fit = log10(Pbarhan_new(find(fx_one>fini,1):find(fx_one>fmid,1)));
freqs_fit = log10(fx_one(find(fx_one>fini,1):find(fx_one>fmid,1)));

p_all1 = polyfit(freqs_fit,power_fit,1);
k1=p_all1(1);
loga=p_all1(2);
model = k1*freqs_fit+loga;
[r2_all1 ~] = rsquare(power_fit,model);

fend=3000;
power_fit = log10(Pbarhan_new(find(fx_one>fmid,1):find(fx_one>fend,1)));
freqs_fit = log10(fx_one(find(fx_one>fmid,1):find(fx_one>fend,1)));

p_all2 = polyfit(freqs_fit,power_fit,1);
k2=p_all2(1);
loga=p_all2(2);
model = k2*freqs_fit+loga;
[r2_all2 ~] = rsquare(power_fit,model); 

% grid minor
xlabel('Frequency (Hz)','fontsize',12)
ylabel('Power Spectrum (dB/Hz)','fontsize',12)
set(gca,'fontsize',12)

annotation(gcf,'textbox',[0.73 0.7 0.1 0.1],'String',{'Power fit (1st order loglog)',[num2str(fini) '-' num2str(fmid) ' Hz: \alpha = ' num2str(k1,'%1.2f') ' (r^2 = ' num2str(r2_all1,'%1.2f') ')'],[num2str(fmid) '-' num2str(fend) ' Hz: \alpha = ' num2str(k2,'%1.2f') ' (r^2 = ' num2str(r2_all2,'%1.2f') ')']},'FontSize',12,'BackgroundColor',[1 1 1]);
       
if with_thr
    fx_inds_split = find(fx_one<fsplit_thr,1,'last');
    Pbarhan_slideavg = smooth(Pbarhan_new,span_smooth,'rloess')';
    Pbarhan_slideavg = [smooth(Pbarhan_new(1:fx_inds_split),span_smooth,'rloess')' Pbarhan_slideavg(fx_inds_split+1:end)];
    Pbarhan_thr = 10*log10(Pbarhan_slideavg)+db_thr;
    hold on
    plot(fx_one,Pbarhan_thr,'g','LineWidth',1.5)
end
titletext = ['Spectrum from ' num2str(M) ' averaged periodograms of length ' num2str(N) ', bartlett-hanning window. sr original = ' num2str(round(sr_orig)) ' Hz'];
title(titletext,'fontsize',12);   
    