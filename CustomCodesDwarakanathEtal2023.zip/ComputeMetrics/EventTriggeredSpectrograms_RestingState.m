clear all
clc
close all

% This is a script to get the event triggered traces in the resting state
% data

%% Load data

cd B:\H07\07-04-2016\PFC
%cd B:\A11\06-04-2016\PFC
load LFPPFC.mat

%% Setup filters and buffer

[b1,a1] = cheby1(4,0.001,[1 9]/250);
[b2,a2] = cheby1(4,0.001,[20 40]/250);
buffer = 175;
nEvents = 5;
evtDur = 250;
fs = 500;

%% Compute the events and choose 10 events at random from each channel otherwise its way too many to compute

evtTriggeredTraces = [];
betaTraces = [];
lowTraces = [];
lowHilbert = [];
betaHilbert = [];
parfor i = 1:96
    tic;
    lowInstAmp = abs(hilbert(filtfilt(b1,a1,LFP.data(i,:))));
    lfpevents = event_detection(lowInstAmp',4,'stdgauss',evtDur);
    
    if length(lfpevents) > nEvents
        
        randEvents = randsample(length(lfpevents),nEvents);
        randEvents = sort(randEvents);
        events = lfpevents(randEvents);
    end
    
    for iEvt = 1:length(events)
        if events(iEvt) > buffer+250 && events(iEvt) < length(LFP.data(i,:))-(buffer+250)
            
            temp = detrend(LFP.data(i,events(iEvt)-(buffer+250):events(iEvt)+buffer+250));
            
            betaTemp = filtfilt(b2,a2,temp);
            betaHilbertTemp = abs(hilbert(betaTemp));
            betaHilbertTemp = betaHilbertTemp(251:end-250);
            betaTemp = betaTemp(251:end-250);
            betaTraces = [betaTraces; betaTemp];
            betaHilbert = [betaHilbert; betaHilbertTemp];
            
            lowTemp = filtfilt(b1,a1,temp);
            lowHilbertTemp = abs(hilbert(lowTemp));
            lowHilbertTemp = lowHilbertTemp(251:end-250);
            lowTemp = lowTemp(251:end-250);
            lowTraces = [lowTraces; lowTemp];
            lowHilbert = [lowHilbert; lowHilbertTemp];
            evtTriggeredTraces = [evtTriggeredTraces;temp];
        end
    end
    toc
end

clear temp;

%% Calculate the spectrograms

parfor iTrace = 1:size(evtTriggeredTraces,1)
    tic;
    [temp, ~] = cwt(evtTriggeredTraces(iTrace,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]);
    evtTriggeredCwt(:,:,iTrace) = abs(temp.^2);
    evtTriggeredCwt_norm1(:,:,iTrace) = zscore(evtTriggeredCwt(:,:,iTrace),[],1);
    evtTriggeredCwt_norm2(:,:,iTrace) = zscore(evtTriggeredCwt(:,:,iTrace),[],2);
    toc;
end

% Just to get the f because the parfor loop doesn't return it

[~, f] = cwt(evtTriggeredTraces(1,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]);

%% Plot

rawMeanSpecgram = nanmean(evtTriggeredCwt,3);
norm1_MeanSpecgram = nanmean(evtTriggeredCwt_norm1,3);
norm2_MeanSpecgram = nanmean(evtTriggeredCwt_norm2,3);

Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
t = linspace(-buffer/fs,(buffer/fs),(2*buffer)+1);

imagesc(t,log2(f),nanmean(evtTriggeredSpecgrams,3))
xlabel('time in s');
ylabel('Hz')
vline(0,'--w'); AX = gca;
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
AX.YLim = log2([min(f), max(f)]);
axis xy
colormap jet
AX.CLim = [0 0.4];

cd B:\Results\RestingState\H07
%mkdir Spectrograms
cd Spectrograms
saveas(gcf,'Spectrograms','fig')
close all

%% Plot the event triggered instantaneous amplitudes

%%% NORMALISE EACH TRACE IN A LOOP AND THEN COMPUTE THE MEAN AND SEM. %%%

for iTrace = 1:size(betaHilbert,1)
    
    betaHilbert(iTrace,:) = normalise(betaHilbert(iTrace,:));
    lowHilbert(iTrace,:) = normalise(lowHilbert(iTrace,:));
    
end

betaMean = nanmean(betaHilbert,1);
lowMean = nanmean(lowHilbert,1);

betaStd = nanstd(betaHilbert,[],1)./sqrt(length(t));
lowStd = nanstd(lowHilbert,[],1)./sqrt(length(t));

figure
H(1)=shadedErrorBar(t,(lowMean),(lowStd));
hold on
P(1)=plot(t,(lowMean),'-r','LineWidth',2);
H(2)=shadedErrorBar(t,(betaMean),betaStd);
P(2)=plot(t,(betaMean),'-k','LineWidth',2);
xlabel('time in s')
ylabel('lfp amplitude')
axis tight;
box off; grid on;
vline(0,'--k')
legend([P(1) H(1).patch P(2) H(2).patch], 'RS Low', 'RS Low SEM', 'RS Beta', 'RS Beta SEM', 'Location','SouthEast');
title(['Low event triggered Beta-Low Overlay - Instananeous Amplitude - RS'])
saveas(gcf,'LowvsBeta_MeanAndSEM_Overlay_H07_RS','fig')

close all

plot(t,normalise(betaMean),'-r','LineWidth',2)
hold on
plot(t,normalise(lowMean),'-k','LineWidth',2)
xlabel('time in s')
ylabel('lfp amplitude')
vline(0,'--b')
grid on
box off
axis tight
title('low vs beta - LF event triggered - H07 RS')
saveas(gcf,'LowvsBeta_Mean_Overlay_H07_RS','fig')
%% Create some raw spectrograms

t_period = 3*fs; % in seconds
c = 0;
t_samps = linspace(0,3,t_period);

for iChan = 1:96
    
    %cd B:\Results\RestingState\H07\Spectrograms
    
    chunkStarts = sort(randsample(length(LFP.data(iChan,:)),nEvents));
    
    for iChunk = 1:length(chunkStarts)
        
        if chunkStarts(iChunk) > t_period && chunkStarts(iChunk) < length(LFP.data(iChan,:))-t_period
            
            c = c+1;
            
            lfpChunk = detrend(LFP.data(iChan,chunkStarts(iChunk)+1:chunkStarts(iChunk)+t_period));
            
            [temp, ~] = cwt(detrend(lfpChunk),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]);
            rawTraceCwt(:,:,c) = abs(temp.^2);
            rawTraceCwt_norm1(:,:,c) = zscore(rawTraceCwt(:,:,c),[],1);
            rawTraceCwt_norm2(:,:,c) = zscore(rawTraceCwt(:,:,c),[],2);
            
            % Plot and Save
            
            figure
            %subplot(1,3,1)
%             imagesc(t_samps,log2(f),rawTraceCwt(:,:,c)-mean(mean(rawTraceCwt(:,:,c))))
%             xlabel('time in s');
%             ylabel('Hz')
%             AX = gca;
%             set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
%             AX.YLim = log2([min(f), max(f)]);
%             axis xy
%             colormap jet
%             AX.CLim = [0 250];
%             title(['Raw Chunk Spectrogram. Channel # :' ' ' num2str(iChan) ' ' 'Chunk #' num2str(c)])
            
            %             subplot(1,3,2)
                        imagesc(t_samps,log2(f),rawTraceCwt_norm1(:,:,c))
                        xlabel('time in s');
                        ylabel('Hz')
                         AX = gca;
                        set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
                        AX.YLim = log2([min(f), max(f)]);
                        axis xy
                        colormap jet
                        AX.CLim = [0 3];
                        colorbar
                        title(['Freq Normalised Chunk Spectrogram. Channel # :' ' ' num2str(iChan) ' ' 'Chunk #' num2str(c)])
            %
            %             subplot(1,3,3)
            %             imagesc(t,log2(f),rawTraceCwt_norm2)
            %             xlabel('time in s');
            %             ylabel('Hz')
            %             vline(0,'--w'); AX = gca;
            %             set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
            %             AX.YLim = log2([min(f), max(f)]);
            %             axis xy
            %             colormap jet
            %             AX = gca;
            %             AX.CLim = [0 2];
            %             title(['Time Normalised Chunk Spectrogram. Channel # :' ' ' num2str(iChan) ' ' 'Chunk #' num2str(c)])
            
            saveas(gcf,['FreqN_Spectrograms_LFPChunks_Channel_' num2str(iChan) '_Chunk_' num2str(c)],'png')
            saveas(gcf,['FreqN_Spectrograms_LFPChunks_Channel_' num2str(iChan) '_Chunk_' num2str(c)],'fig')
            
            close all
            
        end
        
    end
    
end
