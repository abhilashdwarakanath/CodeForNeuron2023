function lfpEventStatisticsTbyT(lfpActivity, domdur, sav_dir_psth,expt,filtType)

% Collect event statistics for the four chosen LFP bands
% Abhilash D MPIBC 2017-18

cd(sav_dir_psth)

pad = 500;

filename = ['MMTbyT_std3.5_blpCharacteristics_' num2str(domdur.domBehind) 'ms_Chebyshev1_' filtType '.mat'];

t =linspace(-domdur.domBehind/1000,domdur.domForward/1000,(domdur.domBehind/2)+(domdur.domForward/2)+1);
evtIdx = ceil(domdur.domBehind/2)+1;
midPoint = t(ceil(length(t)/2));
%% Setup filters

if strcmp(filtType,'theta')
    [b,a] = cheby1(4,0.01,[4 8]/250); % Theta
    %[b1,a1] = cheby1(4,6/250,'low');
    evtDur = 50;
elseif strcmp(filtType,'delta')
    [b,a] = cheby1(4,0.01,[1 4]/250); % delta
    %[b1,a1] = cheby1(4,2/250,'low');
    evtDur = 250;
elseif strcmp(filtType,'beta')
    [b,a] = cheby1(8,0.01,[20 40]/250); % beta
    %[b1,a1] = cheby1(4,25/250,'low');
    evtDur = 13;
elseif strcmp(filtType,'gamma')
    [b,a] = cheby1(16,0.01,[125 200]/250); % gamma
    %[b1,a1] = cheby1(4,162/250,'low');
    evtDur = 3;
elseif strcmp(filtType,'low')
    [b,a] = cheby1(4,0.01,[1 9]/250);
    %[b1,a1] = cheby1(4,5/250,'low');
    evtDur = 56;
    elseif strcmp(filtType,'special')
    [b,a] = cheby1(4,0.01,[2 7]/250);
    %[b1,a1] = cheby1(4,5/250,'low');
    evtDur = 150;
end

binWidth = 25;
bins_pre = -500:binWidth:0; 
bins_pre = bins_pre./1000;
bins_post = 0:binWidth:500; 
bins_post = bins_post./1000;

%% Get Doms 90
    
    % BR Dominances
    
    c = 0;
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1}{1, iCond},2)
            c = c+1;
            for iChan = 1:96
                lfppiece = ((((lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond}{nDom}))));
                [val,~] = max(lfppiece);
                if val<=750
                    lfppiece = filtfilt(b,a,lfppiece);
                    lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                    lfpevents = event_detection(detrend(lfppiece),4,'stdgauss',evtDur);
                    lfpevents(lfpevents<=pad) = [];
                    lfpevents(lfpevents>=(length(t)+pad)) = [];
                    lfpevents = lfpevents-pad;
                    lfpTimes = t(lfpevents);
                    if ~isempty(lfpevents)
                        blpCharacteristics.nEventsPerBin_Pre_BR_270TO90(c,iChan,:) = histc(lfpTimes,bins_pre);
                        blpCharacteristics.nEventsPerBin_Post_BR_270TO90(c,iChan,:) = histc(lfpTimes,bins_post);
                    else
                        blpCharacteristics.nEventsPerBin_Pre_BR_270TO90(c,iChan,:) = zeros(1,length(bins_pre));
                        blpCharacteristics.nEventsPerBin_Post_BR_270TO90(c,iChan,:) = zeros(1,length(bins_post));
                    end
                    
                else
                    blpCharacteristics.nEventsPerBin_Pre_BR_270TO90(c,iChan,:) = zeros(1,length(bins_pre));
                    blpCharacteristics.nEventsPerBin_Post_BR_270TO90(c,iChan,:) = zeros(1,length(bins_post));
                end
                
            end
        end
    end
    
    c = 0;
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1}{1, iCond},2)
            c = c+1;
            for iChan = 1:96
                lfppiece = ((((lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond}{nDom}))));
                [val,~] = max(lfppiece);
                if val<=750
                    lfppiece = filtfilt(b,a,lfppiece);
                    lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                    lfpevents = event_detection(detrend(lfppiece),4,'stdgauss',evtDur);
                    lfpevents(lfpevents<=pad) = [];
                    lfpevents(lfpevents>=(length(t)+pad)) = [];
                    lfpevents = lfpevents-pad;
                    lfpTimes = t(lfpevents);
                    if ~isempty(lfpevents)
                        blpCharacteristics.nEventsPerBin_Pre_BR_90TO270(c,iChan,:) = histc(lfpTimes,bins_pre);
                        blpCharacteristics.nEventsPerBin_Post_BR_90TO270(c,iChan,:) = histc(lfpTimes,bins_post);
                    else
                        blpCharacteristics.nEventsPerBin_Pre_BR_90TO270(c,iChan,:) = zeros(1,length(bins_pre));
                        blpCharacteristics.nEventsPerBin_Post_BR_90TO270(c,iChan,:) = zeros(1,length(bins_post));
                    end
                    
                else
                    blpCharacteristics.nEventsPerBin_Pre_BR_90TO270(c,iChan,:) = zeros(1,length(bins_pre));
                    blpCharacteristics.nEventsPerBin_Post_BR_90TO270(c,iChan,:) = zeros(1,length(bins_post));
                end
                
            end
        end
    end
    
    % PA Dominances
    
    c = 0;
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1}{1, iCond},2)
            c = c+1;
            for iChan = 1:96
                lfppiece = ((((lfpActivity.validSection.PA.data.dom90{1, iChan}{1, iCond}{nDom}))));
                [val,~] = max(lfppiece);
                if val<=750
                    lfppiece = filtfilt(b,a,lfppiece);
                    lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                    lfpevents = event_detection(detrend(lfppiece),4,'stdgauss',evtDur);
                    lfpevents(lfpevents<=pad) = [];
                    lfpevents(lfpevents>=(length(t)+pad)) = [];
                    lfpevents = lfpevents-pad;
                    lfpTimes = t(lfpevents);
                    if ~isempty(lfpevents)
                        blpCharacteristics.nEventsPerBin_Pre_PA_270TO90(c,iChan,:) = histc(lfpTimes,bins_pre);
                        blpCharacteristics.nEventsPerBin_Post_PA_270TO90(c,iChan,:) = histc(lfpTimes,bins_post);
                    else
                        blpCharacteristics.nEventsPerBin_Pre_PA_270TO90(c,iChan,:) = zeros(1,length(bins_pre));
                        blpCharacteristics.nEventsPerBin_Post_PA_270TO90(c,iChan,:) = zeros(1,length(bins_post));
                    end
                    
                else
                    blpCharacteristics.nEventsPerBin_Pre_PA_270TO90(c,iChan,:) = zeros(1,length(bins_pre));
                    blpCharacteristics.nEventsPerBin_Post_PA_270TO90(c,iChan,:) = zeros(1,length(bins_post));
                end
                
            end
        end
    end
    
    c = 0;
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1}{1, iCond},2)
            c = c+1;
            for iChan = 1:96
                lfppiece = ((((lfpActivity.validSection.PA.data.dom270{1, iChan}{1, iCond}{nDom}))));
                [val,~] = max(lfppiece);
                if val<=750
                    lfppiece = filtfilt(b,a,lfppiece);
                    lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                    lfpevents = event_detection(detrend(lfppiece),4,'stdgauss',evtDur);
                    lfpevents(lfpevents<=pad) = [];
                    lfpevents(lfpevents>=(length(t)+pad)) = [];
                    lfpevents = lfpevents-pad;
                    lfpTimes = t(lfpevents);
                    if ~isempty(lfpevents)
                        blpCharacteristics.nEventsPerBin_Pre_PA_90TO270(c,iChan,:) = histc(lfpTimes,bins_pre);
                        blpCharacteristics.nEventsPerBin_Post_PA_90TO270(c,iChan,:) = histc(lfpTimes,bins_post);
                    else
                        blpCharacteristics.nEventsPerBin_Pre_PA_90TO270(c,iChan,:) = zeros(1,length(bins_pre));
                        blpCharacteristics.nEventsPerBin_Post_PA_90TO270(c,iChan,:) = zeros(1,length(bins_post));
                    end
                    
                else
                    blpCharacteristics.nEventsPerBin_Pre_PA_90TO270(c,iChan,:) = zeros(1,length(bins_pre));
                    blpCharacteristics.nEventsPerBin_Post_PA_90TO270(c,iChan,:) = zeros(1,length(bins_post));
                end
                
            end
        end
    end
    
    

save(filename,'blpCharacteristics','-v7.3')
