function generateTbyTLFPRateAllChansSanityCheck

dbstop if error

datasets{1} = 'B:\H07\12-06-2016\PFC\Bfsgrad1';
recDate{1} = '12062016';
fileID{1} = '12-06-2016';
subjID{1} = 'Hayo';
datasets{2} = 'B:\H07\13-07-2016\PFC\Bfsgrad1';
recDate{2} = '13072016';
fileID{2} = '13-07-2016';
subjID{2} = 'Hayo';
datasets{3} = 'B:\H07\20161019\PFC\Bfsgrad1';
recDate{3} = '19102016';
fileID{3} = '20161019';
subjID{3} = 'Hayo';
datasets{4} = 'B:\H07\20161025\PFC\Bfsgrad1';
recDate{4} = '25102016';
fileID{4} = '20161025';
subjID{4} = 'Hayo';
datasets{5} = 'B:\A11\20170305\PFC\Bfsgrad1';
recDate{5} = '05032017';
fileID{5} = '20170305';
subjID{5} = 'Anton';
datasets{6} = 'B:\A11\20170302\PFC\Bfsgrad1';
recDate{6} = '02032017';
fileID{6} = '20170302';
subjID{6} = 'Anton';

prefInfoPaths{1} = 'B:\Results\H07\12-06-2016\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{2} = 'B:\Results\H07\13-07-2016\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{3} = 'B:\Results\H07\20161019\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{4} = 'B:\Results\H07\20161025\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{5} = 'B:\Results\A11\20170305\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{6} = 'B:\Results\A11\20170302\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';

%% Load SU Spikes By Time

for iDataset = 1:6
    
    pad = 500;
    
    t = linspace(-1000,1000,2000);
    
    %% Collect clean dominances
    
    durs.switch = 250;
    durs.domForward = 1000;
    durs.domBehind = 1000;
    params.elecs = 96;
    params.conditions = 8;
    
    % Load relevant LFPs and Spikes
    cd(datasets{iDataset})
    
    eventfile = 'finalevents_audio.mat';
    spikeFile = 'jMUSpikesByTime.mat';
    qnxfile = [subjID{iDataset} '_' recDate{iDataset} '_' 'Bfsgrad1' '.dgz'];
    
    load('lfpByTrial.mat')
    load(spikeFile)
    
    fprintf('Processing Dataset %d of : %d \n',iDataset,6)
    
    % Compute Statistics and Spectrograms
    
    sav_dir = [datasets{iDataset} '\EnsemblePSTHs'];
    mkdir(sav_dir)
    if strcmp(subjID{iDataset},'Hayo')==1
        monkID = 'H07';
    else
        monkID = 'A11';
    end
    
    trialInformation = collectTrialInformationHayo(params,qnxfile,eventfile,'pfc','lfp');
    [lfpActivity] = collectCleanDominancesLFPHayo(params,LFP,jMUspikes,durs);
    
    %% Setup filter
    
    [b1,a1] = cheby1(4,0.001,[1 9]/250); % low
    evtDur = 56;
    
    %% Collect BR
    
    tLFP = linspace(-1000,1000,1001);
    
    for iChan = 1:96
        c = 0;
        for iCond = 1:length(lfpActivity.validSection.BR.data.dom90{iChan})
            for iSwitch = 1:length(lfpActivity.validSection.BR.data.dom90{iChan}{iCond})
                c = c+1; clear spikesPiece; clear lowPiece
               
                piece = lfpActivity.validSection.BR.data.dom90{iChan}{iCond}{iSwitch};
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                lfpevents = event_detection(lowPiece,4,'stdgauss',evtDur);
                lfpevents(lfpevents<=pad | lfpevents>=length(tLFP)+pad) = [];
                lfpevents = lfpevents-pad;
                lfpevents = tLFP(lfpevents);
                lfpSwitches.low.BR.s270TO90{iChan}{c} = lfpevents;
            end
        end
    end
    
    for iChan = 1:96
        c = 0;
        for iCond = 1:length(lfpActivity.validSection.BR.data.dom270{iChan})
            for iSwitch = 1:length(lfpActivity.validSection.BR.data.dom270{iChan}{iCond})
                c = c+1; clear spikesPiece; clear lowPiece
               
                piece = lfpActivity.validSection.BR.data.dom270{iChan}{iCond}{iSwitch};
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                lfpevents = event_detection(lowPiece,4,'stdgauss',evtDur);
                lfpevents(lfpevents<=pad | lfpevents>=length(tLFP)+pad) = [];
                lfpevents = lfpevents-pad;
                lfpevents = tLFP(lfpevents);
                lfpSwitches.low.BR.s90TO270{iChan}{c} = lfpevents;
            end
        end
    end
    
    %% Collect PA
    for iChan = 1:96
        c = 0;
        for iCond = 1:length(lfpActivity.validSection.PA.data.dom90{iChan})
            for iSwitch = 1:length(lfpActivity.validSection.PA.data.dom90{iChan}{iCond})
                c = c+1; clear spikesPiece; clear lowPiece
               
                piece = lfpActivity.validSection.PA.data.dom90{iChan}{iCond}{iSwitch};
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                lfpevents = event_detection(lowPiece,4,'stdgauss',evtDur);
                lfpevents(lfpevents<=pad | lfpevents>=length(tLFP)+pad) = [];
                lfpevents = lfpevents-pad;
                lfpevents = tLFP(lfpevents);
                lfpSwitches.low.PA.s270TO90{iChan}{c} = lfpevents;
            end
        end
    end
    
    for iChan = 1:96
        c = 0;
        for iCond = 1:length(lfpActivity.validSection.PA.data.dom270{iChan})
            for iSwitch = 1:length(lfpActivity.validSection.PA.data.dom270{iChan}{iCond})
                c = c+1; clear spikesPiece; clear lowPiece
               
                piece = lfpActivity.validSection.PA.data.dom270{iChan}{iCond}{iSwitch};
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                lfpevents = event_detection(lowPiece,4,'stdgauss',evtDur);
                lfpevents(lfpevents<=pad | lfpevents>=length(tLFP)+pad) = [];
                lfpevents = lfpevents-pad;
                lfpevents = tLFP(lfpevents);
                lfpSwitches.low.PA.s90TO270{iChan}{c} = lfpevents;
            end
        end
    end
    
    %% Process SDFs and LFPs
    
    edges = -1000:50:1000;
    
    %BR
    % Sel 270, 270TO90
    for iSwitch = 1:length(lfpSwitches.low.BR.s270TO90{1})
        c = 0;
        for iChan = 1:96
            c = c+1; clear spikesPiece; clear lowPiece
           
            lowPiece = (lfpSwitches.low.BR.s270TO90{iChan}{iSwitch});
            currChan = iChan;
            
            if ~isempty(lowPiece)
                lowRate_br_s270TO90(iSwitch,iChan,:) = histc(lowPiece,edges);
            else
                lowRate_br_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
            end
            
        end
        
    end
    
    lowRate_br_s270TO90 = sum(lowRate_br_s270TO90,2);
    lowRate_br_s270TO90 = squeeze(lowRate_br_s270TO90);
    
    
    
    %BR
    % Sel 270, 90TO270
    for iSwitch = 1:length(lfpSwitches.low.BR.s90TO270{1})
        c = 0;
        for iChan = 1:96
            c = c+1; clear spikesPiece; clear lowPiece

            lowPiece = (lfpSwitches.low.BR.s90TO270{iChan}{iSwitch});
            currChan = iChan;
            
            if ~isempty(lowPiece)
                lowRate_br_s90TO270(iSwitch,iChan,:) = histc(lowPiece,edges);
            else
                lowRate_br_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
            end
            
        end
        
    end

    lowRate_br_s90TO270 = sum(lowRate_br_s90TO270,2);
    lowRate_br_s90TO270 = squeeze(lowRate_br_s90TO270);
    
    %PA
    % Sel 270, 270TO90
    for iSwitch = 1:length(lfpSwitches.low.PA.s270TO90{1})
        c = 0;
        for iChan = 1:96
            c = c+1; clear spikesPiece; clear lowPiece
            lowPiece = (lfpSwitches.low.PA.s270TO90{iChan}{iSwitch});
            currChan = iChan;
            
            if ~isempty(lowPiece)
                lowRate_pa_s270TO90(iSwitch,iChan,:) = histc(lowPiece,edges);
            else
                lowRate_pa_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
            end
            
        end
        
    end
    
    lowRate_pa_s270TO90 = sum(lowRate_pa_s270TO90,2);
    lowRate_pa_s270TO90 = squeeze(lowRate_pa_s270TO90);
    
    %PA
    % Sel 270, 90TO270
    for iSwitch = 1:length(lfpSwitches.low.PA.s90TO270{1})
        c = 0;
        for iChan = 1:96
            c = c+1; clear spikesPiece; clear lowPiece

            lowPiece = (lfpSwitches.low.PA.s90TO270{iChan}{iSwitch});
            currChan = iChan;
           
            
            if ~isempty(lowPiece)
                lowRate_pa_s90TO270(iSwitch,iChan,:) = histc(lowPiece,edges);
            else
                lowRate_pa_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
            end
            
        end
        
    end
    
    lowRate_pa_s90TO270 = sum(lowRate_pa_s90TO270,2);
    lowRate_pa_s90TO270 = squeeze(lowRate_pa_s90TO270);
    
    
    %% Consolidate into a structure

    spikingActivityPerTransition.sel270.lowRate.BR.s270TO90 = lowRate_br_s270TO90;
    spikingActivityPerTransition.sel270.lowRate.PA.s270TO90 = lowRate_pa_s270TO90;
    spikingActivityPerTransition.sel270.lowRate.BR.s90TO270 = lowRate_br_s90TO270;
    spikingActivityPerTransition.sel270.lowRate.PA.s90TO270 = lowRate_pa_s90TO270;
    
    save('TbyT_lowRate_1000ms.mat','spikingActivityPerTransition','edges','-v7.3')

    clear lowRate_br_s270TO90; clear lowRate_br_s90TO270;
    clear lowRate_pa_s270TO90; clear lowRate_pa_s90TO270; 
    clear lfpSwitches; clear spikingActivityPerTransition; clear jMUspikes; clear lowPiece;
end
