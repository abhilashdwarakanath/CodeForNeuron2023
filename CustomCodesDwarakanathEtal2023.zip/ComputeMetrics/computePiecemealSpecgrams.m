function [piecemealSpectrograms] = computePiecemealSpecgrams(lfpActivity,sav_dir_psth,durs,tag)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

cd(sav_dir_psth)

filename = ['piecemealSpecgrams_' tag '.mat'];

%% Collect activity

for iChan = 1:96
    
    
    %% Collect traces
    
    BRdominances90 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, iChan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond},2)
            piece = (lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                BRdominances90 = [BRdominances90;piece'];
            end
        end
    end
    
    
    
    
    BRdominances270 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, iChan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond},2)
            piece = (lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                BRdominances270 = [BRdominances270;piece'];
            end
        end
    end
      
    %% Trash junk trials
    
    [val,~] = max(BRdominances90,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    BRdominances90(trashTrials,:) = [];
    
    [val,~] = max(BRdominances270,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    BRdominances270(trashTrials,:) = [];
    
    %% Declare lengths -
    
    t = linspace(-durs.domBehind/1000,durs.switch/1000,(durs.domBehind/2)+(durs.switch/2)+1);
    [~,evtIdx] = min(abs(t-(-0.5)));
    midPoint = t(evtIdx);
    flen = 169;
    tlen = length(BRdominances90(1,:));
    
    %% Compute the CWT - P2NP
    
    % BR
    tic;
    cwtbr90 = zeros(flen,tlen,size(BRdominances90,1));
    cwtbr90_norm1 = zeros(flen,tlen,size(BRdominances90,1));
    for i = 1:size(BRdominances90,1)
        [cwtbr90(:,:,i),f] = cwt(BRdominances90(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
        cwtbr90(:,:,i) = abs(cwtbr90(:,:,i).^2);
        cwtbr90_norm1(:,:,i) = zscore(cwtbr90(:,:,i),[],1);
    end
    
    cwtbr270 = zeros(flen,tlen,size(BRdominances270,1));
    cwtbr270_norm1 = zeros(flen,tlen,size(BRdominances270,1));
    for i = 1:size(BRdominances270,1)
        [cwtbr270(:,:,i),f] = cwt(BRdominances270(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
        cwtbr270(:,:,i) = abs(cwtbr270(:,:,i).^2);
        cwtbr270_norm1(:,:,i) = zscore(cwtbr270(:,:,i),[],1);
    end
    
    cwtbr = cat(3,cwtbr90,cwtbr270);
    cwtbr_norm1 = cat(3,cwtbr90_norm1,cwtbr270_norm1);
    
    toc;
    
    %% Plot
    
%     figure(3)
%     imMat = nanmean(cwtbr(:,501:end-500,:),3);
%     imagesc(t,log2(f),imMat-mean(mean(imMat)))
%     shading('interp')
    Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
%     xlabel('time in s');shading('interp')
%     ylabel('Hz')
%     AX = gca;
%     AX.YLim = log2([min(f), max(f)]);
%     set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
%     axis xy
%     vline(0,'--k')
%     colormap jet
%     AX.CLim = [0 175];
%     title('Piecemeals - Dataset 1 - H07')
%     suptitle('Piecemeal Spectrograms - Clean Dominances')
%     pause(1.5)
%     close all
    
    
    %% Collect the output
    
    piecemealSpectrograms(iChan).t = t;
    piecemealSpectrograms(iChan).f = f;
    piecemealSpectrograms(iChan).Yticks = Yticks;
    piecemealSpectrograms(iChan).BR.dom90 = nanmean(cwtbr90(:,501:end-500,:),3);
    piecemealSpectrograms(iChan).BR.dom270 = nanmean(cwtbr270(:,501:end-500,:),3);
    piecemealSpectrograms(iChan).BR.dom90_norm1 = nanmean(cwtbr90_norm1(:,501:end-500,:),3);
    piecemealSpectrograms(iChan).BR.dom270_norm1 = nanmean(cwtbr270_norm1(:,501:end-500,:),3);
    
end

save(filename,'piecemealSpectrograms','-v7.3');
