function [cleanDomSpectrograms] = computeCleanDomSpecgrams(lfpActivity,sav_dir_psth,durs,tag)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

cd(sav_dir_psth)

filename = ['MM_cleanDomSpecgrams_' tag '.mat'];

%% Collect activity

for iChan = 1:96
    
    
    %% Collect traces
    
    BRdominances90 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, iChan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond},2)
            piece = (lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                BRdominances90 = [BRdominances90;piece'];
            end
        end
    end
    
    
    
    
    BRdominances270 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, iChan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond},2)
            piece = (lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                BRdominances270 = [BRdominances270;piece'];
            end
        end
    end
    
    
    
    
    PAdominances90 = [];
    
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, iChan},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, iChan}{1, iCond},2)
            piece = (lfpActivity.validSection.PA.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                PAdominances90 = [PAdominances90;piece'];
            end
        end
    end
    
    
    
    PAdominances270 = [];
    
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, iChan},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, iChan}{1, iCond},2)
            piece = (lfpActivity.validSection.PA.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                PAdominances270 = [PAdominances270;piece'];
            end
        end
    end
    
    
    
    %% Trash junk trials
    
    [val,~] = max(BRdominances90,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    BRdominances90(trashTrials,:) = [];
    
    [val,~] = max(BRdominances270,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    BRdominances270(trashTrials,:) = [];
    
    [val,~] = max(PAdominances90,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    PAdominances90(trashTrials,:) = [];
    
    [val,~] = max(PAdominances270,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    PAdominances270(trashTrials,:) = [];
    
    %% Equalise number of trials across BR and PA
    
    if size(BRdominances90,1) > size(PAdominances90,1)
        idxs90 = 1:size(PAdominances90,1);
    else
        idxs90 = sort(randperm(size(PAdominances90,1),size(BRdominances90,1))); % Get equal number of PA trials
    end
    PAdominances90 = PAdominances90(idxs90,:);
    
    if size(BRdominances270,1) > size(PAdominances270,1)
        idxs270 = 1:size(PAdominances270,1);
    else
        idxs270 = sort(randperm(size(PAdominances270,1),size(BRdominances270,1))); % Get equal number of PA trials
    end
    PAdominances270 = PAdominances270(idxs270,:);
    
    %% Declare lengths -
    
    t = linspace(-durs.domBehind/1000,durs.domForward/1000,(durs.domBehind/2)+(durs.domForward/2)+1);
    flen = 169;
    tlen = length(BRdominances90(1,:));
    
    
    %% Compute the CWT - P2NP
    
    % BR
    tic;
    cwtbr90 = zeros(flen,tlen,size(BRdominances90,1));
    for i = 1:size(BRdominances90,1)
        [cwtbr90(:,:,i),f] = cwt(BRdominances90(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
        cwtbr90(:,:,i) = abs(cwtbr90(:,:,i).^2);
        cwtbr90_norm1(:,:,i) = zscore(cwtbr90(:,:,i),[],1);

    end
    
    cwtbr270 = zeros(flen,tlen,size(BRdominances270,1));
    for i = 1:size(BRdominances270,1)
        [cwtbr270(:,:,i),f] = cwt(BRdominances270(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
        cwtbr270(:,:,i) = abs(cwtbr270(:,:,i).^2);
        cwtbr270_norm1(:,:,i) = zscore(cwtbr270(:,:,i),[],1);
        
    end
    
    % PA
    
    
    cwtpa90 = zeros(flen,tlen,size(PAdominances90,1));
    for i = 1:size(PAdominances90,1)
        [cwtpa90(:,:,i),f] = cwt(PAdominances90(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
        cwtpa90(:,:,i) = abs(cwtpa90(:,:,i).^2);
        cwtpa90_norm1(:,:,i) = zscore(cwtpa90(:,:,i),[],1);
    end
    
    cwtpa270 = zeros(flen,tlen,size(PAdominances270,1));
    for i = 1:size(PAdominances270,1)
        [cwtpa270(:,:,i),f] = cwt(PAdominances270(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
        cwtpa270(:,:,i) = abs(cwtpa270(:,:,i).^2);
        cwtpa270_norm1(:,:,i) = zscore(cwtpa270(:,:,i),[],1);
    end
    toc
    
    %% Collect the output
    
    Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
    cleanDomSpectrograms(iChan).t = t;
    cleanDomSpectrograms(iChan).f = f;
    cleanDomSpectrograms(iChan).Yticks = Yticks;
    cleanDomSpectrograms(iChan).BR.dom90 = nanmean(cwtbr90(:,501:end-500,:),3);
    cleanDomSpectrograms(iChan).BR.dom270 = nanmean(cwtbr270(:,501:end-500,:),3);
    cleanDomSpectrograms(iChan).PA.dom90 = nanmean(cwtpa90(:,501:end-500,:),3);
    cleanDomSpectrograms(iChan).PA.dom270 = nanmean(cwtpa270(:,501:end-500,:),3);
    cleanDomSpectrograms(iChan).BR.dom90_norm1 = nanmean(cwtbr90_norm1(:,501:end-500,:),3);
    cleanDomSpectrograms(iChan).BR.dom270_norm1 = nanmean(cwtbr270_norm1(:,501:end-500,:),3);
    cleanDomSpectrograms(iChan).PA.dom90_norm1 = nanmean(cwtpa90_norm1(:,501:end-500,:),3);
    cleanDomSpectrograms(iChan).PA.dom270_norm1 = nanmean(cwtpa270_norm1(:,501:end-500,:),3);
    
end

save(filename,'cleanDomSpectrograms','-v7.3');
