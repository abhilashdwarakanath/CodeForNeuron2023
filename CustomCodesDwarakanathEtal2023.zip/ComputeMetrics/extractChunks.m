function [starts,ends, durations ,chunkList] = extractChunks(inputData, tolerance)
%extractChunks - extracts clusters of activity peaks separated by a 
%                distance under a threshold value in a continous signal
% [starts,ends,chunkList] = extractChunks(inputData, tolerance)
% INPUTS
%   inputData - column vector
%   tolerance - float
% OUTPUTS
%   starts - vector containing the start indices of each detected chunk
%   ends - vector array containing the end indices of each detected chunk
%   durations - vector containing the durations of each detected chunk
%   chunkList - cell array containing all the points in a detected chunks
%               for deubgging purposes



chunkList = {};

% Temporary array variable used to collect the consecutive data points,
% instansiated to the first value of the input data
temp = [inputData(1)];

nPoints = length(inputData);

starts = [];
ends  = [];

for idx = 1:nPoints-1
    
    % If the the point is within threshold
    if inputData(idx+1) - inputData(idx) <= tolerance
        % Collect it in the temporary array variable
        temp  = [temp inputData(idx +1)];
    else
        % Otherwise if the next point falls outside the threshold, check if
        % it isn't a single point or the same point being repeated and
        % collect the temporary array variable as a burst 
        if length(temp) ~= 1 && temp(end) ~= temp(1)
            chunkList{end+1} = temp;
        end
        % Clear the temporary array variable and instansiate it with the
        % next value of the input data to repeat the process
        temp = [inputData(idx+1)];
    end
end


% Collect the last chunk that could be left over because of the loop
% ending
if length(temp) ~= 1 && temp(end) ~= temp(1)
    chunkList{end+1} = temp;
end

% Collect the start points
    for i = 1:length(chunkList)
        starts = [starts chunkList{i}(1)];
    end
    
 % Collect the end points
    for i = 1:length(chunkList)
        ends = [ends chunkList{i}(end)];
    end
        
    durations =  ends - starts;

end
