function [spectra] = computeCleanDomSpectra(lfpActivity,sav_dir_psth,durs,tag)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

cd(sav_dir_psth)

filename = ['MM_cleanDomSpectra_' tag '.mat'];

pad = 500;

%% Collect activity

for iChan = 1:96
    
    
    %% Collect traces
    
    BRdominances90 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, iChan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond},2)
            piece = (lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                BRdominances90 = [BRdominances90;piece'];
            end
        end
    end
    
    
    
    
    BRdominances270 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, iChan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond},2)
            piece = (lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                BRdominances270 = [BRdominances270;piece'];
            end
        end
    end
    
    
    
    
    PAdominances90 = [];
    
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, iChan},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, iChan}{1, iCond},2)
            piece = (lfpActivity.validSection.PA.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                PAdominances90 = [PAdominances90;piece'];
            end
        end
    end
    
    
    
    PAdominances270 = [];
    
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, iChan},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, iChan}{1, iCond},2)
            piece = (lfpActivity.validSection.PA.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                PAdominances270 = [PAdominances270;piece'];
            end
        end
    end
    
    
    
    %% Trash junk trials
    
    [val,~] = max(BRdominances90,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    BRdominances90(trashTrials,:) = [];
    
    [val,~] = max(BRdominances270,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    BRdominances270(trashTrials,:) = [];
    
    [val,~] = max(PAdominances90,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    PAdominances90(trashTrials,:) = [];
    
    [val,~] = max(PAdominances270,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    PAdominances270(trashTrials,:) = [];
    
    %% Equalise number of trials across BR and PA
    
    if size(BRdominances90,1) > size(PAdominances90,1)
        idxs90 = 1:size(PAdominances90,1);
    else
        idxs90 = sort(randperm(size(PAdominances90,1),size(BRdominances90,1))); % Get equal number of PA trials
    end
    PAdominances90 = PAdominances90(idxs90,:);
    
    if size(BRdominances270,1) > size(PAdominances270,1)
        idxs270 = 1:size(PAdominances270,1);
    else
        idxs270 = sort(randperm(size(PAdominances270,1),size(BRdominances270,1))); % Get equal number of PA trials
    end
    PAdominances270 = PAdominances270(idxs270,:);
    
    BRdominances90 = BRdominances90(:,pad+1:end-pad)';
    BRdominances270 = BRdominances270(:,pad+1:end-pad)';
    
    PAdominances90 = PAdominances90(:,pad+1:end-pad)';
    PAdominances270 = PAdominances270(:,pad+1:end-pad)';
    
    %% MT params
    
    params.tapers = [3 5];
    params.Fs = 500;
    params.trialave = 1;
    params.pad = 0;

    [S_BR_90,f] = mtspectrumc(BRdominances90,params);
    [S_BR_270,f] = mtspectrumc(BRdominances270,params);
    [S_PA_90,f] = mtspectrumc(PAdominances90,params);
    [S_PA_270,f] = mtspectrumc(PAdominances270,params);
    
    spectra(iChan).BR.dom90 = 10*log10(S_BR_90);
    spectra(iChan).BR.dom270 = 10*log10(S_BR_270);
    
    spectra(iChan).PA.dom90 = 10*log10(S_PA_90);
    spectra(iChan).PA.dom270 = 10*log10(S_PA_270);
end

save(filename,'spectra','f','-v7.3');
    
