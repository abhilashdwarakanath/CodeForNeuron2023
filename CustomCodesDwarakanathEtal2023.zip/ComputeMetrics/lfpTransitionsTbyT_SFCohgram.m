function lfpTransitionsTbyT_SFCohgram(lfpActivity,spikingActivity,sav_dir_psth,durs,fileID)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

dbstop if error

cd(sav_dir_psth)

%% Time parameters

t =linspace(-durs.domBehind/1000,durs.domForward/1000,(durs.domBehind/2)+(durs.domForward/2)+1);
evtIdx = ceil(durs.domBehind/2)+1;
midPoint = t(ceil(length(t)/2));

%% Chronux parameters

params.Fs = 500;
params.tapers = [3 5];
params.trialave = 0;
params.pad = 1; % NExt highest power of 2
params.err = 0;


%% Load Preference array and get preferences

cd(['B:\Results\' fileID '\Bfsgrad\PFC\SUA\Preference_Arrays\cSwitch'])
load('1000_250_1000_DF_pref_array_switch.mat')

% pref90_br = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==2);
% pref90_br = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref90_br,3);
% pref270_br = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==1);
% pref270_br = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref270_br,3);
% pref90_pa = find(pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,2)==2);
% pref90_pa = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(pref90_pa,3);
% pref270_pa = find(pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,2)==1);
% pref270_pa = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(pref270_pa,3);

pref90_br_bs = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==2);
    pref90_br_as = find(pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,2)==2);
    pref90_br_bsas = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==2);
    pref90_br_bs = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref90_br_bs,3);
    pref90_br_as = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(pref90_br_as,3);
    pref90_br_bsas = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref90_br_bsas,3);
    
    pref90_br = unique([pref90_br_bs;pref90_br_as;pref90_br_bsas]);
    
    
    pref270_br_bs = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==1);
    pref270_br_as = find(pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,2)==1);
    pref270_br_bsas = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==1);
    pref270_br_bs = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref270_br_bs,3);
    pref270_br_as = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(pref270_br_as,3);
    pref270_br_bsas = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref270_br_bsas,3);
    
    pref270_br = unique([pref270_br_bs;pref270_br_as;pref270_br_bsas]);
    
    pref90_pa_bs = find(pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,2)==2);
    pref90_pa_as = find(pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(:,2)==2);
    pref90_pa_bsas = find(pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(:,2)==2);
    pref90_pa_bs = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(pref90_pa_bs,3);
    pref90_pa_as = pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(pref90_pa_as,3);
    pref90_pa_bsas = pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(pref90_pa_bsas,3);
    
    pref90_pa = unique([pref90_pa_bs;pref90_pa_as;pref90_pa_bsas]);
    
    
    pref270_pa_bs = find(pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,2)==1);
    pref270_pa_as = find(pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(:,2)==1);
    pref270_pa_bsas = find(pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(:,2)==1);
    pref270_pa_bs = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(pref270_pa_bs,3);
    pref270_pa_as = pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(pref270_pa_as,3);
    pref270_pa_bsas = pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(pref270_pa_bsas,3);
    
    pref270_pa = unique([pref270_pa_bs;pref270_pa_as;pref270_pa_bsas]);
    
    %% Load the maps
    
    if iDataset == 1 || iDataset == 2 || iDataset == 3 || iDataset == 4
        
        cd B:\H07\
        
        load H07ElectrodeInfo.mat
        
    else
        
        cd B:\A11\
        
        load A11ElectrodeInfo.mat
        
    end
        

%% Collect activity

% BR

c = 0;
for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96 
            spikes = spikingActivity.validSection.BR.data.dom90{iChan}{iCond}{nDom};
            spikeTimes_BR_90{c}{iChan} = spikes;
            lfppieceBR90(c,iChan,:) = (((detrend(lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond}{nDom}))));
        end
    end
end

lfp_BR_270TO90 = squeeze(nanmean(lfppieceBR90(:,:,501:end-500),2));

% Do SFC

for iTr = 1:size(lfppieceBR90,1)
    
    % Adjust tapers for each time duration separately
    
    lfpTrace = squeeze(repmat(lfp_BR_270TO90(iTr,:),1,1,96)); % % TO PRESERVE DIMENSIONAL CONSISTENCY, REPLACE 96 WITH nUNITS
    
    for iChan = 1:96
        if ~isempty(spikeTimes_BR_90{iTr}{iChan})
            spikesTemp = spikeTimes_BR_90{iTr}{iChan}./1000;
        else
            spikesTemp = [];
        end
        
        if ~isempty(spikesTemp)
            spikeTimes(iChan,1).times = spikesTemp'+1;
        else
            spikeTimes(iChan,1).times = [];
        end
        
    end
    
    [SFC.BR.sfc_sel90_s270TO90(iTr,:,:,:),SFC.BR.phi_sel90_s270TO90(iTr,:,:,:),~,~,~,t_sfc,f]=cohgramcpt(lfpTrace,spikeTimes,[0.4 0.01],params,1);
    
end

for iTr = 1:size(lfppieceBR90,1)
    
    % Adjust tapers for each time duration separately
    
    lfpTrace = squeeze(repmat(lfp_BR_270TO90(iTr,:),1,1,96)); % To preserve dimensional consistency. Is this okay?
    
    for iChan = 1:96
        if ~isempty(spikeTimes_BR_90{iTr}{iChan})
            spikesTemp = spikeTimes_BR_90{iTr}{iChan}./1000;
        else
            spikesTemp = [];
        end
        
        if ~isempty(spikesTemp)
            spikeTimes(iChan,1).times = spikesTemp'+1;
        else
            spikeTimes(iChan,1).times = [];
        end
        
    end
    
    [SFC.BR.sfc_sel270_s270TO90(iTr,:,:,:),SFC.BR.phi_sel270_s270TO90(iTr,:,:,:),~,~,~,t_sfc,f]=cohgramcpt(lfpTrace,spikeTimes,[0.4 0.01],params,1);
    
end

c = 0;
for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            spikes = spikingActivity.validSection.BR.data.dom270{iChan}{iCond}{nDom};
            spikeTimes_BR_270{c}{iChan} = spikes;
            lfppieceBR270(c,iChan,:) = (((detrend(lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond}{nDom}))));
        end
    end
end

lfp_BR_90TO270 = squeeze(nanmean(lfppieceBR270(:,:,501:end-500),2));

% Do SFC

for iTr = 1:size(lfppieceBR270,1)
    
    % Adjust tapers for each time duration separately
    
    lfpTrace = squeeze(repmat(lfp_BR_90TO270(iTr,:),1,1,96)); % To preserve dimensional consistency. Is this okay?
    
    for iChan = 1:96
        if ~isempty(spikeTimes_BR_270{iTr}{iChan})
            spikesTemp = spikeTimes_BR_270{iTr}{iChan}./1000;
        else
            spikesTemp = [];
        end
        
        if ~isempty(spikesTemp)
            spikeTimes(iChan,1).times = spikesTemp'+1;
        else
            spikeTimes(iChan,1).times = [];
        end
        
    end
    
    [SFC.BR.sfc_sel90_s90TO270(iTr,:,:,:),SFC.BR.phi_sel90_s90TO270(iTr,:,:,:),~,~,~,t_sfc,f]=cohgramcpt(lfpTrace,spikeTimes,[0.4 0.01],params,1);
    
end

for iTr = 1:size(lfppieceBR270,1)
    
    % Adjust tapers for each time duration separately
    
    lfpTrace = squeeze(repmat(lfp_BR_90TO270(iTr,:),1,1,96)); % To preserve dimensional consistency. Is this okay?
    
    for iChan = 1:96
        if ~isempty(spikeTimes_BR_270{iTr}{iChan})
            spikesTemp = spikeTimes_BR_270{iTr}{iChan}./1000;
        else
            spikesTemp = [];
        end
        
        if ~isempty(spikesTemp)
            spikeTimes(iChan,1).times = spikesTemp'+1;
        else
            spikeTimes(iChan,1).times = [];
        end
        
    end
    
    [SFC.BR.sfc_sel270_s90TO270(iTr,:,:,:),SFC.BR.phi_sel270_s90TO270(iTr,:,:,:),~,~,~,t_sfc,f]=cohgramcpt(lfpTrace,spikeTimes,[0.4 0.01],params,1);
    
end


c = 0;
for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            spikes = spikingActivity.validSection.PA.data.dom90{iChan}{iCond}{nDom};
            spikeTimes_PA_90{c}{iChan} = spikes;
            lfppiecePA90(c,iChan,:) = (((detrend(lfpActivity.validSection.PA.data.dom90{1, iChan}{1, iCond}{nDom}))));
        end
    end
end

lfp_PA_270TO90 = squeeze(nanmean(lfppiecePA90(:,:,501:end-500),2));

% Do SFC

for iTr = 1:size(lfppiecePA90,1)
    
    % Adjust tapers for each time duration separately
    
    lfpTrace = squeeze(repmat(lfp_PA_270TO90(iTr,:),1,1,96)); % To preserve dimensional consistency. Is this okay?
    
    for iChan = 1:96
        if ~isempty(spikeTimes_PA_90{iTr}{iChan})
            spikesTemp = spikeTimes_PA_90{iTr}{iChan}./1000;
        else
            spikesTemp = [];
        end
        
        if ~isempty(spikesTemp)
            spikeTimes(iChan,1).times = spikesTemp'+1;
        else
            spikeTimes(iChan,1).times = [];
        end
        
    end
    
    [SFC.PA.sfc_sel90_s270TO90(iTr,:,:,:),SFC.PA.phi_sel90_s270TO90(iTr,:,:,:),~,~,~,t_sfc,f]=cohgramcpt(lfpTrace,spikeTimes,[0.4 0.01],params,1);
    
end

for iTr = 1:size(lfppiecePA90,1)
    
    % Adjust tapers for each time duration separately
    
    lfpTrace = squeeze(repmat(lfp_PA_270TO90(iTr,:),1,1,96)); % To preserve dimensional consistency. Is this okay?
    
    for iChan = 1:96
        if ~isempty(spikeTimes_PA_90{iTr}{iChan})
            spikesTemp = spikeTimes_PA_90{iTr}{iChan}./1000;
        else
            spikesTemp = [];
        end
        
        if ~isempty(spikesTemp)
            spikeTimes(iChan,1).times = spikesTemp'+1;
        else
            spikeTimes(iChan,1).times = [];
        end
        
    end
    
    [SFC.PA.sfc_sel270_s270TO90(iTr,:,:,:),SFC.PA.phi_sel270_s270TO90(iTr,:,:,:),~,~,~,t_sfc,f]=cohgramcpt(lfpTrace,spikeTimes,[0.4 0.01],params,1);
    
end

c = 0;
for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            spikes = spikingActivity.validSection.PA.data.dom270{iChan}{iCond}{nDom};
            spikeTimes_PA_270{c}{iChan} = spikes;
            lfppiecePA270(c,iChan,:) = (((detrend(lfpActivity.validSection.PA.data.dom270{1, iChan}{1, iCond}{nDom}))));
        end
    end
end

lfp_PA_90TO270 = squeeze(nanmean(lfppiecePA270(:,:,501:end-500),2));

% Do SFC

for iTr = 1:size(lfppiecePA270,1)
    
    % Adjust tapers for each time duration separately
    
    lfpTrace = squeeze(repmat(lfp_PA_90TO270(iTr,:),1,1,96)); % To preserve dimensional consistency. Is this okay?
    
    for iChan = 1:96
        if ~isempty(spikeTimes_PA_270{iTr}{iChan})
            spikesTemp = spikeTimes_PA_270{iTr}{iChan}./1000;
        else
            spikesTemp = [];
        end
        
        if ~isempty(spikesTemp)
            spikeTimes(iChan,1).times = spikesTemp'+1;
        else
            spikeTimes(iChan,1).times = [];
        end
        
    end
    
    [SFC.PA.sfc_sel90_s90TO270(iTr,:,:,:),SFC.PA.phi_sel90_s90TO270(iTr,:,:,:),~,~,~,t_sfc,f]=cohgramcpt(lfpTrace,spikeTimes,[0.4 0.01],params,1);
    
end

for iTr = 1:size(lfppiecePA270,1)
    
    % Adjust tapers for each time duration separately
    
    lfpTrace = squeeze(repmat(lfp_PA_90TO270(iTr,:),1,1,96)); % To preserve dimensional consistency. Is this okay?
    
    for iChan = 1:96
        if ~isempty(spikeTimes_PA_270{iTr}{iChan})
            spikesTemp = spikeTimes_PA_270{iTr}{iChan}./1000;
        else
            spikesTemp = [];
        end
        
        if ~isempty(spikesTemp)
            spikeTimes(iChan,1).times = spikesTemp'+1;
        else
            spikeTimes(iChan,1).times = [];
        end
        
    end
    
    [SFC.PA.sfc_sel270_s90TO270(iTr,:,:,:),SFC.PA.phi_sel270_s90TO270(iTr,:,:,:),~,~,~,t_sfc,f]=cohgramcpt(lfpTrace,spikeTimes,[0.4 0.01],params,1);
    
end

%% Collect across ensembles

% BR

    % 90 Selective Ensemble
    SFC.summed.BR.sfc_sel90_s270TO90 =SFC.BR.sfc_sel90_s270TO90(:,:,:,pref90_br);
    SFC.summed.BR.sfc_sel90_s90TO270 = SFC.BR.sfc_sel90_s90TO270(:,:,:,pref90_br);

    
    % 270 Selective Ensemble
    SFC.summed.BR.sfc_sel270_s270TO90 =SFC.BR.sfc_sel270_s270TO90(:,:,:,pref270_br);
    SFC.summed.BR.sfc_sel270_s90TO270 = SFC.BR.sfc_sel270_s90TO270(:,:,:,pref270_br);
    
    % PA
    
    % 90 Selective Ensemble
    SFC.summed.PA.sfc_sel90_s270TO90 =SFC.PA.sfc_sel90_s270TO90(:,:,:,pref90_br);
    SFC.summed.PA.sfc_sel90_s90TO270 = SFC.PA.sfc_sel90_s90TO270(:,:,:,pref90_br);

    
    % 270 Selective Ensemble
    SFC.summed.PA.sfc_sel270_s270TO90 =SFC.PA.sfc_sel270_s270TO90(:,:,:,pref270_br);
    SFC.summed.PA.sfc_sel270_s90TO270 = SFC.PA.sfc_sel270_s90TO270(:,:,:,pref270_br);
    
    % BR
    
    SFC.summed.BR.phi_sel90_s270TO90 =SFC.BR.phi_sel90_s270TO90(:,:,:,pref90_br);
    SFC.summed.BR.phi_sel90_s90TO270 = SFC.BR.phi_sel90_s90TO270(:,:,:,pref90_br);

    
    % 270 Selective Ensemble
    SFC.summed.BR.phi_sel270_s270TO90 =SFC.BR.phi_sel270_s270TO90(:,:,:,pref270_br);
    SFC.summed.BR.phi_sel270_s90TO270 = SFC.BR.phi_sel270_s90TO270(:,:,:,pref270_br);
    
    % PA
    
    % 90 Selective Ensemble
    SFC.summed.PA.phi_sel90_s270TO90 =SFC.PA.phi_sel90_s270TO90(:,:,:,pref90_br);
    SFC.summed.PA.phi_sel90_s90TO270 = SFC.PA.phi_sel90_s90TO270(:,:,:,pref90_br);

    
    % 270 Selective Ensemble
    SFC.summed.PA.phi_sel270_s270TO90 =SFC.PA.phi_sel270_s270TO90(:,:,:,pref270_br);
    SFC.summed.PA.phi_sel270_s90TO270 = SFC.PA.phi_sel270_s90TO270(:,:,:,pref270_br);
clear sfc;


cd(sav_dir_psth)
save('MM_SFCohgram_SUMUSel_1000ms_GlobalLFP.mat','SFC','t_sfc','f','-v7.3');

end
