function [negEvts, posEvts] = getThresholdCrossingEvents(samples,minpeakh,minpeakdist)

%% Convert to row vector if column input.

fprintf('Detecting negtive and positive events...\n')
if size(samples,2)==1
    samples=samples';
end

%% Compute threshold

negThr = -1*minpeakh*std(samples);
posThr = minpeakh*std(samples);

%% Detect events Negative

% Collect positive and negative going spikes i.e. % Find all maxima/minima and ties

negEvts=find(samples(2:end-1)<=samples(1:end-2) & samples(2:end-1)<=samples(3:end))+1;

% Correct for thresholds
negEvts(samples(negEvts)>=negThr)=[];

fprintf('Correcting and aligning Negative events...\n')
if minpeakdist>1
    while 1

        del=diff(negEvts)<minpeakdist;

        if ~any(del), break; end % There must be a more efficient way of doing this instead of using break?

        pks=samples(negEvts);

        [~,mins]=min([pks(del) ; pks([false del])]);

        deln=find(del);

        deln=[deln(mins==1) deln(mins==2)+1];

        negEvts(deln)=[];

    end
end


%% Detect events positive

% Collect positive and negative going spikes i.e. % Find all maxima/minima and ties
posEvts=find(samples(2:end-1)>=samples(1:end-2) & samples(2:end-1)>=samples(3:end))+1;

% Correct for thresholds
posEvts(samples(posEvts)<=posThr)=[];

% Correct and align for duration

fprintf('Correcting and aligning Negative events...\n')
if minpeakdist>1
    while 1

        del=diff(posEvts)<minpeakdist;

        if ~any(del), break; end % There must be a more efficient way of doing this instead of using break?

        pks=samples(posEvts);

        [~,mins]=min([pks(del) ; pks([false del])]);

        deln=find(del);

        deln=[deln(mins==1) deln(mins==2)+1];

        posEvts(deln)=[];

    end
end

end