function [spectrograms] = computePiecemealSpecgramsTbyT(lfpActivity,sav_dir_psth,durs,tag)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

cd(sav_dir_psth)

filename = ['piecemealSpecgrams_trialByTrial_' tag '.mat'];

%% Collect activity


c = 0;
for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            piece = (lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece) & max(piece) < 750
                [specgram,f] = cwt(piece(501:end-500)','morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
                specgram = abs(specgram.^2);
                specgram_BR_90(c,iChan,:,:) = specgram;
            end
        end
    end
end

specgram_BR_90 = squeeze(nanmean(specgram_BR_90,2));

c = 0;
for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            piece = (lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece) & max(piece) < 750
                [specgram,f] = cwt(piece(501:end-500)','morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
                specgram = abs(specgram.^2);
                specgram_BR_270(c,iChan,:,:) = specgram;
            end
        end
    end
end

specgram_BR_270 = squeeze(nanmean(specgram_BR_270,2));

% Collect both together

if length(size(specgram_BR_90)) == 2
    
    temp_specgram_BR_90(1,:,:)  = specgram_BR_90;
    specgram_BR = cat(1,specgram_BR_270,temp_specgram_BR_90);
    
elseif length(size(specgram_BR_270)) == 2
    
    temp_specgram_BR_270(1,:,:) = specgram_BR_270;
    specgram_BR = cat(1,specgram_BR_90,temp_specgram_BR_270);
    
else
    
    specgram_BR = cat(1,specgram_BR_90,specgram_BR_270);
    
end

clear specgram_BR_90;
clear specgram_BR_270;

fprintf('Computation of spectrograms done, saving...\n')
t = linspace(-durs.domBehind/1000,durs.switch/1000,(durs.domBehind/2)+(durs.switch/2)+1);
spectrograms.BR = specgram_BR;
spectrograms.f = f;
spectrograms.t = t;

save(filename,'spectrograms','-v7.3');

end
