function lfpTransitionsTbyT_SFCohgram_globalLFP_ensembleSpiking(lfpActivity,spikingActivity,sav_dir_psth,durs,fileID)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

dbstop if error

cd(sav_dir_psth)

%% Time parameters

t =linspace(-durs.domBehind/1000,durs.domForward/1000,(durs.domBehind/2)+(durs.domForward/2)+1);
evtIdx = ceil(durs.domBehind/2)+1;
midPoint = t(ceil(length(t)/2));

%% Chronux parameters

params.Fs = 500;
params.tapers = [3 5];
params.trialave = 0;
params.pad = 1; % NExt highest power of 2
params.err = 0;

%% Load Preference array and get preferences

cd(['B:\Results\' fileID '\Bfsgrad\PFC\SUA\Preference_Arrays\cSwitch'])
load('1000_250_1000_DF_pref_array_switch.mat')

% pref90_br = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==2);
% pref90_br = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref90_br,3);
% pref270_br = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==1);
% pref270_br = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref270_br,3);
% pref90_pa = find(pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,2)==2);
% pref90_pa = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(pref90_pa,3);
% pref270_pa = find(pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,2)==1);
% pref270_pa = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(pref270_pa,3);

pref90_br_bs = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==2);
pref90_br_as = find(pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,2)==2);
pref90_br_bsas = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==2);
pref90_br_bs = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref90_br_bs,3);
pref90_br_as = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(pref90_br_as,3);
pref90_br_bsas = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref90_br_bsas,3);

pref90_br = unique([pref90_br_bs;pref90_br_as;pref90_br_bsas]);


pref270_br_bs = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==1);
pref270_br_as = find(pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,2)==1);
pref270_br_bsas = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==1);
pref270_br_bs = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref270_br_bs,3);
pref270_br_as = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(pref270_br_as,3);
pref270_br_bsas = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref270_br_bsas,3);

pref270_br = unique([pref270_br_bs;pref270_br_as;pref270_br_bsas]);

pref90_pa_bs = find(pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,2)==2);
pref90_pa_as = find(pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(:,2)==2);
pref90_pa_bsas = find(pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(:,2)==2);
pref90_pa_bs = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(pref90_pa_bs,3);
pref90_pa_as = pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(pref90_pa_as,3);
pref90_pa_bsas = pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(pref90_pa_bsas,3);

pref90_pa = unique([pref90_pa_bs;pref90_pa_as;pref90_pa_bsas]);


pref270_pa_bs = find(pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,2)==1);
pref270_pa_as = find(pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(:,2)==1);
pref270_pa_bsas = find(pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(:,2)==1);
pref270_pa_bs = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(pref270_pa_bs,3);
pref270_pa_as = pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(pref270_pa_as,3);
pref270_pa_bsas = pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(pref270_pa_bsas,3);

pref270_pa = unique([pref270_pa_bs;pref270_pa_as;pref270_pa_bsas]);

%% Collect activity

% BR

c = 0;
for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1}{1, iCond},2)
            c = c+1;
            for iChan = 1:96
                spikes = spikingActivity.validSection.BR.data.dom90{iChan}{iCond}{nDom};
                
            spikeTimes_BR_90{c}{iChan} = spikes;
            lfppieceBR90(c,iChan,:) = (((detrend(lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond}{nDom}))));
            end
        end
end

lfp_BR_270TO90 = squeeze(nanmean(lfppieceBR90(:,:,501:end-500),2));

% Do SFC
    
    for iTr = 1:size(lfppieceBR90,1)
        
        lfpTrace = lfp_BR_270TO90(iTr,:); % To preserve dimensional consistency. Is this okay?
        
        spikesFull = [];
        
        for iChan = 1:length(pref90_br)
            if ~isempty(spikeTimes_BR_90{iTr}{pref90_br(iChan)})
                spikesTemp = spikeTimes_BR_90{iTr}{pref90_br(iChan)}./1000;
            else
                spikesTemp = [];
            end
            spikesFull = [spikesFull spikesTemp];
            
        end
    
        spikesFull = sort(unique(spikesFull));
        
        Ts = (length(t)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
       
        [SFC.sfc_BR_sel90_270TO90(iTr,:,:),SFC.phi_BR_sel90_270TO90(iTr,:,:),~,~,~,f_BR.freqs]=cohgramcpt(lfpTrace',spikesFull',[0.2 0.02],params',0);
        
       
    end


for iBin = 1:4
    
    for iTr = 1:size(lfppieceBR90,1)
        
        lfpTracePre = lfp_BR_270TO90(iTr,preBins.bins); % To preserve dimensional consistency. Is this okay?
        lfpTracePost = lfp_BR_270TO90(iTr,postBins.bins);
        
        spikesPre = [];
        spikesPost = [];
        
        for iChan = 1:length(pref270_br)
            if ~isempty(spikeTimes_BR_90{iTr}{pref270_br(iChan)})
                spikesTemp = spikeTimes_BR_90{iTr}{pref270_br(iChan)}./1000;
            else
                spikesTemp = [];
            end
            spikesPre = [spikesPre spikesTemp(spikesTemp<=t(preBins.bins(end)))];
            spikesPost = [spikesPost spikesTemp(spikesTemp>t(postBins.bins(1)))];
            
        end
        
        spikesPre = sort(spikesPre);
        spikesPost = sort(spikesPost);
        
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPre)/length(pref270_br)/Ts;
        RateEst     = numel(spikesPre)/length(pref270_br)/Ts;
        [SFC.sfc_BR_sel270_270TO90_Pre(iTr,:),SFC.phi_BR_sel270_270TO90_Pre(iTr,:),~,~,~,f_pre_BR.freqs]=coherencycpt(lfpTracePre',spikesPre',params',1,t(preBins.bins));
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPost)/length(pref270_br)/Ts;
        RateEst     = numel(spikesPost)/length(pref270_br)/Ts;
        [SFC.sfc_BR_sel270_270TO90_Post(iTr,:),SFC.phi_BR_sel270_270TO90_Post(iTr,:),~,~,~,f_post_BR.freqs]=coherencycpt(lfpTracePost',spikesPost',params,1,t(postBins.bins));
        
    end
    
end

c = 0;
for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1}{1, iCond},2)
            c = c+1;
            for iChan = 1:96
                spikes = spikingActivity.validSection.BR.data.dom270{iChan}{iCond}{nDom};
                
            spikeTimes_BR_270{c}{iChan} = spikes;
            lfppieceBR270(c,iChan,:) = (((detrend(lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond}{nDom}))));
            end
        end
end

lfp_BR_90TO270 = squeeze(nanmean(lfppieceBR270(:,:,501:end-500),2));

% Do SFC

for iBin = 1:4
    
    for iTr = 1:size(lfppieceBR270,1)
        
        lfpTracePre = lfp_BR_90TO270(iTr,preBins.bins); % To preserve dimensional consistency. Is this okay?
        lfpTracePost = lfp_BR_90TO270(iTr,postBins.bins);
        
        spikesPre = [];
        spikesPost = [];
        
        for iChan = 1:length(pref90_br)
            if ~isempty(spikeTimes_BR_270{iTr}{pref90_br(iChan)})
                spikesTemp = spikeTimes_BR_270{iTr}{pref90_br(iChan)}./1000;
            else
                spikesTemp = [];
            end
            spikesPre = [spikesPre spikesTemp(spikesTemp<=t(preBins.bins(end)))];
            spikesPost = [spikesPost spikesTemp(spikesTemp>t(postBins.bins(1)))];
            
        end
        
        spikesPre = sort(spikesPre);
        spikesPost = sort(spikesPost);
        
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPre)/length(pref90_br)/Ts;
        RateEst     = numel(spikesPre)/length(pref90_br)/Ts;
        [SFC.sfc_BR_sel90_90TO270_Pre(iTr,:),SFC.phi_BR_sel90_90TO270_Pre(iTr,:),~,~,~,f_pre_BR.freqs]=coherencycpt(lfpTracePre',spikesPre',params',1,t(preBins.bins));
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPost)/length(pref90_br)/Ts;
        RateEst     = numel(spikesPost)/length(pref90_br)/Ts;
        [SFC.sfc_BR_sel90_90TO270_Post(iTr,:),SFC.phi_BR_sel90_90TO270_Post(iTr,:),~,~,~,f_post_BR.freqs]=coherencycpt(lfpTracePost',spikesPost',params,1,t(postBins.bins));
        
    end
    
end

for iBin = 1:4
    
    for iTr = 1:size(lfppieceBR270,1)
        
        lfpTracePre = lfp_BR_90TO270(iTr,preBins.bins); % To preserve dimensional consistency. Is this okay?
        lfpTracePost = lfp_BR_90TO270(iTr,postBins.bins);
        
        spikesPre = [];
        spikesPost = [];
        
        for iChan = 1:length(pref270_br)
            if ~isempty(spikeTimes_BR_270{iTr}{pref270_br(iChan)})
                spikesTemp = spikeTimes_BR_270{iTr}{pref270_br(iChan)}./1000;
            else
                spikesTemp = [];
            end
            spikesPre = [spikesPre spikesTemp(spikesTemp<=t(preBins.bins(end)))];
            spikesPost = [spikesPost spikesTemp(spikesTemp>t(postBins.bins(1)))];
            
        end
        
        spikesPre = sort(spikesPre);
        spikesPost = sort(spikesPost);
        
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPre)/length(pref270_br)/Ts;
        RateEst     = numel(spikesPre)/length(pref270_br)/Ts;
        [SFC.sfc_BR_sel270_90TO270_Pre(iTr,:),SFC.phi_BR_sel270_90TO270_Pre(iTr,:),~,~,~,f_pre_BR.freqs]=coherencycpt(lfpTracePre',spikesPre',params',1,t(preBins.bins));
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPost)/length(pref270_br)/Ts;
        RateEst     = numel(spikesPost)/length(pref270_br)/Ts;
        [SFC.sfc_BR_sel270_90TO270_Post(iTr,:),SFC.phi_BR_sel270_90TO270_Post(iTr,:),~,~,~,f_post_BR.freqs]=coherencycpt(lfpTracePost',spikesPost',params,1,t(postBins.bins));
        
    end
    
end
    

% PA

% PA

c = 0;
for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1}{1, iCond},2)
            c = c+1;
            for iChan = 1:96
                spikes = spikingActivity.validSection.PA.data.dom90{iChan}{iCond}{nDom};
                
            spikeTimes_PA_90{c}{iChan} = spikes;
            lfppiecePA90(c,iChan,:) = (((detrend(lfpActivity.validSection.PA.data.dom90{1, iChan}{1, iCond}{nDom}))));
            end
        end
end

lfp_PA_270TO90 = squeeze(nanmean(lfppiecePA90(:,:,501:end-500),2));

% Do SFC

for iBin = 1:4
    
    for iTr = 1:size(lfppiecePA90,1)
        
        lfpTracePre = lfp_PA_270TO90(iTr,preBins.bins); % To preserve dimensional consistency. Is this okay?
        lfpTracePost = lfp_PA_270TO90(iTr,postBins.bins);
        
        spikesPre = [];
        spikesPost = [];
        
        for iChan = 1:length(pref90_pa)
            if ~isempty(spikeTimes_PA_90{iTr}{pref90_pa(iChan)})
                spikesTemp = spikeTimes_PA_90{iTr}{pref90_pa(iChan)}./1000;
            else
                spikesTemp = [];
            end
            spikesPre = [spikesPre spikesTemp(spikesTemp<=t(preBins.bins(end)))];
            spikesPost = [spikesPost spikesTemp(spikesTemp>t(postBins.bins(1)))];
            
        end
        
        spikesPre = sort(spikesPre);
        spikesPost = sort(spikesPost);
        
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPre)/length(pref90_pa)/Ts;
        RateEst     = numel(spikesPre)/length(pref90_pa)/Ts;
        [SFC.sfc_PA_sel90_270TO90_Pre(iTr,:),SFC.phi_PA_sel90_270TO90_Pre(iTr,:),~,~,~,f_pre_PA.freqs]=coherencycpt(lfpTracePre',spikesPre',params',1,t(preBins.bins));
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPost)/length(pref90_pa)/Ts;
        RateEst     = numel(spikesPost)/length(pref90_pa)/Ts;
        [SFC.sfc_PA_sel90_270TO90_Post(iTr,:),SFC.phi_PA_sel90_270TO90_Post(iTr,:),~,~,~,f_post_PA.freqs]=coherencycpt(lfpTracePost',spikesPost',params,1,t(postBins.bins));
        
    end
    
end

for iBin = 1:4
    
    for iTr = 1:size(lfppiecePA90,1)
        
        lfpTracePre = lfp_PA_270TO90(iTr,preBins.bins); % To preserve dimensional consistency. Is this okay?
        lfpTracePost = lfp_PA_270TO90(iTr,postBins.bins);
        
        spikesPre = [];
        spikesPost = [];
        
        for iChan = 1:length(pref270_pa)
            if ~isempty(spikeTimes_PA_90{iTr}{pref270_pa(iChan)})
                spikesTemp = spikeTimes_PA_90{iTr}{pref270_pa(iChan)}./1000;
            else
                spikesTemp = [];
            end
            spikesPre = [spikesPre spikesTemp(spikesTemp<=t(preBins.bins(end)))];
            spikesPost = [spikesPost spikesTemp(spikesTemp>t(postBins.bins(1)))];
            
        end
        
        spikesPre = sort(spikesPre);
        spikesPost = sort(spikesPost);
        
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPre)/length(pref270_pa)/Ts;
        RateEst     = numel(spikesPre)/length(pref270_pa)/Ts;
        [SFC.sfc_PA_sel270_270TO90_Pre(iTr,:),SFC.phi_PA_sel270_270TO90_Pre(iTr,:),~,~,~,f_pre_PA.freqs]=coherencycpt(lfpTracePre',spikesPre',params',1,t(preBins.bins));
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPost)/length(pref270_pa)/Ts;
        RateEst     = numel(spikesPost)/length(pref270_pa)/Ts;
        [SFC.sfc_PA_sel270_270TO90_Post(iTr,:),SFC.phi_PA_sel270_270TO90_Post(iTr,:),~,~,~,f_post_PA.freqs]=coherencycpt(lfpTracePost',spikesPost',params,1,t(postBins.bins));
        
    end
    
end

c = 0;
for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1}{1, iCond},2)
            c = c+1;
            for iChan = 1:96
                spikes = spikingActivity.validSection.PA.data.dom270{iChan}{iCond}{nDom};
                
            spikeTimes_PA_270{c}{iChan} = spikes;
            lfppiecePA270(c,iChan,:) = (((detrend(lfpActivity.validSection.PA.data.dom270{1, iChan}{1, iCond}{nDom}))));
            end
        end
end

lfp_PA_90TO270 = squeeze(nanmean(lfppiecePA270(:,:,501:end-500),2));

% Do SFC

for iBin = 1:4
    
    for iTr = 1:size(lfppiecePA270,1)
        
        lfpTracePre = lfp_PA_90TO270(iTr,preBins.bins); % To preserve dimensional consistency. Is this okay?
        lfpTracePost = lfp_PA_90TO270(iTr,postBins.bins);
        
        spikesPre = [];
        spikesPost = [];
        
        for iChan = 1:length(pref90_pa)
            if ~isempty(spikeTimes_PA_270{iTr}{pref90_pa(iChan)})
                spikesTemp = spikeTimes_PA_270{iTr}{pref90_pa(iChan)}./1000;
            else
                spikesTemp = [];
            end
            spikesPre = [spikesPre spikesTemp(spikesTemp<=t(preBins.bins(end)))];
            spikesPost = [spikesPost spikesTemp(spikesTemp>t(postBins.bins(1)))];
            
        end
        
        spikesPre = sort(spikesPre);
        spikesPost = sort(spikesPost);
        
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPre)/length(pref90_pa)/Ts;
        RateEst     = numel(spikesPre)/length(pref90_pa)/Ts;
        [SFC.sfc_PA_sel90_90TO270_Pre(iTr,:),SFC.phi_PA_sel90_90TO270_Pre(iTr,:),~,~,~,f_pre_PA.freqs]=coherencycpt(lfpTracePre',spikesPre',params',1,t(preBins.bins));
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPost)/length(pref90_pa)/Ts;
        RateEst     = numel(spikesPost)/length(pref90_pa)/Ts;
        [SFC.sfc_PA_sel90_90TO270_Post(iTr,:),SFC.phi_PA_sel90_90TO270_Post(iTr,:),~,~,~,f_post_PA.freqs]=coherencycpt(lfpTracePost',spikesPost',params,1,t(postBins.bins));
        
    end
    
end

for iBin = 1:4
    
    for iTr = 1:size(lfppiecePA270,1)
        
        lfpTracePre = lfp_PA_90TO270(iTr,preBins.bins); % To preserve dimensional consistency. Is this okay?
        lfpTracePost = lfp_PA_90TO270(iTr,postBins.bins);
        
        spikesPre = [];
        spikesPost = [];
        
        for iChan = 1:length(pref270_pa)
            if ~isempty(spikeTimes_PA_270{iTr}{pref270_pa(iChan)})
                spikesTemp = spikeTimes_PA_270{iTr}{pref270_pa(iChan)}./1000;
            else
                spikesTemp = [];
            end
            spikesPre = [spikesPre spikesTemp(spikesTemp<=t(preBins.bins(end)))];
            spikesPost = [spikesPost spikesTemp(spikesTemp>t(postBins.bins(1)))];
            
        end
        
        spikesPre = sort(spikesPre);
        spikesPost = sort(spikesPost);
        
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPre)/length(pref270_pa)/Ts;
        RateEst     = numel(spikesPre)/length(pref270_pa)/Ts;
        [SFC.sfc_PA_sel270_90TO270_Pre(iTr,:),SFC.phi_PA_sel270_90TO270_Pre(iTr,:),~,~,~,f_pre_PA.freqs]=coherencycpt(lfpTracePre',spikesPre',params',1,t(preBins.bins));
        Ts = (length(preBins.bins)/params.Fs); % Because of that one extra sample
        W  = 10/params.Fs;
        N  = Ts*params.Fs;
        K  = floor(2*N*W-1);%number of Slepians
        params.tapers   = [floor(W*N) K];
        AdjRateEst     = numel(spikesPost)/length(pref270_pa)/Ts;
        RateEst     = numel(spikesPost)/length(pref270_pa)/Ts;
        [SFC.sfc_PA_sel270_90TO270_Post(iTr,:),SFC.phi_PA_sel270_90TO270_Post(iTr,:),~,~,~,f_post_PA.freqs]=coherencycpt(lfpTracePost',spikesPost',params,1,t(postBins.bins));
        
    end
    
end
    
f.BR.pre = f_pre_BR;
f.BR.post = f_post_BR;

f.PA.pre = f_pre_PA;
f.PA.post = f_post_PA;

cd(sav_dir_psth)
save('MM_SFC_MUASel_1000ms_GlobalLFP_EnsembleSpiking.mat','SFC','f','-v7.3');

end
