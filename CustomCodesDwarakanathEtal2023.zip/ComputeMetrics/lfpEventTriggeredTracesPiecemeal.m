function lfpEventTriggeredTracesPiecemeal(lfpActivity, durs, sav_dir_psth)

% Collect event statistics for the four chosen LFP bands
% Abhilash D MPIBC 2017-18

cd(sav_dir_psth)

pad = 500;

filename = ['piecemeal_evtTriggered_blpTraces_' num2str(durs.domBehind) 'ms_Chebyshev1_' '.mat'];

t = linspace(-durs.domBehind/1000,durs.switch/1000,(durs.domBehind/2)+(durs.switch/2)+1);
[~,evtIdx] = min(abs(t-(0)));
midPoint = t(evtIdx);

%% Setup filters

[b2,a2] = cheby1(8,0.001,[20 40]/250); % beta
[b1,a1] = cheby1(4,0.001,[1 9]/250);
evtDur = 250;
%% Get Doms 90

buffer = 175;

for chan = 1:96
    
    % BR Dominances 90
    
    
    pre_beta_blp_BR_90_etTraces = [];
    pre_low_blp_BR_90_etTraces = [];
    post_beta_blp_BR_90_etTraces = [];
    post_low_blp_BR_90_etTraces = [];
    specgram_pre_BR_90 = [];
    specgram_post_BR_90 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, chan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, chan}{1, iCond},2)
            lfppiece = ((((lfpActivity.validSection.BR.data.dom90{1, chan}{1, iCond}{nDom}))));
            [val,~] = max(lfppiece);
            if val<=750
                lowFiltLfpPiece = filtfilt(b1,a1,lfppiece);
                lfpAmp = abs(hilbert(lowFiltLfpPiece)); % Squaring works better
                lfpevents = event_detection(detrend(lfpAmp),4,'stdgauss',evtDur);
                lfpevents(lfpevents<=pad) = [];
                lfpevents(lfpevents>=(length(t)+pad)) = [];
                lfpevents = lfpevents-pad;
                lowFiltLfpPiece = lowFiltLfpPiece(pad+1:end-pad);
                
                if ~isempty(lfpevents)
                    
                    for iEvt = 1:length(lfpevents)
                        
                        if lfpevents(iEvt) <= evtIdx && lfpevents(iEvt) > buffer
                            
                            highFiltLfpPiece = filtfilt(b2,a2,lfppiece);
                            highFiltLfpPiece = highFiltLfpPiece(pad+1:end-pad);
                            pre_beta_blp_BR_90_etTraces = [pre_beta_blp_BR_90_etTraces highFiltLfpPiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)];
                            pre_low_blp_BR_90_etTraces = [pre_low_blp_BR_90_etTraces lowFiltLfpPiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)];
                            lfppiece = lfppiece(pad+1:end-pad);
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]);
                            specgram = abs(specgram.^2);
                            specgram_pre_BR_90 = cat(3,specgram_pre_BR_90,specgram);
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter
                            
                        elseif lfpevents(iEvt) >= evtIdx && lfpevents(iEvt) < length(t)-buffer
                            
                            highFiltLfpPiece = filtfilt(b2,a2,lfppiece);
                            highFiltLfpPiece = highFiltLfpPiece(pad+1:end-pad);
                            post_beta_blp_BR_90_etTraces = [post_beta_blp_BR_90_etTraces highFiltLfpPiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)];
                            post_low_blp_BR_90_etTraces = [post_low_blp_BR_90_etTraces lowFiltLfpPiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)];
                            lfppiece = lfppiece(pad+1:end-pad);
                            ettrace = lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer);
                            [specgram, f]=cwt(ettrace,'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]);
                            specgram = abs(specgram.^2);
                            specgram_post_BR_90 = cat(3,specgram_post_BR_90,specgram);
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter

                        end
                        
                    end
                    
                end
                
            end
            
        end
        
    end
    
    eventTriggeredTraces(chan).BR.dom90.Pre.low = pre_low_blp_BR_90_etTraces;
    eventTriggeredTraces(chan).BR.dom90.Pre.beta = pre_beta_blp_BR_90_etTraces;
    eventTriggeredTraces(chan).BR.dom90.Post.low = post_low_blp_BR_90_etTraces;
    eventTriggeredTraces(chan).BR.dom90.Post.beta = post_beta_blp_BR_90_etTraces;
    eventTriggeredTraces(chan).BR.dom90.Pre.specgram = nanmean(specgram_pre_BR_90,3);
    eventTriggeredTraces(chan).BR.dom90.Post.specgram = nanmean(specgram_post_BR_90,3);
    
    % BR dom 270
    
    pre_beta_blp_BR_270_etTraces = [];
    pre_low_blp_BR_270_etTraces = [];
    post_beta_blp_BR_270_etTraces = [];
    post_low_blp_BR_270_etTraces = [];
    specgram_pre_BR_270 = [];
    specgram_post_BR_270 = [];
    
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, chan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, chan}{1, iCond},2)
            lfppiece = ((((lfpActivity.validSection.BR.data.dom270{1, chan}{1, iCond}{nDom}))));
            [val,~] = max(lfppiece);
            if val<=750
                lowFiltLfpPiece = filtfilt(b1,a1,lfppiece);
                lfpAmp = abs(hilbert(lowFiltLfpPiece)); % Squaring works better
                lfpevents = event_detection(detrend(lfpAmp),4,'stdgauss',evtDur);
                lfpevents(lfpevents<=pad) = [];
                lfpevents(lfpevents>=(length(t)+pad)) = [];
                lfpevents = lfpevents-pad;
                lowFiltLfpPiece = lowFiltLfpPiece(pad+1:end-pad);
                
                if ~isempty(lfpevents)
                    
                    for iEvt = 1:length(lfpevents)
                        
                        if lfpevents(iEvt) <= evtIdx && lfpevents(iEvt) > buffer
                            
                            highFiltLfpPiece = filtfilt(b2,a2,lfppiece);
                            highFiltLfpPiece = highFiltLfpPiece(pad+1:end-pad);
                            pre_beta_blp_BR_270_etTraces = [pre_beta_blp_BR_270_etTraces highFiltLfpPiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)];
                            pre_low_blp_BR_270_etTraces = [pre_low_blp_BR_270_etTraces lowFiltLfpPiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)];
                            lfppiece = lfppiece(pad+1:end-pad);
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]);
                            specgram = abs(specgram.^2);
                            specgram_pre_BR_270 = cat(3,specgram_pre_BR_270,specgram);
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter
                            
                        elseif lfpevents(iEvt) >= evtIdx && lfpevents(iEvt) < length(t)-buffer
                            
                            highFiltLfpPiece = filtfilt(b2,a2,lfppiece);
                            highFiltLfpPiece = highFiltLfpPiece(pad+1:end-pad);
                            post_beta_blp_BR_270_etTraces = [post_beta_blp_BR_270_etTraces highFiltLfpPiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)];
                            post_low_blp_BR_270_etTraces = [post_low_blp_BR_270_etTraces lowFiltLfpPiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)];
                            lfppiece = lfppiece(pad+1:end-pad);
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]);
                            specgram = abs(specgram.^2);
                            specgram_post_BR_270 = cat(3,specgram_post_BR_270,specgram);
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter
                            
                        end
                        
                    end
                    
                end
                
            end
            
        end
        
    end
    
    eventTriggeredTraces(chan).BR.dom270.Pre.low = pre_low_blp_BR_270_etTraces;
    eventTriggeredTraces(chan).BR.dom270.Pre.beta = pre_beta_blp_BR_270_etTraces;
    eventTriggeredTraces(chan).BR.dom270.Post.low = post_low_blp_BR_270_etTraces;
    eventTriggeredTraces(chan).BR.dom270.Post.beta = post_beta_blp_BR_270_etTraces;
    eventTriggeredTraces(chan).BR.dom270.Pre.specgram = nanmean(specgram_pre_BR_270,3);
    eventTriggeredTraces(chan).BR.dom270.Post.specgram = nanmean(specgram_post_BR_270,3);
    
    
    
end
            
save(filename,'eventTriggeredTraces','f','-v7.3')
