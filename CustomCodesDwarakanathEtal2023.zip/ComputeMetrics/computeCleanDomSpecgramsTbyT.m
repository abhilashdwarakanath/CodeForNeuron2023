function [spectrograms] = computeCleanDomSpecgramsTbyT(lfpActivity,sav_dir_psth,durs,tag)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

cd(sav_dir_psth)

filename = ['MM_cleanDomSpecgrams_trialByTrial_' tag '.mat'];

%% Collect activity


c = 0;
for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            piece = (lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece) & max(piece) < 750
                [specgram,f] = cwt(piece(501:end-500)','morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
                specgram = abs(specgram.^2);
                specgram_BR_90(c,iChan,:,:) = zscore(specgram,[],1);
            end
        end
    end
end

specgram_BR_90 = squeeze(nanmean(specgram_BR_90,2));


c = 0;
for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            piece = (lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece) & max(piece) < 750
                [specgram,f] = cwt(piece(501:end-500)','morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
                specgram = abs(specgram.^2);
                specgram_BR_270(c,iChan,:,:) = zscore(specgram,[],1);
            end
        end
    end
end

specgram_BR_270 = squeeze(nanmean(specgram_BR_270,2));

% Collect both together

specgram_BR = cat(1,specgram_BR_90,specgram_BR_270);

clear specgram_BR_90;
clear specgram_BR_270;

c = 0;
for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            piece = (lfpActivity.validSection.PA.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece) & max(piece) < 750
                [specgram,f] = cwt(piece(501:end-500)','morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
                specgram = abs(specgram.^2);
                specgram_PA_90(c,iChan,:,:) = zscore(specgram,[],1);
            end
        end
    end
end

specgram_PA_90 = squeeze(nanmean(specgram_PA_90,2));

c = 0;
for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            piece = (lfpActivity.validSection.PA.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece) & max(piece) < 750
                [specgram,f] = cwt(piece(501:end-500)','morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
                specgram = abs(specgram.^2);
                specgram_PA_270(c,iChan,:,:) = zscore(specgram,[],1);
            end
        end
    end
end

specgram_PA_270 = squeeze(nanmean(specgram_PA_270,2));

specgram_PA = cat(1,specgram_PA_90,specgram_PA_270);

clear specgram_PA_90;
clear specgram_PA_270;

fprintf('Computation of spectrograms done, saving...\n')

%% Collect the output

spectrograms.PA = specgram_PA;
spectrograms.BR = specgram_BR;
spectrograms.f = f;

save(filename,'spectrograms','-v7.3');

end