function collectBBLowEventsMyDetection(dur)

% Load structure

dbstop if error

cd('C:\Users\AD263755\Documents\MATLAB\NeuronPaper_MasterStructure')

load('trialSegmentedStructs_v2.mat')

nDatasets = length(neuralActivity);
t = neuralActivity(1).t;
tEvt = neuralActivity(1).tEvt;
params.elecs = 96;
params.pad = 500;
params.buffer = 75;
params.fs = 500;

%% Collect shit

for iDataset = 1:nDatasets

    %Maps

    chans = 1:96;
    elecs = [78 88 68 58 56 48 57 38 47 28 37 27 36 18 45 17 46 8 35 16 24 7 26 6 25 5 15 4 14 3 13 2 77 67 76 66 75 65 74 64 73 54 63 53 72 43 62 55 61 44 52 33 51 34 41 42 31 32 21 22 11 23 10 12 96 87 95 86 94 85 93 84 92 83 91 82 90 81 89 80 79 71 69 70 59 60 50 49 40 39 30 29 19 20 1 9];
    chan2elec = [chans' elecs'];

    if iDataset < 5
        monkID = 'H07';
        map.layout = [NaN	88	78	68	58	48	38	28	18	NaN
            96	87	77	67	57	47	37	27	17	8
            95	86	76	66	56	46	36	26	16	7
            94	85	75	65	55	45	35	25	15	6
            93	84	74	64	54	44	34	24	14	5
            92	83	73	63	53	43	33	23	13	4
            91	82	72	62	52	42	32	22	12	3
            90	81	71	61	51	41	31	21	11	2
            89	80	70	60	50	40	30	20	10	1
            NaN	79	69	59	49	39	29	19	9	NaN];
        map.chan2elec = chan2elec;
    else
        monkID = 'A11';
        map.layout = [NaN    88    78    68    58    48    38    28    18   8
            96    87    77    67    57    47    37    27    17     7
            95    86    76    66    56    46    36    26    16     6
            94    85    75    65    55    45    35    25    15     5
            93    84    74    64    54    44    34    24    14     NaN
            92    83    73    63    53    43    33    23    13     4
            91    82    72    62    52    42    32    22    12     3
            90    81    71    61    51    41    31    21    11     2
            89    80    70    60    50    40    30    20    10     1
            NaN    79    69    59    49    39    29    19     9   NaN];
        map.chan2elec = chan2elec;
    end

    % Selective channels

    pref90_br = neuralActivity(iDataset).sel.BR.upward;
    pref270_br = neuralActivity(iDataset).sel.BR.downpward;

    %% Get data

    lfpActivity = neuralActivity(iDataset).lfp;
    spikingActivity = neuralActivity(iDataset).spikes;

    %% Setup filters

    fprintf('Setup IIR filters...\n')

    [b1,a1] = butter(4,[1 9]/250); % low
    evtDurL = 56;

    [b2,a2] = butter(4,[20 40]/250); % beta
    evtDurB = 12;

    %% Collect BR

    fprintf('START PROCESSING...\n')

    for iChan = 1:params.elecs
        c = 0;
        for iCond = 1:length(spikingActivity.validSection.BR.data.dom90{iChan})
            for iSwitch = 1:length(spikingActivity.validSection.BR.data.dom90{iChan}{iCond})
                tic;
                c = c+1; clear piece; clear lowPiece; clear betaPiece; clear lowEvts; clear betaEvts; clear negBBEvts; clear posBBEvts; clear trigCWT;
                clear trigLFP; clear negEvtTrigLFP; clear negEvtTrigCWT; clear posEvtTrigLFP; clear posEvtTrigCWT;clear negEvtTrigSpikes; clear posEvtTrigSpikes; clear negEvtTrigPhase; clear posEvtTrigTrace; clear negEvtTrigLowPhase; clear posEvtTrigLowPhase;
                spikingEvents.s270TO90{c}{iChan} = spikingActivity.validSection.BR.data.dom90{iChan}{iCond}{iSwitch};
                piece = lfpActivity.validSection.BR.data.dom90{iChan}{iCond}{iSwitch};
                [negBBEvts, posBBEvts] = getThresholdCrossingEvents(piece(params.pad+1:end-params.pad,1),3.5,evtDurB);
                % collect broadband LFP triggered on these events and
                % compute spectrum
                negBBEvts = negBBEvts + params.pad; posBBEvts = posBBEvts + params.pad;

                if ~isempty(negBBEvts)

                    for iEvt = 1:length(negBBEvts)

                        evtTime = t(negBBEvts(iEvt)-params.pad);
                        spkSamps = (spikingEvents.s270TO90{c}{iChan}./1e3);
                        trigSpikes = (spkSamps(spkSamps>=evtTime-0.150 & spkSamps<=evtTime+0.150)).*1e3;
                        trigLFP = piece(negBBEvts(iEvt)-params.buffer:negBBEvts(iEvt)+params.buffer-1);
                        tmp = angle(hilbert(filtfilt(b1,a1,piece)));
                        negEvtTrigLowPhase(iEvt,:) = tmp(negBBEvts(iEvt)-params.buffer:negBBEvts(iEvt)+params.buffer-1);
                        tmp = angle(hilbert(piece));
                        negEvtTrigPhase(iEvt,:) = tmp(negBBEvts(iEvt)-params.buffer:negBBEvts(iEvt)+params.buffer-1);
                        negEvtTrigLFP(iEvt,:) = trigLFP;
                        negEvtTrigSpikes{iEvt} = trigSpikes;

                    end

                else

                    negEvtTrigLFP = [];
                    negEvtTrigPhase = [];
                    negEvtTrigLowPhase = [];
                    negEvtTrigSpikes = [];

                end

                if ~isempty(posBBEvts)

                    for iEvt = 1:length(posBBEvts)

                        evtTime = t(posBBEvts(iEvt)-params.pad);
                        spkSamps = (spikingEvents.s270TO90{c}{iChan}./1e3);
                        trigSpikes = (spkSamps(spkSamps>=evtTime-0.150 & spkSamps<=evtTime+0.150)).*1e3;
                        trigLFP = piece(posBBEvts(iEvt)-params.buffer:posBBEvts(iEvt)+params.buffer-1);
                        tmp = angle(hilbert(filtfilt(b1,a1,piece)));
                        posEvtTrigLowPhase(iEvt,:) = tmp(posBBEvts(iEvt)-params.buffer:posBBEvts(iEvt)+params.buffer-1);
                        tmp = angle(hilbert(piece));
                        posEvtTrigPhase(iEvt,:) = tmp(posBBEvts(iEvt)-params.buffer:posBBEvts(iEvt)+params.buffer-1);
                        posEvtTrigLFP(iEvt,:) = trigLFP;
                        posEvtTrigSpikes{iEvt} = trigSpikes;

                    end

                else

                    posEvtTrigLFP = [];
                    posEvtTrigLowPhase = [];
                    posEvtTrigPhase = [];
                    posEvtTrigSpikes = [];

                end

                negBBEvts = negBBEvts - params.pad;
                posBBEvts = posBBEvts - params.pad;
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                betaPiece = abs(hilbert(filter(b2,a2,piece)));
                lowEvts = event_detection(lowPiece,3.5,'stdgauss',evtDurL);
                lowEvts(lowEvts<= params.pad+1) = []; lowEvts(lowEvts >= params.pad+length(t)-1) = [];
                lowEvts = lowEvts - params.pad;
                betaEvts = event_detection(betaPiece,3.5,'stdgauss',evtDurB);
                betaEvts(betaEvts<= params.pad+1) = []; betaEvts(betaEvts >= params.pad+length(t)-1) = [];
                betaEvts = betaEvts - params.pad;
                lfpEvents.low.s270TO90.instAmp(c,iChan,:) = lowPiece(params.pad+1:end-params.pad);
                lfpEvents.beta.s270TO90.instAmp(c,iChan,:) = betaPiece(params.pad+1:end-params.pad);
                lfpEvents.bb.s270TO90.traces(c,iChan,:) = piece(params.pad+1:end-params.pad);
                lfpEvents.low.s270TO90.events(c,iChan).times = t(lowEvts);
                lfpEvents.beta.s270TO90.events(c,iChan).times = t(betaEvts);
                lfpEvents.bb.s270TO90.negEvents(c,iChan).times = t(negBBEvts);
                lfpEvents.bb.s270TO90.posEvents(c,iChan).times = t(posBBEvts);
                lfpEvents.bb.s270TO90.negEvents(c,iChan).negEvtTrigLFP = negEvtTrigLFP;
                lfpEvents.bb.s270TO90.posEvents(c,iChan).posEvtTrigLFP = posEvtTrigLFP;
                lfpEvents.bb.s270TO90.negEvents(c,iChan).negEvtTrigPhase = negEvtTrigPhase;
                lfpEvents.bb.s270TO90.posEvents(c,iChan).posEvtTrigPhase = posEvtTrigPhase;
                lfpEvents.bb.s270TO90.negEvents(c,iChan).negEvtTrigLowPhase = negEvtTrigLowPhase;
                lfpEvents.bb.s270TO90.posEvents(c,iChan).posEvtTrigLowPhase = posEvtTrigLowPhase;
                spikingEvents.bb.s270TO90.negEvents(c,iChan).negEvtTrigSpikes = negEvtTrigSpikes;
                spikingEvents.bb.s270TO90.posEvents(c,iChan).posEvtTrigSpikes = posEvtTrigSpikes;
                lowTrace = lowPiece(params.pad+1:end-params.pad);
                betaTrace = betaPiece(params.pad+1:end-params.pad);
                bbTrace = piece(params.pad+1:end-params.pad);
                lfpEvents.low.s270TO90.events(c,iChan).times = t(lowEvts);
                lfpEvents.beta.s270TO90.events(c,iChan).times = t(betaEvts);
                lfpEvents.bb.s270TO90.negEvents(c,iChan).times = t(negBBEvts);
                lfpEvents.bb.s270TO90.posEvents(c,iChan).times = t(posBBEvts);
                lfpEvents.low.s270TO90.events(c,iChan).amplitudes = lowTrace(lowEvts);
                lfpEvents.beta.s270TO90.events(c,iChan).amplitudes = betaTrace(betaEvts);
                lfpEvents.bb.s270TO90.negEvents(c,iChan).amplitudes = bbTrace(negBBEvts);
                lfpEvents.bb.s270TO90.posEvents(c,iChan).amplitudes = bbTrace(posBBEvts);

                toc;

            end
        end
    end

    for iChan = 1:params.elecs
        c = 0;
        for iCond = 1:length(spikingActivity.validSection.BR.data.dom270{iChan})
            for iSwitch = 1:length(spikingActivity.validSection.BR.data.dom270{iChan}{iCond})
                tic;
                c = c+1; clear piece; clear lowPiece; clear betaPiece; clear lowEvts; clear betaEvts; clear negBBEvts; clear posBBEvts; clear trigCWT;
                clear trigLFP; clear negEvtTrigLFP; clear negEvtTrigCWT; clear posEvtTrigLFP; clear posEvtTrigCWT;clear negEvtTrigSpikes; clear posEvtTrigSpikes; clear negEvtTrigPhase; clear posEvtTrigTrace; clear negEvtTrigLowPhase; clear posEvtTrigLowPhase;
                spikingEvents.s90TO270{c}{iChan} = spikingActivity.validSection.BR.data.dom270{iChan}{iCond}{iSwitch};
                piece = lfpActivity.validSection.BR.data.dom270{iChan}{iCond}{iSwitch};
                [negBBEvts, posBBEvts] = getThresholdCrossingEvents(piece(params.pad+1:end-params.pad,1),3.5,evtDurB);
                % collect broadband LFP triggered on these events and
                % compute spectrum
                negBBEvts = negBBEvts + params.pad; posBBEvts = posBBEvts + params.pad;

                if ~isempty(negBBEvts)

                    for iEvt = 1:length(negBBEvts)

                        evtTime = t(negBBEvts(iEvt)-params.pad);
                        spkSamps = (spikingEvents.s90TO270{c}{iChan}./1e3);
                        trigSpikes = (spkSamps(spkSamps>=evtTime-0.150 & spkSamps<=evtTime+0.150)).*1e3;
                        trigLFP = piece(negBBEvts(iEvt)-params.buffer:negBBEvts(iEvt)+params.buffer-1);
                        tmp = angle(hilbert(filtfilt(b1,a1,piece)));
                        negEvtTrigLowPhase(iEvt,:) = tmp(negBBEvts(iEvt)-params.buffer:negBBEvts(iEvt)+params.buffer-1);
                        tmp = angle(hilbert(piece));
                        negEvtTrigPhase(iEvt,:) = tmp(negBBEvts(iEvt)-params.buffer:negBBEvts(iEvt)+params.buffer-1);
                        negEvtTrigLFP(iEvt,:) = trigLFP;
                        negEvtTrigSpikes{iEvt} = trigSpikes;

                    end

                else

                    negEvtTrigLFP = [];
                    negEvtTrigPhase = [];
                    negEvtTrigLowPhase = [];
                    negEvtTrigSpikes = [];

                end

                if ~isempty(posBBEvts)

                    for iEvt = 1:length(posBBEvts)

                        evtTime = t(posBBEvts(iEvt)-params.pad);
                        spkSamps = (spikingEvents.s90TO270{c}{iChan}./1e3);
                        trigSpikes = (spkSamps(spkSamps>=evtTime-0.150 & spkSamps<=evtTime+0.150)).*1e3;
                        trigLFP = piece(posBBEvts(iEvt)-params.buffer:posBBEvts(iEvt)+params.buffer-1);
                        tmp = angle(hilbert(filtfilt(b1,a1,piece)));
                        posEvtTrigLowPhase(iEvt,:) = tmp(posBBEvts(iEvt)-params.buffer:posBBEvts(iEvt)+params.buffer-1);
                        tmp = angle(hilbert(piece));
                        posEvtTrigPhase(iEvt,:) = tmp(posBBEvts(iEvt)-params.buffer:posBBEvts(iEvt)+params.buffer-1);
                        posEvtTrigLFP(iEvt,:) = trigLFP;
                        posEvtTrigSpikes{iEvt} = trigSpikes;

                    end

                else

                    posEvtTrigLFP = [];
                    posEvtTrigLowPhase = [];
                    posEvtTrigPhase = [];
                    posEvtTrigSpikes = [];

                end

                negBBEvts = negBBEvts - params.pad;
                posBBEvts = posBBEvts - params.pad;
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                betaPiece = abs(hilbert(filter(b2,a2,piece)));
                lowEvts = event_detection(lowPiece,3.5,'stdgauss',evtDurL);
                lowEvts(lowEvts<= params.pad+1) = []; lowEvts(lowEvts >= params.pad+length(t)-1) = [];
                lowEvts = lowEvts - params.pad;
                betaEvts = event_detection(betaPiece,3.5,'stdgauss',evtDurB);
                betaEvts(betaEvts<= params.pad+1) = []; betaEvts(betaEvts >= params.pad+length(t)-1) = [];
                betaEvts = betaEvts - params.pad;
                lfpEvents.low.s90TO270.instAmp(c,iChan,:) = lowPiece(params.pad+1:end-params.pad);
                lfpEvents.beta.s90TO270.instAmp(c,iChan,:) = betaPiece(params.pad+1:end-params.pad);
                lfpEvents.bb.s90TO270.traces(c,iChan,:) = piece(params.pad+1:end-params.pad);
                lfpEvents.low.s90TO270.events(c,iChan).times = t(lowEvts);
                lfpEvents.beta.s90TO270.events(c,iChan).times = t(betaEvts);
                lfpEvents.bb.s90TO270.negEvents(c,iChan).times = t(negBBEvts);
                lfpEvents.bb.s90TO270.posEvents(c,iChan).times = t(posBBEvts);
                lfpEvents.bb.s90TO270.negEvents(c,iChan).negEvtTrigLFP = negEvtTrigLFP;
                lfpEvents.bb.s90TO270.posEvents(c,iChan).posEvtTrigLFP = posEvtTrigLFP;
                lfpEvents.bb.s90TO270.negEvents(c,iChan).negEvtTrigPhase = negEvtTrigPhase;
                lfpEvents.bb.s90TO270.posEvents(c,iChan).posEvtTrigPhase = posEvtTrigPhase;
                lfpEvents.bb.s90TO270.negEvents(c,iChan).negEvtTrigLowPhase = negEvtTrigLowPhase;
                lfpEvents.bb.s90TO270.posEvents(c,iChan).posEvtTrigLowPhase = posEvtTrigLowPhase;
                spikingEvents.bb.s90TO270.negEvents(c,iChan).negEvtTrigSpikes = negEvtTrigSpikes;
                spikingEvents.bb.s90TO270.posEvents(c,iChan).posEvtTrigSpikes = posEvtTrigSpikes;
                lowTrace = lowPiece(params.pad+1:end-params.pad);
                betaTrace = betaPiece(params.pad+1:end-params.pad);
                bbTrace = piece(params.pad+1:end-params.pad);
                lfpEvents.low.s90TO270.events(c,iChan).times = t(lowEvts);
                lfpEvents.beta.s90TO270.events(c,iChan).times = t(betaEvts);
                lfpEvents.bb.s90TO270.negEvents(c,iChan).times = t(negBBEvts);
                lfpEvents.bb.s90TO270.posEvents(c,iChan).times = t(posBBEvts);
                lfpEvents.low.s90TO270.events(c,iChan).amplitudes = lowTrace(lowEvts);
                lfpEvents.beta.s90TO270.events(c,iChan).amplitudes = betaTrace(betaEvts);
                lfpEvents.bb.s90TO270.negEvents(c,iChan).amplitudes = bbTrace(negBBEvts);
                lfpEvents.bb.s90TO270.posEvents(c,iChan).amplitudes = bbTrace(posBBEvts);

                toc;

            end
        end
    end


    neuralEvents(iDataset).lfp = lfpEvents;
    neuralEvents(iDataset).spikes = spikingEvents;
    neuralEvents(iDataset).selChans.upward = pref90_br;
    neuralEvents(iDataset).selChans.downward = pref270_br;
    neuralEvents(iDataset).t = t;
    neuralEvents(iDataset).tEvt = tEvt;
    neuralEvents(iDataset).params = params;
    neuralEvents(iDataset).subjID = monkID;
    neuralEvents(iDataset).map = map;

    fprintf('Processed dataset %d of %d...\n',iDataset,length(neuralActivity));

end

%% Save shit

fprintf('All datasets processed...\n')
fprintf('Navigating to results folder...\n')
cd('C:\Users\AD263755\Documents\MATLAB\NeuronPaper_MasterStructure\')
fprintf('Saving structure...\n')
save(['eventsData_BR_v9_' num2str(dur) 'ms.mat'],'neuralEvents','-v7.3')

end
