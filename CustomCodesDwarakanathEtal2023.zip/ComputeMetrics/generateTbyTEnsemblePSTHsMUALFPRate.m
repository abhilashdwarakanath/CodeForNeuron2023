function generateTbyTEnsemblePSTHsMUALFPRate

dbstop if error

datasets{1} = 'B:\H07\12-06-2016\PFC\Bfsgrad1';
recDate{1} = '12062016';
fileID{1} = '12-06-2016';
subjID{1} = 'Hayo';
datasets{2} = 'B:\H07\13-07-2016\PFC\Bfsgrad1';
recDate{2} = '13072016';
fileID{2} = '13-07-2016';
subjID{2} = 'Hayo';
datasets{3} = 'B:\H07\20161019\PFC\Bfsgrad1';
recDate{3} = '19102016';
fileID{3} = '20161019';
subjID{3} = 'Hayo';
datasets{4} = 'B:\H07\20161025\PFC\Bfsgrad1';
recDate{4} = '25102016';
fileID{4} = '20161025';
subjID{4} = 'Hayo';
datasets{5} = 'B:\A11\20170305\PFC\Bfsgrad1';
recDate{5} = '05032017';
fileID{5} = '20170305';
subjID{5} = 'Anton';
datasets{6} = 'B:\A11\20170302\PFC\Bfsgrad1';
recDate{6} = '02032017';
fileID{6} = '20170302';
subjID{6} = 'Anton';

prefInfoPaths{1} = 'B:\Results\H07\12-06-2016\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{2} = 'B:\Results\H07\13-07-2016\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{3} = 'B:\Results\H07\20161019\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{4} = 'B:\Results\H07\20161025\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{5} = 'B:\Results\A11\20170305\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{6} = 'B:\Results\A11\20170302\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';

%% Load SU Spikes By Time

for iDataset = 1:6
    
    cd(datasets{iDataset})
    load jMUSpikesByTime.mat
    
    cd(prefInfoPaths{iDataset})
    load('1000_250_1000_DF_pref_array_switch.mat')
    
    %     pref90_br = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==2);
    %     pref90_br = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref90_br,3);
    %
    %     pref270_br = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==1);
    %     pref270_br = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref270_br,3);
    %
    %     pref90_pa = find(pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(:,2)==2);
    %     pref90_pa = pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(pref90_pa,3);
    %
    %     pref270_pa = find(pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(:,2)==1);
    %     pref270_pa = pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(pref270_pa,3);
    
    pref90_br_bs = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==2);
    pref90_br_as = find(pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,2)==2);
    pref90_br_bsas = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==2);
    pref90_br_bs = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref90_br_bs,3);
    pref90_br_as = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(pref90_br_as,3);
    pref90_br_bsas = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref90_br_bsas,3);
    
    pref90_br = unique([pref90_br_bs;pref90_br_as;pref90_br_bsas]);
    
    
    pref270_br_bs = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==1);
    pref270_br_as = find(pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,2)==1);
    pref270_br_bsas = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==1);
    pref270_br_bs = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref270_br_bs,3);
    pref270_br_as = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(pref270_br_as,3);
    pref270_br_bsas = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref270_br_bsas,3);
    
    pref270_br = unique([pref270_br_bs;pref270_br_as;pref270_br_bsas]);
    
    pref90_pa_bs = find(pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,2)==2);
    pref90_pa_as = find(pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(:,2)==2);
    pref90_pa_bsas = find(pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(:,2)==2);
    pref90_pa_bs = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(pref90_pa_bs,3);
    pref90_pa_as = pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(pref90_pa_as,3);
    pref90_pa_bsas = pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(pref90_pa_bsas,3);
    
    pref90_pa = unique([pref90_pa_bs;pref90_pa_as;pref90_pa_bsas]);
    
    
    pref270_pa_bs = find(pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,2)==1);
    pref270_pa_as = find(pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(:,2)==1);
    pref270_pa_bsas = find(pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(:,2)==1);
    pref270_pa_bs = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(pref270_pa_bs,3);
    pref270_pa_as = pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(pref270_pa_as,3);
    pref270_pa_bsas = pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(pref270_pa_bsas,3);
    
    pref270_pa = unique([pref270_pa_bs;pref270_pa_as;pref270_pa_bsas]);
    
    pad = 500;
    
    t = linspace(-1000,1000,2000);
    
    %% Collect clean dominances
    
    durs.switch = 250;
    durs.domForward = 1000;
    durs.domBehind = 1000;
    params.elecs = 96;
    params.conditions = 8;
    
    % Load relevant LFPs and Spikes
    cd(datasets{iDataset})
    
    eventfile = 'finalevents_audio.mat';
    spikeFile = 'jMUSpikesByTime.mat';
    qnxfile = [subjID{iDataset} '_' recDate{iDataset} '_' 'Bfsgrad1' '.dgz'];
    
    load('lfpByTrial.mat')
    
    fprintf('Processing Dataset %d of : %d \n',iDataset,6)
    
    % Compute Statistics and Spectrograms
    
    sav_dir = [datasets{iDataset} '\EnsemblePSTHs\MM'];
    mkdir(sav_dir)
    if strcmp(subjID{iDataset},'Hayo')==1
        monkID = 'H07';
    else
        monkID = 'A11';
    end
    
    trialInformation = collectTrialInformationMM(params,qnxfile,eventfile,'pfc','lfp');
    [lfpActivity] = collectCleanDominancesLFPMM(params,LFP,jMUspikes,durs);
    [spikingActivity] = collectCleanDominancesSpikesMM(params,jMUspikes,durs);
    
    %% Setup filter
    
    [b1,a1] = cheby1(4,0.001,[1 9]/250); % low
    evtDur = 56;
    
    %% Collect BR
    
    tLFP = linspace(-1000,1000,1001);
    
    for iChan = 1:96
        c = 0;
        for iCond = 1:length(spikingActivity.validSection.BR.data.dom90{iChan})
            for iSwitch = 1:length(spikingActivity.validSection.BR.data.dom90{iChan}{iCond})
                c = c+1; clear spikesPiece; clear lowPiece
                cleanSwitches.BR.s270TO90{iChan}{c} = spikingActivity.validSection.BR.data.dom90{iChan}{iCond}{iSwitch};
                piece = lfpActivity.validSection.BR.data.dom90{iChan}{iCond}{iSwitch};
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                
                lfpSwitches.low.BR.s270TO90(c,iChan,:) = lowPiece(501:end-500);
            end
        end
    end
    
    for iChan = 1:96
        c = 0;
        for iCond = 1:length(spikingActivity.validSection.BR.data.dom270{iChan})
            for iSwitch = 1:length(spikingActivity.validSection.BR.data.dom270{iChan}{iCond})
                c = c+1; clear spikesPiece; clear lowPiece
                cleanSwitches.BR.s90TO270{iChan}{c} = spikingActivity.validSection.BR.data.dom270{iChan}{iCond}{iSwitch};
                piece = lfpActivity.validSection.BR.data.dom270{iChan}{iCond}{iSwitch};
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                lfpSwitches.low.BR.s90TO270(c,iChan,:) = lowPiece(501:end-500);
            end
        end
    end
    
    %% Collect PA
    for iChan = 1:96
        c = 0;
        for iCond = 1:length(spikingActivity.validSection.PA.data.dom90{iChan})
            for iSwitch = 1:length(spikingActivity.validSection.PA.data.dom90{iChan}{iCond})
                c = c+1; clear spikesPiece; clear lowPiece
                cleanSwitches.PA.s270TO90{iChan}{c} = spikingActivity.validSection.PA.data.dom90{iChan}{iCond}{iSwitch};
                piece = lfpActivity.validSection.PA.data.dom90{iChan}{iCond}{iSwitch};
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                lfpSwitches.low.PA.s270TO90(c,iChan,:) = lowPiece(501:end-500);
            end
        end
    end
    
    for iChan = 1:96
        c = 0;
        for iCond = 1:length(spikingActivity.validSection.PA.data.dom270{iChan})
            for iSwitch = 1:length(spikingActivity.validSection.PA.data.dom270{iChan}{iCond})
                c = c+1; clear spikesPiece; clear lowPiece
                cleanSwitches.PA.s90TO270{iChan}{c} = spikingActivity.validSection.PA.data.dom270{iChan}{iCond}{iSwitch};
                piece = lfpActivity.validSection.PA.data.dom270{iChan}{iCond}{iSwitch};
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                lfpSwitches.low.PA.s90TO270(c,iChan,:) = lowPiece(501:end-500);
            end
        end
    end
    
    %% Process SDFs and LFPs
    
    edges = -1000:50:1000;
    
    %BR
    % Sel 270, 270TO90
    for iSwitch = 1:length(cleanSwitches.BR.s270TO90{1})
        c = 0;
        for iChan = 1:length(pref270_br)
            c = c+1; clear spikesPiece; clear lowPiece
            spikesPiece = (cleanSwitches.BR.s270TO90{pref270_br(iChan)}{iSwitch});
            
            if ~isempty(spikesPiece)
                sdf_br_sel270_s270TO90(iSwitch,iChan,:) = histc(spikesPiece,edges);
            else
                sdf_br_sel270_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
            end
            
        end
        
    end
    
    sdf_br_sel270_s270TO90 = sum(sdf_br_sel270_s270TO90,2);
    sdf_br_sel270_s270TO90 = squeeze(sdf_br_sel270_s270TO90);
    
    if isempty(pref90_br)
        
        sdf_br_sel90_s90TO270 = nan(1,length(edges));
        low_br_sel90_s90TO270 = nan(1,length(edges));
        
    else
        
        % Sel 90, 270TO90
        for iSwitch = 1:length(cleanSwitches.BR.s270TO90{1})
            c = 0;
            for iChan = 1:length(pref90_br)
                c = c+1; clear spikesPiece; clear lowPiece
                spikesPiece = (cleanSwitches.BR.s270TO90{pref90_br(iChan)}{iSwitch});
                
                if ~isempty(spikesPiece)
                    sdf_br_sel90_s270TO90(iSwitch,iChan,:) = histc(spikesPiece,edges);
                else
                    sdf_br_sel90_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
                end
                
            end
            
        end
        
        sdf_br_sel90_s270TO90 = sum(sdf_br_sel90_s270TO90,2);
        sdf_br_sel90_s270TO90 = squeeze(sdf_br_sel90_s270TO90);
        
    end
    
    %BR
    % Sel 270, 90TO270
    for iSwitch = 1:length(cleanSwitches.BR.s90TO270{1})
        c = 0;
        for iChan = 1:length(pref270_br)
            c = c+1; clear spikesPiece; clear lowPiece
            spikesPiece = (cleanSwitches.BR.s90TO270{pref270_br(iChan)}{iSwitch});
            
            if ~isempty(spikesPiece)
                sdf_br_sel270_s90TO270(iSwitch,iChan,:) = histc(spikesPiece,edges);
            else
                sdf_br_sel270_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
            end
            
        end
        
    end
    
    sdf_br_sel270_s90TO270 = sum(sdf_br_sel270_s90TO270,2);
    sdf_br_sel270_s90TO270 = squeeze(sdf_br_sel270_s90TO270);
    
    if isempty(pref90_br)
        
        sdf_br_sel90_s270TO90 = nan(1,length(edges));
        low_br_sel90_s270TO90 = nan(1,length(edges));
        
    else
        % Sel 90, 90TO270
        for iSwitch = 1:length(cleanSwitches.BR.s90TO270{1})
            c = 0;
            for iChan = 1:length(pref90_br)
                c = c+1; clear spikesPiece; clear lowPiece
                spikesPiece = (cleanSwitches.BR.s90TO270{pref90_br(iChan)}{iSwitch});
                
                if ~isempty(spikesPiece)
                    sdf_br_sel90_s90TO270(iSwitch,iChan,:) = histc(spikesPiece,edges);
                else
                    sdf_br_sel90_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
                end
                
            end
            
        end
        
        sdf_br_sel90_s90TO270 = sum(sdf_br_sel90_s90TO270,2);
        sdf_br_sel90_s90TO270 = squeeze(sdf_br_sel90_s90TO270);
        
    end
    %PA
    % Sel 270, 270TO90
    for iSwitch = 1:length(cleanSwitches.PA.s270TO90{1})
        c = 0;
        for iChan = 1:length(pref270_pa)
            c = c+1; clear spikesPiece; clear lowPiece
            spikesPiece = (cleanSwitches.PA.s270TO90{pref270_pa(iChan)}{iSwitch});
            
            if ~isempty(spikesPiece)
                sdf_pa_sel270_s270TO90(iSwitch,iChan,:) = histc(spikesPiece,edges);
            else
                sdf_pa_sel270_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
            end
            
        end
        
    end
    
    sdf_pa_sel270_s270TO90 = sum(sdf_pa_sel270_s270TO90,2);
    sdf_pa_sel270_s270TO90 = squeeze(sdf_pa_sel270_s270TO90);
    
    % Sel 90, 270TO90
    for iSwitch = 1:length(cleanSwitches.PA.s270TO90{1})
        c = 0;
        for iChan = 1:length(pref90_pa)
            c = c+1; clear spikesPiece; clear lowPiece
            spikesPiece = (cleanSwitches.PA.s270TO90{pref90_pa(iChan)}{iSwitch});
            
            if ~isempty(spikesPiece)
                sdf_pa_sel90_s270TO90(iSwitch,iChan,:) = histc(spikesPiece,edges);
            else
                sdf_pa_sel90_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
            end
            
        end
        
    end
    
    sdf_pa_sel90_s270TO90 = sum(sdf_pa_sel90_s270TO90,2);
    sdf_pa_sel90_s270TO90 = squeeze(sdf_pa_sel90_s270TO90);
    
    %PA
    % Sel 270, 90TO270
    for iSwitch = 1:length(cleanSwitches.PA.s90TO270{1})
        c = 0;
        for iChan = 1:length(pref270_pa)
            c = c+1; clear spikesPiece; clear lowPiece
            spikesPiece = (cleanSwitches.PA.s90TO270{pref270_pa(iChan)}{iSwitch});
            
            if ~isempty(spikesPiece)
                sdf_pa_sel270_s90TO270(iSwitch,iChan,:) = histc(spikesPiece,edges);
            else
                sdf_pa_sel270_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
            end
            
        end
        
    end
    
    sdf_pa_sel270_s90TO270 = sum(sdf_pa_sel270_s90TO270,2);
    sdf_pa_sel270_s90TO270 = squeeze(sdf_pa_sel270_s90TO270);
    
    
    % Sel 90, 90TO270
    for iSwitch = 1:length(cleanSwitches.PA.s90TO270{1})
        c = 0;
        for iChan = 1:length(pref90_pa)
            c = c+1; clear spikesPiece; clear lowPiece
            spikesPiece = (cleanSwitches.PA.s90TO270{pref90_pa(iChan)}{iSwitch});
            
            if ~isempty(spikesPiece)
                sdf_pa_sel90_s90TO270(iSwitch,iChan,:) = histc(spikesPiece,edges);
            else
                sdf_pa_sel90_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
            end
            
        end
        
    end
    
    sdf_pa_sel90_s90TO270 = sum(sdf_pa_sel90_s90TO270,2);
    sdf_pa_sel90_s90TO270 = squeeze(sdf_pa_sel90_s90TO270);
    
    %% Process LFPs
    
    low_br_sel90_s270TO90 = squeeze(nanmean(lfpSwitches.low.BR.s270TO90(:,pref90_br,:),2));
    low_br_sel270_s270TO90 = squeeze(nanmean(lfpSwitches.low.BR.s270TO90(:,pref270_br,:),2));
    low_br_sel90_s90TO270 = squeeze(nanmean(lfpSwitches.low.BR.s90TO270(:,pref90_br,:),2));
    low_br_sel270_s90TO270 = squeeze(nanmean(lfpSwitches.low.BR.s90TO270(:,pref270_br,:),2));
    low_pa_sel90_s270TO90 = squeeze(nanmean(lfpSwitches.low.PA.s270TO90(:,pref90_pa,:),2));
    low_pa_sel270_s270TO90 = squeeze(nanmean(lfpSwitches.low.PA.s270TO90(:,pref270_pa,:),2));
    low_pa_sel90_s90TO270 = squeeze(nanmean(lfpSwitches.low.PA.s90TO270(:,pref90_pa,:),2));
    low_pa_sel270_s90TO270 = squeeze(nanmean(lfpSwitches.low.PA.s90TO270(:,pref270_pa,:),2));
    
    %% Consolidate into a structure
    
    spikingActivityPerTransition.sel90.sdf.BR.s270TO90 = sdf_br_sel90_s270TO90;
    spikingActivityPerTransition.sel90.sdf.PA.s270TO90 = sdf_pa_sel90_s270TO90;
    spikingActivityPerTransition.sel90.sdf.BR.s90TO270 = sdf_br_sel90_s90TO270;
    spikingActivityPerTransition.sel90.sdf.PA.s90TO270 = sdf_pa_sel90_s90TO270;
    spikingActivityPerTransition.sel270.sdf.BR.s270TO90 = sdf_br_sel270_s270TO90;
    spikingActivityPerTransition.sel270.sdf.PA.s270TO90 = sdf_pa_sel270_s270TO90;
    spikingActivityPerTransition.sel270.sdf.BR.s90TO270 = sdf_br_sel270_s90TO270;
    spikingActivityPerTransition.sel270.sdf.PA.s90TO270 = sdf_pa_sel270_s90TO270;
    
    spikingActivityPerTransition.sel90.lowRate.BR.s270TO90 = low_br_sel90_s270TO90;
    spikingActivityPerTransition.sel90.lowRate.PA.s270TO90 = low_pa_sel90_s270TO90;
    spikingActivityPerTransition.sel90.lowRate.BR.s90TO270 = low_br_sel90_s90TO270;
    spikingActivityPerTransition.sel90.lowRate.PA.s90TO270 = low_pa_sel90_s90TO270;
    spikingActivityPerTransition.sel270.lowRate.BR.s270TO90 = low_br_sel270_s270TO90;
    spikingActivityPerTransition.sel270.lowRate.PA.s270TO90 = low_pa_sel270_s270TO90;
    spikingActivityPerTransition.sel270.lowRate.BR.s90TO270 = low_br_sel270_s90TO270;
    spikingActivityPerTransition.sel270.lowRate.PA.s90TO270 = low_pa_sel270_s90TO270;
    
    
    figure
    subplot(2,2,1)
    plot(edges(3:end-2)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel90.sdf.BR.s90TO270(:,3:end-2),1))))
    hold on
    plot(edges(3:end-2)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel270.sdf.BR.s90TO270(:,3:end-2),1))))
    plot(tLFP(26:976)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel90.lowRate.BR.s90TO270(:,26:976),1))))
    plot(tLFP(26:976)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel270.lowRate.BR.s90TO270(:,26:976),1))))
    vline(0,'--b')
    title('90TO270 - BR')
    legend('90 Selective SDF','270 Selective SDF','90 Selective LF','270 Selective LF')
    subplot(2,2,2)
    plot(edges(3:end-2)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel90.sdf.BR.s270TO90(:,3:end-2),1))))
    hold on
    plot(edges(3:end-2)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel270.sdf.BR.s270TO90(:,3:end-2),1))))
    plot(tLFP(26:976)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel90.lowRate.BR.s270TO90(:,26:976),1))))
    plot(tLFP(26:976)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel270.lowRate.BR.s270TO90(:,26:976),1))))
    vline(0,'--b')
    title('270TO90 - BR')
    legend('90 Selective SDF','270 Selective SDF','90 Selective LF','270 Selective LF')
    
    subplot(2,2,3)
    plot(edges(3:end-2)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel90.sdf.PA.s90TO270(:,3:end-2),1))))
    hold on
    plot(edges(3:end-2)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel270.sdf.PA.s90TO270(:,3:end-2),1))))
    plot(tLFP(26:976)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel90.lowRate.PA.s90TO270(:,26:976),1))))
    plot(tLFP(26:976)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel270.lowRate.PA.s90TO270(:,26:976),1))))
    vline(0,'--b')
    title('90TO270 - PA')
    legend('90 Selective SDF','270 Selective SDF','90 Selective LF','270 Selective LF')
    subplot(2,2,4)
    plot(edges(3:end-2)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel90.sdf.PA.s270TO90(:,3:end-2),1))))
    hold on
    plot(edges(3:end-2)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel270.sdf.PA.s270TO90(:,3:end-2),1))))
    plot(tLFP(26:976)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel90.lowRate.PA.s270TO90(:,26:976),1))))
    plot(tLFP(26:976)./1000,smooth(normalise(sum(spikingActivityPerTransition.sel270.lowRate.PA.s270TO90(:,26:976),1))))
    vline(0,'--b')
    title('270TO90 - PA')
    legend('90 Selective SDF','270 Selective SDF','90 Selective LF','270 Selective LF')
    
    cd(sav_dir)
    pause(3)
    close all
    
    save('MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel.mat','spikingActivityPerTransition','edges','-v7.3')
    
    clear sdf_br_sel270_s270TO90; clear sdf_br_sel270_s90TO270; clear sdf_br_sel90_s270TO90; clear sdf_br_sel90_s90TO270;
    clear sdf_pa_sel270_s270TO90; clear sdf_pa_sel270_s90TO270; clear sdf_pa_sel90_s270TO90; clear sdf_pa_sel90_s90TO270;
    clear low_br_sel270_s270TO90; clear low_br_sel270_s90TO270; clear low_br_sel90_s270TO90; clear low_br_sel90_s90TO270;
    clear low_pa_sel270_s270TO90; clear low_pa_sel270_s90TO270; clear low_pa_sel90_s270TO90; clear low_pa_sel90_s90TO270;
    clear spikingActivity; clear lfpSwitches; clear spikingActivityPerTransition; clear cleanSwitches; clear jMUspikes; clear lowPiece; clear spikesPiece;
end
