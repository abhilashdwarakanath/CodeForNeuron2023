clear all
clc
close all

% This is a script to get the event triggered traces in the resting state
% data

dbstop if error

%% Load data

% Load LFPs

%cd B:\H07\07-04-2016\PFC
cd B:\A11\06-04-2016\PFC
load LFPPFC.mat

% load eye movements

cd EMSegmentation
load NSX_TimeStamps.mat

emy = read_NC5('NSX130.NC5',1,lts);
emyDec = decimate(emy,2);
emx = read_NC5('NSX129.NC5',1,lts);
emxDec = decimate(emx,2);
%% Setup filters and buffer

[b1,a1] = cheby1(4,0.001,[1 9]/250);
buffer = 250;
nEvents = 5;
evtDur = 56;
fs = 500;

%% Compute the events and choose 5 events at random from each channel otherwise its way too many to compute

counter = 0;
for i = 1:96
    
    tic;
    lowInstAmp = abs(hilbert(filtfilt(b1,a1,[zeros(1,250) detrend(LFP.data(i,:)) zeros(1,250)])));
    lfpevents = event_detection(lowInstAmp',4,'stdgauss',evtDur);
    lfpevents(lfpevents<=250 & lfpevents>=length(LFP.data(i,:))) = [];
    lfpevents = lfpevents-250;
    rawTrace = detrend(LFP.data(i,:));
    
    if length(lfpevents) > nEvents
        
        randEvents = randsample(length(lfpevents),nEvents);
        randEvents = sort(randEvents);
        events = lfpevents(randEvents);
        
    end
    
    for iEvt = 1:length(events)
        if events(iEvt) > buffer && events(iEvt) < length(LFP.data(i,:))-buffer
            counter = counter+1;
            evt = events(iEvt);
            lfEmy = emyDec(events(iEvt)-buffer:events(iEvt)+buffer); % Y-position
            lfEmx = emxDec(events(iEvt)-buffer:events(iEvt)+buffer); % X-position
            lfResVec = sqrt(lfEmx.^2 + lfEmy.^2); % Resultant vector
            temp = rawTrace(events(iEvt)-buffer:events(iEvt)+buffer);
            
            [c, f] = cwt([zeros(1,250) temp zeros(1,250)],'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]);
            c = abs(c.^2);
            c = c(:,251:end-250);
            Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
            t = linspace(-buffer/fs,(buffer/fs),(2*buffer)+1);
            
            figure('units','normalized','outerposition',[0 0 1 1])
            
            subplot(2,1,1)
            plot(t,normalise(lfEmy),'LineWidth',2)
            hold on
            plot(t,normalise(lfEmx),'LineWidth',2)
            plot(t,normalise(lfResVec),'--','LineWidth',2)
            xlabel('time [s]')
            ylabel('normalised amplitude (position)')
            legend('Y-position','X-position','Resultant Vector in 2D')
            
            subplot(2,1,2)
            imagesc(t,log2(f),zscore(c,[],1))
            xlabel('time [s]');
            ylabel('Hz')
            vline(0,'--w'); AX = gca;
            set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
            AX.YLim = log2([min(f), max(f)]);
            axis xy
            colormap jet
            AX.CLim = [0 2];
            pause(1.5)
            cd B:\Results\RestingState\H07
            mkdir Spectrograms
            cd Spectrograms
            mkdir LFTriggeredEM
            cd LFTriggeredEM
            saveas(gcf,['LF_EM_Spectrograms_' num2str(counter)],'fig')
            toc;
            close all 
        end
        
    end
end



