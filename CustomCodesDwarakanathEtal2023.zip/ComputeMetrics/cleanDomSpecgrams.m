function [cleanDomSpectrograms] = cleanDomSpecgrams(pref_array,lfpActivity,durs,tag)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves. 
% Abhilash D. MPIBC 2017-18

%% Get preference arrays

if isfield(pref_array,'pref_sim_Dom_PhyRiv')
    
    fprintf('Dominance preference array found....using it\n')
    for i = 1:size(pref_array.pref_sim_Dom_PhyRiv.com_sig_u,1)
        prefs(i) = pref_array.pref_sim_Dom_PhyRiv.com_sig_u(i,2);
    end
    pref90idx = prefs==2;
    pref270idx = prefs==1;
    pref90 = pref_array.pref_sim_Dom_PhyRiv.com_sig_u(pref90idx,3);
    pref270 = pref_array.pref_sim_Dom_PhyRiv.com_sig_u(pref270idx,3);
    pref90 = pref90';pref270 = pref270';
    filename = ['cleanDomSpectrograms' tag 'DomSel' '.mat'];

else
    fprintf('Dominance preference array not found....defaulting to PA_FS\n')
    for i = 1:size(pref_array.pref_sim.com_sig_u,1)
        prefs(i) = pref_array.pref_sim.com_sig_u(i,2);
    end
    pref90idx = prefs==2;
    pref270idx = prefs==1;
    pref90 = pref_array.pref_sim.com_sig_u(pref90idx,3);
    pref270 = pref_array.pref_sim.com_sig_u(pref270idx,3);
    pref90 = pref90';pref270 = pref270';
    filename = ['cleanDomSpectrograms' tag 'PAFSSel' '.mat'];
end

%% Collect activity across all preferring channels and collate them - BR

% NP2P

np2pbr90 = [];
for i = 1:length(pref90)
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, pref90(i)},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, pref90(i)}{1, iCond},2)
            piece = (lfpActivity.validSection.BR.data.dom90{1, pref90(i)}{1, iCond}{nDom});
            if ~isnan(piece)
                np2pbr90 = [np2pbr90;piece'];
            end
        end
    end
end

np2pbr270 = [];
for i = 1:length(pref270)
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, pref270(i)},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, pref270(i)}{1, iCond},2)
            piece = (lfpActivity.validSection.BR.data.dom270{1, pref270(i)}{1, iCond}{nDom});
            if ~isnan(piece)
                np2pbr270 = [np2pbr270;piece'];
            end
        end
    end
end


% P2NP

p2npbr270 = [];
for i = 1:length(pref90)
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, pref90(i)},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1,  pref90(i)}{1, iCond},2)
            piece = (lfpActivity.validSection.BR.data.dom270{1,  pref90(i)}{1, iCond}{nDom});
            if ~isnan(piece)
                p2npbr270 = [p2npbr270;piece'];
            end
        end
    end
end

% P2NP

p2npbr90 = [];
for i = 1:length(pref270)
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, pref270(i)},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1,  pref270(i)}{1, iCond},2)
            piece = (lfpActivity.validSection.BR.data.dom90{1,  pref270(i)}{1, iCond}{nDom});
            if ~isnan(piece)
                p2npbr90 = [p2npbr90;piece'];
            end
        end
    end
end

%% Collect for PA 

% NP2P

np2ppa90 = [];
for i = 1:length(pref90)
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, pref90(i)},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, pref90(i)}{1, iCond},2)
            piece = (lfpActivity.validSection.PA.data.dom90{1, pref90(i)}{1, iCond}{nDom});
            if ~isnan(piece)
                np2ppa90 = [np2ppa90;piece'];
            end
        end
    end
end

np2ppa270 = [];
for i = 1:length(pref270)
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, pref270(i)},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, pref270(i)}{1, iCond},2)
            piece = (lfpActivity.validSection.PA.data.dom270{1, pref270(i)}{1, iCond}{nDom});
            if ~isnan(piece)
                np2ppa270 = [np2ppa270;piece'];
            end
        end
    end
end


% P2NP

p2nppa270 = [];
for i = 1:length(pref90)
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, pref90(i)},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1,  pref90(i)}{1, iCond},2)
            piece = (lfpActivity.validSection.PA.data.dom270{1,  pref90(i)}{1, iCond}{nDom});
            if ~isnan(piece)
                p2nppa270 = [p2nppa270;piece'];
            end
        end
    end
end

% P2NP

p2nppa90 = [];
for i = 1:length(pref270)
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, pref270(i)},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1,  pref270(i)}{1, iCond},2)
            piece = (lfpActivity.validSection.PA.data.dom90{1,  pref270(i)}{1, iCond}{nDom});
            if ~isnan(piece)
                p2nppa90 = [p2nppa90;piece'];
            end
        end
    end
end

%% Take care of trash trials i.e. discard trials with massive movement artifacts.

% np2p
[val,~] = max(np2ppa90,[],2);
idx = val>=750;
trashTrials = find(idx==1);
np2ppa90(trashTrials,:) = [];

[val,~] = max(np2ppa270,[],2);
idx = val>=750;
trashTrials = find(idx==1);
np2ppa270(trashTrials,:) = [];

[val,~] = max(np2pbr90,[],2);
idx = val>=750;
trashTrials = find(idx==1);
np2pbr90(trashTrials,:) = [];

[val,~] = max(np2pbr270,[],2);
idx = val>=750;
trashTrials = find(idx==1);
np2pbr270(trashTrials,:) = [];

%p2np

[val,~] = max(p2nppa90,[],2);
idx = val>=750;
trashTrials = find(idx==1);
p2nppa90(trashTrials,:) = [];

[val,~] = max(p2nppa270,[],2);
idx = val>=750;
trashTrials = find(idx==1);
p2nppa270(trashTrials,:) = [];

[val,~] = max(p2npbr90,[],2);
idx = val>=750;
trashTrials = find(idx==1);
p2npbr90(trashTrials,:) = [];

[val,~] = max(p2npbr270,[],2);
idx = val>=750;
trashTrials = find(idx==1);
p2npbr270(trashTrials,:) = [];


%% Remove VEP!!!

% Think about this!! Looks like in some datasets removing the VEPs makes a
% difference, whereas in others, it doesn't. What could be the reason? For
% e.g. 12-06-2016 has a strong VEP component but 20161025 doesn't.

% BR

% meanp2np90 = nanmean(p2npbr90,1);
% meanp2np270 = nanmean(p2npbr270,1);
% meannp2p90 = nanmean(np2pbr90,1);
% meannp2p270 = nanmean(np2pbr270,1);
% 
% p2npbr90 = p2npbr90-meanp2np90;
% p2npbr270 = p2npbr270-meanp2np270;
% np2pbr90 = np2pbr90-meannp2p90;
% np2pbr270 = np2pbr270-meannp2p270;
% 
% % PA
% 
% meanp2np90 = nanmean(p2nppa90,1);
% meanp2np270 = nanmean(p2nppa270,1);
% meannp2p90 = nanmean(np2ppa90,1);
% meannp2p270 = nanmean(np2ppa270,1);
% 
% p2nppa90 = p2nppa90-meanp2np90;
% p2nppa270 = p2nppa270-meanp2np270;
% np2ppa90 = np2ppa90-meannp2p90;
% np2ppa270 = np2ppa270-meannp2p270;

%% Declare lengths - 

t = linspace(-durs.domBehind/1000,durs.domForward/1000,(durs.domBehind/2)+(durs.domForward/2)+1);
flen = 169;
tlen = length(np2pbr90(1,:));

%% Compute the CWT - NP2P

% BR

np2pcwtbr90 = zeros(flen,tlen,size(np2pbr90,1));
for i = 1:size(np2pbr90,1)
    [np2pcwtbr90(:,:,i),f] = cwt(np2pbr90(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
    np2pcwtbr90(:,:,i) = abs(np2pcwtbr90(:,:,i).^2);
end

np2pcwtbr270 = zeros(flen,tlen,size(np2pbr270,1));
for i = 1:size(np2pbr270,1)
    [np2pcwtbr270(:,:,i),f] = cwt(np2pbr270(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
    np2pcwtbr270(:,:,i) = abs(np2pcwtbr270(:,:,i).^2);
end

% PA

if size(np2pbr90,1) > size(np2ppa90,1)
    idxs90 = 1:size(np2ppa90,1);
else
idxs90 = sort(randperm(size(np2ppa90,1),size(np2pbr90,1))); % Get equal number of PA trials
end
np2pcwtpa90 = zeros(flen,tlen,size(np2pbr90,1));
for i = 1:length(idxs90)
    [np2pcwtpa90(:,:,i),f] = cwt(np2ppa90(idxs90(i),:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
    np2pcwtpa90(:,:,i) = abs(np2pcwtpa90(:,:,i).^2);
end

if size(np2pbr270,1) > size(np2ppa270,1)
    idxs270 = 1:size(np2ppa270,1);
else
idxs270 = sort(randperm(size(np2ppa270,1),size(np2pbr270,1))); % Get equal number of PA trials
end
np2pcwtpa270 = zeros(flen,tlen,size(np2pbr270,1));
for i = 1:length(idxs270)
    [np2pcwtpa270(:,:,i),f] = cwt(np2ppa270(idxs270(i),:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
    np2pcwtpa270(:,:,i) = abs(np2pcwtpa270(:,:,i).^2);
end
%% Compute the CWT - P2NP

% BR

p2npcwtbr90 = zeros(flen,tlen,size(p2npbr90,1));
for i = 1:size(p2npbr90,1)
    [p2npcwtbr90(:,:,i),f] = cwt(p2npbr90(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
    p2npcwtbr90(:,:,i) = abs(p2npcwtbr90(:,:,i).^2);
end

p2npcwtbr270 = zeros(flen,tlen,size(p2npbr270,1));
for i = 1:size(p2npbr270,1)
    [p2npcwtbr270(:,:,i),f] = cwt(p2npbr270(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
    p2npcwtbr270(:,:,i) = abs(p2npcwtbr270(:,:,i).^2);
end

% PA

if size(p2npbr90,1) > size(p2nppa90,1)
    idxs90 = 1:size(p2nppa90,1);
else
idxs90 = sort(randperm(size(p2nppa90,1),size(p2npbr90,1))); % Get equal number of PA trials
end
p2npcwtpa90 = zeros(flen,tlen,size(p2npbr90,1));
for i = 1:length(idxs90)
    [p2npcwtpa90(:,:,i),f] = cwt(p2nppa90(idxs90(i),:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
    p2npcwtpa90(:,:,i) = abs(p2npcwtpa90(:,:,i).^2);
end

if size(p2npbr270,1) > size(p2nppa270,1)
    idxs270 = 1:size(p2nppa270,1);
else
idxs270 = sort(randperm(size(p2nppa270,1),size(p2npbr270,1))); % Get equal number of PA trials
end
p2npcwtpa270 = zeros(flen,tlen,size(p2npbr270,1));
for i = 1:length(idxs270)
    [p2npcwtpa270(:,:,i),f] = cwt(p2nppa270(idxs270(i),:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
    p2npcwtpa270(:,:,i) = abs(p2npcwtpa270(:,:,i).^2);
end
%% Plot

figure(2)
subplot(2,2,1)
imMat = nanmean(np2pcwtbr90,3);
imagesc(t,log2(f),imMat(:,251:end-250,:))
shading('interp')
Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
xlabel('time in s');shading('interp')
ylabel('Hz')
vline(0,'--k')
AX = gca;
AX.YLim = log2([min(f), max(f)]);
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
axis xy
vline(0,'--k')
colormap jet
AX.CLim = [50 175];
title('NP2P BR - Upward Preference - Dataset 1 - H07')
subplot(2,2,2)
imMat = nanmean(np2pcwtbr270,3);
imagesc(t,log2(f),imMat(:,251:end-250,:))
shading('interp')
Yticks = 2.^(round(log2(min(f))):round(log2(max(f)))); 
xlabel('time in s');shading('interp')
ylabel('Hz')
vline(0,'--k')
AX = gca;
AX.YLim = log2([min(f), max(f)]);
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
axis xy
vline(0,'--k')
colormap jet
AX.CLim = [50 175];
title('NP2P BR - Downward Preference - Dataset 1 - H07')
subplot(2,2,3)
imMat = nanmean(np2pcwtpa90,3);
imagesc(t,log2(f),imMat(:,251:end-250,:))
shading('interp')
Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
xlabel('time in s');shading('interp')
ylabel('Hz')
vline(0,'--k')
AX = gca;
AX.YLim = log2([min(f), max(f)]);
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
axis xy
vline(0,'--k')
colormap jet
AX.CLim = [50 175];
title('NP2P PA - Upward Preference - Dataset 1 - H07')
subplot(2,2,4)
imMat = nanmean(np2pcwtpa270,3);
imagesc(t,log2(f),imMat(:,251:end-250,:))
shading('interp')
Yticks = 2.^(round(log2(min(f))):round(log2(max(f)))); 
xlabel('time in s');shading('interp')
ylabel('Hz')
vline(0,'--k')
AX = gca;
AX.YLim = log2([min(f), max(f)]);
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
axis xy
vline(0,'--k')
colormap jet
AX.CLim = [50 175];
title('NP2P PA - Downward Preference - Dataset 1 - H07')

figure(3)
subplot(2,2,1)
imMat = nanmean(p2npcwtbr90,3);
imagesc(t,log2(f),imMat(:,251:end-250,:))
shading('interp')
Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
xlabel('time in s');shading('interp')
ylabel('Hz')
vline(0,'--k')
AX = gca;
AX.YLim = log2([min(f), max(f)]);
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
axis xy
vline(0,'--k')
colormap jet
AX.CLim = [50 175];
title('p2np BR - Upward Preference - Dataset 1 - H07')
subplot(2,2,2)
imMat = nanmean(p2npcwtbr270,3);
imagesc(t,log2(f),imMat(:,251:end-250,:))
shading('interp')
Yticks = 2.^(round(log2(min(f))):round(log2(max(f)))); 
xlabel('time in s');shading('interp')
ylabel('Hz')
vline(0,'--k')
AX = gca;
AX.YLim = log2([min(f), max(f)]);
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
axis xy
vline(0,'--k')
colormap jet
AX.CLim = [50 175];
title('p2np BR - Downward Preference - Dataset 1 - H07')
subplot(2,2,3)
imMat = nanmean(p2npcwtpa90,3);
imagesc(t,log2(f),imMat(:,251:end-250,:))
shading('interp')
Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
xlabel('time in s');shading('interp')
ylabel('Hz')
vline(0,'--k')
AX = gca;
AX.YLim = log2([min(f), max(f)]);
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
axis xy
vline(0,'--k')
colormap jet
AX.CLim = [50 175];
title('p2np PA - Upward Preference - Dataset 1 - H07')
subplot(2,2,4)
imMat = nanmean(p2npcwtpa270,3);
imagesc(t,log2(f),imMat(:,251:end-250,:))
shading('interp')
Yticks = 2.^(round(log2(min(f))):round(log2(max(f)))); 
xlabel('time in s');shading('interp')
ylabel('Hz')
vline(0,'--k')
AX = gca;
AX.YLim = log2([min(f), max(f)]);
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
axis xy
vline(0,'--k')
colormap jet
AX.CLim = [50 175];
title('p2np PA - Downward Preference - Dataset 1 - H07')

%% Collect the output

cleanDomSpectrograms.t = t;
cleanDomSpectrograms.f = f;
cleanDomSpectrograms.Yticks = Yticks;
cleanDomSpectrograms.BR.np2p90 = np2pcwtbr90;
cleanDomSpectrograms.BR.np2p270 = np2pcwtbr270;
cleanDomSpectrograms.BR.p2np90 = p2npcwtbr90;
cleanDomSpectrograms.BR.p2np270 = p2npcwtbr270;
cleanDomSpectrograms.PA.np2p90 = np2pcwtpa90;
cleanDomSpectrograms.PA.np2p270 = np2pcwtpa270;
cleanDomSpectrograms.PA.p2np90 = p2npcwtpa90;
cleanDomSpectrograms.PA.p2np270 = p2npcwtpa270;

save(filename,'cleanDomSpectrograms','-v7.3');