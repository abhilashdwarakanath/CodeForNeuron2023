function generate_spikeLFP_phaseDistribution(lfpDoms, jMUDominances, domdur, sav_dir_psth,pref_array,expt,filtType)

cd(sav_dir_psth)

min_domDur = domdur(1);
max_domDur = domdur(2);

timeWin = min_domDur/2;
t = linspace(-1000,min_domDur,(min_domDur+1000)/2);
[x,y] = smoothingkernel(min_domDur/1000,500,0.005,'gaussian');

%% Collect preferences by unit

if isfield(pref_array,'pref_sim_Dom_PhyRiv')
    
    fprintf('Dominance preference array found....using it\n')
    for i = 1:size(pref_array.pref_sim_Dom_PhyRiv.com_sig_u,1)
        prefs(i) = pref_array.pref_sim_Dom_PhyRiv.com_sig_u(i,2);
    end
    pref90idx = prefs==2;
    pref270idx = prefs==1;
    pref90 = pref_array.pref_sim_Dom_PhyRiv.com_sig_u(pref90idx,3);
    pref270 = pref_array.pref_sim_Dom_PhyRiv.com_sig_u(pref270idx,3);
    pref90 = pref90';pref270 = pref270';
    filename = ['spikeLFPPhaseDist_' filtType '_' num2str(domdur(1)) '_' 'DomSel' '.mat'];

else
    fprintf('Dominance preference array not found....defaulting to PA_FS\n')
    for i = 1:size(pref_array.pref_sim.com_sig_u,1)
        prefs(i) = pref_array.pref_sim.com_sig_u(i,2);
    end
    pref90idx = prefs==2;
    pref270idx = prefs==1;
    pref90 = pref_array.pref_sim.com_sig_u(pref90idx,3);
    pref270 = pref_array.pref_sim.com_sig_u(pref270idx,3);
    pref90 = pref90';pref270 = pref270';
    filename = ['spikeLFPPhaseDist_' filtType '_' num2str(domdur(1)) '_' 'PAFSSel' '.mat'];
end

%% Collect dominances based on dominance durations.

for i = 1:length(lfpDoms.data.domDur.dom90)
    
    valid_idx.dom90{i} = find(cell2mat(lfpDoms.data.domDur.dom90{i})>min_domDur & cell2mat(lfpDoms.data.domDur.dom90{i})<max_domDur)+1;
    
    valid_dur.dom90{i} = cell2mat(lfpDoms.data.domDur.dom90{i}(valid_idx.dom90{i}));
    
end

for i = 1:length(lfpDoms.data.domDur.dom270)
    valid_idx.dom270{i} = find(cell2mat(lfpDoms.data.domDur.dom270{i})>min_domDur & cell2mat(lfpDoms.data.domDur.dom270{i})<max_domDur)+1;
    
    valid_dur.dom270{i} = cell2mat(lfpDoms.data.domDur.dom270{i}(valid_idx.dom270{i}));
    
end

%% Setup filters

if strcmp(filtType,'theta')
    [b,a] = butter(3,[4 8]/250); % Theta
    evtDur = 50;
elseif strcmp(filtType,'delta')
    [b,a] = butter(3,[1 4]/250); % beta
    evtDur = 125;
elseif strcmp(filtType,'beta')
    [b,a] = butter(3,[15 35]/250); % beta
    evtDur = 15;
elseif strcmp(filtType,'gamma')
    [b,a] = butter(3,[125 200]/250); % gamma
    evtDur = 3;
elseif strcmp(filtType,'low')
    [b,a] = butter(3,[0.1 8]/250);
    evtDur = 50;
end

%% Compute Spike-LFP Coherograms - NP to P

% Idea - For each dominance, detect the theta events. Collect all phases
% going from the first theta-event to the switch. 

np2p90_preswitch_phases = [];

for chan = pref90 % Only check non-preferred to preferred
    
    for iCond = 1:length(valid_idx.dom90)-4
        
        lfp_dom90{chan}{iCond} =  lfpDoms.data.dom90{chan}{iCond}(valid_idx.dom90{iCond});
        
        spike_dom90{chan}{iCond} =  jMUDominances.data.dom90{chan}{iCond}(valid_idx.dom90{iCond});
        
    end
    
    % BR Dominances
    
    c = 0;
    for iCond = 1:4
        for nDoms = 1:length(lfp_dom90{chan}{iCond})
            c = c+1;
            np2pvepbr90(c,:) = filtfilt(b,a,lfp_dom90{chan}{iCond}{nDoms}(1:500+timeWin));
        end
    end
    
    np2pvepbr90 = nanmean(np2pvepbr90,1);
    
    prePhase = [];
    
    for iCond = 1:4
        for nDoms = 1:length(lfp_dom90{chan}{iCond})
            lfpfilt = filtfilt(b,a,lfp_dom90{chan}{iCond}{nDoms}(1:500+timeWin))-np2pvepbr90';
            np2pbr90(chan,iCond,nDoms,:) = lfpfilt;
            thetaEvents = event_detection(lfpfilt,2,'madgauss',evtDur);
            thetaEvents = thetaEvents(thetaEvents>ceil((evtDur/2)) & thetaEvents<=500);
            lfppiece = (angle(hilbert(filtfilt(b,a,lfp_dom90{chan}{iCond}{nDoms}(1:500+timeWin)))));
            spikeTimes = spike_dom90{chan}{iCond}{nDoms}(spike_dom90{chan}{iCond}{nDoms}<=min_domDur);
            st = zeros(1,length(t));
            if ~isempty(spikeTimes)
                for nSpk = 1:length(spikeTimes)
                    val = spikeTimes(nSpk); %value to find
                    tmp = abs(t-val);
                    [idx idx] = min(tmp); %index of closest value
                    spkIdx(nSpk) = idx;
                end
                st(spkIdx) = 1;
                clear spkIdx;
                preInds = [];
                for nEvts = 1:length(thetaEvents)
                    preInds = [preInds find(st(thetaEvents(nEvts)-ceil((evtDur/2)):thetaEvents(nEvts)+ceil((evtDur/2)))==1)+thetaEvents(nEvts)];
                end

                if isempty(spikeTimes)
                    prephase = [];
                else
                    prephase = lfppiece(preInds);
                end
                %pp1 = prephase(prephase<=((-pi/2)+ (pi/8))& prephase>=((-pi/2) - (pi/8)));
                %pp2 = prephase(prephase>=((pi/2)- (pi/8))& prephase<=((pi/2) + (pi/8)));
                %prephase = [pp1' pp2'];
                %postInds = find(st(501:end)==1);
                %postphase = lfppiece(postInds);
            end
            prePhase = [prePhase, prephase'];
            clear preInds; clear postInds;
        end
    end
    np2p90_preswitch_phases = [np2p90_preswitch_phases, prePhase];
end


np2p270_preswitch_phases = [];

for chan = pref270
    
    for iCond = 1:length(valid_idx.dom90)-4
        
        lfp_dom270{chan}{iCond} = lfpDoms.data.dom270{chan}{iCond}(valid_idx.dom270{iCond});
        
        spike_dom270{chan}{iCond} = jMUDominances.data.dom270{chan}{iCond}(valid_idx.dom270{iCond});
        
    end
    
    prePhase = [];
    
    c = 0;
    for iCond = 1:4
        for nDoms = 1:length(lfp_dom270{chan}{iCond})
            c = c+1;
            np2pvepbr270(c,:) = filtfilt(b,a,lfp_dom270{chan}{iCond}{nDoms}(1:500+timeWin));
        end
    end
    
    np2pvepbr270 = nanmean(np2pvepbr270,1);
    
    for iCond = 1:4
        for nDoms = 1:length(lfp_dom270{chan}{iCond})
            lfpfilt = filtfilt(b,a,lfp_dom270{chan}{iCond}{nDoms}(1:500+timeWin))-np2pvepbr270';
            np2pbr270(chan,iCond,nDoms,:) = lfpfilt;
            thetaEvents = event_detection(lfpfilt,2,'madgauss',evtDur);
            thetaEvents = thetaEvents(thetaEvents>ceil((evtDur/2)) & thetaEvents<=500);
            lfppiece = (angle(hilbert(filtfilt(b,a,lfp_dom270{chan}{iCond}{nDoms}(1:500+timeWin)))));
            spikeTimes = spike_dom270{chan}{iCond}{nDoms}(spike_dom270{chan}{iCond}{nDoms}<=min_domDur);
            st = zeros(1,length(t));
            if ~isempty(spikeTimes)
                for nSpk = 1:length(spikeTimes)
                    val = spikeTimes(nSpk); %value to find
                    tmp = abs(t-val);
                    [idx idx] = min(tmp); %index of closest value
                    spkIdx(nSpk) = idx;
                end
                st(spkIdx) = 1;
                clear spkIdx;
                preInds = [];
                for nEvts = 1:length(thetaEvents)
                    preInds = [preInds find(st(thetaEvents(nEvts)-ceil((evtDur/2)):thetaEvents(nEvts)+ceil((evtDur/2)))==1)+thetaEvents(nEvts)];
                end

                if isempty(spikeTimes)
                    prephase = [];
                else
                    prephase = lfppiece(preInds);
                end
                %pp1 = prephase(prephase<=((-pi/2)+ (pi/8))& prephase>=((-pi/2) - (pi/8)));
                %pp2 = prephase(prephase>=((pi/2)- (pi/8))& prephase<=((pi/2) + (pi/8)));
                %prephase = [pp1' pp2'];
                %postInds = find(st(501:end)==1);
                %postphase = lfppiece(postInds);
            end
            prePhase = [prePhase, prephase'];
            %postPhase = [postPhase, postphase'];
            clear preInds; clear postInds;
        end
        
    end
    np2p270_preswitch_phases = [np2p270_preswitch_phases, prePhase];
    %np2p270_postswitch_phases = [np2p270_postswitch_phases, postPhase];
end

%% P to NP

p2np90_preswitch_phases = [];

for chan = pref90 % Only check preferred to non-preferred
    
    for iCond = 1:length(valid_idx.dom90)-4
        
        lfp_dom270{chan}{iCond} =  lfpDoms.data.dom270{chan}{iCond}(valid_idx.dom270{iCond});
        
        spike_dom270{chan}{iCond} =  jMUDominances.data.dom270{chan}{iCond}(valid_idx.dom270{iCond});
        
    end
    
    % BR Dominances
    
    prePhase = [];
    c = 0;
    for iCond = 1:4
        for nDoms = 1:length(lfp_dom270{chan}{iCond})
            c = c+1;
            p2npvepbr90(c,:) = filtfilt(b,a,lfp_dom270{chan}{iCond}{nDoms}(1:500+timeWin));
        end
    end
    
    p2npvepbr90 = nanmean(p2npvepbr90,1);
    
    for iCond = 1:4
        for nDoms = 1:length(lfp_dom270{chan}{iCond})
            lfpfilt = filtfilt(b,a,lfp_dom270{chan}{iCond}{nDoms}(1:500+timeWin))-p2npvepbr90';
            p2npbr90(chan,iCond,nDoms,:) = lfpfilt;
            thetaEvents = event_detection(lfpfilt,2,'madgauss',evtDur);
            thetaEvents = thetaEvents(thetaEvents>ceil((evtDur/2)) & thetaEvents<=500);
            lfppiece = (angle(hilbert(filtfilt(b,a,lfp_dom270{chan}{iCond}{nDoms}(1:500+timeWin)))));
            spikeTimes = spike_dom270{chan}{iCond}{nDoms}(spike_dom270{chan}{iCond}{nDoms}<=min_domDur);
            st = zeros(1,length(t));
            if ~isempty(spikeTimes)
                for nSpk = 1:length(spikeTimes)
                    val = spikeTimes(nSpk); %value to find
                    tmp = abs(t-val);
                    [idx idx] = min(tmp); %index of closest value
                    spkIdx(nSpk) = idx;
                end
                st(spkIdx) = 1;
                clear spkIdx;
                preInds = [];
              for nEvts = 1:length(thetaEvents)
                    preInds = [preInds find(st(thetaEvents(nEvts)-ceil((evtDur/2)):thetaEvents(nEvts)+ceil((evtDur/2)))==1)+thetaEvents(nEvts)];
                end

                if isempty(spikeTimes)
                    prephase = [];
                else
                    prephase = lfppiece(preInds);
                end
                %pp1 = prephase(prephase<=((-pi/2)+ (pi/8))& prephase>=((-pi/2) - (pi/8)));
                %pp2 = prephase(prephase>=((pi/2)- (pi/8))& prephase<=((pi/2) + (pi/8)));
                %prephase = [pp1' pp2'];
                %postInds = find(st(501:end)==1);
                %postphase = lfppiece(postInds);
            end
            prePhase = [prePhase, prephase'];
            %postPhase = [postPhase, postphase'];
            clear preInds; clear postInds;
        end
    end
    p2np90_preswitch_phases = [p2np90_preswitch_phases, prePhase];
    %p2np90_postswitch_phases = [p2np90_postswitch_phases, postPhase];
end


p2np270_preswitch_phases = [];


for chan = pref270
    
    for iCond = 1:length(valid_idx.dom90)-4
        
        lfp_dom90{chan}{iCond} = lfpDoms.data.dom90{chan}{iCond}(valid_idx.dom90{iCond});
        
        spike_dom90{chan}{iCond} = jMUDominances.data.dom90{chan}{iCond}(valid_idx.dom90{iCond});
        
    end
    
    prePhase = [];
     c = 0;
    for iCond = 1:4
        for nDoms = 1:length(lfp_dom90{chan}{iCond})
            c = c+1;
            p2npvepbr270(c,:) = filtfilt(b,a,lfp_dom90{chan}{iCond}{nDoms}(1:500+timeWin));
        end
    end
    
    p2npvepbr270 = nanmean(p2npvepbr270,1);
    
    for iCond = 1:4
        for nDoms = 1:length(lfp_dom90{chan}{iCond})
            lfpfilt = filtfilt(b,a,lfp_dom90{chan}{iCond}{nDoms}(1:500+timeWin))-p2npvepbr270';
            p2npbr270(chan,iCond,nDoms,:) = lfpfilt;
            thetaEvents = event_detection(lfpfilt,2,'madgauss',evtDur);
            thetaEvents = thetaEvents(thetaEvents>ceil((evtDur/2)) & thetaEvents<=500);
            lfppiece = (angle(hilbert(filtfilt(b,a,lfp_dom90{chan}{iCond}{nDoms}(1:500+timeWin)))));
            spikeTimes = spike_dom90{chan}{iCond}{nDoms}(spike_dom90{chan}{iCond}{nDoms}<=min_domDur);
            st = zeros(1,length(t));
            if ~isempty(spikeTimes)
                for nSpk = 1:length(spikeTimes)
                    val = spikeTimes(nSpk); %value to find
                    tmp = abs(t-val);
                    [idx idx] = min(tmp); %index of closest value
                    spkIdx(nSpk) = idx;
                end
                st(spkIdx) = 1;
                clear spkIdx;
                preInds = [];
               for nEvts = 1:length(thetaEvents)
                    preInds = [preInds find(st(thetaEvents(nEvts)-ceil((evtDur/2)):thetaEvents(nEvts)+ceil((evtDur/2)))==1)+thetaEvents(nEvts)];
                end

                if isempty(spikeTimes)
                    prephase = [];
                else
                    prephase = lfppiece(preInds);
                end
                %pp1 = prephase(prephase<=((-pi/2)+ (pi/8))& prephase>=((-pi/2) - (pi/8)));
                %pp2 = prephase(prephase>=((pi/2)- (pi/8))& prephase<=((pi/2) + (pi/8)));
                %prephase = [pp1' pp2'];
                %postInds = find(st(501:end)==1);
                %postphase = lfppiece(postInds);
            end
            prePhase = [prePhase, prephase'];
            %postPhase = [postPhase, postphase'];
            clear preInds; clear postInds;
        end
        
    end
    p2np270_preswitch_phases = [p2np270_preswitch_phases, prePhase];
    %p2np270_postswitch_phases = [p2np270_postswitch_phases, postPhase];
end

spikePhaseActivity.phases.p2np90 = p2np90_preswitch_phases;
spikePhaseActivity.phases.p2np270 = p2np270_preswitch_phases;
spikePhaseActivity.phases.np2p90 = np2p90_preswitch_phases;
spikePhaseActivity.phases.np2p270 = np2p270_preswitch_phases;

spikePhaseActivity.traces.p2np90 = p2npbr90;
spikePhaseActivity.traces.p2np270 = p2npbr270;
spikePhaseActivity.traces.np2p90 = np2pbr90;
spikePhaseActivity.traces.np2p270 = np2pbr270;

spikePhaseActivity.filter = filtType;
spikePhaseActivity.threshold = 2.5;
spikePhaseActivity.thrType = 'madgauss';
spikePhaseActivity.minEvtDur = evtDur;

save(filename,'spikePhaseActivity')

%% Plot histcounts (normalised). Maybe also compute distribution distances?

edges1 = -pi:pi/50:0;
edges2 = 0:pi/50:pi; % To unwrap 

% 90 dom

preswitchhalf = histc(np2p90_preswitch_phases,edges1);
preswitchhalf2 = histc(np2p90_preswitch_phases,edges2);
np2p_90_preswitch = [preswitchhalf2(1:end-1) preswitchhalf(1:end-1)];
%postswitchhalf = histc(np2p90_postswitch_phases,edges1);
%postswitchhalf2 = histc(np2p90_postswitch_phases,edges2);
%np2p_90_postswitch = [postswitchhalf2(1:end-1) postswitchhalf(1:end-1)];

preswitchhalf = histc(p2np90_preswitch_phases,edges1);
preswitchhalf2 = histc(p2np90_preswitch_phases,edges2);
p2np_90_preswitch = [preswitchhalf2(1:end-1) preswitchhalf(1:end-1)];
%postswitchhalf = histc(np2p90_postswitch_phases,edges1);
%postswitchhalf2 = histc(np2p90_postswitch_phases,edges2);
%p2np_90_postswitch = [postswitchhalf2(1:end-1) postswitchhalf(1:end-1)];

% 270 dom

preswitchhalf = histc(np2p270_preswitch_phases,edges1);
preswitchhalf2 = histc(np2p270_preswitch_phases,edges2);
np2p_270_preswitch = [preswitchhalf2(1:end-1) preswitchhalf(1:end-1)];
%postswitchhalf = histc(np2p270_postswitch_phases,edges1);
%postswitchhalf2 = histc(np2p270_postswitch_phases,edges2);
%np2p_270_postswitch = [postswitchhalf2(1:end-1) postswitchhalf(1:end-1)];

preswitchhalf = histc(p2np270_preswitch_phases,edges1);
preswitchhalf2 = histc(p2np270_preswitch_phases,edges2);
p2np_270_preswitch = [preswitchhalf2(1:end-1) preswitchhalf(1:end-1)];
%postswitchhalf = histc(np2p270_postswitch_phases,edges1);
%postswitchhalf2 = histc(np2p270_postswitch_phases,edges2);
%p2np_270_postswitch = [postswitchhalf2(1:end-1) postswitchhalf(1:end-1)];

phaxis = linspace(0,2*pi,length([edges1 edges2])-2);

% plot

subplot(1,2,1)
polarplot(phaxis,smooth(smooth(normalise(np2p_270_preswitch))),'LineWidth',1.5)
hold on
polarplot(phaxis,smooth(smooth(normalise(p2np_90_preswitch))),'LineWidth',1.5)
%xlabel('phase in radians')
%ylabel('normalised counts')
legend('NP to P 270','P to nP 90')
title('90 to 270')
%grid on; box off; axis tight

subplot(1,2,2)
polarplot(phaxis,smooth(smooth(normalise(np2p_90_preswitch))),'LineWidth',1.5)
hold on
polarplot(phaxis,smooth(smooth(normalise(p2np_270_preswitch))),'LineWidth',1.5)
%xlabel('phase in radians')
%ylabel('normalised counts')
legend('NP to P 90','P to NP 270')
title('270 to 90')
%grid on; box off; axis tight



