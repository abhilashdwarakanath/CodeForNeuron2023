function [cleanDomPSTHs] = computeCleanDomPSTHs(spikingActivity,sav_dir_psth,durs,tag)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

cd(sav_dir_psth)

filename = ['chronux_cleanDomjMUPSTHS_' tag '.mat'];

%% Collect activity
duration = durs.domForward;
t = linspace(-duration,duration,2*duration+1);

for iChan = 1:96
    
    
    %% Collect traces
    
    c= 0;
    for iCond = 1:size(spikingActivity.validSection.BR.data.dom90{1, iChan},2)
        for nDom = 1:size(spikingActivity.validSection.BR.data.dom90{1, iChan}{1, iCond},2)
            piece = (spikingActivity.validSection.BR.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isempty(piece)
                c=c+1;
                BRdominances90(c).times = piece./1000;
            else
                c=c+1;
                BRdominances90(c).times = [];
            end
        end
    end

    c= 0;
    for iCond = 1:size(spikingActivity.validSection.BR.data.dom270{1, iChan},2)
        for nDom = 1:size(spikingActivity.validSection.BR.data.dom270{1, iChan}{1, iCond},2)
            piece = (spikingActivity.validSection.BR.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isempty(piece)
                c=c+1;
                BRdominances270(c).times = piece./1000;
            else
                c=c+1;
                BRdominances270(c).times = [];
            end
        end
    end
    
    c= 0;
    for iCond = 1:size(spikingActivity.validSection.PA.data.dom90{1, iChan},2)
        for nDom = 1:size(spikingActivity.validSection.PA.data.dom90{1, iChan}{1, iCond},2)
            piece = (spikingActivity.validSection.PA.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isempty(piece)
                c=c+1;
                PAdominances90(c).times = piece./1000;
            else
                c=c+1;
                PAdominances90(c).times = [];
            end
        end
    end

    c= 0;
    for iCond = 1:size(spikingActivity.validSection.PA.data.dom270{1, iChan},2)
        for nDom = 1:size(spikingActivity.validSection.PA.data.dom270{1, iChan}{1, iCond},2)
            piece = (spikingActivity.validSection.PA.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isempty(piece)
                c=c+1;
                PAdominances270(c).times = piece./1000;
            else
                c=c+1;
                PAdominances270(c).times = [];
            end
        end
    end
    
    %% Compute PSTH
    
    % BR
    
    [sdf_br_90,T,err_br_90] = psth(BRdominances90,25/1000,'n',[-duration/1000 duration/1000],1,t/1000);
    [sdf_br_270,T,err_br_270] = psth(BRdominances270,25/1000,'n',[-duration/1000 duration/1000],1,t/1000);
    
    % PA
    
    [sdf_pa_90,T,err_pa_90] = psth(PAdominances90,25/1000,'n',[-duration/1000 duration/1000],1,t/1000);
    [sdf_pa_270,T,err_pa_270] = psth(PAdominances270,25/1000,'n',[-duration/1000 duration/1000],1,t/1000);
    
    % Check if they are empty
    
    if isempty(sdf_br_90)
        sdf_br_90 = zeros(1,length(t));
        err_br_90 = zeros(1,length(t));
    end
    
    if isempty(sdf_br_270)
        sdf_br_270 = zeros(1,length(t));
        err_br_270 = zeros(1,length(t));
    end
    
    if isempty(sdf_pa_90)
        sdf_pa_90 = zeros(1,length(t));
        err_pa_90 = zeros(1,length(t));
    end
    
    if isempty(sdf_pa_270)
        sdf_pa_270 = zeros(1,length(t));
        err_pa_270 = zeros(1,length(t));
    end
    
    %% Plot
    
    figure(3)
    set(gcf, 'Position', get(0, 'Screensize'));
    subplot(1,2,1)
    H(1)=shadedErrorBar(t,sdf_br_90,err_br_90);
    hold on
    P(1) = plot(t,sdf_br_90,'-b','LineWidth',1.25);
    H(2)=shadedErrorBar(t,sdf_br_270,err_br_270);
    P(2) = plot(t,sdf_br_270,'-r','LineWidth',1.25);
    xlabel('time in s')
    ylabel('spikes/s')
    vline(0,'--k')
    grid on; box off; axis tight;
    legend([P(1) H(1).patch P(2) H(2).patch], 'BR 270TO90', '270TO90 SEM', 'BR 90TO270', '90TO270 SEM', 'Location','SouthEast');
    title('BR Dominances - Dataset 1 - H07')
    subplot(1,2,2)
    H(1)=shadedErrorBar(t,sdf_pa_90,err_pa_90);
    hold on
    P(1) = plot(t,sdf_pa_90,'-b','LineWidth',1.25);
    H(2)=shadedErrorBar(t,sdf_pa_270,err_pa_270);
    P(2) = plot(t,sdf_pa_270,'-r','LineWidth',1.25);
    xlabel('time in s')
    ylabel('spikes/s')
    vline(0,'--k')
    grid on; box off; axis tight;
    legend([P(1) H(1).patch P(2) H(2).patch], 'PA 270TO90', '270TO90 SEM', 'PA 90TO270', '90TO270 SEM', 'Location','SouthEast');
    title('PA Dominances - Dataset 1 - H07')
    suptitle('PA & BR 90 and 270 PSTHs - Raw - Clean Dominances')
    pause(1)
    close all
    
    %% Collect the output
    
    cleanDomPSTHs(iChan).BR.dom90(1,:) = sdf_br_90;
    cleanDomPSTHs(iChan).BR.dom90(2,:) = err_br_90;
    cleanDomPSTHs(iChan).BR.dom270(1,:) = sdf_br_270;
    cleanDomPSTHs(iChan).BR.dom270(2,:) = err_br_270;
    
    
    cleanDomPSTHs(iChan).PA.dom90(1,:) = sdf_pa_90;
    cleanDomPSTHs(iChan).PA.dom90(2,:) = err_pa_90;
    cleanDomPSTHs(iChan).PA.dom270(1,:) = sdf_pa_270;
    cleanDomPSTHs(iChan).PA.dom270(2,:) = err_pa_270;
    
end

save(filename,'cleanDomPSTHs','-v7.3');
