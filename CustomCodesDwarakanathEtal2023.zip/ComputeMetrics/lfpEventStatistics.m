function lfpEventStatistics(lfpActivity, domdur, pref_array, sav_dir_psth,expt,filtType)

% Collect event statistics for the four chosen LFP bands
% Abhilash D MPIBC 2017-18

cd(sav_dir_psth)

pad = 250;

t =linspace(-domdur.domBehind/1000,domdur.domForward/1000,(domdur.domBehind/2)+(domdur.domForward/2)+1);
evtIdx = ceil(domdur.domBehind/2)+1;
%% Get sites with preferences

if isfield(pref_array,'pref_sim_Dom_PhyRiv')
    
    fprintf('Dominance preference array found....using it\n')
    for i = 1:size(pref_array.pref_sim_Dom_PhyRiv.com_sig_u,1)
        prefs(i) = pref_array.pref_sim_Dom_PhyRiv.com_sig_u(i,2);
    end
    pref90idx = prefs==2;
    pref270idx = prefs==1;
    pref90 = pref_array.pref_sim_Dom_PhyRiv.com_sig_u(pref90idx,3);
    pref270 = pref_array.pref_sim_Dom_PhyRiv.com_sig_u(pref270idx,3);
    pref90 = pref90';pref270 = pref270';
    filename = ['blpCharacteristics_' num2str(domdur.domForward) 'ms_' filtType '_' 'DomSel' '.mat'];
    
else
    fprintf('Dominance preference array not found....defaulting to PA_FS\n')
    for i = 1:size(pref_array.pref_sim.com_sig_u,1)
        prefs(i) = pref_array.pref_sim.com_sig_u(i,2);
    end
    pref90idx = prefs==2;
    pref270idx = prefs==1;
    pref90 = pref_array.pref_sim.com_sig_u(pref90idx,3);
    pref270 = pref_array.pref_sim.com_sig_u(pref270idx,3);
    pref90 = pref90';pref270 = pref270';
    filename = ['blpCharacteristics_' num2str(domdur.domForward) 'ms_' filtType '_' 'PAFSSel' '.mat'];
end

%% Setup filters

if strcmp(filtType,'theta')
    [b,a] = butter(3,[4 8]/250); % Theta
    [b1,a1] = butter(3,6/250,'low');
    evtDur = 63;
elseif strcmp(filtType,'delta')
    [b,a] = butter(3,[1 4]/250); % delta
    [b1,a1] = butter(3,2/250,'low');
    evtDur = 125;
elseif strcmp(filtType,'beta')
    [b,a] = butter(3,[24 46]/250); % beta
    [b1,a1] = butter(3,25/250,'low');
    evtDur = 11;
elseif strcmp(filtType,'gamma')
    [b,a] = butter(3,[125 200]/250); % gamma
    [b1,a1] = butter(3,162/250,'low');
    evtDur = 3;
elseif strcmp(filtType,'low')
    [b,a] = butter(3,[1 9]/250);
    [b1,a1] = butter(3,5/250,'low');
    evtDur = 56;
end

%% Characterise NP to P

% Pref 90
c = 0;

for chan = 1:length(pref90) % Only check non-preferred to preferred
    c = c+1;
    
    % BR Dominances
    
    blpTraces_np2p_br_90 = [];
    blpPreAmps_np2p_br_90 = [];
    blpPreAmps_np2p_pa_90 = [];
    blpTraces_np2p_pa_90 = [];
    blpPostAmps_np2p_br_90 = [];
    blpPostAmps_np2p_pa_90 = [];
    nEvents_np2p_pre_br_90 = [];
    nEvents_np2p_pre_pa_90 = [];
    nEvents_np2p_post_br_90 = [];
    nEvents_np2p_post_pa_90 = [];
    blpPreEvents_np2p_br_90 = [];
    blpPostEvents_np2p_br_90 = [];
    blpPreEvents_np2p_pa_90 = [];
    blpPostEvents_np2p_pa_90 = [];
    
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, pref90(chan)},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, pref90(chan)}{1, iCond},2)
            lfppiece = ((filtfilt(b,a,detrend(lfpActivity.validSection.BR.data.dom90{1, pref90(chan)}{1, iCond}{nDom}))));
            lfppiece = abs(hilbert(lfppiece)); % Squaring works better
            lfpevents = event_detection(lfppiece,2,'madgauss',evtDur);
            lfpevents(lfpevents<=pad) = [];
            lfpevents(lfpevents>=(length(lfppiece)-pad)) = [];
            lfpevents = lfpevents-pad; % Otherwise the values get pushed forward
            lfppiece = lfppiece(pad+1:end-pad);
                            blpTraces_np2p_br_90 = [blpTraces_np2p_br_90;lfppiece'];

            if ~isempty(lfpevents)
                preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                preEvents = lfpevents(lfpevents<=evtIdx)-evtIdx;
                postEvents = lfpevents(lfpevents>evtIdx)-evtIdx;
                blpPreAmps_np2p_br_90 = [blpPreAmps_np2p_br_90 preAmps'];
                blpPostAmps_np2p_br_90 = [blpPostAmps_np2p_br_90 postAmps'];
                blpPreEvents_np2p_br_90 = [blpPreEvents_np2p_br_90 preEvents];
                blpPostEvents_np2p_br_90 = [blpPostEvents_np2p_br_90 postEvents];
                nEvents_np2p_pre_br_90 = [nEvents_np2p_pre_br_90 numel(lfpevents(lfpevents<(evtIdx)))];
                nEvents_np2p_post_br_90 = [nEvents_np2p_post_br_90 numel(lfpevents(lfpevents>(evtIdx)))];
            end
            clear ampEvt; clear lfpevents;
        end
    end
    
    %PA Dominances
    
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, pref90(chan)},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, pref90(chan)}{1, iCond},2)
            lfppiece = ((filtfilt(b,a,detrend(lfpActivity.validSection.PA.data.dom90{1, pref90(chan)}{1, iCond}{nDom}))));
            lfppiece = abs(hilbert(lfppiece)); % Squaring works better
            lfpevents = event_detection(lfppiece,2,'madgauss',evtDur);
            lfpevents(lfpevents<=pad) = [];
            lfpevents(lfpevents>=(length(lfppiece)-pad)) = [];
            lfpevents = lfpevents-pad; % Otherwise the values get pushed forward
            lfppiece = lfppiece(pad+1:end-pad);
                            blpTraces_np2p_pa_90 = [blpTraces_np2p_pa_90;lfppiece'];

            if ~isempty(lfpevents)
                preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                preEvents = lfpevents(lfpevents<=evtIdx)-evtIdx;
                postEvents = lfpevents(lfpevents>evtIdx)-evtIdx;
                blpPreAmps_np2p_pa_90 = [blpPreAmps_np2p_pa_90 preAmps'];
                blpPostAmps_np2p_pa_90 = [blpPostAmps_np2p_pa_90 postAmps'];
                blpPreEvents_np2p_pa_90 = [blpPreEvents_np2p_pa_90 preEvents];
                blpPostEvents_np2p_pa_90 = [blpPostEvents_np2p_pa_90 postEvents];
                nEvents_np2p_pre_pa_90 = [nEvents_np2p_pre_pa_90 numel(lfpevents(lfpevents<=(evtIdx)))];
                nEvents_np2p_post_pa_90 = [nEvents_np2p_post_pa_90 numel(lfpevents(lfpevents>(evtIdx)))];
            end
            clear ampEvt; clear lfpevents;
        end
    end
    
    blpCharacteristicsNP2P_90(pref90(chan)).BR.NP2P90.traces = blpTraces_np2p_br_90;
    blpCharacteristicsNP2P_90(pref90(chan)).BR.NP2P90.preAmps = blpPreAmps_np2p_br_90;
    blpCharacteristicsNP2P_90(pref90(chan)).BR.NP2P90.postAmps = blpPostAmps_np2p_br_90;
    blpCharacteristicsNP2P_90(pref90(chan)).BR.NP2P90.preEvtTimes = blpPreEvents_np2p_br_90;
    blpCharacteristicsNP2P_90(pref90(chan)).BR.NP2P90.postEvtTimes = blpPostEvents_np2p_br_90;
    blpCharacteristicsNP2P_90(pref90(chan)).BR.NP2P90.nPreEvents = sum(nEvents_np2p_pre_br_90);
    blpCharacteristicsNP2P_90(pref90(chan)).BR.NP2P90.nPostEvents = sum(nEvents_np2p_post_br_90);
    
    blpCharacteristicsNP2P_90(pref90(chan)).PA.NP2P90.traces = blpTraces_np2p_pa_90;
    blpCharacteristicsNP2P_90(pref90(chan)).PA.NP2P90.preAmps = blpPreAmps_np2p_pa_90;
    blpCharacteristicsNP2P_90(pref90(chan)).PA.NP2P90.postAmps = blpPostAmps_np2p_pa_90;
    blpCharacteristicsNP2P_90(pref90(chan)).PA.NP2P90.preEvtTimes = blpPreEvents_np2p_pa_90;
    blpCharacteristicsNP2P_90(pref90(chan)).PA.NP2P90.postEvtTimes = blpPostEvents_np2p_pa_90;
    blpCharacteristicsNP2P_90(pref90(chan)).PA.NP2P90.nPreEvents = sum(nEvents_np2p_pre_pa_90);
    blpCharacteristicsNP2P_90(pref90(chan)).PA.NP2P90.nPostEvents = sum(nEvents_np2p_post_pa_90);
    
    
end

% Pref 270
c = 0;


for chan = 1:length(pref270) % Only check non-preferred to preferred
    c = c+1;
    
    % BR Dominances
    
    blpTraces_np2p_br_270 = [];
    blpPreAmps_np2p_br_270 = [];
    blpPreAmps_np2p_pa_270 = [];
    blpTraces_np2p_pa_270 = [];
    blpPostAmps_np2p_br_270 = [];
    blpPostAmps_np2p_pa_270 = [];
    nEvents_np2p_pre_br_270 = [];
    nEvents_np2p_pre_pa_270 = [];
    nEvents_np2p_post_br_270 = [];
    nEvents_np2p_post_pa_270 = [];
    blpPreEvents_np2p_br_270 = [];
    blpPostEvents_np2p_br_270 = [];
    blpPreEvents_np2p_pa_270 = [];
    blpPostEvents_np2p_pa_270 = [];
    
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, pref270(chan)},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, pref270(chan)}{1, iCond},2)
            lfppiece = ((filtfilt(b,a,detrend(lfpActivity.validSection.BR.data.dom270{1, pref270(chan)}{1, iCond}{nDom}))));
            lfppiece = abs(hilbert(lfppiece)); % Squaring works better
            lfpevents = event_detection(lfppiece,2,'madgauss',evtDur);
            lfpevents(lfpevents<=pad) = [];
            lfpevents(lfpevents>=(length(lfppiece)-pad)) = [];
            lfpevents = lfpevents-pad; % Otherwise the values get pushed forward
            lfppiece = lfppiece(pad+1:end-pad);
                            blpTraces_np2p_br_270 = [blpTraces_np2p_br_270;lfppiece'];

            if ~isempty(lfpevents)
                preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                preEvents = lfpevents(lfpevents<=evtIdx)-evtIdx;
                postEvents = lfpevents(lfpevents>evtIdx)-evtIdx;
                blpPreAmps_np2p_br_270 = [blpPreAmps_np2p_br_270 preAmps'];
                blpPostAmps_np2p_br_270 = [blpPostAmps_np2p_br_270 postAmps'];
                blpPreEvents_np2p_br_270 = [blpPreEvents_np2p_br_270 preEvents];
                blpPostEvents_np2p_br_270 = [blpPostEvents_np2p_br_270 postEvents];
                nEvents_np2p_pre_br_270 = [nEvents_np2p_pre_br_270 numel(lfpevents(lfpevents<(evtIdx)))];
                nEvents_np2p_post_br_270 = [nEvents_np2p_post_br_270 numel(lfpevents(lfpevents>(evtIdx)))];
            end
            clear ampEvt; clear lfpevents;
        end
    end
    
    %PA Dominances
    
    for iCond = 5:size(lfpActivity.validSection.PA.data.dom270{1, pref270(chan)},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, pref270(chan)}{1, iCond},2)
            lfppiece = ((filtfilt(b,a,detrend(lfpActivity.validSection.PA.data.dom270{1, pref270(chan)}{1, iCond}{nDom}))));
            lfppiece = abs(hilbert(lfppiece)); % Squaring works better
            lfpevents = event_detection(lfppiece,2,'madgauss',evtDur);
            lfpevents(lfpevents<=pad) = [];
            lfpevents(lfpevents>=(length(lfppiece)-pad)) = [];
            lfpevents = lfpevents-pad; % Otherwise the values get pushed forward
            lfppiece = lfppiece(pad+1:end-pad);
                            blpTraces_np2p_pa_270 = [blpTraces_np2p_pa_270;lfppiece'];

            if ~isempty(lfpevents)
                preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                preEvents = lfpevents(lfpevents<=evtIdx)-evtIdx;
                postEvents = lfpevents(lfpevents>evtIdx)-evtIdx;
                blpPreAmps_np2p_pa_270 = [blpPreAmps_np2p_pa_270 preAmps'];
                blpPostAmps_np2p_pa_270 = [blpPostAmps_np2p_pa_270 postAmps'];
                blpPreEvents_np2p_pa_270 = [blpPreEvents_np2p_pa_270 preEvents];
                blpPostEvents_np2p_pa_270 = [blpPostEvents_np2p_pa_270 postEvents];
                nEvents_np2p_pre_pa_270 = [nEvents_np2p_pre_pa_270 numel(lfpevents(lfpevents<=(evtIdx)))];
                nEvents_np2p_post_pa_270 = [nEvents_np2p_post_pa_270 numel(lfpevents(lfpevents>(evtIdx)))];
            end
            clear ampEvt; clear lfpevents;
        end
    end
    
    blpCharacteristicsNP2P_270(pref270(chan)).BR.NP2P270.traces = blpTraces_np2p_br_270;
    blpCharacteristicsNP2P_270(pref270(chan)).BR.NP2P270.preAmps = blpPreAmps_np2p_br_270;
    blpCharacteristicsNP2P_270(pref270(chan)).BR.NP2P270.postAmps = blpPostAmps_np2p_br_270;
    blpCharacteristicsNP2P_270(pref270(chan)).BR.NP2P270.preEvtTimes = blpPreEvents_np2p_br_270;
    blpCharacteristicsNP2P_270(pref270(chan)).BR.NP2P270.postEvtTimes = blpPostEvents_np2p_br_270;
    blpCharacteristicsNP2P_270(pref270(chan)).BR.NP2P270.nPreEvents = sum(nEvents_np2p_pre_br_270);
    blpCharacteristicsNP2P_270(pref270(chan)).BR.NP2P270.nPostEvents = sum(nEvents_np2p_post_br_270);
    
    blpCharacteristicsNP2P_270(pref270(chan)).PA.NP2P270.traces = blpTraces_np2p_pa_270;
    blpCharacteristicsNP2P_270(pref270(chan)).PA.NP2P270.preAmps = blpPreAmps_np2p_pa_270;
    blpCharacteristicsNP2P_270(pref270(chan)).PA.NP2P270.postAmps = blpPostAmps_np2p_pa_270;
    blpCharacteristicsNP2P_270(pref270(chan)).PA.NP2P270.preEvtTimes = blpPreEvents_np2p_pa_270;
    blpCharacteristicsNP2P_270(pref270(chan)).PA.NP2P270.postEvtTimes = blpPostEvents_np2p_pa_270;
    blpCharacteristicsNP2P_270(pref270(chan)).PA.NP2P270.nPreEvents = sum(nEvents_np2p_pre_pa_270);
    blpCharacteristicsNP2P_270(pref270(chan)).PA.NP2P270.nPostEvents = sum(nEvents_np2p_post_pa_270);
    
end

%% Characterise P2NP

% Pref 270
c = 0;

for chan = 1:length(pref270) % Only check non-preferred to preferred
    c = c+1;
    % BR Dominances
    
    blpTraces_p2np_br_90 = [];
    blpPreAmps_p2np_br_90 = [];
    blpPreAmps_p2np_pa_90 = [];
    blpTraces_p2np_pa_90 = [];
    blpPostAmps_p2np_br_90 = [];
    blpPostAmps_p2np_pa_90 = [];
    nEvents_p2np_pre_br_90 = [];
    nEvents_p2np_pre_pa_90 = [];
    nEvents_p2np_post_br_90 = [];
    nEvents_p2np_post_pa_90 = [];
    blpPreEvents_p2np_br_90 = [];
    blpPostEvents_p2np_br_90 = [];
    blpPreEvents_p2np_pa_90 = [];
    blpPostEvents_p2np_pa_90 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, pref270(chan)},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, pref270(chan)}{1, iCond},2)
            lfppiece = ((filtfilt(b,a,detrend(lfpActivity.validSection.BR.data.dom90{1, pref270(chan)}{1, iCond}{nDom}))));
            lfppiece = abs(hilbert(lfppiece)); % Squaring works better
            lfpevents = event_detection(lfppiece,2,'madgauss',evtDur);
            lfpevents(lfpevents<=pad) = [];
            lfpevents(lfpevents>=(length(lfppiece)-pad)) = [];
            lfpevents = lfpevents-pad; % Otherwise the values get pushed forward
            lfppiece = lfppiece(pad+1:end-pad);
                            blpTraces_p2np_br_90 = [blpTraces_p2np_br_90;lfppiece'];

            if ~isempty(lfpevents)
                preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                preEvents = lfpevents(lfpevents<=evtIdx)-evtIdx;
                postEvents = lfpevents(lfpevents>evtIdx)-evtIdx;
                blpPreAmps_p2np_br_90 = [blpPreAmps_p2np_br_90 preAmps'];
                blpPostAmps_p2np_br_90 = [blpPostAmps_p2np_br_90 postAmps'];
                blpPreEvents_p2np_br_90 = [blpPreEvents_p2np_br_90 preEvents];
                blpPostEvents_p2np_br_90 = [blpPostEvents_p2np_br_90 postEvents];
                nEvents_p2np_pre_br_90 = [nEvents_p2np_pre_br_90 numel(lfpevents(lfpevents<(evtIdx)))];
                nEvents_p2np_post_br_90 = [nEvents_p2np_post_br_90 numel(lfpevents(lfpevents>(evtIdx)))];
            end
            clear ampEvt; clear lfpevents;
        end
    end
    
    %PA Dominances
    
    for iCond = 5:size(lfpActivity.validSection.PA.data.dom90{1, pref270(chan)},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, pref270(chan)}{1, iCond},2)
            lfppiece = ((filtfilt(b,a,detrend(lfpActivity.validSection.PA.data.dom90{1, pref270(chan)}{1, iCond}{nDom}))));
            lfppiece = abs(hilbert(lfppiece)); % Squaring works better
            lfpevents = event_detection(lfppiece,2,'madgauss',evtDur);
            lfpevents(lfpevents<=pad) = [];
            lfpevents(lfpevents>=(length(lfppiece)-pad)) = [];
            lfpevents = lfpevents-pad; % Otherwise the values get pushed forward
            lfppiece = lfppiece(pad+1:end-pad);
                            blpTraces_p2np_pa_90 = [blpTraces_p2np_pa_90;lfppiece'];

            if ~isempty(lfpevents)
                preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                preEvents = lfpevents(lfpevents<=evtIdx)-evtIdx;
                postEvents = lfpevents(lfpevents>evtIdx)-evtIdx;
                blpPreAmps_p2np_pa_90 = [blpPreAmps_p2np_pa_90 preAmps'];
                blpPostAmps_p2np_pa_90 = [blpPostAmps_p2np_pa_90 postAmps'];
                blpPreEvents_p2np_pa_90 = [blpPreEvents_p2np_pa_90 preEvents];
                blpPostEvents_p2np_pa_90 = [blpPostEvents_p2np_pa_90 postEvents];
                nEvents_p2np_pre_pa_90 = [nEvents_p2np_pre_pa_90 numel(lfpevents(lfpevents<(evtIdx)))];
                nEvents_p2np_post_pa_90 = [nEvents_p2np_post_pa_90 numel(lfpevents(lfpevents>(evtIdx)))];
            end
            clear ampEvt; clear lfpevents;
        end
    end
    
    blpCharacteristicsP2NP_270(pref270(chan)).BR.P2NP90.traces = blpTraces_p2np_br_90;
    blpCharacteristicsP2NP_270(pref270(chan)).BR.P2NP90.preAmps = blpPreAmps_p2np_br_90;
    blpCharacteristicsP2NP_270(pref270(chan)).BR.P2NP90.postAmps = blpPostAmps_p2np_br_90;
    blpCharacteristicsP2NP_270(pref270(chan)).BR.P2NP90.preEvtTimes = blpPreEvents_p2np_br_90;
    blpCharacteristicsP2NP_270(pref270(chan)).BR.P2NP90.postEvtTimes = blpPostEvents_p2np_br_90;
    blpCharacteristicsP2NP_270(pref270(chan)).BR.P2NP90.nPreEvents = sum(nEvents_p2np_pre_br_90);
    blpCharacteristicsP2NP_270(pref270(chan)).BR.P2NP90.nPostEvents = sum(nEvents_p2np_post_br_90);
    
    blpCharacteristicsP2NP_270(pref270(chan)).PA.P2NP90.traces = blpTraces_p2np_pa_90;
    blpCharacteristicsP2NP_270(pref270(chan)).PA.P2NP90.preAmps = blpPreAmps_p2np_pa_90;
    blpCharacteristicsP2NP_270(pref270(chan)).PA.P2NP90.postAmps = blpPostAmps_p2np_pa_90;
    blpCharacteristicsP2NP_270(pref270(chan)).PA.P2NP90.preEvtTimes = blpPreEvents_p2np_pa_90;
    blpCharacteristicsP2NP_270(pref270(chan)).PA.P2NP90.postEvtTimes = blpPostEvents_p2np_pa_90;
    blpCharacteristicsP2NP_270(pref270(chan)).PA.P2NP90.nPreEvents = sum(nEvents_p2np_pre_pa_90);
    blpCharacteristicsP2NP_270(pref270(chan)).PA.P2NP90.nPostEvents = sum(nEvents_p2np_post_pa_90);
    
    
end

% Pref 90

c = 0;

for chan = 1:length(pref90) % Only check non-preferred to preferred
    c = c+1;
    
    % BR Dominances
    
    blpTraces_p2np_br_270 = [];
    blpPreAmps_p2np_br_270 = [];
    blpPreAmps_p2np_pa_270 = [];
    blpTraces_p2np_pa_270 = [];
    blpPostAmps_p2np_br_270 = [];
    blpPostAmps_p2np_pa_270 = [];
    nEvents_p2np_pre_br_270 = [];
    nEvents_p2np_pre_pa_270 = [];
    nEvents_p2np_post_br_270 = [];
    nEvents_p2np_post_pa_270 = [];
    blpPreEvents_p2np_br_270 = [];
    blpPostEvents_p2np_br_270 = [];
    blpPreEvents_p2np_pa_270 = [];
    blpPostEvents_p2np_pa_270 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, pref90(chan)},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, pref90(chan)}{1, iCond},2)
            lfppiece = ((filtfilt(b,a,detrend(lfpActivity.validSection.BR.data.dom270{1, pref90(chan)}{1, iCond}{nDom}))));
            lfppiece = abs(hilbert(lfppiece)); % Squaring works better
            lfpevents = event_detection(lfppiece,2,'madgauss',evtDur);
            lfpevents(lfpevents<=pad) = [];
            lfpevents(lfpevents>=(length(lfppiece)-pad)) = [];
            lfpevents = lfpevents-pad; % Otherwise the values get pushed forward
            lfppiece = lfppiece(pad+1:end-pad);
                            blpTraces_p2np_br_270 = [blpTraces_p2np_br_270;lfppiece'];

            if ~isempty(lfpevents)
                preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                preEvents = lfpevents(lfpevents<=evtIdx)-evtIdx;
                postEvents = lfpevents(lfpevents>evtIdx)-evtIdx;
                blpPreAmps_p2np_br_270 = [blpPreAmps_p2np_br_270 preAmps'];
                blpPostAmps_p2np_br_270 = [blpPostAmps_p2np_br_270 postAmps'];
                blpPreEvents_p2np_br_270 = [blpPreEvents_p2np_br_270 preEvents];
                blpPostEvents_p2np_br_270 = [blpPostEvents_p2np_br_270 postEvents];
                nEvents_p2np_pre_br_270 = [nEvents_p2np_pre_br_270 numel(lfpevents(lfpevents<(evtIdx)))];
                nEvents_p2np_post_br_270 = [nEvents_p2np_post_br_270 numel(lfpevents(lfpevents>(evtIdx)))];
            end
            clear ampEvt; clear lfpevents;
        end
    end
    
    %PA Dominances
    
    for iCond = 5:size(lfpActivity.validSection.PA.data.dom270{1, pref90(chan)},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, pref90(chan)}{1, iCond},2)
            lfppiece = ((filtfilt(b,a,detrend(lfpActivity.validSection.PA.data.dom270{1, pref90(chan)}{1, iCond}{nDom}))));
            lfppiece = abs(hilbert(lfppiece)); % Squaring works better
            lfpevents = event_detection(lfppiece,2,'madgauss',evtDur);
            lfpevents(lfpevents<=pad) = [];
            lfpevents(lfpevents>=(length(lfppiece)-pad)) = [];
            lfpevents = lfpevents-pad; % Otherwise the values get pushed forward
            lfppiece = lfppiece(pad+1:end-pad);
                            blpTraces_p2np_pa_270 = [blpTraces_p2np_pa_270;lfppiece'];

            if ~isempty(lfpevents)
                preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                preEvents = lfpevents(lfpevents<=evtIdx)-evtIdx;
                postEvents = lfpevents(lfpevents>evtIdx)-evtIdx;
                blpPreAmps_p2np_pa_270 = [blpPreAmps_p2np_pa_270 preAmps'];
                blpPostAmps_p2np_pa_270 = [blpPostAmps_p2np_pa_270 postAmps'];
                blpPreEvents_p2np_pa_270 = [blpPreEvents_p2np_pa_270 preEvents];
                blpPostEvents_p2np_pa_270 = [blpPostEvents_p2np_pa_270 postEvents];
                nEvents_p2np_pre_pa_270 = [nEvents_p2np_pre_pa_270 numel(lfpevents(lfpevents<(evtIdx)))];
                nEvents_p2np_post_pa_270 = [nEvents_p2np_post_pa_270 numel(lfpevents(lfpevents>(evtIdx)))];
            end
            clear ampEvt; clear lfpevents;
        end
    end
    
    blpCharacteristicsP2NP_90(pref90(chan)).BR.P2NP270.traces = blpTraces_p2np_br_270;
    blpCharacteristicsP2NP_90(pref90(chan)).BR.P2NP270.preAmps = blpPreAmps_p2np_br_270;
    blpCharacteristicsP2NP_90(pref90(chan)).BR.P2NP270.postAmps = blpPostAmps_p2np_br_270;
    blpCharacteristicsP2NP_90(pref90(chan)).BR.P2NP270.preEvtTimes = blpPreEvents_p2np_br_270;
    blpCharacteristicsP2NP_90(pref90(chan)).BR.P2NP270.postEvtTimes = blpPostEvents_p2np_br_270;
    blpCharacteristicsP2NP_90(pref90(chan)).BR.P2NP270.nPreEvents = sum(nEvents_p2np_pre_br_270);
    blpCharacteristicsP2NP_90(pref90(chan)).BR.P2NP270.nPostEvents = sum(nEvents_p2np_post_br_270);
    
    blpCharacteristicsP2NP_90(pref90(chan)).PA.P2NP270.traces = blpTraces_p2np_pa_270;
    blpCharacteristicsP2NP_90(pref90(chan)).PA.P2NP270.preAmps = blpPreAmps_p2np_pa_270;
    blpCharacteristicsP2NP_90(pref90(chan)).PA.P2NP270.postAmps = blpPostAmps_p2np_pa_270;
    blpCharacteristicsP2NP_90(pref90(chan)).PA.P2NP270.preEvtTimes = blpPreEvents_p2np_pa_270;
    blpCharacteristicsP2NP_90(pref90(chan)).PA.P2NP270.postEvtTimes = blpPostEvents_p2np_pa_270;
    blpCharacteristicsP2NP_90(pref90(chan)).PA.P2NP270.nPreEvents = sum(nEvents_p2np_pre_pa_270);
    blpCharacteristicsP2NP_90(pref90(chan)).PA.P2NP270.nPostEvents = sum(nEvents_p2np_post_pa_270);
    
end

save(filename,'blpCharacteristicsP2NP_90','blpCharacteristicsP2NP_270','blpCharacteristicsNP2P_90','blpCharacteristicsNP2P_270','-v7.3')