function lfpEventRateInTimeTbyT(lfpActivity, domdur, sav_dir_psth,expt,filtType)

% Collect event statistics for the four chosen LFP bands
% Abhilash D MPIBC 2017-18

cd(sav_dir_psth)

pad = 500;

filename = ['MMstd4_TbyT_eventRateByTime_' num2str(domdur.domBehind) 'ms_Chebyshev1_' filtType '.mat'];

t =linspace(-domdur.domBehind/1000,domdur.domForward/1000,(domdur.domBehind/2)+(domdur.domForward/2)+1);
evtIdx = ceil(domdur.domBehind/2)+1;
midPoint = t(ceil(length(t)/2));

sigma = 1/50;

[x,y] = smoothingkernel(domdur.domBehind/1000,500,sigma,'gaussian');
%% Setup filters

if strcmp(filtType,'theta')
    [b,a] = cheby1(4,0.01,[4 8]/250); % Theta
    %[b1,a1] = cheby1(4,6/250,'low');
    evtDur = 50;
elseif strcmp(filtType,'delta')
    [b,a] = cheby1(4,0.01,[1 4]/250); % delta
    %[b1,a1] = cheby1(4,2/250,'low');
    evtDur = 250;
elseif strcmp(filtType,'beta')
    [b,a] = cheby1(8,0.01,[20 40]/250); % beta
    %[b1,a1] = cheby1(4,25/250,'low');
    evtDur = 13;
elseif strcmp(filtType,'gamma')
    [b,a] = cheby1(16,0.01,[125 200]/250); % gamma
    %[b1,a1] = cheby1(4,162/250,'low');
    evtDur = 3;
elseif strcmp(filtType,'low')
    [b,a] = cheby1(4,0.01,[1 9]/250);
    %[b1,a1] = cheby1(4,5/250,'low');
    evtDur = 56;
    elseif strcmp(filtType,'special')
    [b1,a1] = cheby1(4,0.01,[2 7]/250);
    %[b1,a1] = cheby1(4,5/250,'low');
    evtDur = 150;
end

%% Get Doms 90
    
    % BR Dominances
    
    c = 0;
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1}{1, iCond},2)
            c= c+1;
            for chan = 1:96
                lfppiece = ((((lfpActivity.validSection.BR.data.dom90{1, chan}{1, iCond}{nDom}))));
                [val,~] = max(lfppiece);
                if val<=750
                    lfppiece = filtfilt(b,a,lfppiece);
                    lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                    lfpevents = event_detection(detrend(lfppiece),4,'stdgauss',evtDur);
                    lfpevents(lfpevents<=pad) = [];
                    lfpevents(lfpevents>=(length(t)+pad)) = [];
                    lfpevents = lfpevents-pad;
                    lfpevents = (lfpevents-evtIdx)/500;
                    
                    if ~isempty(lfpevents)
                        er_br_dom90 = zeros(1,length(t));
                        for nSpk = 1:length(lfpevents)
                            val = lfpevents(nSpk); %value to find
                            tmp = abs(t-val);
                            [idx idx] = min(tmp); %index of closest value
                            spkIdx(nSpk) = idx;
                        end
                        er_br_dom90(spkIdx) = 1;
                        erTrace_br_dom90(c,chan,:) = conv(er_br_dom90,y,'same');
                        clear spkIdx
                    else
                        erTrace_br_dom90(c,chan,:) = zeros(1,length(t));
                    end
                    
                end
                
            end
        end
        
    end
    eventRatePerTransition.BR.dom90 = erTrace_br_dom90;
    
    c = 0;
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1}{1, iCond},2)
            c= c+1;
            for chan = 1:96
                lfppiece = ((((lfpActivity.validSection.BR.data.dom270{1, chan}{1, iCond}{nDom}))));
                [val,~] = max(lfppiece);
                if val<=750
                    lfppiece = filtfilt(b,a,lfppiece);
                    lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                    lfpevents = event_detection(detrend(lfppiece),4,'stdgauss',evtDur);
                    lfpevents(lfpevents<=pad) = [];
                    lfpevents(lfpevents>=(length(t)+pad)) = [];
                    lfpevents = lfpevents-pad;
                    lfpevents = (lfpevents-evtIdx)/500;
                    
                    if ~isempty(lfpevents)
                        er_br_dom270 = zeros(1,length(t));
                        for nSpk = 1:length(lfpevents)
                            val = lfpevents(nSpk); %value to find
                            tmp = abs(t-val);
                            [idx idx] = min(tmp); %index of closest value
                            spkIdx(nSpk) = idx;
                        end
                        er_br_dom270(spkIdx) = 1;
                        erTrace_br_dom270(c,chan,:) = conv(er_br_dom270,y,'same');
                        clear spkIdx
                    else
                        erTrace_br_dom270(c,chan,:) = zeros(1,length(t));
                    end
                    
                end
                
            end
        end
        
    end
    eventRatePerTransition.BR.dom270 = erTrace_br_dom270;
    
    c = 0;
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1}{1, iCond},2)
            c= c+1;
            for chan = 1:96
                lfppiece = ((((lfpActivity.validSection.PA.data.dom90{1, chan}{1, iCond}{nDom}))));
                [val,~] = max(lfppiece);
                if val<=750
                    lfppiece = filtfilt(b,a,lfppiece);
                    lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                    lfpevents = event_detection(detrend(lfppiece),4,'stdgauss',evtDur);
                    lfpevents(lfpevents<=pad) = [];
                    lfpevents(lfpevents>=(length(t)+pad)) = [];
                    lfpevents = lfpevents-pad;
                    lfpevents = (lfpevents-evtIdx)/500;
                    
                    if ~isempty(lfpevents)
                        er_pa_dom90 = zeros(1,length(t));
                        for nSpk = 1:length(lfpevents)
                            val = lfpevents(nSpk); %value to find
                            tmp = abs(t-val);
                            [idx idx] = min(tmp); %index of closest value
                            spkIdx(nSpk) = idx;
                        end
                        er_pa_dom90(spkIdx) = 1;
                        erTrace_pa_dom90(c,chan,:) = conv(er_pa_dom90,y,'same');
                        clear spkIdx
                    else
                        erTrace_pa_dom90(c,chan,:) = zeros(1,length(t));
                    end
                    
                end
                
            end
        end
        
    end
    eventRatePerTransition.PA.dom90 = erTrace_pa_dom90;
    
    c = 0;
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1}{1, iCond},2)
            c= c+1;
            for chan = 1:96
                lfppiece = ((((lfpActivity.validSection.PA.data.dom270{1, chan}{1, iCond}{nDom}))));
                [val,~] = max(lfppiece);
                if val<=750
                    lfppiece = filtfilt(b,a,lfppiece);
                    lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                    lfpevents = event_detection(detrend(lfppiece),4,'stdgauss',evtDur);
                    lfpevents(lfpevents<=pad) = [];
                    lfpevents(lfpevents>=(length(t)+pad)) = [];
                    lfpevents = lfpevents-pad;
                    lfpevents = (lfpevents-evtIdx)/500;
                    
                    if ~isempty(lfpevents)
                        er_pa_dom270 = zeros(1,length(t));
                        for nSpk = 1:length(lfpevents)
                            val = lfpevents(nSpk); %value to find
                            tmp = abs(t-val);
                            [idx idx] = min(tmp); %index of closest value
                            spkIdx(nSpk) = idx;
                        end
                        er_pa_dom270(spkIdx) = 1;
                        erTrace_pa_dom270(c,chan,:) = conv(er_pa_dom270,y,'same');
                        clear spkIdx
                    else
                        erTrace_pa_dom270(c,chan,:) = zeros(1,length(t));
                    end
                    
                end
                
            end
        end
        
    end
    eventRatePerTransition.PA.dom270 = erTrace_pa_dom270;
    
    

save(filename,'eventRatePerTransition','-v7.3')
