# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import matplotlib as plt
import numpy as np
import csv

signal_data = np.loadtxt('/Users/admin/Desktop/SpikeData/BetaBurstingEventsMichelMethod_Chan1_RS.csv', delimiter=',')



def extract_chunks(input_data, tolerance):
    # First figure out which compound data structure to use in the form of 
    # (start, end) and then return an array containing the data structure 
    # as elements
     chunks = []
     
     temp = [input_data[0]]
     
     for i in range(len(input_data) - 1):
         if input_data[i+1] - input_data[i] <= tolerance:
             temp.append(input_data[i+1])
         else:
             if len(temp) != 1 and temp[len(temp) -1] != temp[0]:
                 chunks.append(temp)
             temp = [input_data[i+1]]
         print(temp)
     if len(temp) != 1 and temp[len(temp) -1] != temp[0]:
         chunks.append(temp)
     return chunks
        
def chunk_lengths(chunks):
    # First figure out which compound data structure to use in the form of 
    # (start, end) and then decompose it and return the sum of all end - start
    # values
    lengths = []
    for chunk in chunks:
        lengths.append((chunk[len(chunk) -1] - chunk[0]))
    return np.asarray(lengths)

delta = 0.27
signal_data /= 500
chunks = extract_chunks(signal_data, np.mean(np.diff(signal_data)) - delta)
flattened = [val for sublist in chunks for val in sublist]
chunkArray = np.array(flattened)
lengths = chunk_lengths(chunks)

starts = []
for i in chunks:
    starts.append(i[0])
    
ends = []
for i in chunks:
    ends.append(i[len(i) -1])
    
with open('chunks.csv', mode='w') as chunks_file:
    writer = csv.writer(chunks_file, delimiter=',')
    writer.writerow(starts)
    writer.writerow(ends)
    
plt.pyplot.hist(lengths, bins=100)

