function lfpBroadbandEvents(lfpActivity, domdur, sav_dir_psth)

% Collect event statistics for the four chosen LFP bands
% Abhilash D MPIBC 2017-18

cd(sav_dir_psth)

pad = 500;

filename = ['broadband_evtTriggered_blpTraces_' num2str(domdur.domBehind) 'ms.mat'];

t =linspace(-domdur.domBehind/1000,domdur.domForward/1000,(domdur.domBehind/2)+(domdur.domForward/2)+1);
evtIdx = ceil(domdur.domBehind/2)+1; % This is where the switch happens.

evtDur = 25;

%% Get Doms 90

buffer = 175; % We will collect 350ms

for chan = 1:96
    
    % BR Dominances 90
    
    pre_blp_BR_90_etTraces = [];
    post_blp_BR_90_etTraces = [];
    specgram_pre_BR_90 = [];
    specgram_post_BR_90 = [];
    specgram_pre_BR_90_norm1 = [];
    specgram_post_BR_90_norm1 = [];
    specgram_pre_BR_90_norm2 = [];
    specgram_post_BR_90_norm2 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, chan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, chan}{1, iCond},2)
            lfppiece = ((((lfpActivity.validSection.BR.data.dom90{1, chan}{1, iCond}{nDom}))));
            [val,~] = max(lfppiece);
            if val<=750
                lfpAmp = abs(hilbert(lfppiece)); % Squaring works better but we will stick with the Hilbert as of now because its more standard
                lfpevents = event_detection(detrend(lfpAmp),4,'stdgauss',evtDur); % Detect the events here
                lfpevents(lfpevents<=pad) = []; % Remove events which are due to the filtering artifact due to zero-padding. This is what saves us.
                lfpevents(lfpevents>=(length(t)+pad)) = []; 
                lfpevents = lfpevents-pad; % Adjust the event times due to the padding
                lfpTrace = lfpAmp(pad+1:end-pad); % Now collect the filtered lfp piece and remove the padding 
                
                if ~isempty(lfpevents)
                    
                    for iEvt = 1:length(lfpevents)
                        
                        if lfpevents(iEvt) <= evtIdx && lfpevents(iEvt) > buffer % This is for the pre-switch events
                            
                            pre_blp_BR_90_etTraces = [pre_blp_BR_90_etTraces lfpTrace(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)]; % Collect lf triggered beta traces
                            lfppiece = lfppiece(pad+1:end-pad); % Remove padding from the original LFP piece
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]); % Compute the spectrogram here on the original LFP trace triggered at the low frequency event
                            specgram = abs(specgram.^2); 
                            specgram_pre_BR_90 = cat(3,specgram_pre_BR_90,specgram);
                            specgram_pre_BR_90_norm1 = cat(3,specgram_pre_BR_90_norm1,zscore(specgram,[],1));
                            specgram_pre_BR_90_norm2 = cat(3,specgram_pre_BR_90_norm1,zscore(specgram,[],2));
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter - inelegant hack but serves its purpose really well.
                            
                        elseif lfpevents(iEvt) >= evtIdx && lfpevents(iEvt) < length(t)-buffer % This is for the post-switch events
                            
                            post_blp_BR_90_etTraces = [post_blp_BR_90_etTraces lfpTrace(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)]; % Collect lf triggered beta traces
                            lfppiece = lfppiece(pad+1:end-pad); % Remove padding from the original LFP piece
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]); % Compute the spectrogram here on the original LFP trace triggered at the low frequency event
                            specgram = abs(specgram.^2); 
                            specgram_post_BR_90 = cat(3,specgram_post_BR_90,specgram);
                            specgram_post_BR_90_norm1 = cat(3,specgram_post_BR_90_norm1,zscore(specgram,[],1));
                            specgram_post_BR_90_norm2 = cat(3,specgram_post_BR_90_norm1,zscore(specgram,[],2));
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter - inelegant hack but serves its purpose really well.

                        end
                        
                    end
                    
                end
                
            end
            
        end
        
    end
    
    eventTriggeredTraces(chan).BR.dom90.Pre.low = pre_blp_BR_90_etTraces;
    eventTriggeredTraces(chan).BR.dom90.Post.beta = post_blp_BR_90_etTraces;
    eventTriggeredTraces(chan).BR.dom90.Pre.specgram = nanmean(specgram_pre_BR_90,3);
    eventTriggeredTraces(chan).BR.dom90.Post.specgram = nanmean(specgram_post_BR_90,3);
    eventTriggeredTraces(chan).BR.dom90.Pre.specgram_norm1 = nanmean(specgram_pre_BR_90_norm1,3);
    eventTriggeredTraces(chan).BR.dom90.Pre.specgram_norm2 = nanmean(specgram_pre_BR_90_norm2,3);
    eventTriggeredTraces(chan).BR.dom90.Post.specgram_norm1 = nanmean(specgram_post_BR_90_norm1,3);
    eventTriggeredTraces(chan).BR.dom90.Post.specgram_norm2 = nanmean(specgram_post_BR_90_norm2,3);
    
    
   % BR Dominances 270
    
    pre_blp_BR_270_etTraces = [];
    post_blp_BR_270_etTraces = [];
    specgram_pre_BR_270 = [];
    specgram_post_BR_270 = [];
    specgram_pre_BR_270_norm1 = [];
    specgram_post_BR_270_norm1 = [];
    specgram_pre_BR_270_norm2 = [];
    specgram_post_BR_270_norm2 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, chan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, chan}{1, iCond},2)
            lfppiece = ((((lfpActivity.validSection.BR.data.dom270{1, chan}{1, iCond}{nDom}))));
            [val,~] = max(lfppiece);
            if val<=750
                lfpAmp = abs(hilbert(lfppiece)); % Squaring works better but we will stick with the Hilbert as of now because its more standard
                lfpevents = event_detection(detrend(lfpAmp),4,'stdgauss',evtDur); % Detect the events here
                lfpevents(lfpevents<=pad) = []; % Remove events which are due to the filtering artifact due to zero-padding. This is what saves us.
                lfpevents(lfpevents>=(length(t)+pad)) = []; 
                lfpevents = lfpevents-pad; % Adjust the event times due to the padding
                lfpTrace = lfpAmp(pad+1:end-pad); % Now collect the filtered lfp piece and remove the padding 
                
                if ~isempty(lfpevents)
                    
                    for iEvt = 1:length(lfpevents)
                        
                        if lfpevents(iEvt) <= evtIdx && lfpevents(iEvt) > buffer % This is for the pre-switch events
                            
                            pre_blp_BR_270_etTraces = [pre_blp_BR_270_etTraces lfpTrace(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)]; % Collect lf triggered beta traces
                            lfppiece = lfppiece(pad+1:end-pad); % Remove padding from the original LFP piece
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]); % Compute the spectrogram here on the original LFP trace triggered at the low frequency event
                            specgram = abs(specgram.^2); 
                            specgram_pre_BR_270 = cat(3,specgram_pre_BR_270,specgram);
                            specgram_pre_BR_270_norm1 = cat(3,specgram_pre_BR_270_norm1,zscore(specgram,[],1));
                            specgram_pre_BR_270_norm2 = cat(3,specgram_pre_BR_270_norm1,zscore(specgram,[],2));
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter - inelegant hack but serves its purpose really well.
                            
                        elseif lfpevents(iEvt) >= evtIdx && lfpevents(iEvt) < length(t)-buffer % This is for the post-switch events
                            
                            post_blp_BR_270_etTraces = [post_blp_BR_270_etTraces lfpTrace(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)]; % Collect lf triggered beta traces
                            lfppiece = lfppiece(pad+1:end-pad); % Remove padding from the original LFP piece
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]); % Compute the spectrogram here on the original LFP trace triggered at the low frequency event
                            specgram = abs(specgram.^2); 
                            specgram_post_BR_270 = cat(3,specgram_post_BR_270,specgram);
                            specgram_post_BR_270_norm1 = cat(3,specgram_post_BR_270_norm1,zscore(specgram,[],1));
                            specgram_post_BR_270_norm2 = cat(3,specgram_post_BR_270_norm1,zscore(specgram,[],2));
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter - inelegant hack but serves its purpose really well.

                        end
                        
                    end
                    
                end
                
            end
            
        end
        
    end
    
    eventTriggeredTraces(chan).BR.dom270.Pre.low = pre_blp_BR_270_etTraces;
    eventTriggeredTraces(chan).BR.dom270.Post.beta = post_blp_BR_270_etTraces;
    eventTriggeredTraces(chan).BR.dom270.Pre.specgram = nanmean(specgram_pre_BR_270,3);
    eventTriggeredTraces(chan).BR.dom270.Post.specgram = nanmean(specgram_post_BR_270,3);
    eventTriggeredTraces(chan).BR.dom270.Pre.specgram_norm1 = nanmean(specgram_pre_BR_270_norm1,3);
    eventTriggeredTraces(chan).BR.dom270.Pre.specgram_norm2 = nanmean(specgram_pre_BR_270_norm2,3);
    eventTriggeredTraces(chan).BR.dom270.Post.specgram_norm1 = nanmean(specgram_post_BR_270_norm1,3);
    eventTriggeredTraces(chan).BR.dom270.Post.specgram_norm2 = nanmean(specgram_post_BR_270_norm2,3);
    
     % PA Dominances 90
    
    pre_blp_PA_90_etTraces = [];
    post_blp_PA_90_etTraces = [];
    specgram_pre_PA_90 = [];
    specgram_post_PA_90 = [];
    specgram_pre_PA_90_norm1 = [];
    specgram_post_PA_90_norm1 = [];
    specgram_pre_PA_90_norm2 = [];
    specgram_post_PA_90_norm2 = [];
    
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, chan},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, chan}{1, iCond},2)
            lfppiece = ((((lfpActivity.validSection.PA.data.dom90{1, chan}{1, iCond}{nDom}))));
            [val,~] = max(lfppiece);
            if val<=750
                lfpAmp = abs(hilbert(lfppiece)); % Squaring works better but we will stick with the Hilbert as of now because its more standard
                lfpevents = event_detection(detrend(lfpAmp),4,'stdgauss',evtDur); % Detect the events here
                lfpevents(lfpevents<=pad) = []; % Remove events which are due to the filtering artifact due to zero-padding. This is what saves us.
                lfpevents(lfpevents>=(length(t)+pad)) = []; 
                lfpevents = lfpevents-pad; % Adjust the event times due to the padding
                lfpTrace = lfpAmp(pad+1:end-pad); % Now collect the filtered lfp piece and remove the padding 
                
                if ~isempty(lfpevents)
                    
                    for iEvt = 1:length(lfpevents)
                        
                        if lfpevents(iEvt) <= evtIdx && lfpevents(iEvt) > buffer % This is for the pre-switch events
                            
                            pre_blp_PA_90_etTraces = [pre_blp_PA_90_etTraces lfpTrace(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)]; % Collect lf triggered beta traces
                            lfppiece = lfppiece(pad+1:end-pad); % Remove padding from the original LFP piece
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]); % Compute the spectrogram here on the original LFP trace triggered at the low frequency event
                            specgram = abs(specgram.^2); 
                            specgram_pre_PA_90 = cat(3,specgram_pre_PA_90,specgram);
                            specgram_pre_PA_90_norm1 = cat(3,specgram_pre_PA_90_norm1,zscore(specgram,[],1));
                            specgram_pre_PA_90_norm2 = cat(3,specgram_pre_PA_90_norm1,zscore(specgram,[],2));
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter - inelegant hack but serves its purpose really well.
                            
                        elseif lfpevents(iEvt) >= evtIdx && lfpevents(iEvt) < length(t)-buffer % This is for the post-switch events
                            
                            post_blp_PA_90_etTraces = [post_blp_PA_90_etTraces lfpTrace(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)]; % Collect lf triggered beta traces
                            lfppiece = lfppiece(pad+1:end-pad); % Remove padding from the original LFP piece
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]); % Compute the spectrogram here on the original LFP trace triggered at the low frequency event
                            specgram = abs(specgram.^2); 
                            specgram_post_PA_90 = cat(3,specgram_post_PA_90,specgram);
                            specgram_post_PA_90_norm1 = cat(3,specgram_post_PA_90_norm1,zscore(specgram,[],1));
                            specgram_post_PA_90_norm2 = cat(3,specgram_post_PA_90_norm1,zscore(specgram,[],2));
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter - inelegant hack but serves its purpose really well.

                        end
                        
                    end
                    
                end
                
            end
            
        end
        
    end
    
    eventTriggeredTraces(chan).PA.dom90.Pre.low = pre_blp_PA_90_etTraces;
    eventTriggeredTraces(chan).PA.dom90.Post.beta = post_blp_PA_90_etTraces;
    eventTriggeredTraces(chan).PA.dom90.Pre.specgram = nanmean(specgram_pre_PA_90,3);
    eventTriggeredTraces(chan).PA.dom90.Post.specgram = nanmean(specgram_post_PA_90,3);
    eventTriggeredTraces(chan).PA.dom90.Pre.specgram_norm1 = nanmean(specgram_pre_PA_90_norm1,3);
    eventTriggeredTraces(chan).PA.dom90.Pre.specgram_norm2 = nanmean(specgram_pre_PA_90_norm2,3);
    eventTriggeredTraces(chan).PA.dom90.Post.specgram_norm1 = nanmean(specgram_post_PA_90_norm1,3);
    eventTriggeredTraces(chan).PA.dom90.Post.specgram_norm2 = nanmean(specgram_post_PA_90_norm2,3);
    
    
   % PA Dominances 270
    
    pre_blp_PA_270_etTraces = [];
    post_blp_PA_270_etTraces = [];
    specgram_pre_PA_270 = [];
    specgram_post_PA_270 = [];
    specgram_pre_PA_270_norm1 = [];
    specgram_post_PA_270_norm1 = [];
    specgram_pre_PA_270_norm2 = [];
    specgram_post_PA_270_norm2 = [];
    
    for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, chan},2)
        for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, chan}{1, iCond},2)
            lfppiece = ((((lfpActivity.validSection.PA.data.dom270{1, chan}{1, iCond}{nDom}))));
            [val,~] = max(lfppiece);
            if val<=750
                lfpAmp = abs(hilbert(lfppiece)); % Squaring works better but we will stick with the Hilbert as of now because its more standard
                lfpevents = event_detection(detrend(lfpAmp),4,'stdgauss',evtDur); % Detect the events here
                lfpevents(lfpevents<=pad) = []; % Remove events which are due to the filtering artifact due to zero-padding. This is what saves us.
                lfpevents(lfpevents>=(length(t)+pad)) = []; 
                lfpevents = lfpevents-pad; % Adjust the event times due to the padding
                lfpTrace = lfpAmp(pad+1:end-pad); % Now collect the filtered lfp piece and remove the padding 
                
                if ~isempty(lfpevents)
                    
                    for iEvt = 1:length(lfpevents)
                        
                        if lfpevents(iEvt) <= evtIdx && lfpevents(iEvt) > buffer % This is for the pre-switch events
                            
                            pre_blp_PA_270_etTraces = [pre_blp_PA_270_etTraces lfpTrace(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)]; % Collect lf triggered beta traces
                            lfppiece = lfppiece(pad+1:end-pad); % Remove padding from the original LFP piece
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]); % Compute the spectrogram here on the original LFP trace triggered at the low frequency event
                            specgram = abs(specgram.^2); 
                            specgram_pre_PA_270 = cat(3,specgram_pre_PA_270,specgram);
                            specgram_pre_PA_270_norm1 = cat(3,specgram_pre_PA_270_norm1,zscore(specgram,[],1));
                            specgram_pre_PA_270_norm2 = cat(3,specgram_pre_PA_270_norm1,zscore(specgram,[],2));
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter - inelegant hack but serves its purpose really well.
                            
                        elseif lfpevents(iEvt) >= evtIdx && lfpevents(iEvt) < length(t)-buffer % This is for the post-switch events
                            
                            post_blp_PA_270_etTraces = [post_blp_PA_270_etTraces lfpTrace(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer)]; % Collect lf triggered beta traces
                            lfppiece = lfppiece(pad+1:end-pad); % Remove padding from the original LFP piece
                            [specgram, f] = cwt(lfppiece(lfpevents(iEvt)-buffer+1:lfpevents(iEvt)+buffer),'morse',500,'VoicesPerOctave',24,'NumOctaves',6,'WaveletParameters',[3 30]); % Compute the spectrogram here on the original LFP trace triggered at the low frequency event
                            specgram = abs(specgram.^2); 
                            specgram_post_PA_270 = cat(3,specgram_post_PA_270,specgram);
                            specgram_post_PA_270_norm1 = cat(3,specgram_post_PA_270_norm1,zscore(specgram,[],1));
                            specgram_post_PA_270_norm2 = cat(3,specgram_post_PA_270_norm1,zscore(specgram,[],2));
                            lfppiece = [zeros(pad,1);lfppiece;zeros(pad,1)]; % To pad back for the next iteration to filter - inelegant hack but serves its purpose really well.

                        end
                        
                    end
                    
                end
                
            end
            
        end
        
    end
    
    eventTriggeredTraces(chan).PA.dom270.Pre.low = pre_blp_PA_270_etTraces;
    eventTriggeredTraces(chan).PA.dom270.Post.beta = post_blp_PA_270_etTraces;
    eventTriggeredTraces(chan).PA.dom270.Pre.specgram = nanmean(specgram_pre_PA_270,3);
    eventTriggeredTraces(chan).PA.dom270.Post.specgram = nanmean(specgram_post_PA_270,3);
    eventTriggeredTraces(chan).PA.dom270.Pre.specgram_norm1 = nanmean(specgram_pre_PA_270_norm1,3);
    eventTriggeredTraces(chan).PA.dom270.Pre.specgram_norm2 = nanmean(specgram_pre_PA_270_norm2,3);
    eventTriggeredTraces(chan).PA.dom270.Post.specgram_norm1 = nanmean(specgram_post_PA_270_norm1,3);
    eventTriggeredTraces(chan).PA.dom270.Post.specgram_norm2 = nanmean(specgram_post_PA_270_norm2,3);
    eventTriggeredTraces(chan).f = f;
    eventTriggeredTraces(chan).t = t;
    
end
            
save(filename,'eventTriggeredTraces','f','-v7.3')
