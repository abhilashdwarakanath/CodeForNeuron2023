function lfpEventStatisticsAllChansLastLFPEvent(lfpActivity, domdur, sav_dir_psth,expt,filtType)

dbstop in lfpEventStatisticsAllChansLastLFPEvent at 85 if numel(preEvents)>1

% Collect event statistics for the four chosen LFP bands
% Abhilash D MPIBC 2017-18

cd(sav_dir_psth)

pad = 500;

filename = ['std3.5_lastEvent_blpCharacteristics_' num2str(domdur.domBehind) 'ms_Chebyshev1_' filtType '.mat'];

t =linspace(-domdur.domBehind/1000,domdur.domForward/1000,(domdur.domBehind/2)+(domdur.domForward/2)+1);
evtIdx = ceil(domdur.domBehind/2)+1;
midPoint = t(ceil(length(t)/2));
%% Setup filters

if strcmp(filtType,'theta')
    [b,a] = cheby1(4,0.01,[4 8]/250); % Theta
    %[b1,a1] = cheby1(4,6/250,'low');
    evtDur = 50;
elseif strcmp(filtType,'delta')
    [b,a] = cheby1(4,0.01,[1 4]/250); % delta
    %[b1,a1] = cheby1(4,2/250,'low');
    evtDur = 250;
elseif strcmp(filtType,'beta')
    [b,a] = cheby1(8,0.01,[20 40]/250); % beta
    %[b1,a1] = cheby1(4,25/250,'low');
    evtDur = 13;
elseif strcmp(filtType,'gamma')
    [b,a] = cheby1(16,0.01,[125 200]/250); % gamma
    %[b1,a1] = cheby1(4,162/250,'low');
    evtDur = 3;
elseif strcmp(filtType,'low')
    [b,a] = cheby1(4,0.01,[1 9]/250);
    %[b1,a1] = cheby1(4,5/250,'low');
    evtDur = 56;
elseif strcmp(filtType,'special')
    [b,a] = cheby1(4,0.01,[2 7]/250);
    %[b1,a1] = cheby1(4,5/250,'low');
    evtDur = 150;
end

%% Get Doms 90

for chan = 1:96
    
    % BR Dominances
    
    blpTraces_br_90 = [];
    blpPreAmps_br_90 = [];
    blpPreAmps_pa_90 = [];
    blpTraces_pa_90 = [];
    blpPostAmps_br_90 = [];
    blpPostAmps_pa_90 = [];
    nEvents_pre_br_90 = [];
    nEvents_pre_pa_90 = [];
    nEvents_post_br_90 = [];
    nEvents_post_pa_90 = [];
    blpPreEvents_br_90 = [];
    blpPostEvents_br_90 = [];
    blpPreEvents_pa_90 = [];
    blpPostEvents_pa_90 = [];
    
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, chan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, chan}{1, iCond},2)
            lfppiece = ((((lfpActivity.validSection.BR.data.dom90{1, chan}{1, iCond}{nDom}))));
            [val,~] = max(lfppiece);
            if val<=750
                lfppiece = filtfilt(b,a,lfppiece);
                lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                lfpevents = event_detection(detrend(lfppiece),3.5,'stdgauss',evtDur);
                lfpevents(lfpevents<=pad) = [];
                lfpevents(lfpevents>=(length(t)+pad)) = [];
                lfpevents = lfpevents-pad;
                lfppiece = lfppiece(pad+1:end-pad);
                blpTraces_br_90 = [blpTraces_br_90;lfppiece'];
                if ~isempty(lfpevents)
                    
                    preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                    postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                    preEvents = (lfpevents(lfpevents<=evtIdx)-evtIdx)/500;
                    postEvents = (lfpevents(lfpevents>evtIdx)-evtIdx)/500;
                    
                    if ~isempty(preAmps)
                        blpPreAmps_br_90 = [blpPreAmps_br_90 preAmps(end)'];
                    else
                        blpPreAmps_br_90 = [blpPreAmps_br_90 preAmps'];
                    end
                    blpPostAmps_br_90 = [blpPostAmps_br_90 postAmps'];
                    if ~isempty(preEvents)
                        blpPreEvents_br_90 = [blpPreEvents_br_90 preEvents(end)];
                    else
                        blpPreEvents_br_90 = [blpPreEvents_br_90 preEvents];
                    end
                    blpPostEvents_br_90 = [blpPostEvents_br_90 postEvents];
                    
                    nEvents_pre_br_90 = [nEvents_pre_br_90 numel(preEvents(preEvents<(midPoint)))];
                    nEvents_post_br_90 = [nEvents_post_br_90 numel(postEvents(postEvents>(midPoint)))];
                end
                
            end
            
        end
    end
    
    
    
    blpCharacteristics(chan).BR.dom90.traces = blpTraces_br_90;
    blpCharacteristics(chan).BR.dom90.preAmps = blpPreAmps_br_90;
    blpCharacteristics(chan).BR.dom90.postAmps = blpPostAmps_br_90;
    blpCharacteristics(chan).BR.dom90.preEvtTimes = blpPreEvents_br_90;
    blpCharacteristics(chan).BR.dom90.postEvtTimes = blpPostEvents_br_90;
    blpCharacteristics(chan).BR.dom90.nPreEvents = sum(nEvents_pre_br_90);
    blpCharacteristics(chan).BR.dom90.nPostEvents = sum(nEvents_post_br_90);
    
end

%% Get doms 270

for chan = 1:96
    
    % BR Dominances
    
    blpTraces_br_270 = [];
    blpPreAmps_br_270 = [];
    blpPreAmps_pa_270 = [];
    blpTraces_pa_270 = [];
    blpPostAmps_br_270 = [];
    blpPostAmps_pa_270 = [];
    nEvents_pre_br_270 = [];
    nEvents_pre_pa_270 = [];
    nEvents_post_br_270 = [];
    nEvents_post_pa_270 = [];
    blpPreEvents_br_270 = [];
    blpPostEvents_br_270 = [];
    blpPreEvents_pa_270 = [];
    blpPostEvents_pa_270 = [];
    
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, chan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, chan}{1, iCond},2)
            lfppiece = ((((lfpActivity.validSection.BR.data.dom270{1, chan}{1, iCond}{nDom}))));
            [val,~] = max(lfppiece);
            if val<=750
                lfppiece = filtfilt(b,a,lfppiece);
                lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                lfpevents = event_detection(detrend(lfppiece),3.5,'stdgauss',evtDur);
                lfpevents(lfpevents<=pad) = [];
                lfpevents(lfpevents>=(length(t)+pad)) = [];
                lfpevents = lfpevents-pad;
                lfppiece = lfppiece(pad+1:end-pad);
                blpTraces_br_270 = [blpTraces_br_270;lfppiece'];
                
                if ~isempty(lfpevents)
                    preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                    postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                    preEvents = (lfpevents(lfpevents<=evtIdx)-evtIdx)/500;
                    postEvents = (lfpevents(lfpevents>evtIdx)-evtIdx)/500;
                    
                    if ~isempty(preAmps)
                        blpPreAmps_br_270 = [blpPreAmps_br_270 preAmps(end)'];
                    else
                        blpPreAmps_br_270 = [blpPreAmps_br_270 preAmps'];
                    end
                    blpPostAmps_br_270 = [blpPostAmps_br_270 postAmps'];
                    if ~isempty(preEvents)
                        blpPreEvents_br_270 = [blpPreEvents_br_270 preEvents(end)];
                    else
                        blpPreEvents_br_270 = [blpPreEvents_br_270 preEvents];
                    end
                    blpPostEvents_br_270 = [blpPostEvents_br_270 postEvents];
                    nEvents_pre_br_270 = [nEvents_pre_br_270 numel(preEvents(preEvents<(midPoint)))];
                    nEvents_post_br_270 = [nEvents_post_br_270 numel(postEvents(postEvents>(midPoint)))];
                end
                
            end
            
        end
    end
    
    
    
    blpCharacteristics(chan).BR.dom270.traces = blpTraces_br_270;
    blpCharacteristics(chan).BR.dom270.preAmps = blpPreAmps_br_270;
    blpCharacteristics(chan).BR.dom270.postAmps = blpPostAmps_br_270;
    blpCharacteristics(chan).BR.dom270.preEvtTimes = blpPreEvents_br_270;
    blpCharacteristics(chan).BR.dom270.postEvtTimes = blpPostEvents_br_270;
    blpCharacteristics(chan).BR.dom270.nPreEvents = sum(nEvents_pre_br_270);
    blpCharacteristics(chan).BR.dom270.nPostEvents = sum(nEvents_post_br_270);
    
end

save(filename,'blpCharacteristics','-v7.3')
