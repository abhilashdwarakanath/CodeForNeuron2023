function [spectra] = computeCleanDomSpectraTbyT(lfpActivity,sav_dir_psth,durs,tag)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

cd(sav_dir_psth)

filename = ['MM_cleanDomSpectra_TbyT_' tag '.mat'];

pad = 500;

%% Collect activity

params.tapers = [3 5];
params.Fs = 500;
params.trialave = 1;
params.pad = 0;

c = 0;
for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            piece = (lfpActivity.validSection.BR.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece) & max(piece) < 750
                BRtraces90(c,iChan,:) = piece(pad+1:end-pad);
            end
        end
    end
end

c = 0;
for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            piece = (lfpActivity.validSection.BR.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece) & max(piece) < 750
                BRtraces270(c,iChan,:) = piece(pad+1:end-pad);
            end
        end
    end
end

BRtraces = cat(1,BRtraces270,BRtraces90);

clear BRtraces90; clear BRtraces270;

for iTrans = 1:size(BRtraces,1)
    
    [BRSpectra(iTrans,:),f] = mtspectrumc(squeeze(BRtraces(iTrans,:,:))',params);
    BRSpectra(iTrans,:) = 10*log10(BRSpectra(iTrans,:));

end

c = 0;
for iCond = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.PA.data.dom90{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            piece = (lfpActivity.validSection.PA.data.dom90{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece) & max(piece) < 750
                PAtraces90(c,iChan,:) = piece(pad+1:end-pad);
            end
        end
    end
end

c = 0;
for iCond = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1},2)
    for nDom = 1:size(lfpActivity.validSection.PA.data.dom270{1, 1}{1, iCond},2)
        c = c+1;
        for iChan = 1:96
            piece = (lfpActivity.validSection.PA.data.dom270{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece) & max(piece) < 750
                PAtraces270(c,iChan,:) = piece(pad+1:end-pad);
            end
        end
    end
end

PAtraces = cat(1,PAtraces270,PAtraces90);

clear PAtraces90; clear PAtraces270;

for iTrans = 1:size(PAtraces,1)
    
    [PASpectra(iTrans,:),f] = mtspectrumc(squeeze(PAtraces(iTrans,:,:))',params);
    PASpectra(iTrans,:) = 10*log10(PASpectra(iTrans,:));

end

fprintf('Computation of spectra done, saving...\n')

%% Collect the output

spectra.PA = PASpectra;
spectra.BR = BRSpectra;
spectra.f = f;

save(filename,'spectra','-v7.3');
    
