function [betaPeriodStarts,betaPeriodEnds,silentPeriodStarts, silentPeriodEnds] = extractBetaAndSilentPeriods(vector)
%extractBetaAndSilentPeriods - extracts periods of beta activity and beta
%   supression periods based on a signal of 1s and 0s
% [betaPeriodStarts,betaPeriodEnds,silentPeriodStarts, silentPeriodEnds] = extractBetaAndSilentPeriods(vector)
% INPUTS
%   vector - column vector containing a stream of 0s and 1s
% OUTPUTS
%   betaPeriodStarts - vector containing the start indices of each detected
%   beta period(continous 1s)
%   betaPeriodEnds - vector containing the end indices of each detected
%   beta period(continous 1s)
%   silentPeriodStarts - vector containing the start indices of each 
%   detected silent period(continous 0s)
%   silentPeriodEnds - vector containing the end indices of each detected
%   silent period(continous 0s)
%

betaPeriodStarts = [];
silentPeriodStarts = [];
betaPeriodEnds = [];
silentPeriodEnds =[];

nPoints = length(vector);

for index = 1:nPoints-1
    if vector(index) == 0
        if isempty(silentPeriodStarts)
            silentPeriodStarts = [silentPeriodStarts index];
        elseif vector(index+1) ~= vector(index)
            silentPeriodEnds = [silentPeriodEnds index];
            betaPeriodStarts = [betaPeriodStarts index+1];
        end
    else
        if isempty(betaPeriodStarts)
            betaPeriodStarts = [betaPeriodStarts index];
        elseif vector(index+1) ~= vector(index)
            betaPeriodEnds = [betaPeriodEnds index];
            silentPeriodStarts = [silentPeriodStarts index+1];
        end
    end
    
    
end

% Last element is missing from the loop
if vector(end) == 0
    silentPeriodEnds = [silentPeriodEnds index];
else
     betaPeriodEnds = [betaPeriodEnds index];
end

end