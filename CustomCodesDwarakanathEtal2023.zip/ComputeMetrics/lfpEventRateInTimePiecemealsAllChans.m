function lfpEventRateInTimePiecemealsAllChans(lfpActivity, domdur, sav_dir_psth,expt,filtType)

% Collect event statistics for the four chosen LFP bands
% Abhilash D MPIBC 2017-18

cd(sav_dir_psth)

pad = 500;

filename = ['MMstd4_eventRateByTime_Piecemeals_' num2str(domdur.domBehind) 'ms_Chebyshev1_' filtType '.mat'];

t =linspace(-domdur.domBehind/1000,domdur.domForward/1000,(domdur.domBehind/2)+(domdur.domForward/2)+1);
evtIdx = ceil(domdur.domBehind/2)+1;
midPoint = t(ceil(length(t)/2));

    sigma = 1/25;

[x,y] = smoothingkernel(1,500,sigma,'gaussian');
%% Setup filters

if strcmp(filtType,'theta')
    [b,a] = cheby1(4,0.01,[4 8]/250); % Theta
    %[b1,a1] = cheby1(4,6/250,'low');
    evtDur = 125;
elseif strcmp(filtType,'delta')
    [b,a] = cheby1(4,0.01,[1 4]/250); % delta
    %[b1,a1] = cheby1(4,2/250,'low');
    evtDur = 250;
elseif strcmp(filtType,'beta')
    [b,a] = cheby1(8,0.01,[20 40]/250); % beta
    %[b1,a1] = cheby1(4,25/250,'low');
    evtDur = 44;
elseif strcmp(filtType,'gamma')
    [b,a] = cheby1(16,0.01,[125 200]/250); % gamma
    %[b1,a1] = cheby1(4,162/250,'low');
    evtDur = 3;
elseif strcmp(filtType,'low')
    [b,a] = cheby1(4,0.01,[1 9]/250);
    %[b1,a1] = cheby1(4,5/250,'low');
    evtDur = 56;
    elseif strcmp(filtType,'alpha')
    [b,a] = cheby1(4,0.01,[9 16]/250);
    %[b1,a1] = cheby1(4,5/250,'low');
    evtDur = 31;
end

%% Get Doms 90

for chan = 1:96
    
    % BR Dominances
    
    c = 0;
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom90{1, chan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom90{1, chan}{1, iCond},2)
            lfppiece = ((((lfpActivity.validSection.BR.data.dom90{1, chan}{1, iCond}{nDom}))));
            [val,~] = max(lfppiece);
            if val<=750
                c= c+1;
                lfppiece = filtfilt(b,a,lfppiece);
                lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                lfpevents = event_detection(detrend(lfppiece),4,'stdgauss',evtDur);
                lfpevents(lfpevents<=pad) = [];
                lfpevents(lfpevents>=(length(t)+pad)) = [];
                lfpevents = lfpevents-pad;
                lfpevents = (lfpevents-evtIdx)/500;
                
                if ~isempty(lfpevents)
                    er_br_dom90 = zeros(1,length(t));
                    for nSpk = 1:length(lfpevents)
                        val = lfpevents(nSpk); %value to find
                        tmp = abs(t-val);
                        [idx idx] = min(tmp); %index of closest value
                        spkIdx(nSpk) = idx;
                    end
                    er_br_dom90(spkIdx) = 1;
                    erTrace_br_dom90(c,:) = conv(er_br_dom90,y,'same');
                    clear spkIdx
                else
                    erTrace_br_dom90(c,:) = zeros(1,length(t));
                end
                
            end
            
        end
    end
    
    eventRatePerTransition(chan).BR.dom90 = erTrace_br_dom90;
    
end

%% Get doms 270

for chan = 1:96
    
    % BR Dominances
    
     c = 0;
    for iCond = 1:size(lfpActivity.validSection.BR.data.dom270{1, chan},2)
        for nDom = 1:size(lfpActivity.validSection.BR.data.dom270{1, chan}{1, iCond},2)
            lfppiece = ((((lfpActivity.validSection.BR.data.dom270{1, chan}{1, iCond}{nDom}))));
            [val,~] = max(lfppiece);
            if val<=750
                c= c+1;
                lfppiece = filtfilt(b,a,lfppiece);
                lfppiece = abs(hilbert(lfppiece)); % Squaring works better
                lfpevents = event_detection(detrend(lfppiece),4,'stdgauss',evtDur);
                lfpevents(lfpevents<=pad) = [];
                lfpevents(lfpevents>=(length(t)+pad)) = [];
                lfpevents = lfpevents-pad;
                lfpevents = (lfpevents-evtIdx)/500;
                
                if ~isempty(lfpevents)
                    er_br_dom270 = zeros(1,length(t));
                    for nSpk = 1:length(lfpevents)
                        val = lfpevents(nSpk); %value to find
                        tmp = abs(t-val);
                        [idx idx] = min(tmp); %index of closest value
                        spkIdx(nSpk) = idx;
                    end
                    er_br_dom270(spkIdx) = 1;
                    erTrace_br_dom270(c,:) = conv(er_br_dom270,y,'same');
                    clear spkIdx
                else
                    erTrace_br_dom270(c,:) = zeros(1,length(t));
                end
                
            end
            
        end
    end
    
    eventRatePerTransition(chan).BR.dom270 = erTrace_br_dom270;
    
end

save(filename,'eventRatePerTransition','-v7.3')
