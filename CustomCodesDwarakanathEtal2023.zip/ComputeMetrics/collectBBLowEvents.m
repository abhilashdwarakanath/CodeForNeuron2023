function collectBBLowEvents(dur)

dbstop if error

%% Enumerate Datasets

datasets{1} = 'C:\Users\AD263755\Documents\MATLAB\Data\1';
recDate{1} = '12062016';
subjID{1} = 'Hayo';
datasets{2} = 'C:\Users\AD263755\Documents\MATLAB\Data\2';
recDate{2} = '13072016';
subjID{2} = 'Hayo';
datasets{3} = 'C:\Users\AD263755\Documents\MATLAB\Data\3';
recDate{3} = '19102016';
subjID{3} = 'Hayo';
datasets{4} = 'C:\Users\AD263755\Documents\MATLAB\Data\4';
recDate{4} = '25102016';
subjID{4} = 'Hayo';
datasets{5} = 'C:\Users\AD263755\Documents\MATLAB\Data\5';
recDate{5} = '05032017';
subjID{5} = 'Anton';
datasets{6} = 'C:\Users\AD263755\Documents\MATLAB\Data\6';
recDate{6} = '02032017';
subjID{6} = 'Anton';

%% Define parameters and time vectors

durs.switch = 250;
durs.domForward = dur;
durs.domBehind = dur;
params.elecs = 96;
params.conditions = 8;
params.fs = 500;
params.pad = 500;
params.buffer = 75;

t = linspace(-dur/1e3,-dur/1e3,dur+1);
tEvt = linspace(-(2*params.buffer)/1e3,(2*params.buffer)/1e3,params.buffer*2);

%% Collect shit

for iDataset = 1:length(datasets)

    %Maps

    chans = 1:96;
    elecs = [78 88 68 58 56 48 57 38 47 28 37 27 36 18 45 17 46 8 35 16 24 7 26 6 25 5 15 4 14 3 13 2 77 67 76 66 75 65 74 64 73 54 63 53 72 43 62 55 61 44 52 33 51 34 41 42 31 32 21 22 11 23 10 12 96 87 95 86 94 85 93 84 92 83 91 82 90 81 89 80 79 71 69 70 59 60 50 49 40 39 30 29 19 20 1 9];
    chan2elec = [chans' elecs'];

    if strcmp(subjID{iDataset},'Hayo')==1
        monkID = 'H07';
        map.layout = [NaN	88	78	68	58	48	38	28	18	NaN
            96	87	77	67	57	47	37	27	17	8
            95	86	76	66	56	46	36	26	16	7
            94	85	75	65	55	45	35	25	15	6
            93	84	74	64	54	44	34	24	14	5
            92	83	73	63	53	43	33	23	13	4
            91	82	72	62	52	42	32	22	12	3
            90	81	71	61	51	41	31	21	11	2
            89	80	70	60	50	40	30	20	10	1
            NaN	79	69	59	49	39	29	19	9	NaN];
        map.chan2elec = chan2elec;
    else
        monkID = 'A11';
        map.layout = [NaN    88    78    68    58    48    38    28    18   8
            96    87    77    67    57    47    37    27    17     7
            95    86    76    66    56    46    36    26    16     6
            94    85    75    65    55    45    35    25    15     5
            93    84    74    64    54    44    34    24    14     NaN
            92    83    73    63    53    43    33    23    13     4
            91    82    72    62    52    42    32    22    12     3
            90    81    71    61    51    41    31    21    11     2
            89    80    70    60    50    40    30    20    10     1
            NaN    79    69    59    49    39    29    19     9   NaN];
        map.chan2elec = chan2elec;
    end

    % Selective channels

    cd(datasets{iDataset})

    load('1000_250_1000_DF_pref_array_switch.mat')

    pref90_br_bs = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==2);
    pref90_br_as = find(pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,2)==2);
    pref90_br_bsas = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==2);
    pref90_br_bs = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref90_br_bs,3);
    pref90_br_as = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(pref90_br_as,3);
    pref90_br_bsas = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref90_br_bsas,3);

    pref90_br = unique([pref90_br_bs;pref90_br_as;pref90_br_bsas]);


    pref270_br_bs = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==1);
    pref270_br_as = find(pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,2)==1);
    pref270_br_bsas = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==1);
    pref270_br_bs = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref270_br_bs,3);
    pref270_br_as = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(pref270_br_as,3);
    pref270_br_bsas = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref270_br_bsas,3);

    pref270_br = unique([pref270_br_bs;pref270_br_as;pref270_br_bsas]);

    %% Collect clean dominances

    % Load relevant LFPs and Spikes
    cd(datasets{iDataset})

    eventfile = 'finalevents_audio.mat';
    spikeFile = 'jMUSpikesByTime.mat';
    lfpFile = 'lfpByTrial.mat';
    qnxfile = [subjID{iDataset} '_' recDate{iDataset} '_' 'Bfsgrad1' '.dgz'];

    load(lfpFile)
    load(spikeFile);

    fprintf('Loading Dataset %d of : %d \n',iDataset,length(datasets))

    fprintf('Collect trial information...\n')

    trialInformation = collectTrialInformationMM(params,qnxfile,eventfile,'pfc','lfp');
    [lfpActivity] = collectCleanDominancesLFPMM(params,LFP,jMUspikes,durs);
    [spikingActivity] = collectCleanDominancesSpikesMM(params,jMUspikes,durs);

    %% Setup filters

    fprintf('Setup IIR filters...\n')

    [b1,a1] = butter(4,[1 9]/250); % low
    evtDurL = 56;

    [b2,a2] = butter(4,[20 40]/250); % beta
    evtDurB = 12;

    %% Collect BR

    fprintf('START PROCESSING...\n')

    for iChan = 1:params.elecs
        c = 0;
        for iCond = 1:length(spikingActivity.validSection.BR.data.dom90{iChan})
            for iSwitch = 1:length(spikingActivity.validSection.BR.data.dom90{iChan}{iCond})
                tic;
                c = c+1; clear piece; clear lowPiece; clear betaPiece; clear lowEvts; clear betaEvts; clear negBBEvts; clear posBBEvts; clear trigCWT; clear trigLFP; clear negEvtTrigLFP; clear negEvtTrigCWT; clear postEvtTrigLFP; clear postEvtTrigCWT;
                spikingEvents.s270TO90{c}{iChan} = spikingActivity.validSection.BR.data.dom90{iChan}{iCond}{iSwitch};
                piece = lfpActivity.validSection.BR.data.dom90{iChan}{iCond}{iSwitch};
                negBBEvts = event_detection(-1.*piece,4,'stdgauss',56);
                posBBEvts = event_detection(piece,4,'stdgauss',56);
                negBBEvts(negBBEvts<= params.pad+1) = []; negBBEvts(negBBEvts >= params.pad+length(t)-1) = [];
                posBBEvts(posBBEvts<= params.pad+1) = []; posBBEvts(posBBEvts >= params.pad+length(t)-1) = [];
                % collect broadband LFP triggered on these events and
                % compute spectrum

                if ~isempty(negBBEvts)

                    for iEvt = 1:length(negBBEvts)

                        trigLFP = piece(negBBEvts(iEvt)-params.buffer:negBBEvts(iEvt)+params.buffer-1);
                        [trigCWT,f] = cwt(detrend(trigLFP),'morse',params.fs,'VoicesPerOctave',24,'NumOctaves',4,'WaveletParameters',[3 30]);
                        negEvtTrigLFP(iEvt,:) = trigLFP;
                        negEvtTrigCWT(iEvt,:,:) = abs(trigCWT).^2;

                    end

                else

                    negEvtTrigLFP = [];
                    negEvtTrigCWT = [];

                end

                if ~isempty(posBBEvts)

                    for iEvt = 1:length(posBBEvts)

                        trigLFP = piece(posBBEvts(iEvt)-params.buffer:posBBEvts(iEvt)+params.buffer-1);
                        [trigCWT,f] = cwt(detrend(trigLFP),'morse',params.fs,'VoicesPerOctave',24,'NumOctaves',4,'WaveletParameters',[3 30]);
                        posEvtTrigLFP(iEvt,:) = trigLFP;
                        posEvtTrigCWT(iEvt,:,:) = abs(trigCWT).^2;

                    end

                else

                    posEvtTrigLFP = [];
                    posEvtTrigCWT = [];

                end

                negBBEvts = negBBEvts - params.pad+1;
                posBBEvts = posBBEvts - params.pad+1;
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                betaPiece = abs(hilbert(filter(b2,a2,piece)));
                lowEvts = event_detection(lowPiece,4,'stdgauss',evtDurL);
                lowEvts(lowEvts<= params.pad+1) = []; lowEvts(lowEvts >= params.pad+length(t)-1) = [];
                lowEvts = lowEvts - params.pad+1;
                betaEvts = event_detection(betaPiece,3.5,'stdgauss',evtDurB);
                betaEvts(betaEvts<= params.pad+1) = []; betaEvts(betaEvts >= params.pad+length(t)-1) = [];
                betaEvts = betaEvts - params.pad+1;
                lfpEvents.low.s270TO90.instAmp(c,iChan,:) = lowPiece(params.pad+1:end-params.pad);
                lfpEvents.beta.s270TO90.instAmp(c,iChan,:) = betaPiece(params.pad+1:end-params.pad);
                lfpEvents.bb.s90TO270.traces(c,iChan,:) = piece(params.pad+1:end-params.pad);
                lfpEvents.low.s270TO90.events(c,iChan).times = t(lowEvts);
                lfpEvents.beta.s270TO90.events(c,iChan).times = t(betaEvts);
                lfpEvents.bb.s270TO90.negEvents(c,iChan).times = t(negBBEvts);
                lfpEvents.bb.s270TO90.posEvents(c,iChan).times = t(posBBEvts);
                lfpEvents.bb.s270TO90.negEvents(c,iChan).negEvtTrigLFP = negEvtTrigLFP;
                lfpEvents.bb.s270TO90.negEvents(c,iChan).negEvtTrigCWT = negEvtTrigCWT;
                lfpEvents.bb.s270TO90.posEvents(c,iChan).posEvtTrigLFP = posEvtTrigLFP;
                lfpEvents.bb.s270TO90.posEvents(c,iChan).posEvtTrigCWT = posEvtTrigCWT;
                lowTrace = lowPiece(params.pad+1:end-params.pad);
                betaTrace = lowPiece(params.pad+1:end-params.pad);
                bbTrace = piece(params.pad+1:end-params.pad);
                lfpEvents.low.s270TO90.events(c,iChan).times = t(lowEvts);
                lfpEvents.beta.s270TO90.events(c,iChan).times = t(betaEvts);
                lfpEvents.bb.s270TO90.negEvents(c,iChan).times = t(negBBEvts);
                lfpEvents.bb.s270TO90.posEvents(c,iChan).times = t(posBBEvts);
                lfpEvents.low.s270TO90.events(c,iChan).amplitudes = lowTrace(lowEvts);
                lfpEvents.beta.s270TO90.events(c,iChan).amplitudes = betaTrace(betaEvts);
                lfpEvents.bb.s270TO90.negEvents(c,iChan).amplitudes = bbTrace(negBBEvts);
                lfpEvents.bb.s270TO90.posEvents(c,iChan).amplitudes = bbTrace(posBBEvts);

                toc;

            end
        end
    end

    for iChan = 1:params.elecs
        c = 0;
        for iCond = 1:length(spikingActivity.validSection.BR.data.dom270{iChan})
            for iSwitch = 1:length(spikingActivity.validSection.BR.data.dom270{iChan}{iCond})
                c = c+1; clear piece; clear lowPiece; clear betaPiece; clear lowEvts; clear betaEvts; clear negBBEvts; clear posBBEvts; clear trigCWT; clear trigLFP; clear negEvtTrigLFP; clear negEvtTrigCWT; clear postEvtTrigLFP; clear postEvtTrigCWT;
                tic;
                spikingEvents.s90TO270{c}{iChan} = spikingActivity.validSection.BR.data.dom270{iChan}{iCond}{iSwitch};
                piece = lfpActivity.validSection.BR.data.dom270{iChan}{iCond}{iSwitch};
                negBBEvts = event_detection(-1.*piece,4,'stdgauss',56);
                posBBEvts = event_detection(piece,4,'stdgauss',56);
                negBBEvts(negBBEvts<= params.pad+1) = []; negBBEvts(negBBEvts >= params.pad+length(t)-1) = [];
                posBBEvts(posBBEvts<= params.pad+1) = []; posBBEvts(posBBEvts >= params.pad+length(t)-1) = [];
                % collect broadband LFP triggered on these events and
                % compute spectrum

                if ~isempty(negBBEvts)

                    for iEvt = 1:length(negBBEvts)

                        trigLFP = piece(negBBEvts(iEvt)-params.buffer:negBBEvts(iEvt)+params.buffer-1);
                        [trigCWT,f] = cwt(detrend(trigLFP),'morse',params.fs,'VoicesPerOctave',24,'NumOctaves',4,'WaveletParameters',[3 30]);
                        negEvtTrigLFP(iEvt,:) = trigLFP;
                        negEvtTrigCWT(iEvt,:,:) = abs(trigCWT).^2;

                    end

                else

                    negEvtTrigLFP = [];
                    negEvtTrigCWT = [];

                end

                if ~isempty(posBBEvts)

                    for iEvt = 1:length(posBBEvts)

                        trigLFP = piece(posBBEvts(iEvt)-params.buffer:posBBEvts(iEvt)+params.buffer-1);
                        [trigCWT,f] = cwt(detrend(trigLFP),'morse',params.fs,'VoicesPerOctave',24,'NumOctaves',4,'WaveletParameters',[3 30]);
                        posEvtTrigLFP(iEvt,:) = trigLFP;
                        posEvtTrigCWT(iEvt,:,:) = abs(trigCWT).^2;

                    end

                else

                    posEvtTrigLFP = [];
                    posEvtTrigCWT = [];

                end

                negBBEvts = negBBEvts - params.pad+1;
                posBBEvts = posBBEvts - params.pad+1;
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                betaPiece = abs(hilbert(filter(b2,a2,piece)));
                lowEvts = event_detection(lowPiece,4,'stdgauss',evtDurL);
                lowEvts(lowEvts<= params.pad+1) = []; lowEvts(lowEvts >= params.pad+length(t)-1) = [];
                lowEvts = lowEvts - params.pad+1;
                betaEvts = event_detection(betaPiece,3.5,'stdgauss',evtDurB);
                betaEvts(betaEvts<= params.pad+1) = []; betaEvts(betaEvts >= params.pad+length(t)-1) = [];
                betaEvts = betaEvts - params.pad+1;
                lfpEvents.low.s90TO270.instAmp(c,iChan,:) = lowPiece(params.pad+1:end-params.pad);
                lfpEvents.beta.s90TO270.instAmp(c,iChan,:) = betaPiece(params.pad+1:end-params.pad);
                lfpEvents.bb.s90TO270.traces(c,iChan,:) = piece(params.pad+1:end-params.pad);
                lfpEvents.low.s90TO270.events(c,iChan).times = t(lowEvts);
                lfpEvents.beta.s90TO270.events(c,iChan).times = t(betaEvts);
                lfpEvents.bb.s90TO270.negEvents(c,iChan).times = t(negBBEvts);
                lfpEvents.bb.s90TO270.posEvents(c,iChan).times = t(posBBEvts);
                lfpEvents.bb.s90TO270.negEvents(c,iChan).negEvtTrigLFP = negEvtTrigLFP;
                lfpEvents.bb.s90TO270.negEvents(c,iChan).negEvtTrigCWT = negEvtTrigCWT;
                lfpEvents.bb.s90TO270.posEvents(c,iChan).posEvtTrigLFP = posEvtTrigLFP;
                lfpEvents.bb.s90TO270.posEvents(c,iChan).posEvtTrigCWT = posEvtTrigCWT;
                lowTrace = lowPiece(params.pad+1:end-params.pad);
                betaTrace = lowPiece(params.pad+1:end-params.pad);
                bbTrace = piece(params.pad+1:end-params.pad);
                lfpEvents.low.s90TO270.events(c,iChan).times = t(lowEvts);
                lfpEvents.beta.s90TO270.events(c,iChan).times = t(betaEvts);
                lfpEvents.bb.s90TO270.negEvents(c,iChan).times = t(negBBEvts);
                lfpEvents.bb.s90TO270.posEvents(c,iChan).times = t(posBBEvts);
                lfpEvents.low.s90TO270.events(c,iChan).amplitudes = lowTrace(lowEvts);
                lfpEvents.beta.s90TO270.events(c,iChan).amplitudes = betaTrace(betaEvts);
                lfpEvents.bb.s90TO270.negEvents(c,iChan).amplitudes = bbTrace(negBBEvts);
                lfpEvents.bb.s90TO270.posEvents(c,iChan).amplitudes = bbTrace(posBBEvts);

                toc;
            end
        end
    end

    neuralEvents(iDataset).lfp = lfpEvents;
    neuralEvents(iDataset).spikes = spikingEvents;
    neuralEvents(iDataset).selChans.upward = pref90_br;
    neuralEvents(iDataset).selChans.downward = pref270_br;
    neuralEvents(iDataset).t = t;
    neuralEvents(iDataset).f = f;
    neuralEvents(iDataset).tEvt = tEvt;
    neuralEvents(iDataset).subjID = monkID;
    neuralEvents(iDataset).recDate = recDate{iDataset};
    neuralEvents(iDataset).params = params;
    neuralEvents(iDataset).map = map;

    fprintf('Processed dataset %d of %d...\n',iDataset,length(datasets));

end

%% Save shit

fprintf('All datasets processed...\n')
fprintf('Navigating to results folder...\n')
mkdir C:\Users\AD263755\Documents\MATLAB\Data\Results\MasterStructures
cd C:\Users\AD263755\Documents\MATLAB\Data\Results\MasterStructures
fprintf('Saving structure...\n')
save(['eventsData_v3_' num2str(dur) 'ms.mat'],'neuralEvents','-v7.3')

end
