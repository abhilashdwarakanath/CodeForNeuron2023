function [manualPAEvents] = computeManualPASwitchSpecgramsStatisticsMM(lfpActivity,sav_dir_psth,tag)

% Computes spectrograms for clean dominances. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

cd(sav_dir_psth)

durs.domBehind = 500;
durs.domForward = 500;

%% Collect activity

[b1,a1] = cheby1(4,0.001,[1 9]/250); % low

t = linspace(-0.5,0.5,501);

for iChan = 1:96
    
    tic;
    %% Collect traces
    
    PAdominances = [];
    domevents = [];
    for iCond = 5:8
        for nDom = 1:size(lfpActivity.data.SwitchData{1, iChan}{1, iCond},2)
            piece = detrend(lfpActivity.data.SwitchData{1, iChan}{1, iCond}{nDom});
            if ~isnan(piece)
                tmp = [zeros(1,250) piece' zeros(1,250)];
                hilbertTemp = abs(hilbert(filtfilt(b1,a1,tmp)));
                events = event_detection(hilbertTemp',4,'stdgauss',56);
                events = events-250;
                if ~isempty(events)
                    tmpTime = t(events);
                    domevents = [domevents tmpTime];
                end
                PAdominances = [PAdominances;piece'];
            end
        end
    end
    
    
    
    %% Trash junk trials
    
    [val,~] = max(PAdominances,[],2);
    idx = val>=750;
    trashTrials = find(idx==1);
    PAdominances(trashTrials,:) = [];
    
    
    %% Declare lengths -
    
    t = linspace(-durs.domBehind/1000,durs.domForward/1000,(durs.domBehind/2)+(durs.domForward/2)+1);
    flen = 169;
    
    
    %% Compute the CWT - P2NP
    
    %PA
    
%     cwtpa90 = zeros(flen,length(t),size(PAdominances90,1));
%     for i = 1:size(PAdominances90,1)
%         [cwtpa90(:,:,i),f] = cwt(PAdominances90(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
%         cwtpa90(:,:,i) = abs(cwtpa90(:,:,i).^2);
%         cwtpa90_norm1(:,:,i) = zscore(cwtpa90(:,:,i),[],1);
%         cwtpa90_norm2(:,:,i) = zscore(cwtpa90(:,:,i),[],2);
%     end
%     
%     cwtpa270 = zeros(flen,length(t),size(PAdominances270,1));
%     for i = 1:size(PAdominances270,1)
%         [cwtpa270(:,:,i),f] = cwt(PAdominances270(i,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
%         cwtpa270(:,:,i) = abs(cwtpa270(:,:,i).^2);
%         cwtpa270_norm1(:,:,i) = zscore(cwtpa270(:,:,i),[],1);
%         cwtpa270_norm2(:,:,i) = zscore(cwtpa270(:,:,i),[],2);
%     end
    
    
    %% Collect the output
    
%     Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
%     manualPASpectrograms(iChan).t = t;
%     manualPASpectrograms(iChan).f = f;
%     manualPASpectrograms(iChan).Yticks = Yticks;
%     manualPASpectrograms(iChan).PA.dom90_norm1 = nanmean(cwtpa90_norm1,3);
%     manualPASpectrograms(iChan).PA.dom270_norm1 = nanmean(cwtpa270_norm1,3);
%     manualPASpectrograms(iChan).PA.dom90_norm2 = nanmean(cwtpa90_norm2,3);
%     manualPASpectrograms(iChan).PA.dom270_norm2 = nanmean(cwtpa270_norm2,3);
    manualPAEvents(iChan).PA.domevents = domevents;
    
    toc
    
end

filename = ['manualPAEvents_' tag '.mat'];
save(filename,'manualPAEvents','-v7.3');
