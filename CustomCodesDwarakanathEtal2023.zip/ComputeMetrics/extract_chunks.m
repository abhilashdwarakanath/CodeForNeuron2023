function extract_chunks(input_data, tolerance)
    % First figure out which compound data structure to use in the form of 
    % (start, end) and then return an array containing the data structure 
    % as elements
     
    chunks = [];
     
     temp = [];
     
     for i = 1:length(input_data) - 1
         
         if input_data(i+1) - input_data(i) <= tolerance
             temp = [temp input_data(i+1)];
         elseif length(temp) ~= 1 && temp(length(temp) -1)  ~= temp(1)
                 chunks = [chunks temp];
             temp = [input_data(i+1)];
         end
         %print(temp)
     if length(temp) ~= 1 && temp(length(temp) -1) ~= temp(1)
         chunks = [chunks temp];
     end
        
     end
     
end