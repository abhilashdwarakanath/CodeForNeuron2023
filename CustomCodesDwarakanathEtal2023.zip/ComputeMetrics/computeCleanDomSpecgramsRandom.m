function computeCleanDomSpecgramsRandom(LFP,jMUDominances,sav_dir_psth,durs,tag)

% Computes spectrograms for random triggered. Also cleans up trials and
% takes care of padding. CWT is used with a Morse wavelet. 24 octaves.
% Abhilash D. MPIBC 2017-18

dbstop if error

cd(sav_dir_psth)

filename1 = ['randomTriggeredSpecgrams_' tag '.mat'];
filename2 = ['std3.5_nIter_randomTrigger_blpCharacteristics_' num2str(durs.domBehind) 'ms_Chebyshev1_' 'low' '.mat'];
%% Collect activity

for iCond = 1:4
    for iTrial = 1:length(jMUDominances.data.events{iCond})
        events = jMUDominances.data.events{iCond}{iTrial};
        if sum(ismember(events,7))== 0 && sum(ismember(events,9)) == 0
            emptyTrials{iCond}{iTrial} = 1;
        else
            emptyTrials{iCond}{iTrial} = 0;
        end
    end
end

%% Collect the stuff

nIter = 100;

for iIter = 1:nIter
    
    fprintf('Running iteration number %d of %d \n',iIter,nIter);
    
    tic;
    
    c = 0;
    for iCond = 1:4
        
        for iTrial = 1:length(emptyTrials{iCond})
            if emptyTrials{iCond}{iTrial} == 1
                c = c+1;
                eventTimes = ceil(((jMUDominances.data.eventTimes{iCond}{iTrial})./3e4)*500);
                events = jMUDominances.data.events{iCond}{iTrial};
                idx1 = find(events==3);
                idx2 = find(events==4);
                tp1 = eventTimes(idx1)+1000;
                tp2 = eventTimes(idx2)-1000;
                samp1 = randi([tp1 tp2],1);
                samp2 = samp1+750;
                for iChan = 1:96
                    lfpTemp1 = detrend(LFP.data{iChan}{iCond}{iTrial}(251:end-250));
                    lfpPiece1{c}(iChan,:) = lfpTemp1(samp1-250:samp1+250);
                    lfpPiece2{c}(iChan,:) = lfpTemp1(samp2-250:samp2+250);
                end
                
            end
        end
    end
    
%     randomTriggeredSpecgrams1 = [];
%     randomTriggeredSpecgrams1_norm1 = [];
%     for i = 1:length(lfpPiece1)
%         for j = 1:96
%             tic;
%             [cwtRand,f] = cwt(lfpPiece1{i}(j,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
%             cwtRand = abs(cwtRand.^2);
%             randomTriggeredSpecgrams1 = cat(3,randomTriggeredSpecgrams1,cwtRand);
%             cwtRand = zscore(cwtRand,[],1);
%             randomTriggeredSpecgrams1_norm1 = cat(3,randomTriggeredSpecgrams1_norm1,cwtRand);
%             toc
%         end
%     end
%     
%     for i = 1:length(lfpPiece2)
%         for j = 1:96
%             tic;
%             [cwtRand,f] = cwt(lfpPiece2{i}(j,:),'morse',500,'VoicesPerOctave',24,'NumOctaves',7,'WaveletParameters',[3 30]);
%             cwtRand = abs(cwtRand.^2);
%             randomTriggeredSpecgrams1 = cat(3,randomTriggeredSpecgrams1,cwtRand);
%             cwtRand = zscore(cwtRand,[],1);
%             randomTriggeredSpecgrams1_norm1 = cat(3,randomTriggeredSpecgrams1_norm1,cwtRand);
%             toc
%         end
%     end
    
    t = linspace(-0.5,0.5,501);
    
    %% Collect traces and event amps and times for statistics
    
    [~,evtIdx] = min(abs(t-(0)));
    midPoint = t(evtIdx);
    [b,a] = cheby1(4,0.01,[1 9]/250);
    evtDur = 56;
    pad = 250;
    
    % First sample
    
    for iChan = 1:96
        
        blpTraces_piece1 = [];
        blpPreAmps_piece1 = [];
        blpPostAmps_piece1 = [];
        nEvents_pre_piece1 = [];
        nEvents_post_piece1 = [];
        blpPreEvents_piece1 = [];
        blpPostEvents_piece1 = [];
        
        
        for iPiece = 1:length(lfpPiece1)
            
            piece = [zeros(1,250) lfpPiece1{iPiece}(iChan,:) zeros(1,250)];
            lfppiece = abs(hilbert(filtfilt(b,a,piece)));
            lfpevents = event_detection(detrend(lfppiece'),3.5,'stdgauss',evtDur);
            lfpevents(lfpevents<=pad) = [];
            lfpevents(lfpevents>=(length(t)+pad)) = [];
            lfpevents = lfpevents-pad;
            lfppiece = lfppiece(pad+1:end-pad);
            blpTraces_piece1 = [blpTraces_piece1;lfppiece];
            
            if ~isempty(lfpevents)
                
                preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                preEvents = lfpevents(lfpevents<=evtIdx);
                preEvents = t(preEvents);
                postEvents = lfpevents(lfpevents>evtIdx);
                postEvents = t(postEvents);
                blpPreAmps_piece1 = [blpPreAmps_piece1 preAmps];
                blpPostAmps_piece1 = [blpPostAmps_piece1 postAmps];
                blpPreEvents_piece1 = [blpPreEvents_piece1 preEvents];
                blpPostEvents_piece1 = [blpPostEvents_piece1 postEvents];
                
                nEvents_pre_piece1 = [nEvents_pre_piece1 numel(preEvents(preEvents<(midPoint)))];
                nEvents_post_piece1 = [nEvents_post_piece1 numel(postEvents(postEvents>(midPoint)))];
            end
            
            
        end
        
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample1.traces = blpTraces_piece1;
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample1.preAmps = blpPreAmps_piece1;
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample1.postAmps = blpPostAmps_piece1;
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample1.preEvtTimes = blpPreEvents_piece1;
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample1.postEvtTimes = blpPostEvents_piece1;
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample1.nPreEvents = sum(nEvents_pre_piece1);
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample1.nPostEvents = sum(nEvents_post_piece1);
        
    end
    
    % 2nd Sample
    
    for iChan = 1:96
        
        blpTraces_piece2 = [];
        blpPreAmps_piece2 = [];
        blpPostAmps_piece2 = [];
        nEvents_pre_piece2 = [];
        nEvents_post_piece2 = [];
        blpPreEvents_piece2 = [];
        blpPostEvents_piece2 = [];
        
        
        for iPiece = 1:length(lfpPiece2)
            
            piece = [zeros(1,250) lfpPiece2{iPiece}(iChan,:) zeros(1,250)];
            lfppiece = abs(hilbert(filtfilt(b,a,piece)));
            lfpevents = event_detection(detrend(lfppiece'),3.5,'stdgauss',evtDur);
            lfpevents(lfpevents<=pad) = [];
            lfpevents(lfpevents>=(length(t)+pad)) = [];
            lfpevents = lfpevents-pad;
            lfppiece = lfppiece(pad+1:end-pad);
            blpTraces_piece2 = [blpTraces_piece2;lfppiece];
            
            if ~isempty(lfpevents)
                
                preAmps = lfppiece(lfpevents(lfpevents<=evtIdx));
                postAmps = lfppiece(lfpevents(lfpevents>evtIdx));
                preEvents = lfpevents(lfpevents<=evtIdx);
                preEvents = t(preEvents);
                postEvents = lfpevents(lfpevents>evtIdx);
                postEvents = t(postEvents);
                blpPreAmps_piece2 = [blpPreAmps_piece2 preAmps];
                blpPostAmps_piece2 = [blpPostAmps_piece2 postAmps];
                blpPreEvents_piece2 = [blpPreEvents_piece2 preEvents];
                blpPostEvents_piece2 = [blpPostEvents_piece2 postEvents];
                
                nEvents_pre_piece2 = [nEvents_pre_piece2 numel(preEvents(preEvents<(midPoint)))];
                nEvents_post_piece2 = [nEvents_post_piece2 numel(postEvents(postEvents>(midPoint)))];
            end
            
            
        end
        
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample2.traces = blpTraces_piece2;
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample2.preAmps = blpPreAmps_piece2;
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample2.postAmps = blpPostAmps_piece2;
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample2.preEvtTimes = blpPreEvents_piece2;
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample2.postEvtTimes = blpPostEvents_piece2;
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample2.nPreEvents = sum(nEvents_pre_piece2);
        blpCharacteristicsRT(iChan).nIter(iIter).randomTrigger.sample2.nPostEvents = sum(nEvents_post_piece2);
        
    end
    
    toc
    
end

%% Save the processed data structures

%save(filename1,'randomTriggeredSpecgrams1','randomTriggeredSpecgrams1_norm1','t','f','-v7.3');
save(filename2, 'blpCharacteristicsRT','t','-v7.3');
