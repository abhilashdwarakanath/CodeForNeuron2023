function ensembleLFPsSelectivityClassifier

%% Enumerate datasets

datasets{1} = 'C:\Data\H07\12-06-2016\PFC\Bfsgrad1\EnsemblePSTHs\MM\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel.mat';
recDate{1} = '12062016';
fileID{1} = '12-06-2016';
subjID{1} = 'Hayo';
datasets{2} = 'C:\Data\H07\13-07-2016\PFC\Bfsgrad1\EnsemblePSTHs\MM\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel.mat';
recDate{2} = '13072016';
fileID{2} = '13-07-2016';
subjID{2} = 'Hayo';
datasets{3} = 'C:\Data\H07\20161019\PFC\Bfsgrad1\EnsemblePSTHs\MM\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel.mat';
recDate{3} = '19102016';
fileID{3} = '20161019';
subjID{3} = 'Hayo';
datasets{4} = 'C:\Data\H07\20161025\PFC\Bfsgrad1\EnsemblePSTHs\MM\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel.mat';
recDate{4} = '25102016';
fileID{4} = '20161025';
subjID{4} = 'Hayo';
datasets{5} = 'C:\Data\A11\20170305\PFC\Bfsgrad1\EnsemblePSTHs\MM\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel.mat';
recDate{5} = '05032017';
fileID{5} = '20170305';
subjID{5} = 'Anton';
datasets{6} = 'C:\Data\A11\20170302\PFC\Bfsgrad1\EnsemblePSTHs\MM\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel.mat';
recDate{6} = '02032017';
fileID{6} = '20170302';
subjID{6} = 'Anton';


%% For LF

low_sel90_BR_s270TO90 = [];
low_sel90_BR_s90TO270 = [];
low_sel270_BR_s270TO90 = [];
low_sel270_BR_s90TO270 = [];

for iDataset = 1:length(datasets)
    
    load(datasets{iDataset})
    
    low_sel90_BR_s270TO90 = [low_sel90_BR_s270TO90;spikingActivityPerTransition.sel90.lowRate.BR.s270TO90];
    low_sel90_BR_s90TO270 = [low_sel90_BR_s90TO270;spikingActivityPerTransition.sel90.lowRate.BR.s90TO270];
    low_sel270_BR_s270TO90 = [low_sel270_BR_s270TO90;spikingActivityPerTransition.sel270.lowRate.BR.s270TO90];
    low_sel270_BR_s90TO270 = [low_sel270_BR_s90TO270;spikingActivityPerTransition.sel270.lowRate.BR.s90TO270];
    
    
end

% Normalise each before averaging and taking SEM

for iTr = 1:size(low_sel90_BR_s270TO90,1)
    
    low_sel90_BR_s270TO90(iTr,:) = normalise(low_sel90_BR_s270TO90(iTr,:));
    
end

lab11 = zeros(iTr,1);

for iTr = 1:size(low_sel90_BR_s90TO270,1)
    
    low_sel90_BR_s90TO270(iTr,:) = normalise(low_sel90_BR_s90TO270(iTr,:));
    
end

lab12 = zeros(iTr,1);

for iTr = 1:size(low_sel270_BR_s270TO90,1)
    
    low_sel270_BR_s270TO90(iTr,:) = normalise(low_sel270_BR_s270TO90(iTr,:));
    
end

lab21 = ones(iTr,1);

for iTr = 1:size(low_sel270_BR_s90TO270,1)
    
    low_sel270_BR_s90TO270(iTr,:) = normalise(low_sel270_BR_s90TO270(iTr,:));
    
end

lab22 = ones(iTr,1);

%% Collect predictors and labels

dataset = [low_sel90_BR_s270TO90;low_sel270_BR_s270TO90;low_sel90_BR_s90TO270;low_sel270_BR_s90TO270];
input_labels = [lab11;lab21;lab12;lab22];

input_data = dataset(:,1:501);


%% Run SVM classifier

nRuns = 1000;

for iRun = 1:nRuns

    tic;

    inds = 1:size(input_data,1); % All indices

    CVSVMModel = fitcsvm(input_data,input_labels,'Holdout',0.20,'ClassNames',{'1','0'},...
        'Standardize',false,'CrossVal','on') % Train cross-validated model with 20% partitioning for Test

    CompactSVMModel = CVSVMModel.Trained{1}; % Extract trained, compact classifier
    testInds = test(CVSVMModel.Partition);   % Extract the test indices

    idxs = find(testInds==1);
    trainInds = setdiff(inds,idxs);
    XTest = input_data(testInds,:);
    YTest = input_labels(testInds,:);
    XTrain = input_data(trainInds,:);
    YTrain = input_labels(trainInds,:);

    [YTestPred,score] = predict(CompactSVMModel,XTest);
    [YTrainPred,score2] = predict(CompactSVMModel,XTrain);
    [YShuffledPred,score3] = predict(CompactSVMModel,XTest);

    [ROC_X_train(:,iRun), ROC_Y_train(:,iRun), ROC_T_train(:,iRun), AUC_train(iRun)] = perfcurve(YTrain, score2(:,1), '1');
    [ROC_X_test(:,iRun), ROC_Y_test(:,iRun), ROC_T_test(:,iRun), AUC_test(iRun)] = perfcurve(YTest, score(:,1), '1');
    [ROC_X_shuff(:,iRun), ROC_Y_shuff(:,iRun), ROC_T_shuff(:,iRun), AUC_shuff(iRun)] = perfcurve(YTest(randperm(length(YTest))), score3(:,1), '1');

    % Use this only if required

%     rocObj1 = rocmetrics(YTest,score,CompactSVMModel.ClassNames);
%     rocObj2 = rocmetrics(YTrain,score2,CompactSVMModel.ClassNames);
%     rocObj3 = rocmetrics(YTest(randperm(length(YTest))),score,CompactSVMModel.ClassNames);
%    
%     plot(rocObj1,AverageROCType="macro",ClassNames=[])
%     hold on
%     plot(rocObj2,AverageROCType="macro",ClassNames=[])
%     plot(rocObj3,AverageROCType="macro",ClassNames=[])
%     legend('Test','Train','Test Shuffled')

toc;

end

figure()

subplot(1,2,1)
plot(nanmean(ROC_X_train,2),nanmean(ROC_Y_train,2),'-b','LineWidth',1.25)
hold on
plot(nanmean(ROC_X_test,2),nanmean(ROC_Y_test,2),'-r','LineWidth',1.25)
plot(nanmean(ROC_X_shuff,2),nanmean(ROC_Y_shuff,2),'-g','LineWidth',1.25)
plot([0:0.1:1],[0:0.1:1],'--k','LineWidth',2)
xlabel('FPR')
ylabel('TFR')
title('ROC n = 1000')
legend('Training data', 'Test data', 'Test labels shuffled')
box off

subplot(1,2,2)
groups = [AUC_train' AUC_test' AUC_shuff'];
boxplot(groups)
hline(0.5,'-k')
ylim([0 1])
title('AUCROC')
box off


%%
% qpsth_sample = classifyQuasiPSTHcurves(input_data, input_labels);
% randomcurves_sample = classifyQuasiPSTHcurves();
% 
% figure;
% boxplot([qpsth_sample, randomcurves_sample]);
% title('Test data, random curve classifier vs QPSTH classifier');
% 
% display('t-test, hypothesis probed to be rejected: do X-Y come from normal distr with zero mean?'); 
% [h_ttest, p_ttest] = ttest(qpsth_sample, randomcurves_sample)
% 
% display('KS-test, hypothesis probed to be rejected: do X and Y come from same continuous distribution?'); 
% [h_ttest, p_kstest] = kstest2(qpsth_sample, randomcurves_sample)
% 
% %% Classification function
% 
% function [test_posterior] = classifyQuasiPSTHcurves(data, labels)
% %
% % [success] = classifyQuasiPSTHcurves(data, labels)
% %   Trains a 2-class SVM classifier on portion of (train) 'data' given 'labels' and return
% %   and returns posterior probabilities that the other portion (test) belongs to 2nd class.
% %   When no input is passed, uses random "smooth" curves as an "indiscriminable" model.
% %
% %
% %  Comment: if 'data' and 'labels' are empty, we generate random data, 
% %   otherwise use 'data' and 'labels' as input;
% %   example data: every row of 'data' is a vector, every column is a 
% %   vector feature; 'labels' has one column, every row is a class label.
% %
% % Input:    data   - input curves to classify
% %           labels  - true labels of curves
% %
% % Output:   test_posterior   - posterior class probabilities for test data
% %
% % Last updated: 2022-08-26 (Leonid Fedorov).  
% %
% 
% 
% if nargin() == 1
%     display("No data passed for classification");
%     %these can be adjusted so that "random" smooth curves match potential data
%     vectorLength = 251; %these can be adjuste
%     numSamples = 648;
% 
%     labels = [ones(floor(numSamples / 2), 1); zeros(floor(numSamples / 2), 1)];
% 
%     data = Inf(numSamples, vectorLength);
% 
% 
%     for i = 1 : numSamples
%         %vectorLength is the number of vector features, other numbers are parameters
%         [f, x] = rsgeng1D(vectorLength, 10, 0.1, 10);
%         data(i, :) = f;
%     end
% elseif nargin == 2
%     display("Data passed for classification");
% else
%     error("Incorrect Input passed")
% end
% 
% %Set up input and test data portion
% X = data;
% Y = labels;
% holdoutPortion = 0.2;
% 
% dataIndices = 1:numel(labels);
% 
% testIndices = randsample(dataIndices, floor(holdoutPortion * dataIndices(end)), 'false');
% trainIndices = setdiff(dataIndices, testIndices);
% 
% testData = data(testIndices, :);
% trainData = data(trainIndices, :);
% 
% testLabels = labels(testIndices, :);
% trainLabels = labels(trainIndices, :);
% 
% %fit SVM model to training data, default kernel is linear
% SVMModel = fitcsvm(trainData, trainLabels, 'Standardize', true, 'ClassNames', {'1', '0'});
% %same model, with scores converted to probabilities
% SVMModelPosterior = fitPosterior(SVMModel, trainData, trainLabels); 
% %estimate posterior probabilities for test data
% [predictedTestLabels, posteriorTestProbabilities] = predict(SVMModelPosterior, testData);
% %check performance using initial test labels and estimated test probabilities (for the first class)
% [ROC_X_test, ROC_Y_test, ROC_T_test, AUC_test] = perfcurve(testLabels, posteriorTestProbabilities(:, 2), '0');
% 
% %get scores for already used training data to look at AUC and ROC
% %in terms of classification labels, there should be
% %no difference between scores and posterior probabilities
% [predictedTrainLabels, trainScores] = predict(SVMModel, trainData);
% [ROC_X_train, ROC_Y_train, ROC_T_train, AUC_train] = perfcurve(trainLabels, trainScores(:,1), '1');
% 
% 
% %Plot histogram of predicted posterior probability for the first class in test data
% posteriorTestMean = mean(posteriorTestProbabilities(:, 1));
% figure;
% subplot(2, 2, 1);
% histogram(posteriorTestProbabilities(:, 2), 30);
% title('Test set posterior histogram');
% hold on
% plot([posteriorTestMean posteriorTestMean], [0 8], 'r--', 'LineWidth', 2.0)
% subplot(2, 2, 2);
% boxplot(posteriorTestProbabilities(:, 2))
% title('Test set posterior boxplot');
% subplot(2, 2,[3 4]);
% plot(ROC_X_train, ROC_Y_train);
% title(strcat('AUC train = ', num2str(AUC_train)))
% 
% test_posterior = posteriorTestProbabilities(:, 1);
% 
% return;





