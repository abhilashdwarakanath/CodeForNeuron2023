clear all
clc
close all

% This is a script to get the event triggered traces in the resting state
% data

%% Load dataset 1

% Load LFPs

cd B:\H07\07-04-2016\PFC
%cd B:\A11\06-04-2016\PFC
load LFPPFC.mat

% load eye movements

cd EMSegmentation
load NSX_TimeStamps.mat

emy = read_NC5('NSX130.NC5',1,lts);
emyDec = decimate(emy,2);
%% Setup filters and buffer

[b1,a1] = cheby1(4,0.001,[1 9]/250);
evtDur = 56;
fs = 500;
ttime = length(emyDec)/fs;
%% Get the events, store them and compute burst rate

parfor i = 1:96
    
    tic;
    lowInstAmp = abs(hilbert(filtfilt(b1,a1,[zeros(1,500) LFP.data(i,:) zeros(1,500)])));
    lfpevents = event_detection(lowInstAmp',4,'stdgauss',evtDur);
    lfpevents(lfpevents<=500 & lfpevents>=length(LFP.data(i,:))) = [];
    burstRate(i) = numel(lfpevents)/ttime;
    toc
end

clear temp;

lowBurstRate{1} = burstRate;
%% Load dataset 2

% Load LFPs

%cd B:\H07\07-04-2016\PFC
cd B:\A11\06-04-2016\PFC
load LFPPFC.mat

% load eye movements

cd EMSegmentation
load NSX_TimeStamps.mat

emy = read_NC5('NSX130.NC5',1,lts);
emyDec = decimate(emy,2);
ttime = length(emyDec)/fs;

parfor i = 1:96
    
    tic;
    lowInstAmp = abs(hilbert(filtfilt(b1,a1,[zeros(1,500) LFP.data(i,:) zeros(1,500)])));
    lfpevents = event_detection(lowInstAmp',4,'stdgauss',evtDur);
    lfpevents(lfpevents<=500 & lfpevents>=length(LFP.data(i,:))) = [];
    burstRate(i) = numel(lfpevents)/ttime;
    toc
end

clear temp;

lowBurstRate{2} = burstRate;

%% Plot violin plots for the two data sets

dataMatrix = [lowBurstRate{1};lowBurstRate{2}];
dataMatrix = dataMatrix(:);

colors(1:length(dataMatrix)) = ones(length(dataMatrix),1);
[names{1:length(dataMatrix)}] = deal('LBR');
g = gramm('x',names,'y',dataMatrix,'color',colors);
set_order_options(g,'x',0)
g.stat_violin('normalization','area','dodge',0,'fill','edge');
g.set_names('x','Pooled RS Sessions','y','bursts/channel/s','size',24)
g.stat_boxplot('width',0.1,'notch','true');
g.set_title('RS Burst Rate');
g.update()
grid on