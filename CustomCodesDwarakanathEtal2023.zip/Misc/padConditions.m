cd B:\A11\20170302\PFC\Bfsgrad1\
load SUMUDominancesByTime.mat
for i = 1:96
if ~isempty(SUMUDominances.data.PA_MOA.dom90{i})
for iUnit = 1:length(SUMUDominances.data.PA_MOA.dom90{i})
for iCond = 1:4
SUMUDominances.data.PA_MOA.dom90{i}{iUnit}{iCond} = SUMUDominances.data.dom90{i}{iUnit}{iCond};
SUMUDominances.data.PA_MOA.dom270{i}{iUnit}{iCond} = SUMUDominances.data.dom270{i}{iUnit}{iCond};
end
end
end
end
save('SUMUDominancesByTime.mat','SUMUDominances','-v7.3')
clear all