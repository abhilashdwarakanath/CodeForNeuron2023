sigEnergy_BR_s270TO90 = [];
for i = 1:6
sigEnergy_BR_s270TO90 = cat(1,sigEnergy_BR_s270TO90,squeeze(nanmean(lfpStatistics.signalEnergy.s270TO90.BR.Pre{i},1)));
end
sigEnergy_BR_s90TO270 = [];
for i = 1:6
sigEnergy_BR_s90TO270 = cat(1,sigEnergy_BR_s90TO270,squeeze(nanmean(lfpStatistics.signalEnergy.s90TO270.BR.Pre{i},1)));
end
sigEnergy_BR = nanmean(cat(1,sigEnergy_BR_s270TO90,sigEnergy_BR_s90TO270),1);

sigEnergy_PA_s270TO90 = [];
for i = 1:6
sigEnergy_PA_s270TO90 = cat(1,sigEnergy_PA_s270TO90,squeeze(nanmean(lfpStatistics.signalEnergy.s270TO90.PA.Pre{i},1)));
end
sigEnergy_PA_s90TO270 = [];
for i = 1:6
sigEnergy_PA_s90TO270 = cat(1,sigEnergy_PA_s90TO270,squeeze(nanmean(lfpStatistics.signalEnergy.s90TO270.PA.Pre{i},1)));
end
sigEnergy_PA = nanmean(cat(1,sigEnergy_PA_s270TO90,sigEnergy_PA_s90TO270),1);