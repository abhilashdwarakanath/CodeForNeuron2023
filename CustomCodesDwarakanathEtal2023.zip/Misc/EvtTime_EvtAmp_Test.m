preBR_evtTimes = [];
prePA_evtTimes = [];

preBR_evtAmps = [];
prePA_evtAmps = [];

for i = 1:6
    for j = 1:96
    
    preBR_evtTimes = [preBR_evtTimes lfpStatistics.eventTimes.BR.s270TO90.Pre{i}{j} lfpStatistics.eventTimes.BR.s90TO270.Pre{i}{j}];
    preBR_evtAmps = [preBR_evtAmps lfpStatistics.eventAmps.BR.s270TO90.Pre{i}{j} lfpStatistics.eventAmps.BR.s90TO270.Pre{i}{j}];
    
    prePA_evtTimes = [prePA_evtTimes lfpStatistics.eventTimes.PA.s270TO90.Pre{i}{j} lfpStatistics.eventTimes.PA.s90TO270.Pre{i}{j}];
    prePA_evtAmps = [prePA_evtAmps lfpStatistics.eventAmps.PA.s270TO90.Pre{i}{j} lfpStatistics.eventAmps.PA.s90TO270.Pre{i}{j}];
    
    end

end

t = linspace(-0.5,0.5,501);

for i = 1:length(t)
    
    [~,idx] = find(preBR_evtTimes==t(i));
    tempAmps = preBR_evtAmps(idx);
    meanAmps_BR(i) = nanmean(tempAmps);
    
    [~,idx] = find(prePA_evtTimes==t(i));
    tempAmps = prePA_evtAmps(idx);
    meanAmps_PA(i) = nanmean(tempAmps);
    
end

for i = 1:length(t)
    
    [~,idx] = find(preBR_evtTimes==t(i));
    nAmps_BR(i) = numel(idx);
    
    [~,idx] = find(prePA_evtTimes==t(i));
    nAmps_PA(i) = numel(idx);
    
end