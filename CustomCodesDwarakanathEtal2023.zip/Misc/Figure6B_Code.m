t = linspace(-1,1,1001);

pd_brPeaks = fitdist(brPeaks','kernel');
pd_paPeaks = fitdist(paPeaks','kernel');
pd_coBR = fitdist(crossovers_BR','kernel');
pd_coPA = fitdist(crossovers_PA','kernel');
pd_brPeakRates = fitdist(brPeakTimes','kernel');
area(t,normalise(pdf(pd_brPeakRates,t)),'EdgeColor','k')
hold on
area(t,normalise(pdf(pd_brPeaks,t)),'EdgeColor','k')
area(t,normalise(pdf(pd_coBR,t)),'EdgeColor','k')
box off
xlabel('time relative to switch [s]')
ylabel('normalised probability density')
legend('LFP Peak Rate Times','LFP Burst Times', 'Ensemble Convergence Times')
vline(median(brPeakTimes),'--k')
median(crossoverTimes_BR)
std(crossoverTimes_BR)
[h p] = ttest(crossoverTimes_BR)
[p h] = ranksum(crossoverTimes_BR,brPeakTimes)
median(brPeakTimes)
std(brPeakTimes)
median(brPeaks)
std(brPeaks)
[p h] = ranksum(crossoverTimes_BR,brPeaks)

bursts_PA_270 = [preSwitchPeaks_PA_270 postSwitchPeaks_PA_270];
bursts_PA_90 = [preSwitchPeaks_PA_90 postSwitchPeaks_PA_90];

bursts_BR_270 = [preSwitchPeaks_BR_270 postSwitchPeaks_BR_270];
bursts_BR_90 = [preSwitchPeaks_BR_90 postSwitchPeaks_BR_90];

pd_bursts_PA_270 = fitdist(bursts_PA_270','kernel');
pd_bursts_PA_90 = fitdist(bursts_PA_90','kernel');

pd_bursts_BR_270 = fitdist(bursts_BR_270','kernel');
pd_bursts_BR_90 = fitdist(bursts_BR_90','kernel');

pd_peakTime_PA_270 = fitdist(full_lowPeakTime_PA_270TO90','kernel');
pd_peakTime_PA_90 = fitdist(full_lowPeakTime_PA_90TO270','kernel');

pd_peakTime_BR_270 = fitdist(full_lowPeakTime_BR_270TO90','kernel');
pd_peakTime_BR_90 = fitdist(full_lowPeakTime_BR_90TO270','kernel');

pd_crossoverTimes_BR_270 = fitdist(cotimes_trends3.BR_270to90','kernel');
pd_crossoverTimes_BR_90 = fitdist(cotimes_trends3.BR_90to270','kernel');

pd_crossoverTimes_PA_270 = fitdist(cotimes_trends3.PA_270to90','kernel');
pd_crossoverTimes_PA_90 = fitdist(cotimes_trends3.PA_90to270','kernel');

subplot(2,2,1)
plot(t,normalise(pdf(pd_bursts_BR_270,t)))
hold on
plot(t,normalise(pdf(pd_peakTime_BR_270,t)))
plot(t,normalise(pdf(pd_crossoverTimes_BR_270,t)))
vline(0,'--k')
ylabel('normalised probability density')
title('BR 270TO90')

subplot(2,2,2)
plot(t,normalise(pdf(pd_bursts_BR_90,t)))
hold on
plot(t,normalise(pdf(pd_peakTime_BR_90,t)))
plot(t,normalise(pdf(pd_crossoverTimes_BR_90,t)))
vline(0,'--k')
title('BR 90TO270')

subplot(2,2,3)
plot(t,normalise(pdf(pd_bursts_PA_270,t)),'--')
hold on
plot(t,normalise(pdf(pd_peakTime_PA_270,t)),'--')
plot(t,normalise(pdf(pd_crossoverTimes_PA_270,t)),'--')
vline(0,'--k')
ylabel('normalised probability density')
xlabel('time relative to switch [s]')
title('PA 270TO90')

subplot(2,2,4)
plot(t,normalise(pdf(pd_bursts_PA_90,t)),'--')
hold on
plot(t,normalise(pdf(pd_peakTime_PA_90,t)),'--')
plot(t,normalise(pdf(pd_crossoverTimes_PA_90,t)),'--')
vline(0,'--k')
xlabel('time relative to switch [s]')
title('PA 90TO270')
legend('LFP Burst Times','Peak Rate in Time','Ensemble Crossover Times')