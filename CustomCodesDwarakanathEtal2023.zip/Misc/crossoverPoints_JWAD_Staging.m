c = 0;
for iDataset = 1:6
for i = 1:size(crossovers(iDataset).spikingActivity.sel90.BR.s270TO90,1)
c = c+1;    
[crss_BR_270TO90(c),crsr_BR_270TO90(c),crse_BR_270TO90(c)] = intsct(t,normalise(crossovers(iDataset).spikingActivity.sel90.BR.s270TO90(i,:)),normalise(crossovers(iDataset).spikingActivity.sel270.BR.s270TO90(i,:)),4);
clf
end
end

c = 0;
for iDataset = 1:6
for i = 1:size(crossovers(iDataset).spikingActivity.sel90.BR.s90TO270,1)
c = c+1;    
[crss_BR_90TO270(c),crsr_BR_90TO270(c),crse_BR_90TO270(c)] = intsct(t,normalise(crossovers(iDataset).spikingActivity.sel90.BR.s90TO270(i,:)),normalise(crossovers(iDataset).spikingActivity.sel270.BR.s90TO270(i,:)),4);
clf
end
end

c = 0;
for iDataset = 1:6
for i = 1:size(crossovers(iDataset).spikingActivity.sel90.PA.s270TO90,1)
c = c+1;    
[crss_PA_270TO90(c),crsr_PA_270TO90(c),crse_PA_270TO90(c)] = intsct(t,normalise(crossovers(iDataset).spikingActivity.sel90.PA.s270TO90(i,:)),normalise(crossovers(iDataset).spikingActivity.sel270.PA.s270TO90(i,:)),4);
clf
end
end

c = 0;
for iDataset = 1:6
for i = 1:size(crossovers(iDataset).spikingActivity.sel90.PA.s90TO270,1)
c = c+1;    
[crss_PA_90TO270(c),crsr_PA_90TO270(c),crse_PA_90TO270(c)] = intsct(t,normalise(crossovers(iDataset).spikingActivity.sel90.PA.s90TO270(i,:)),normalise(crossovers(iDataset).spikingActivity.sel270.PA.s90TO270(i,:)),4);
clf
end
end