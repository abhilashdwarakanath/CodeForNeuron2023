earlyPeaks = [];
middlePeaks = [];
latePeaks = [];
for i=1:42, 
	peakTimes = []; 
	for j = 1:96,
		peakTimes = [peakTimes nTrans(i).chanPeaks(j).peaks];
	end 
	earlyPeaks= [earlyPeaks sum(peakTimes < -0.3333)]; 
	middlePeaks = [middlePeaks sum(peakTimes < -0.1667 & peakTimes >= -0.3333)];
	latePeaks = [latePeaks sum(peakTimes >= -0.16667)];
end
mean((earlyPeaks/96)*100)
mean((middlePeaks/96)*100)
mean((latePeaks/96)*100)
plot([(earlyPeaks/96)*100;(middlePeaks/96)*100;(latePeaks/96)*100]','-.')