    

for chan = 1:96
    elec = chan2elec(chan,2);
    figure(1000)
    [r(chan),c(chan)] = find(HayoPFCmap == elec);
    subplot2(10,10,r(chan),c(chan));
    
    plot(t,smooth(switchTrace(chan,:)),'-r','LineWidth',0.5)
    vline(0,'-w')
    set(gca,'Color','k')
    set(gca,'xtick',[])
    set(gca,'xticklabel',[])
    set(gca,'ytick',[])
    set(gca,'yticklabel',[])
end

    
    figure(1000)
    set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.