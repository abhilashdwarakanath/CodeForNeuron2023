for iDataset = 1:6
for iTransition = 1:size(ensemblePSTHs(iDataset).spikingActivity.sel90.BR.s270TO90,1)
crossovers(iDataset).spikingActivity.sel90.BR.s270TO90(iTransition,:) = smooth(edges(3:end-2),normalise(ensemblePSTHs(iDataset).spikingActivity.sel90.BR.s270TO90(iTransition,3:end-2)),'lowess');
crossovers(iDataset).spikingActivity.sel270.BR.s270TO90(iTransition,:) = smooth(edges(3:end-2),normalise(ensemblePSTHs(iDataset).spikingActivity.sel270.BR.s270TO90(iTransition,3:end-2)),'lowess');
end
for iTransition = 1:size(ensemblePSTHs(iDataset).spikingActivity.sel90.BR.s90TO270,1)
crossovers(iDataset).spikingActivity.sel90.BR.s90TO270(iTransition,:) = smooth(edges(3:end-2),normalise(ensemblePSTHs(iDataset).spikingActivity.sel90.BR.s90TO270(iTransition,3:end-2)),'lowess');
crossovers(iDataset).spikingActivity.sel270.BR.s90TO270(iTransition,:) = smooth(edges(3:end-2),normalise(ensemblePSTHs(iDataset).spikingActivity.sel270.BR.s90TO270(iTransition,3:end-2)),'lowess');
end
for iTransition = 1:size(ensemblePSTHs(iDataset).spikingActivity.sel90.PA.s270TO90,1)
crossovers(iDataset).spikingActivity.sel90.PA.s270TO90(iTransition,:) = smooth(edges(3:end-2),normalise(ensemblePSTHs(iDataset).spikingActivity.sel90.PA.s270TO90(iTransition,3:end-2)),'lowess');
crossovers(iDataset).spikingActivity.sel270.PA.s270TO90(iTransition,:) = smooth(edges(3:end-2),normalise(ensemblePSTHs(iDataset).spikingActivity.sel270.PA.s270TO90(iTransition,3:end-2)),'lowess');
end
for iTransition = 1:size(ensemblePSTHs(iDataset).spikingActivity.sel90.PA.s90TO270,1)
crossovers(iDataset).spikingActivity.sel90.PA.s90TO270(iTransition,:) = smooth(edges(3:end-2),normalise(ensemblePSTHs(iDataset).spikingActivity.sel90.PA.s90TO270(iTransition,3:end-2)),'lowess');
crossovers(iDataset).spikingActivity.sel270.PA.s90TO270(iTransition,:) = smooth(edges(3:end-2),normalise(ensemblePSTHs(iDataset).spikingActivity.sel270.PA.s90TO270(iTransition,3:end-2)),'lowess');
end
end

crossovers(1).t = edges(3:end-2);
crossovers(2).t = edges(3:end-2);
crossovers(3).t = edges(3:end-2);
crossovers(4).t = edges(3:end-2);
crossovers(5).t = edges(3:end-2);
crossovers(6).t = edges(3:end-2);