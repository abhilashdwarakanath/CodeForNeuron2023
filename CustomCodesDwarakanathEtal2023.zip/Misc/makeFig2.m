subplot(3,2,1)
plot(t,normalise(detrend(brOKNTraces(23,:))),'-r','LineWidth',1.5)
box off
vline(0,'--k')
set(gca,'xtick',[])
subplot(3,2,2)
plot(t,normalise(detrend(paOKNTraces(11,:))),'-k','LineWidth',1.5)
box off
vline(0,'--k')
set(gca,'xtick',[])
set(gca,'ytick',[])

subplot(3,2,3)
Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
imagesc(t,log2(f),cwtbr90_avg(:,:,23)); shading('interp')
ylabel('Hz')
vline(0,'--w'); AX = gca;
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
AX.YLim = log2([min(f), max(f)]);
axis xy
colormap jet
set(gca,'xtick',[])
subplot(3,2,4)
Yticks = 2.^(round(log2(min(f))):round(log2(max(f))));
imagesc(t,log2(f),cwtpa90_avg(:,:,11)); shading('interp')
ylabel('Hz')
vline(0,'--w'); AX = gca;
set(AX, 'YTick',log2(Yticks(:)), 'YTickLabel',num2str(sprintf('%g\n',Yticks)))
AX.YLim = log2([min(f), max(f)]);
axis xy
colormap jet
set(gca,'xtick',[])
set(gca,'ytick',[])

subplot(3,2,5)
plot(t,normalise(lowTracesBR(23,:)))
hold on
plot(t,normalise(betaTracesBR(23,:))+1.5)
vline(0,'--k')
xlabel('time relative to switch [s]')
axis tight
vline(0,'--k')
box off
subplot(3,2,6)
plot(t,normalise(lowTracesPA(11,:)))
hold on
plot(t,normalise(betaTracesPA(11,:))+1.5)
vline(0,'--k')
xlabel('time relative to switch [s]')
axis tight
vline(0,'--k')
box off
set(gca,'ytick',[])