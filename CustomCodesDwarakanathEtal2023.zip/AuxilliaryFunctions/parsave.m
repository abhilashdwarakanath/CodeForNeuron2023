function parsave(fname, x,y)
    save(fname, 'lowInstAmp', 'betaInstAmp')
end