function spikeTrainCleaned = removeCommonArtifacts(params,spikeTrain)

detect = zeros(size(spikeTrain));

fprintf('Create detection kernel using tolerance offset...\n')

detectionKernel = ones(1,2*params.offset);

fprintf('Detect coincidences...\n')

for iChan=1:params.elecs/2

    tic;

    out = conv(spikeTrain(iChan, :), detectionKernel);

    detect(iChan,:) = out(params.offset:end-params.offset)>0;

    toc;

end

hits = sum(detect, 1);

fprintf('Clean up coincident spikes...\n')

[~, remIdx] = find((hits>params.channelThreshold));

spikeTrainCleaned = spikeTrain;

spikeTrainCleaned(:,remIdx) = 0;

end

