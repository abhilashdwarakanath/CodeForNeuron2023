function clusteringSingleChannel(params,spikes,chans)

% Do single-channel clustering using Klustakwik. An EVD, an SVD and a
% Probabilistic PCA, all three can be used here. Just comment out the
% methods you don't want to use. I prefer the probabilistic PCA.

waveforms = spikes.waveforms;
times = spikes.times;

kluname = ['!KlustaKwik' num2str(chans) '.exe'];

if isempty(waveforms)
    fprintf('No spikes here, no clustering done, channel removed...')
elseif size(waveforms,1) < params.minSpkNum
    fprintf('Too few spikes, no clustering done, channel removed...')
else
    
    %% Do the PCA
    fprintf('Computing principal components...\n')
    % subtract off the mean for each dimension
    %[r,c] = size(waveforms);
    %mn = mean(waveforms,1);
    %swaveforms = waveforms - repmat(mn,r,1);
    
    % construct the matrix Y by normalising it with the sigma. Is this
    % necessary?
    %Y = swaveforms' / sqrt(c-1);
    
    % Either use a singular value decomposition
    %[~,~,PC] = svd(Y);
    
    % Or use an eigendecomposition of the covariance matrix
    
    %cwaveforms = cov(Y);
    %[PC,~] = eigs(cwaveforms,params.numFeatures);
    %PC = fliplr(PC(:,1:5));
    %clear cwaveforms % Save some memory
    % project the original data
    %eigenwaveforms = fliplr(PC') * waveforms;
    
    % Use probabilistic PCA which whitens the data and then uses an EM
    % algorithm to compute coefficients which also takes care of
    % non-parametric stuff
    
    %[~,PC,~] = ppca(waveforms,params.numFeatures+3);
    %[PC,W] = ppca_new(waveforms',params.numFeatures);
    %cd('L:\projects\AbhilashD\Preprocessing_Abhi_Toolbox\bh_tsne')
    %PC = fast_tsne(waveforms, 2, 45, 30, 0.5);
    %cd(directories.PFC)
    %[PC,W] = ppca_new(Y',params.numFeatures);
    %PC = PC'; % convert to column vector
    %[~,y] = smoothingkernel(0.0015,params.fs,0.00015,'gaussian');
    %convKer = diff(diff(y));
    %convWaveforms = zeros(size(waveforms,1),size(waveforms,2));
    %for i = 1:size(waveforms,1)
    %    convWaveforms(i,:) = conv(waveforms(i,:),convKer,'same');
    %end

    [coeffs,PC] = pca(waveforms);
    %coeffs = fliplr(coeffs);
    %PC = coeffs*waveforms';
    %PC = PC';
    %PC = fliplr(PC);
    PC = PC(:,1:3);
    %[PC,~] = ppca_new(convWaveforms',params.numFeatures);
    %PC = PC';
    %cPC = myPCA(convWaveforms,params.numFeatures);
    
    %% Fet for KK
    
    fetfilename = ['autoResult'];
    fid = fopen([fetfilename,'.fet.' num2str(chans)], 'w');
    fprintf(fid, '%d\r\n',(size(PC,2)));
    fclose(fid);
    delimiter = ' ';
    [~, nCols] = size(PC);
    formatStr = [repmat(['%i' delimiter], 1, (nCols-1)) '%i' '\n'];
    fid = fopen([fetfilename,'.fet.' num2str(chans)], 'a');
    fprintf(fid, formatStr, PC');
    fclose(fid);
    
        
    %% Run KlustaKwik
    fprintf('Clustering using Klustakwik...\n')
    copyfile('L:\projects\AbhilashD\NewPipelineAwakeData\SpikeDetectionClustering\KlustaKwik\KlustaKwik-1_7.exe',kluname(2:end));
    %eval(['!KlustaKwik-1_7.exe ' fetfilename ' -MinClusters ' params.minclus ' -MaxClusters ' params.maxclus ' -MaxPossibleClusters ' params.maxclus*5 ' -UseFeatures 11110']);
    eval([kluname ' ' fetfilename ' ' num2str(chans) ' -MinClusters' ' 2' ' -MaxClusters' ' 6' ' -MaxPossibleClusters' ' 7' ' -UseFeatures all'])
    %eval([kluname ' ' fetfilename ' ' num2str(chans) ' -UseFeatures all'])
    % Remove the klustakwik.exe to avoid clutter
    delete(kluname(2:end));
    
    %% Write the FET file for Klustakwik
    
    [nSpikes,nSamples] = size(PC);
    valRange = max(abs(PC));
    
    PC = int32(PC .* repmat(0.9 * double(intmax('int16')) ./ valRange, nSpikes,1));
    
    %Create vector with spike times as multiples of the sampling period
    %(1 / samplingFrequency)
    
    times = times/30;
    spkTimes=int32((times-min(times))* params.fs / 1000)';
    
    if isrow(spkTimes) == 1
        PC = [PC spkTimes'];
    else
        PC = [PC spkTimes];
    end
    fetfilename = ['autoResult'];
    fid = fopen([fetfilename,'.fet.' num2str(chans)], 'w');
    fprintf(fid, '%d\r\n',int32(size(PC,2))); 
    fclose(fid);
    delimiter = ' ';
    [~, nCols] = size(PC);
    formatStr = [repmat(['%i' delimiter], 1, int32(nCols-1)) '%i' '\n'];
    fid = fopen([fetfilename,'.fet.' num2str(chans)], 'a');
    fprintf(fid, formatStr, PC');
    fclose(fid);

    %% Rewrite FET file for Klusters and write the SPK file
    
    waveforms = waveforms';
    [nSamples,nSpikes] = size(waveforms);
    fprintf('Writing the SPK file...\n')
    forspkfile = reshape(waveforms, nSamples*nSpikes, 1)';
    fid1 = fopen([fetfilename '.spk.' num2str(chans)], 'w');
    fwrite(fid, forspkfile, 'int16');
    fclose(fid1);
    
end

end