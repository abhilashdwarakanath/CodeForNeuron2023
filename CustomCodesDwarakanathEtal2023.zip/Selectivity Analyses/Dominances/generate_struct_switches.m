function generate_struct_switches


%% Load the dataset
% cd B:\H07\12-06-2016\PFC\Bfsgrad1\
load jMUSwitchesByTime

%% Declare a struct for saving the data

jMUSwitchesVK = struct;
jMUSwitchesVK = jMUSwitches;


%% Loop through all the channels, conds, switch types, trials and the number of switches to collect all the valid switches in the two directions:
%  90 to 270
%  270 to 90

for chan = 1:length(jMUSwitches.data.spikesByTime)
%     chan = 11;
    for iCond = 1:8
        
% create huge cells to store the data (This should be larger than the expected switches)

        tmp_Vdata_90TO270{chan}{iCond} = cell(1000,1);
        tmp_Vdata_270TO90{chan}{iCond} = cell(1000,1);
        
        idx1 = 1; idx2 = 1;
        
        for switchtyp = 1:2
            
            for nTr = 1:length(jMUSwitches.data.spikesByTime{chan}{iCond}{switchtyp})
                
                if iscell(jMUSwitches.data.spikesByTime{chan}{iCond}{switchtyp}{nTr})
                    
                    for switchNum = 1:length(jMUSwitches.data.spikesByTime{chan}{iCond}{switchtyp}{nTr})
                                                
                        
                        if switchtyp == 1
                            
                            tmp_Vdata_90TO270{chan}{iCond}{idx1} = jMUSwitches.data.spikesByTime{chan}{iCond}{switchtyp}{nTr}{switchNum};
                            idx1 = idx1+1;
                            
                        elseif switchtyp == 2
                            
                            tmp_Vdata_270TO90{chan}{iCond}{idx2} = jMUSwitches.data.spikesByTime{chan}{iCond}{switchtyp}{nTr}{switchNum};
                            idx2 = idx2+1;
                            
                        end
                        
                        
                    end
                    
                end
                
            end
            
        end
        
% remove empty cells
        
%         SwitchData_90TO270{chan}{iCond} = tmp_Vdata_90TO270{chan}{iCond}(~cellfun('isempty',tmp_Vdata_90TO270{chan}{iCond}))';
%         SwitchData_270TO90{chan}{iCond} = tmp_Vdata_270TO90{chan}{iCond}(~cellfun('isempty',tmp_Vdata_270TO90{chan}{iCond}))';    

        SwitchData_90TO270{chan}{iCond} = tmp_Vdata_90TO270{chan}{iCond}(1:(idx1-1))';
        SwitchData_270TO90{chan}{iCond} = tmp_Vdata_270TO90{chan}{iCond}(1:(idx2-1))';   
        
    end
    
end

%% Add the new structures and save the structure in the same directory

jMUSwitchesVK.data.SwitchData_90TO270 = SwitchData_90TO270;
jMUSwitchesVK.data.SwitchData_270TO90 = SwitchData_270TO90;
jMUSwitchesVK.data.SwitchData_format = '{nChan}{iCond}{nSwitch}';
save('jMUSwitchesByTimeVK','jMUSwitchesVK');






