function [pref_array, d_prime]=check_preference_switch_mua(tim_win, muadata1, muadata2, tst_typ, tst_cnd)

%% This code assesses the preference across sites if they prefer the grating moving up or down, during the bfsgrad paradigm.
% 
% Input: 
% 
% 1. tim_win: Time window to use for assessing selectivity. Input should be a window
% in milliseconds (typically - [-1500 0] or [0 1500])
% 2. muadata1: format - cell array (1*96). Each cell contains data from the
% eight different conditions, when the switches were 90 to 270.
% 3. muadata2: format - cell array (1*96). Each cell contains data from the
% eight different conditions, when the switches were 270 to 90.
% 4. tst_typ: 'spike count' OR 'mean psth'
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2016/10/20

%% Declare certain variables

if strcmp(tst_cnd,'rivalry')    
    cond_to_compare = [1 2 3 4];
elseif strcmp(tst_cnd,'physical')
    cond_to_compare = [5 6 7 8];
end


if tim_win(1)<0
    
    timwin_typ = 'before_switch';
    cond_to_compare_title = strvcat('90','270');
    
elseif tim_win(1)>=0
    
    timwin_typ = 'after_switch';
    cond_to_compare_title = strvcat('270','90');
    
end


for num_chan = 1:size(muadata1,2)
    
    temp_muadata_cond_one = []; temp_muadata_cond_two = [];
    spkCnt_cond1 = []; spkCnt_cond2 = [];
    cond_one_mean = []; cond_two_mean = [];
    
    pref_array{num_chan,5} = num_chan;
    
    %% CASE: Spike Count
    
    if strcmp(tst_typ,'spike count')
        
        temp_muadata_cond_one = [muadata1{num_chan}{cond_to_compare(1)} muadata1{num_chan}{cond_to_compare(2)}...
            muadata1{num_chan}{cond_to_compare(3)} muadata1{num_chan}{cond_to_compare(4)}];
        temp_muadata_cond_two = [muadata2{num_chan}{cond_to_compare(1)} muadata2{num_chan}{cond_to_compare(2)}...
            muadata2{num_chan}{cond_to_compare(3)} muadata2{num_chan}{cond_to_compare(4)}];
                
    end
    
    for trl_cnd1 = 1:size(temp_muadata_cond_one,2)
        
        spkCnt_cond1(trl_cnd1) = length(find(temp_muadata_cond_one{trl_cnd1}>tim_win(1) & temp_muadata_cond_one{trl_cnd1}<tim_win(2)));
        
    end
    
    for trl_cnd2 = 1:size(temp_muadata_cond_two,2)
        
        spkCnt_cond2(trl_cnd2) = length(find(temp_muadata_cond_two{trl_cnd2}>tim_win(1) & temp_muadata_cond_two{trl_cnd2}<tim_win(2)));
        
    end
    
    cond_one_mean = mean(spkCnt_cond1);
    cond_two_mean = mean(spkCnt_cond2);
    
    p_val = [];
    [pref_array{num_chan,1}, p_val] = ranksum(spkCnt_cond1,spkCnt_cond2);
    pref_array{num_chan,2} = double(p_val);
    
    if  isnan(pref_array{num_chan,1})
        pref_array{num_chan,1} = 0;
        pref_array{num_chan,2} = 0;
    end
    
    
    if cond_one_mean > cond_two_mean
        
        pref_array{num_chan,4} = {cond_to_compare_title(1,:)};
        
        d_prime(num_chan) = (cond_one_mean - cond_two_mean)/sqrt((var(spkCnt_cond1)+var(spkCnt_cond2))/2);
        
        if strcmp(timwin_typ ,'before_switch')
            
           pref_array{num_chan,3} = 2;
            
        elseif strcmp(timwin_typ,'after_switch')
            
           pref_array{num_chan,3} = 1;            
            
        end
        
    else        
        
        pref_array{num_chan,4} = {cond_to_compare_title(2,:)};     

        d_prime(num_chan) = (cond_two_mean - cond_one_mean)/sqrt((var(spkCnt_cond2)+var(spkCnt_cond1))/2);
        
        if strcmp(timwin_typ ,'before_switch')
                        
            pref_array{num_chan,3} = 1;           
            
        elseif strcmp(timwin_typ,'after_switch')
            
           pref_array{num_chan,3} = 2;
            
        end         
        
    end
        
end
    



