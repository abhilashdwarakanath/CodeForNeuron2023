function analyze_mua_bfsgrad(ds_info, an_info, roi, trl_phase)


%% This code carries out all the basic MUA analysis for the bfsgrad paradigm for ONE dataset.
% 
% Input: 
% 
% 1. ds_info: A file containing the appropriate directory and dataset
%   information.
% 2. an_info: A file contatining the appropriate information about the
%   progress of the analysis.
% 3. roi: region of interest - PFC or PPC.
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/4/27



switch trl_phase
    
    case 'BFS'

%% Load the data and check for region of interest

if strcmp(roi,'PFC')    
    cd(ds_info.jMUspikesPath.PFC);
    array_idx = 1;
    load('jMUSpikesByTime');
elseif strcmp(roi,'PPC')   
    cd(ds_info.jMUspikesPath.PPC);
    array_idx = 2;
    load('jMUSpikesByTime');    
end

%% Generate the appropriate folder structure for saving the results

generate_folder_structure('Bfsgrad','MUA','PSTH',ds_info,roi);

%% Main Results Directory

res_dir = strcat('B:\Results\',ds_info.monk,'\',ds_info.dataset,'\Bfsgrad\',ds_info.activeArray{array_idx},'\MUA\');
ttl_suffix = strcat('-',ds_info.monk,'-',ds_info.activeArray{array_idx},'-', ds_info.dataset);

%% WORK ON Physical Alternation and Flash Suppression Switch

%% Create PSTHs - Stimulus Onset Aligned Data

align_evt_soa = 'SOA';
sav_dir_PsthSoa = strcat(res_dir, 'PSTH_Sites\PSTH_SOAligned');
% sav_fig = saveOrNot(an_info.sdf_soa_fig);
sav_fig = 0;

[sdf_soa] = generate_psth_bfsgrad(jMUspikes,align_evt_soa, sav_dir_PsthSoa, sav_fig);

%% Create PSTHs - Mask Onset Aligned Data

align_evt_moa = 'MOA';
sav_dir_PsthSoa = strcat(res_dir, 'PSTH_Sites\PSTH_MOAligned');
% sav_fig = saveOrNot(an_info.sdf_soa_fig);
sav_fig = 0;

[sdf_moa] = generate_psth_bfsgrad(jMUspikes,align_evt_moa, sav_dir_PsthSoa, sav_fig);

%% Get spikesparse matrices for a given time window

% use a binwidth divisible by the temporal data below, or there might be issues in plotting after.
binWidth = 50; 

[res_mua_soa,muadata_soa] = get_spksparse_bfsgrad(jMUspikes,align_evt_soa,binWidth);
[res_mua_moa,muadata_moa] = get_spksparse_bfsgrad(jMUspikes,align_evt_moa,binWidth);

%% Generate the appropriate folder structure for saving the results

generate_folder_structure('Bfsgrad','MUA','Selectivity',ds_info,roi);

%% Check Preferences in Physical Alternation/Flash Suppression (for mask onset aligned data)

sav_dir_SelArray = strcat(res_dir, 'Preference_Arrays\PA_FS');
[pref_array] = get_pref_array_bfsgrad(muadata_moa, sav_dir_SelArray);

%%  Make and save the bar plot with all the preferences

% sav_fig = saveOrNot(an_info.barPlot_Pref);
sav_fig = 1;
generate_barplot_stats(pref_array.pref_sim,ttl_suffix,sav_dir_SelArray,sav_fig);

%% Generate SDF - Maps according to electrode's array location

sav_dir_SdfMap = strcat(res_dir, 'PSTH_Maps'); sav_fig = 1;
generate_sdf_map_bfsgrad(sdf_moa, pref_array, jMUspikes, sav_dir_SdfMap, ttl_suffix,sav_fig)

%% Make Preference Maps

sav_dir_PrefMap = strcat(res_dir, 'Preference_Maps'); sav_fig = 1;
% for the physical alternation condition
generate_pref_map_bfsgrad(pref_array, jMUspikes, sav_dir_PrefMap, ttl_suffix,'PA', sav_fig);
% for the flash suppression condition
generate_pref_map_bfsgrad(pref_array, jMUspikes, sav_dir_PrefMap, ttl_suffix,'FS', sav_fig);

%% Prepare figures related to d-Prime

sav_dir_dPrime = strcat(res_dir, '\d_Prime\PA_FS'); sav_fig = 1;
cond2comp = 'PA_FS';
generate_figs_dprime_bfsgrad(pref_array,sav_dir_dPrime, ttl_suffix, cond2comp, sav_fig)

%% Create Population PSTHs - Mask Onset Aligned Data

sav_dir_popPSTH = strcat(res_dir, 'PSTH_Population\PSTH_MOAligned'); sav_fig = 1;
generate_pop_psth_mu_bfsgrad(res_mua_moa, pref_array, binWidth, sav_dir_popPSTH, ttl_suffix, sav_fig)

%% Check this again with another dataset before implementing.
% Sites with opposite preference in the physical alternation and flash
% suppression condition. 

% % % % pref_paOpp_sig_mu = pref_sim.pri_diff_sig_u_mat;
% % % % units_typ = strcat('Mean of - ',num2str(length(pref_paOpp_sig_mu)),'- Sites significantly modulated in the PA condition in the opposite direction');
% % % % generate_population_mu_psth(res_mua_moa,pref_paOpp_sig_mu,units_typ,binWidth,tim_trl_dur);
% % % % units_typ = [];
% % % % 
% % % % pref_fsOpp_sig_mu = pref_sim.sec_diff_sig_u_mat;
% % % % units_typ = strcat('Mean of - ',num2str(length(pref_fsOpp_sig_mu)),'- Sites significantly modulated in the FS condition in the opposite direction');
% % % % generate_population_mu_psth(res_mua_moa,pref_fsOpp_sig_mu,units_typ,binWidth,tim_trl_dur);
% % % % units_typ = [];

%% WORK ON Dominances

    case 'Dominance'
%% Load the data and check for region of interest       

if strcmp(roi,'PFC')    
    cd(ds_info.jMUspikesPath.PFC);
    array_idx = 1;
    load('jMUDominancesByTime');
elseif strcmp(roi,'PPC')   
    cd(ds_info.jMUspikesPath.PPC);
    array_idx = 2;
    load('jMUDominancesByTime');    
end

%% Generate the appropriate folder structure for saving the results

generate_folder_structure('Bfsgrad','MUA','PSTH',ds_info,roi);

%% Get the most appropriate dominances for further analysis

% set temporal parameters

min_domDur = 1000;
max_domDur = 8000;

% get the idx and duration of valid dominances according to parameters

domDur = jMUDominances.data.domDur;
[valid_domIdx, valid_domDur] = get_dom_idx(domDur,min_domDur,max_domDur);

% get only the data with valid dominance periods
domData.dom90 = jMUDominances.data.dom90;
domData.dom270 = jMUDominances.data.dom270;

[spk_dom90, spk_dom270] = get_spk_dom(domData,valid_domIdx);

num_dom90 = sum(cellfun(@length,valid_domDur.dom90(:,1:4)));
num_dom270 = sum(cellfun(@length,valid_domDur.dom270(:,1:4)));
bar([num_dom90 num_dom270])


%% Main Results Directory

res_dir = strcat('B:\Results\',ds_info.monk,'\',ds_info.dataset,'\Bfsgrad\',ds_info.activeArray{array_idx},'\MUA\');
ttl_suffix = strcat('-',ds_info.monk,'-',ds_info.activeArray{array_idx},'-', ds_info.dataset);

%% Generate PSTHs - Dominance Related

tim_window_Dominance = [-.5 min_domDur/1000];
sigma = 0.040;
sav_dir_PsthDom = strcat(res_dir,'PSTH_Sites\PSTH_Dominances');
sav_fig = saveOrNot(an_info.sdf_switch_fig);

[sdf_dom] = generate_psth_dom_chan(spk_dom90,spk_dom270, tim_window_Dominance, sigma, sav_dir_PsthDom, sav_fig);

if an_info.sdf_dom_fil == 0
    cd(sav_dir_PsthDom);
    save('sdf_dom.mat', 'sdf_dom');
end

%% convert mua data for further analysis

muadata_90 = spk_dom90;
muadata_270 = spk_dom270;

%% Get spikesparse matrices for a given time window

binWidth = 50;
offset_dom = -300;
tWin_dom = 1000;
[res_mua_90] = spkByTime2spkSparse(spk_dom90,binWidth,offset_dom,tWin_dom);

offset_dom = -300;
tWin_dom = 1000;
[res_mua_270] = spkByTime2spkSparse(spk_dom270,binWidth,offset_dom,tWin_dom);

%% Generate the appropriate folder structure for saving the results

generate_folder_structure('Bfsgrad','MUA','Selectivity',ds_info,roi);

%% Check Preferences related to switch

sav_dir_SelArray = strcat(res_dir, 'Preference_Arrays\Dominance');
[pref_array_dom] = get_pref_array_dom_bfsgrad(muadata_270, muadata_90, min_domDur, sav_dir_SelArray);


%%  Make and save the bar plot with all the preferences

% sav_fig = saveOrNot(an_info.barPlot_Pref);
sav_fig = 0;
generate_barplot_stats(pref_array_dom.pref_sim_Dom_PhyRiv,ttl_suffix,sav_dir,sav_fig);

%% Generate SDF - Maps according to electrode's array location

sav_dir_SdfMap = strcat(res_dir, 'PSTH_Maps');
generate_sdf_map_dom_bfsgrad(sdf_dom, pref_array_dom, jMUDominances, sav_dir, ttl_suffix)

%% Make Preference Maps

sav_dir_PrefMap = strcat(res_dir, 'Preference_Maps'); sav_fig = 1;
% for the physical alternation condition
generate_pref_map_bfsgrad(pref_array_dom, jMUDominances, sav_dir_PrefMap, ttl_suffix,'Phy_Dom', sav_fig);
% for the rivalry condition
generate_pref_map_bfsgrad(pref_array_dom, jMUDominances, sav_dir_PrefMap, ttl_suffix,'Riv_Dom', sav_fig);

%% Prepare figures related to d-Prime

sav_dir_dPrime = strcat(res_dir, '\d_Prime\Dominance'); sav_fig = 1;
generate_figs_dprime_bfsgrad(pref_array_dom,sav_dir_dPrime, ttl_suffix, sav_fig)

%% Create Population PSTHs - Dominance Onset Aligned Data

trl_dur = abs(offset_dom)+tWin_dom;
% tim_trl_dur = [(offset_switch+binWidth):binWidth:tWin_switch];

%%%%% Check how to do this properly!!! 
tim_trl_dur = [(offset_dom)+binWidth/2:binWidth:(tWin_dom)-(binWidth)/2];

calc_typ = 'Switches_First';
sav_dir_popPSTH = strcat(res_dir, 'PSTH_Population\PSTH_Dominances\',calc_typ);
pop_psth_typ = 'Dom_MUA';
[pop_psth_dom] = get_pop_psth_input(pop_psth_typ, pref_array_dom, ttl_suffix);

for num_pop_psth = 1:length(pop_psth_dom)
    
    [pop_psth_phy_riv_dom(num_pop_psth)] = generate_population_mu_psth_switch(res_mua_270,res_mua_90,pop_psth_dom(num_pop_psth).mu2plot, ...
        pop_psth_dom(num_pop_psth).units_typ, binWidth,tim_trl_dur, calc_typ, sav_dir_popPSTH, sav_fig, ...
        pop_psth_dom(num_pop_psth).sav_nam);
%     close all;
end

calc_typ = 'Sites_First';
sav_dir_popPSTH = strcat(res_dir, 'PSTH_Population\PSTH_Dominances\',calc_typ);
pop_psth_typ = 'Dom_MUA';
[pop_psth_dom] = get_pop_psth_input(pop_psth_typ, pref_array_dom, ttl_suffix);

for num_pop_psth = 1:length(pop_psth_switch)
    
    generate_population_mu_psth_switch(res_mua_270,res_mua_90,pop_psth_dom(num_pop_psth).mu2plot, ...
        pop_psth_dom(num_pop_psth).units_typ, binWidth,tim_trl_dur, calc_typ, sav_dir_popPSTH, sav_fig, ...
        pop_psth_dom(num_pop_psth).sav_nam);
    close all;
end

%% WORK ON Rivalry Switches

    case 'Switches'
%% Load the data and check for region of interest

if strcmp(roi,'PFC')    
    cd(ds_info.jMUspikesPath.PFC);
    array_idx = 1;
    load('jMUSwitchesByTime');
elseif strcmp(roi,'PPC')   
    cd(ds_info.jMUspikesPath.PPC);
    array_idx = 2;
    load('jMUSwitchesByTime');    
end

%% Generate the appropriate folder structure for saving the results

generate_folder_structure('Bfsgrad','MUA','PSTH',ds_info,roi);

%% Main Results Directory

res_dir = strcat('B:\Results\',ds_info.monk,'\',ds_info.dataset,'\Bfsgrad\',ds_info.activeArray{array_idx},'\MUA\');
ttl_suffix = strcat('-',ds_info.monk,'-',ds_info.activeArray{array_idx},'-', ds_info.dataset);

%% Generate PSTHs - Switch Related

tim_window_Switch = [-1.5 1.5];
sigma = 0.040;
sav_dir_PsthSwitch = strcat(res_dir,'PSTH_Sites\PSTH_Switches');
sav_fig = saveOrNot(an_info.sdf_switch_fig);

[sdf_switch] = generate_psth_switches_chan(jMUSwitches, tim_window_Switch, sigma, sav_dir_PsthSwitch, sav_fig);

if an_info.sdf_switch_fil == 0
    cd(sav_dir_PsthSwitch);
    save('sdf_switch.mat', 'sdf_switch');
end

% [sdf] =  generate_psth_bfsgrad(jMUspikes, align_evt, sav_dir, sav_fig)

%% convert mua data for further analysis

muadata_90TO270 = jMUSwitches.data.spikesByTime_90TO270;
muadata_270TO90 = jMUSwitches.data.spikesByTime_270TO90;

%% Get spikesparse matrices for a given time window

binWidth = 50;
offset_switch = -1500;
tWin_switch = 1500;
[res_mua_90TO270] = spkByTime2spkSparse(muadata_90TO270,binWidth,offset_switch,tWin_switch);

offset_switch = -1500;
tWin_switch = 1500;
[res_mua_270TO90] = spkByTime2spkSparse(muadata_270TO90,binWidth,offset_switch,tWin_switch);

%% Check Preferences related to switch

sav_dir_SelArray = strcat(res_dir, 'Preference_Arrays\Switch');
[pref_array_switch] = get_pref_array_switch_bfsgrad(muadata_90TO270, muadata_270TO90, sav_dir_SelArray);

%% Generate SDF - Maps according to electrode's array location

sav_dir_SdfMap = strcat(res_dir, 'PSTH_Maps');
generate_sdf_map_switch_bfsgrad(sdf_switch, pref_array_switch, jMUSwitches, sav_dir, ttl_suffix)

% % % % % get the appropriate parameters necessary for plotting
% % % % 
% % % % tim_window = sdf_switch.t;
% % % % chan2elec = jMUSwitches.chanElecs.electrodeInfo;
% % % % elec_map = jMUSwitches.map;
% % % % sav_dir_SdfMap = strcat(res_dir, 'PSTH_Maps');
% % % % 
% % % % % physical alternation condition
% % % % 
% % % % sig_typ = 'Phy_Switch_MUA';
% % % % [dat,figProps] = generate_data4map(sig_typ, sdf_switch, ttl_suffix);
% % % % bold_sites{1} = pref_sim_switch_Phy_BsAs.pri_sig_u(:,3);
% % % % bold_sites{2} = pref_sim_switch_Phy_BsAs.sec_sig_u(:,3);
% % % % 
% % % % boxed_sites{1} = pref_sim_switch_PhyRiv_BsBs.com_sig_u(:,3);
% % % % boxed_sites{2} = pref_sim_switch_PhyRiv_AsAs.com_sig_u(:,3);
% % % % boxed_sites{3} = pref_sim_switch_Phy_BsAs.com_sig_u(:,3);
% % % % 
% % % % sav_fig = saveOrNot(an_info.sdfMap_PA);
% % % % generate_dat_map(dat, tim_window, chan2elec, elec_map, bold_sites, boxed_sites, figProps, sav_dir_SdfMap, sav_fig)
% % % % bold_sites = []; boxed_sites = [];
% % % % 
% % % % % rivalry condition
% % % % 
% % % % sig_typ = 'Riv_Switch_MUA';
% % % % [dat,figProps] = generate_data4map(sig_typ, sdf_switch, ttl_suffix);
% % % % bold_sites{1} = pref_sim_switch_Riv_BsAs.pri_sig_u(:,3);
% % % % bold_sites{2} = pref_sim_switch_Riv_BsAs.sec_sig_u(:,3);
% % % % 
% % % % boxed_sites{1} = pref_sim_switch_PhyRiv_BsBs.com_sig_u(:,3);
% % % % boxed_sites{2} = pref_sim_switch_PhyRiv_AsAs.com_sig_u(:,3);
% % % % boxed_sites{3} = pref_sim_switch_Riv_BsAs.com_sig_u(:,3);
% % % % 
% % % % sav_fig = saveOrNot(an_info.sdfMap_PA);
% % % % generate_dat_map(dat, tim_window, chan2elec, elec_map, bold_sites, boxed_sites, figProps, sav_dir_SdfMap, sav_fig)
% % % % bold_sites = []; boxed_sites = [];


%% Make Preference Maps

% for the physical alternation switches - before switch

p_thres_array = [0.05:0.1:0.95];
pref_array_cond = pref_array_switch.bs_pref_array_Phy;
ttl_pref_map = strcat('PA - Before Switch - Preference Map',ttl_suffix);

sav_fig = saveOrNot(an_info.prefMap_PASwitches);
sav_dir_PrefMap = strcat(res_dir, 'Preference_Maps');
get_pref_map_thres(pref_array_cond, chan2elec,elec_map,p_thres_array,ttl_pref_map,sav_dir_PrefMap,sav_fig)
pref_array_cond =[]; ttl_pref_map = [];

% for the physical alternation switches - after switch

p_thres_array = [0.05:0.1:0.95];
pref_array_cond = pref_array_switch.as_pref_array_Phy;
ttl_pref_map = strcat('PA - After Switch - Preference Map',ttl_suffix);

sav_fig = saveOrNot(an_info.prefMap_PASwitches);
sav_dir_PrefMap = strcat(res_dir, 'Preference_Maps');
get_pref_map_thres(pref_array_cond, chan2elec,elec_map,p_thres_array,ttl_pref_map,sav_dir_PrefMap,sav_fig)
pref_array_cond =[]; ttl_pref_map = [];

% for rivalry switches - before switch

p_thres_array = [0.05:0.1:0.95];
pref_array_cond = pref_array_switch.bs_pref_array_Riv;
ttl_pref_map = strcat('Rivalry - Before Switch - Preference Map',ttl_suffix);

sav_fig = saveOrNot(an_info.prefMap_RivSwitches);
sav_dir_PrefMap = strcat(res_dir, 'Preference_Maps');
get_pref_map_thres(pref_array_cond, chan2elec,elec_map,p_thres_array,ttl_pref_map,sav_dir_PrefMap,sav_fig)
pref_array_cond =[]; ttl_pref_map = [];

% for rivalry switches - after switch

p_thres_array = [0.05:0.1:0.95];
pref_array_cond = pref_array_switch.as_pref_array_Riv;
ttl_pref_map = strcat('Rivalry - After Switch - Preference Map',ttl_suffix);

sav_fig = saveOrNot(an_info.prefMap_RivSwitches);
sav_dir_PrefMap = strcat(res_dir, 'Preference_Maps');
get_pref_map_thres(pref_array_cond, chan2elec,elec_map,p_thres_array,ttl_pref_map,sav_dir_PrefMap,sav_fig)
pref_array_cond =[]; ttl_pref_map = [];


%% Generate Population PSTHs

trl_dur = abs(offset_switch)+tWin_switch;
% tim_trl_dur = [(offset_switch+binWidth):binWidth:tWin_switch];
tim_trl_dur = [(offset_switch)+binWidth/2:binWidth:(tWin_switch)-(binWidth)/2];

calc_typ = 'Switches_First';
sav_dir_popPSTH = strcat(res_dir, 'PSTH_Population\PSTH_Switches\',calc_typ);
pop_psth_typ = 'Switch_MUA';
[pop_psth_switch] = get_pop_psth_input(pop_psth_typ, pref_array_switch, ttl_suffix);

for num_pop_psth = 1:length(pop_psth_switch)
    
    [pop_psth_phy_riv_switch(num_pop_psth)] = generate_population_mu_psth_switch(res_mua_90TO270,res_mua_270TO90,pop_psth_switch(num_pop_psth).mu2plot, ...
        pop_psth_switch(num_pop_psth).units_typ, binWidth,tim_trl_dur, calc_typ, sav_dir_popPSTH, sav_fig, ...
        pop_psth_switch(num_pop_psth).sav_nam);
%     close all;
end

calc_typ = 'Sites_First';
sav_dir_popPSTH = strcat(res_dir, 'PSTH_Population\PSTH_Switches\',calc_typ);
pop_psth_typ = 'Switch_MUA';
[pop_psth_switch] = get_pop_psth_input(pop_psth_typ, pref_array_switch, ttl_suffix);

for num_pop_psth = 1:length(pop_psth_switch)
    
    generate_population_mu_psth_switch(res_mua_90TO270,res_mua_270TO90,pop_psth_switch(num_pop_psth).mu2plot, ...
        pop_psth_switch(num_pop_psth).units_typ, binWidth,tim_trl_dur, calc_typ, sav_dir_popPSTH, sav_fig, ...
        pop_psth_switch(num_pop_psth).sav_nam);
    close all;
end

%% FS and rivalry - same preference



%% PA, FS and before switch - same preference


%% Make the movies for the PSTH data

sav_dir_SwitchMovie = strcat(res_dir, 'PSTH_Movies');

% define variables for physical switches

sig_typ = 'PSTH_Switches';
sig_subtyp = 'Phy';
dataIn = sdf_switch;
norm_method = 'max_min';
sig_sites = pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(:,3);
tim_window = [-1.4 1.4];
chan2elec = jMUSwitches.chanElecs.electrodeInfo;
elec_map = jMUSwitches.map;

% generate movie data
[movDat] = generate_movie_data_bfsgrad(sig_typ, sig_subtyp, dataIn, norm_method, sig_sites, tim_window,chan2elec,elec_map);

% make the movie

make_movie_map(movDat,sav_dir_SwitchMovie)

% define variables for rivalry switches

sig_typ = 'PSTH_Switches';
sig_subtyp = 'Riv';
dataIn = sdf_switch;
norm_method = 'max_min';
sig_sites = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,3);
tim_window = [-1.4 1.4];
chan2elec = jMUSwitches.chanElecs.electrodeInfo;
elec_map = jMUSwitches.map;

% generate movie data
[movDat] = generate_movie_data_bfsgrad(sig_typ, sig_subtyp, dataIn, norm_method, sig_sites, tim_window,chan2elec,elec_map);

% make the movie

make_movie_map(movDat,sav_dir_SwitchMovie)


    case 'Dominance'
        
        
        
        
        
end



















