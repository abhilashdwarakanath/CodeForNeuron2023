function generate_sdf_map_bfsgrad(sdf_moa, pref_array, jMUspikes, sav_dir, ttl_suffix, sav_fig)

%% This code generates SDF - Maps according to electrode's array location for bfsgrad
% 
% Input: 
% 
% 1. sdf_moa: the sdf data with psths
% 2. pref_array: preference arrays
% 3. jMUspikes: data structure with spikes
% 4. sav_dir: saving directory
% 5. ttl_suffix: title for the sdf maps
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/06/15


%% get the appropriate parameters necessary for plotting

tim_window = sdf_moa.t;
chan2elec = jMUspikes.chanElecs.electrodeInfo;
elec_map = jMUspikes.map;

%% physical alternation condition

sig_typ = 'PA_MUA';
[dat,figProps] = generate_data4map(sig_typ, sdf_moa, ttl_suffix);
bold_sites = pref_array.pref_sim.pri_sig_u(:,3);
boxed_sites = pref_array.pref_sim.com_sig_u(:,3);

% sav_fig = saveOrNot(an_info.sdfMap_PA);
generate_dat_map(dat, tim_window, chan2elec, elec_map, bold_sites, boxed_sites, figProps, sav_dir, sav_fig)
bold_sites = []; boxed_sites = [];

%% flash suppression condition

sig_typ = 'FS_MUA';
[dat,figProps] = generate_data4map(sig_typ, sdf_moa, ttl_suffix);
bold_sites = pref_array.pref_sim.sec_sig_u(:,3);
boxed_sites = pref_array.pref_sim.com_sig_u(:,3);

% sav_fig = saveOrNot(an_info.sdfMap_PA);
generate_dat_map(dat, tim_window, chan2elec, elec_map, bold_sites, boxed_sites, figProps, sav_dir, sav_fig)
bold_sites = []; boxed_sites = [];