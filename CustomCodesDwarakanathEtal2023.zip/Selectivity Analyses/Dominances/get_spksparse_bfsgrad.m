function [res_mua,muadata] = get_spksparse_bfsgrad(jMUspikes,align_evt,binWidth)

%% This code gets the spikesparse matrices for a given time window for datasets of bfsgrad.
% 
% Input: 
% 
% 1. jMUspikes: the data structure with spikes
% 2. align_evt: aligning event - SOA|MOA
% 3. binWidth: bin width
% 
% Output: 
% res_mua
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/06/15



switch align_evt
    
    case 'SOA'
        
        [muadata] = convMuaFormat(jMUspikes.data,align_evt);

        % parameters for stimulus onset aligned data
        
        offset_stimon = -300;
        tWin_soa = 4000;

        % get spksparse matrices

        [res_mua] = spkByTime2spkSparse(muadata,binWidth,offset_stimon,tWin_soa);
        
        
    case 'MOA'
        
        [muadata] = convMuaFormat(jMUspikes.data,align_evt);

        % parameters for mask onset aligned data
        
        offset_maskon = -2300;
        tWin_moa = 2000;

        % get spksparse matrices

        [res_mua] = spkByTime2spkSparse(muadata,binWidth,offset_maskon,tWin_moa);
        
end