function make_folder(fol_name,cd_in)

% This code takes input as folder name(fol_name), and the logical cd_in
% (decision to move inside the created directory or not).
% Helper function for generate_folder_structure.
% 
% % Usage: make_folder(fol_name,cd_in)
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/4/12
% 



% Get a list of all files and folders in this folder.
files = dir;

% Get a logical vector that tells which is a directory.
dirFlags = [files.isdir];

% Extract only those that are directories.
subFolders = files(dirFlags);
subFolders(1:2) = [];

% Check if the given directory already exists.
if ~isempty(subFolders)    
    for k = 1 : length(subFolders)
        fol_exist(k) = strcmp(fol_name,subFolders(k).name);
    end
else
    fol_exist = 0;
end

% Take appropriate action
if ~sum(fol_exist)>0
    mkdir(fol_name);
end

if (cd_in==1)
    cd(fol_name);
end
    