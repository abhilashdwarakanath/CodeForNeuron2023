function [cond,cond_title] = get_conditions_bfsgrad(conditions_wanted,total_conditions)

%% The script Gets the conditions of bfsgrad for running any script.

% Usage: get_conditions_bfsgrad 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2016/10/19

%  It compares with the
% available conditions and then sends out indices for extraction of data.



        cond_id = zeros(1, total_conditions);
        
        conditions_existing = strvcat('BR_R90_L270','BR_R270_L90','BR_L90_R270','BR_L270_R90','PA_R90_L270','PA_R270_L90','PA_L90_R270','PA_L270_R90');
        
        for i = 1:length(conditions_wanted)
            
            temp_cond(i) =  strmatch(conditions_wanted(i),conditions_existing);
            cond_id(temp_cond(i)) = temp_cond(i);
            
        end
        
%         cond = find(cond_id);
        
        cond = temp_cond;
        cond_title = conditions_existing(cond,:);