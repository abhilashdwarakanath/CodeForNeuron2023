function generate_pref_map_bfsgrad(pref_array, jMUspikes, sav_dir, ttl_suffix,cond, sav_fig)

%% This code generates Preference Maps according to electrode's array location for bfsgrad
% 
% Input: 
% 
% 1. pref_array: preference arrays
% 2. jMUspikes: data structure with spikes
% 3. sav_dir: saving directory
% 4. ttl_suffix: title for the sdf maps
% 5. cond: condition
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/06/15


%% assign parameters

chan2elec = jMUspikes.chanElecs.electrodeInfo;
elec_map = jMUspikes.map;
p_thres_array = [0.05:0.1:0.95];

switch cond
    
    case 'PA'
        
        %% for the physical alternation condition
        
        pref_array_cond = pref_array.pa;
        ttl_pref_map = strcat('Physical Alternation - Preference Map',ttl_suffix);
        % sav_fig = saveOrNot(an_info.prefMap_PA);
        sav_fig = 1;
        get_pref_map_thres(pref_array_cond, chan2elec,elec_map,p_thres_array,ttl_pref_map,sav_dir,sav_fig)
        
    case 'FS'
        
        %% for the flash suppression condition
        
        pref_array_cond = pref_array.fs;
        ttl_pref_map = strcat('Flash Suppression - Preference Map',ttl_suffix);
        % sav_fig = saveOrNot(an_info.prefMap_FS);
        sav_fig = 1;
        get_pref_map_thres(pref_array_cond, chan2elec,elec_map,p_thres_array,ttl_pref_map,sav_dir,sav_fig)
        
    case 'Phy_Dom'
        
        %% for the physical alternation condition
        
        pref_array_cond = pref_array.dom_pref_array_Phy;
        ttl_pref_map = strcat('Physical Alternation - Dominance - Preference Map',ttl_suffix);
        % sav_fig = saveOrNot(an_info.prefMap_PA);
        sav_fig = 1;
        get_pref_map_thres(pref_array_cond, chan2elec,elec_map,p_thres_array,ttl_pref_map,sav_dir,sav_fig)
        
    case 'Riv_Dom'
        
        %% for the rivalry condition
        
        pref_array_cond = pref_array.dom_pref_array_Riv;
        ttl_pref_map = strcat('Rivalry - Dominance - Preference Map',ttl_suffix);
        % sav_fig = saveOrNot(an_info.prefMap_PA);
        sav_fig = 1;
        get_pref_map_thres(pref_array_cond, chan2elec,elec_map,p_thres_array,ttl_pref_map,sav_dir,sav_fig)
        
end