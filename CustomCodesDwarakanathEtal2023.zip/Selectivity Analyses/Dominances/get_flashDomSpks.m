function [spk_dom90, spk_dom270] = get_flashDomSpks(jMUDominances, domWin)

%% This code puts gets the spiking activity based upon the dominance duration window.
% 
% Input: 
% 
% 1. jMUDominances: the typical data structure
% 2. domWin: dominance window, typically [1000 8000]
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/6/29

%% get the idx and duration of valid dominances according to parameters

domDur = jMUDominances.data.domDur;

min_domDur = domWin(1);
max_domDur = domWin(2);

[valid_domIdx, valid_domDur] = get_flashdom_idx(domDur,min_domDur,max_domDur);

%% get only the data with valid dominance periods

domData.dom90 = jMUDominances.data.flashDomMOA;
domData.dom270 = jMUDominances.data.flashDomMOA;

[spk_dom90, spk_dom270] = get_spk_dom(domData,valid_domIdx);

% num_dom90 = sum(cellfun(@length,valid_domDur.dom90(:,1:4)));
% num_dom270 = sum(cellfun(@length,valid_domDur.dom270(:,1:4)));
% bar([num_dom90 num_dom270])