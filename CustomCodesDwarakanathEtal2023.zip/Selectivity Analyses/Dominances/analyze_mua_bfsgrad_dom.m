function analyze_mua_bfsgrad_dom(ds_info, roi)


%% This code carries out all the basic MUA analysis for the bfsgrad paradigm for ONE dataset during the Dominance phase.
% 
% Input: 
% 
% 1. ds_info: A file containing the appropriate directory and dataset
%   information.
% 
% 2. roi: region of interest - PFC or PPC.
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/08/09
% 

%% WORK ON Dominances

trl_phase = 'Dominance';

%% Load the data and check for region of interest       

if strcmp(roi,'PFC')    
    cd(ds_info.jMUspikesPath.PFC);
    array_idx = 1;
    load('jMUDominancesByTime');
elseif strcmp(roi,'PPC')   
    cd(ds_info.jMUspikesPath.PPC);
    array_idx = 2;
    load('jMUDominancesByTime');    
end

%% Set temporal parameters and get appropriate dominances and spikes

min_domDur = 1000; max_domDur = 8000;
domWin = [min_domDur max_domDur];
domDur = jMUDominances.data.domDur;

[valid_domIdx, valid_domDur] = get_dom_idx(domDur,min_domDur,max_domDur);

[spk_dom90, spk_dom270] = get_DomSpks(jMUDominances, domWin);

%% Main Results Directory

res_dir = strcat('E:\Data\Results\',ds_info.monk,'\',ds_info.dataset,'\Bfsgrad\',ds_info.activeArray{array_idx},'\MUA\');
ttl_suffix = strcat('-',ds_info.monk,'-',ds_info.activeArray{array_idx},'-', ds_info.dataset);


%% convert mua data for further analysis

muadata_90 = spk_dom90;
muadata_270 = spk_dom270;

%% Get spikesparse matrices for a given time window

binWidth = 50; offset_dom = -1000; tWin_dom = 1000;
[res_mua_90] = spkByTime2spkSparse(spk_dom90,binWidth,offset_dom,tWin_dom);
[res_mua_270] = spkByTime2spkSparse(spk_dom270,binWidth,offset_dom,tWin_dom);

%% Generate the appropriate folder structure for saving the results

generate_folder_structure('Bfsgrad','MUA','Selectivity',ds_info,roi);

%% Check Preferences related to switch

sav_dir_SelArray = strcat(res_dir, 'Preference_Arrays\Dominance');
[pref_array_dom] = get_pref_array_dom_bfsgrad(spk_dom270, spk_dom90, min_domDur, sav_dir_SelArray);
cd(sav_dir_SelArray)
save('pref_array_dom.mat','pref_array_dom');






