function [movDat] = generate_movie_data_bfsgrad(sig_typ, sig_subtyp, dataIn, norm_method, sig_sites, tim_window,chan2elec,elec_map)

% This code generates data required for making a movie of the data in the map format.
% It takes input as the sig_typ(PSTH_Switches,LFP, etc), dataIn(the data itself),
% norm_method(the normalzation procedure - max_min or zscore),
% sig_sites(significant sites), tim_window(time window of interest).
% Also see generate_dat_map
% % Usage: generate_movie_data_bfsgrad(sig_typ, dataIn, norm_method, sig_sites, tim_window)
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/5/26
% 


%% Define structure

movDat = struct;

%% Prepare data for making a movie for different signal types

switch sig_typ
    
    
    %% Data for PSTH Switches
    
    case 'PSTH_Switches'
        
        
        %         get the time window for the movie data
        
        t_idx = find(dataIn.t(:)>tim_window(1)&dataIn.t(:)<tim_window(end));
        movDat.t_mov = dataIn.t(t_idx(1):t_idx(end));
        
        %         make the appropriate matrix for storing data
        
        movDat.dat = zeros(4,10,10,length(t_idx));
        
        
        %         get data for every channel
        
        for chan = 1:length(dataIn.chan)
            
            elec = chan2elec(chan,2);
            [r(chan),c(chan)] = find(elec_map == elec);
            
            %             get the data for physical and rivalry case
            if strcmp(sig_subtyp,'Phy')
                if (~isempty(dataIn.chan(chan).pa_90to270))
                    tmp_sdf_270TO90 = dataIn.chan(chan).pa_270to90(t_idx(1):t_idx(end));
                    tmp_sdf_90TO270 = dataIn.chan(chan).pa_90to270(t_idx(1):t_idx(end));
                end
            elseif strcmp(sig_subtyp,'Riv')
                if (~isempty(dataIn.chan(chan).fs_90to270))
                    tmp_sdf_270TO90 = dataIn.chan(chan).fs_270to90(t_idx(1):t_idx(end));
                    tmp_sdf_90TO270 = dataIn.chan(chan).fs_90to270(t_idx(1):t_idx(end));
                end
            end
            
            %                 Normalize the PSTH data
            
            switch norm_method
                
                
                %                     Subtract the minimum and divide by the range
                case 'max_min'
                    
                    movDat.dat(1,r(chan),c(chan),:) = (tmp_sdf_90TO270-min(tmp_sdf_90TO270))/(max(tmp_sdf_90TO270)-min(tmp_sdf_90TO270));
                    movDat.dat(2,r(chan),c(chan),:) = (tmp_sdf_270TO90-min(tmp_sdf_270TO90))/(max(tmp_sdf_270TO90)-min(tmp_sdf_270TO90));
                    
                    if find(sig_sites(:) == chan)
                        
                        movDat.dat(3,r(chan),c(chan),:) = (tmp_sdf_90TO270-min(tmp_sdf_90TO270))/(max(tmp_sdf_90TO270)-min(tmp_sdf_90TO270));
                        movDat.dat(4,r(chan),c(chan),:) = (tmp_sdf_270TO90-min(tmp_sdf_270TO90))/(max(tmp_sdf_270TO90)-min(tmp_sdf_270TO90));
                        
                    end
                    
                    %                     convert to z scores
                case 'zscore'
                    
                    movDat.dat(1,r(chan),c(chan),:) = zscore(tmp_sdf_90TO270);
                    movDat.dat(2,r(chan),c(chan),:) = zscore(tmp_sdf_270TO90);
                    
                    if find(sig_mu(:) == chan)
                        
                        movDat.dat(3,(chan),c(chan),:) = (tmp_sdf_90TO270-min(tmp_sdf_90TO270))/(max(tmp_sdf_90TO270)-min(tmp_sdf_90TO270));
                        movDat.dat(4,(chan),c(chan),:) = (tmp_sdf_270TO90-min(tmp_sdf_270TO90))/(max(tmp_sdf_270TO90)-min(tmp_sdf_270TO90));
                        
                    end
            end
        end
        
        %         define the labels
        if strcmp(sig_subtyp,'Phy')
            movDat.labels = {'90 to 270 - All Channels - Physical'; '270 to 90 - All Channels - Physical'; ...
                '90 to 270 - Sig. Channels - Physical'; '270 to 90 - Sig. Channels - Physical'};
            movDat.name = 'switches_physical.avi';
        elseif strcmp(sig_subtyp,'Riv')
            movDat.labels = {'90 to 270 - All Channels - Rivalry'; '270 to 90 - All Channels - Rivalry'; ...
                '90 to 270 - Sig. Channels - Rivalry'; '270 to 90 - Sig. Channels - Rivalry'};
            movDat.name = 'switches_rivalry.avi';
        end
        
    case 'PSTH_Switches_Pref_NonPref'
        
        
        
        
        
        
    case 'LFP_Switches_Pref'
        
        
        
end



