function makefig_scatter_dprime(pref_sim, pa_dprime, fs_dprime, sav_dir, sav_fig)


%% A script to make a scatter plot for d primes of the units.
% Usage: makefig_scatter_dprime(pref_sim, pa_dprime, fs_dprime)
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2016/11/3


pa_comU_dprime = pa_dprime(pref_sim.com_sig_u(:,3));
fs_comU_dprime = fs_dprime(pref_sim.com_sig_u(:,3));

figure;
s = 40;
scatter(pa_comU_dprime,fs_comU_dprime,s,'MarkerEdgeColor','k', 'MarkerFaceColor',[0.5 0.5 0.5]);
xlim([0 4]);ylim([0 4]);
set(gca, 'XTick',[0:4],'XTickLabel',[0:4],'YTick',[0:4],'YTickLabel',[0:4])
lsline;
xlabel('d-Prime - sensory selectivity');
ylabel('d-Prime - perceptual selectivity');
title('d-Primes - Sites with significant preference to the same stimulus across conditions')

   
if sav_fig ==1
    
    cd(sav_dir)    
    saveas(gcf,'Scatter - D_Prime','ai')
    saveas(gcf,'Scatter - D_Prime','fig')
    exportfig(gcf,'Scatter - D_Prime','Format','jpeg')
    exportfig(gcf,'Scatter - D_Prime','Format','eps','Color','cmyk')    

end