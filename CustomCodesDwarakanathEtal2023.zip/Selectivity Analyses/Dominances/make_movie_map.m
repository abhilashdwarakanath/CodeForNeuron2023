function make_movie_map(movDat,sav_dir)


%%%%% incomplete file %%%%% 

%% Open a file in the specified directory.
cd(sav_dir);
v = VideoWriter(movDat.name);
open(v);

%% Prepare the figure for getting movie frames. 
figure(2);
% h_tim = uicontrol('Style','slider','Position', [50 10 500 20], 'Min', 1, 'Max',length(t_mov),'Value',1);
colormap('gray');

for i = 1:length(movDat.t_mov)
    subplot(2,2,1)
    imagesc(squeeze(movDat.dat(1,:,:,i)));
    title(movDat.labels{1})
    subplot(2,2,2)
    imagesc(squeeze(movDat.dat(2,:,:,i)));
    title(movDat.labels{1})
    subplot(2,2,3)
    imagesc(squeeze(movDat.dat(3,:,:,i)));
    title(movDat.labels{3})
    subplot(2,2,4)
    imagesc(squeeze(movDat.dat(4,:,:,i)));
    title(movDat.labels{4})
    suplabel(num2str(t_mov(i)),'t');
    %     h_tim.Value = i;
    fig = gcf;
    f(i) = getframe(fig);
    writeVideo(v,f(i));
end

close(v);



for i = 1:length(t_mov)
    
    for k = 1:size(movDat,1)
    
        subplot2((size(movDat,1)/2),2,k)
        imagesc(Nmovdat_90TO270(k,:,:,i));
        title(mov_name{k,:})
        
    end
    
    fig = gcf;
    f(i) = getframe(fig);
    writeVideo(v,f(i));
    
end

close(v);





t_mov = sdf_switch.t(find(sdf_switch.t(:)>tim_window(1)&sdf_switch.t(:)<tim_window(end)));

open(v);
figure(23);

for i = 1:length(movDat_mov)
    subplot(2,2,1)
    imagesc(squeeze(movDat(1,:,:,i)));
    title('90 to 270 - All Channels')
    subplot(2,2,2)
    imagesc(squeeze(movDat(2,:,:,i)));
    title('270 to 90 - All Channels')
    subplot(2,2,3)
    imagesc(squeeze(movDat(3,:,:,i)));
    title('90 to 270 - Sig. Channels')
    subplot(2,2,4)
    imagesc(squeeze(movDat(4,:,:,i)));
    title('270 to 90 - Sig. Channels')
    suplabel(num2str(t_mov(i)),'t');
    %     h_tim.Value = i;
    fig = gcf;
    f(i) = getframe(fig);
    writeVideo(v,f(i));
end


close(v);
