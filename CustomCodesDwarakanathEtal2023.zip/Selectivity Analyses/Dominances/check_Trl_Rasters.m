function check_Trl_Rasters



%% get the clean trials

for iCond = 1:length(jMUDominances.data.cleanTrials)
          
        trl_idx{iCond} = find(cell2mat(jMUDominances.data.cleanTrials{iCond}));        

end


%% Assign plausible good candidate channels based upon visual inspection of SDF Maps

% chan2chk = [14 21 58 32 62 88 93 94];
chan2chk = [14 21];

%% Get the OKN trace and the spiking rasters

cd('B:\Results\H07\12-06-2016\Bfsgrad\PFC\MUA\Test_SingleTrial');
ppt_nam = ('SingleTrial_MUA.ppt');
saveppt2(ppt_nam,'f',0,'t','SingleTrial_MUA');

% create a low pass filter

[b,a]= butter(3,20/500,'low');

for iCond = 1:length(jMUspikes.data{1}.okn.trace)
    
    iCond = 4;
    
    for iTrl = 1:length(trl_idx{iCond})
        
        iTrl = 8;
        
        
        
        figure(13)
        set(gcf,'units','normalized','outerposition',[0.5 0 0.5 0.5])
 
%         set(gcf,'units','normalized','outerposition',[0 0 0.5 1])
        evtTim = [jMUspikes.data{1}.eventTimes{iCond}{trl_idx{iCond}(iTrl)}*1000];

        oknTrace = jMUspikes.data{1}.okn.trace{iCond}{trl_idx{iCond}(iTrl)};
        filtOknTrace = filtfilt(b,a,oknTrace);
        
%         subplot(length(chan2chk)+2,1,[1 2]);
%         plot(oknTrace,'g','LineWidth',1.5);
%         vline(evtTim);
%         xlim([0 length(oknTrace)]);

        subplot(length(chan2chk)+2,1,[1 2]);
        plot(filtOknTrace,'g','LineWidth',1.5); 
        ylim([-0.000005 0.000015]);
        w = evtTim(:,[2 3]);
        vline(w,{'k','k'},{'Stimulation Start','Flash Suppression'});
        xlim([0 length(oknTrace)]);
        
        for iChan = 1:length(chan2chk)            
                        
            spkTrn(1).spiketime = jMUspikes.data{chan2chk(iChan)}.spikesUnaligned{iCond}{trl_idx{iCond}(iTrl)};
            subplot(length(chan2chk)+2,1,2+iChan);
            spk_rasterplot_bfsgrad(spkTrn,'k',[evtTim(1) evtTim(end)])
            vline(evtTim);
            xlim([0 length(oknTrace)]);
            title(strcat('channel number - ',num2str(chan2chk(iChan))));
            spkTrn(1).spiketime = [];
        end
        a = figure(13);
        xlabel('Time(in milliseconds)')
        suplabel(strcat('Condition - ',num2str(iCond),'Trial Number - ', num2str(iTrl)),'t');
        pause
%     saveppt2(ppt_nam,'f',a,'title',strcat('Condition - ',num2str(iCond),'- Trial idx -', num2str(trl_idx{iCond}(iTrl))));
        close(figure(13))
    end
    
end

