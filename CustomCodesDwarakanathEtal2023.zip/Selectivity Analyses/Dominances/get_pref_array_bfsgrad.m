function [pref_array] = get_pref_array_bfsgrad(muadata_moa, sav_dir)

%% This code gets the preference array for a given time window for datasets of bfsgrad.
% 
% Input: 
% 
% 1. muadata_moa: the data structure with spikes
% 2. sav_dir: saving directory
% 
% Output: 
% pref_array
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/06/15


%% Create a structure for storing preference related data

pref_array = struct;
pref_array.description = {'p_val';'h_val';'pref_stim_270_1_90_2';'pref_conds';'chan_number'};

% Assign parameters

pref_array.tim_win = [0 1500]; % Time Window for analysis;
pref_array.tst_typ = ('spike count'); % Test type

% Conditions for Physical Alternation condition/Flash Suppression Condition

pref_array.cnd2cmp_pa = {'PA_R90_L270';'PA_L90_R270';'PA_R270_L90';'PA_L270_R90'};
pref_array.cnd2cmp_fs = {'BR_R90_L270';'BR_L90_R270';'BR_R270_L90';'BR_L270_R90'}; 

%% check PA condition

[pref_array.pa, pref_array.pa_dprime] = check_preference_mua(pref_array.tim_win, muadata_moa, pref_array.cnd2cmp_pa, pref_array.tst_typ);
pref_array.pa_table = array2table(pref_array.pa,'VariableNames',pref_array.description);

%% check FS condition

[pref_array.fs, pref_array.fs_dprime] = check_preference_mua(pref_array.tim_win, muadata_moa, pref_array.cnd2cmp_fs, pref_array.tst_typ);
pref_array.fs_table = array2table(pref_array.fs,'VariableNames',pref_array.description);

%% Check if the preference is maintained across conditions

% PA and FS - same preference

conds = {'Physical Alternation';'Flash Suppression'};

[pref_sim] = check_pref_sim(pref_array.pa,pref_array.fs,conds);
pref_array.pref_sim = pref_sim;

% if an_info.sdf_moa_fil == 0
    cd(sav_dir);
    save('pref_array.mat', 'pref_array');
% end
