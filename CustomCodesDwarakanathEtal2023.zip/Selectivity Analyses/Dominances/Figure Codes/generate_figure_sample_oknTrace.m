function generate_figure_sample_oknTrace



% take a physical alternation trial and filter it

oknTrace = jMUspikes.data{1}.okn.trace{7}{5};

[b,a]= butter(3,20/500,'low');
filtOknTrace = filtfilt(b,a,oknTrace);

% get the event times

evtTim = [jMUspikes.data{1}.eventTimes{7}{5}*1000];
w = evtTim(:,[2 3]);

% plot the OKN trace

figure
set(gcf,'units','normalized','outerposition',[0.5 0 0.5 0.25])
plot(filtOknTrace,'g','LineWidth',3)

xlim([0 4000]);
ylim([-200 600]);
vline(w,{'k','k'},{'Grating moving up','Grating moving down'});

xlabel('Time(in milliseconds)');
ylabel('a.u.');
grid on