% function generate_pop_psth_figure









offset_maskon = -2300;
tWin_moa = 2000;
trl_dur = abs(offset_maskon)+tWin_moa;
tim_trl_dur = [(offset_maskon+binWidth/2):binWidth:(tWin_moa-binWidth/2)];




figure
set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.
subplot(2,6,1)
plot(tim_trl_dur, pop_psth_pa_fs(1).pa_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_pa_fs(1).pa_p2np,'r','LineWidth',3);
xlim([-200 tWin_moa]); ylim([12 20]);
vline_vk(0);
axis square
xlabel('Time');
ylabel('Spikes/second');
title('Physical Alternation','FontSize',16);
% legend('Non Preferred to Preferred','Preferred to Non preferred');

% plot the psth in the fs condition

subplot(2,6,2)
plot(tim_trl_dur, pop_psth_pa_fs(1).fs_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_pa_fs(1).fs_p2np,'r','LineWidth',3);
xlim([-200 tWin_moa]); ylim([10 30]);
vline_vk(0);
axis square
xlabel('Time');
% ylabel('Spikes/second');
title('Flash Suppression','FontSize',16);
% legend('Non Preferred to Preferred','Preferred to Non preferred');

subplot(2,6,7)
plot(tim_trl_dur, pop_psth_pa_fs(3).pa_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_pa_fs(3).pa_p2np,'r','LineWidth',3);
xlim([-200 tWin_moa]); ylim([10 30]);
vline_vk(0);
axis square
xlabel('Time');
ylabel('Spikes/second');
title('Physical Alternation','FontSize',16);
% legend('Non Preferred to Preferred','Preferred to Non preferred');

% plot the psth in the fs condition

subplot(2,6,8)
plot(tim_trl_dur, pop_psth_pa_fs(3).fs_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_pa_fs(3).fs_p2np,'r','LineWidth',3);
xlim([-200 tWin_moa]); ylim([10 30]);
vline_vk(0);
axis square
xlabel('Time');
% ylabel('Spikes/second');
title('Flash Suppression','FontSize',16);
% legend('Non Preferred to Preferred','Preferred to Non preferred');





offset_dom = -300;
tWin_dom = 1000;
trl_dur = abs(offset_dom)+tWin_dom;
% tim_trl_dur = [(offset_switch+binWidth):binWidth:tWin_switch];

%%%%% Check how to do this properly!!! 
tim_trl_dur = [(offset_dom)+binWidth/2:binWidth:(tWin_dom)-(binWidth)/2];

subplot(2,6,3)
plot(tim_trl_dur, pop_psth_phy_riv_dom(1).pa_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_phy_riv_dom(1).pa_p2np,'r','LineWidth',3);
xlim([-200 tWin_dom]); ylim([10 25]);
vline_vk(0);
axis square
xlabel('Time');
% ylabel('Spikes/second');
title('Sensory Stimulation','FontSize',16);
% legend('Non Preferred to Preferred','Preferred to Non preferred');

% plot the psth in the fs condition

subplot(2,6,4)
plot(tim_trl_dur, pop_psth_phy_riv_dom(1).riv_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_phy_riv_dom(1).riv_p2np,'r','LineWidth',3);
xlim([-200 tWin_dom]); ylim([10 25]);
vline_vk(0);
axis square
xlabel('Time');
% ylabel('Spikes/second');
title('Perceptual Dominance','FontSize',16);
% legend('Non Preferred to Preferred','Preferred to Non preferred');

subplot(2,6,9)
plot(tim_trl_dur, pop_psth_phy_riv_dom(3).pa_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_phy_riv_dom(3).pa_p2np,'r','LineWidth',3);
xlim([-200 tWin_dom]); ylim([10 25]);
vline_vk(0);
axis square
xlabel('Time');
% ylabel('Spikes/second');
title('Sensory Stimulation','FontSize',16);
% legend('Non Preferred to Preferred','Preferred to Non preferred');

% plot the psth in the fs condition

subplot(2,6,10)
plot(tim_trl_dur, pop_psth_phy_riv_dom(3).riv_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_phy_riv_dom(3).riv_p2np,'r','LineWidth',3);
xlim([-200 tWin_dom]); ylim([10 25]);
vline_vk(0);
axis square
xlabel('Time');
% ylabel('Spikes/second');
title('Perceptual Dominance','FontSize',16);




binWidth = 50;
offset_switch = -1500;
tWin_switch = 1500;

tim_trl_dur = [(offset_switch)+binWidth/2:binWidth:(tWin_switch)-(binWidth)/2];

subplot(2,6,5)
plot(tim_trl_dur, pop_psth_phy_riv_switch(3).pa_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_phy_riv_switch(3).pa_p2np,'r','LineWidth',3);
xlim([offset_switch tWin_switch]); ylim([10 35]);
vline_vk(0);
axis square
xlabel('Time');
% ylabel('Spikes/second');
title('Sensory Switches','FontSize',16);
% legend('Non Preferred to Preferred','Preferred to Non preferred');

% plot the psth in the fs condition

subplot(2,6,6)
plot(tim_trl_dur, pop_psth_phy_riv_switch(3).riv_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_phy_riv_switch(3).riv_p2np,'r','LineWidth',3);
xlim([offset_switch tWin_switch]); ylim([10 35]);
vline_vk(0);
axis square
xlabel('Time');
% ylabel('Spikes/second');
title('Perceptual Switches','FontSize',16);
% legend('Non Preferred to Preferred','Preferred to Non preferred');

subplot(2,6,11)
plot(tim_trl_dur, pop_psth_phy_riv_switch(11).pa_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_phy_riv_switch(11).pa_p2np,'r','LineWidth',3);
xlim([offset_switch tWin_switch]); ylim([10 35]);
vline_vk(0);
axis square
xlabel('Time');
% ylabel('Spikes/second');
title('Sensory Switches','FontSize',16);
% legend('Non Preferred to Preferred','Preferred to Non preferred');

% plot the psth in the fs condition

subplot(2,6,12)
plot(tim_trl_dur, pop_psth_phy_riv_switch(11).riv_np2p,'b','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_phy_riv_switch(11).riv_p2np,'r','LineWidth',3);
xlim([offset_switch tWin_switch]); ylim([10 35]);
vline_vk(0);
axis square
xlabel('Time');
% ylabel('Spikes/second');
title('Perceptual Switches','FontSize',16);


saveas(gcf,strcat('Pop PSTH - site - ', num2str(chan)),'jpg')
saveas(gcf,strcat('Pop PSTH - site - ', num2str(chan)),'ai')
saveas(gcf,strcat('Pop PSTH - site - ', num2str(chan)),'fig')
close all




