% function generate_sdf_figure(ds_info, chan)






% cd('B:\H07\12-06-2016\PFC\Bfsgrad1\');
% load('jMUSpikesByTime');
% load('jMUDominancesByTime');
% load('jMUSwitchesByTime');

cd('B:\Results\H07\12-06-2016\Bfsgrad\PFC\MUA\PSTH_Sites\Selected_Sites');

spk_lim = [10 40];

sel_chans = [14 15 21 23 25 32 58 62 88 93 94];
for iChan = 1:length(sel_chans)
    
    chan = sel_chans(iChan);
tim_window = [-0.3 2.5];
t_lim = [-0.2 2];
sigma = 0.040;


% stimulus change - 90 to 27;0
cond_pa_90 = [jMUspikes.data{chan}.spikesMOAligned{5} jMUspikes.data{chan}.spikesMOAligned{7}];
cond_fs_90 = [jMUspikes.data{chan}.spikesMOAligned{1} jMUspikes.data{chan}.spikesMOAligned{3}];

% stimulus change - 270 to 90

cond_pa_270 = [jMUspikes.data{chan}.spikesMOAligned{6} jMUspikes.data{chan}.spikesMOAligned{8}];
cond_fs_270 = [jMUspikes.data{chan}.spikesMOAligned{2} jMUspikes.data{chan}.spikesMOAligned{4}];

x_Ticks = [-0.2 0 0.5 1 1.5 2];
x_TicksLabel = [-0.2 0 0.5 1 1.5 2];


%% Convert the spike timing data into chronux format and smooth with chronux

% stimulus change - 90 to 270
[SPKdata_pa_90] = spikesSOAligned2ChrSpk(cond_pa_90);
[SPKdata_fs_90] = spikesSOAligned2ChrSpk(cond_fs_90);
[sdf_pa_90, t, err_pa_90] = psth(SPKdata_pa_90, sigma, 'n', tim_window);
[sdf_fs_90, t, err_fs_90] = psth(SPKdata_fs_90, sigma, 'n', tim_window);

% stimulus change - 270 to 90
[SPKdata_pa_270] = spikesSOAligned2ChrSpk(cond_pa_270);
[SPKdata_fs_270] = spikesSOAligned2ChrSpk(cond_fs_270);
[sdf_pa_270, t, err_pa_270] = psth(SPKdata_pa_270, sigma, 'n', tim_window);
[sdf_fs_270, t, err_fs_270] = psth(SPKdata_fs_270, sigma, 'n', tim_window);


%% Make Figure and save it

figure('units','normalized','outerposition',[0 0 1 1])

subplot(3,6,1)
hold on;
%     errorbar(t,sdf_pa_90,err_pa_90,'k');
%     errorbar(t,sdf_fs_90,err_fs_90,'r');
%     errorbar(t,sdf_pa_270,err_pa_270,'b');
%     errorbar(t,sdf_fs_270,err_fs_270,'g');

plot(t,sdf_pa_90,'k','LineWidth',3)
plot(t,sdf_pa_270,'k:','LineWidth',3)

xlim(t_lim); ylim(spk_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
xlabel('Time (seconds)'); ylabel('Spikes/second');
title('Physical Alternation','FontSize',16);
axis square
%     this is opposite to the trace labels, because this is the second
%     stimulus.
% legend('Downward moving grating','Upward moving grating','Location','NorthEast')

subplot(3,6,7)
spk_rasterplot_bfsgrad(SPKdata_pa_90,'k',[tim_window(1) tim_window(end)]);
xlim(t_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
ylabel('Trials');
% xlabel('Time');
axis square
title('Downward moving grating','FontSize',13);

subplot(3,6,13)
spk_rasterplot_bfsgrad(SPKdata_pa_270,'k',[tim_window(1) tim_window(end)]);
xlim(t_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
ylabel('Trials');
xlabel('Time (seconds)');
axis square
title('Upward moving grating','FontSize',13);


subplot(3,6,2)
hold on;

plot(t,sdf_fs_90,'r','LineWidth',3)
plot(t,sdf_fs_270,'r:','LineWidth',3)

xlim(t_lim); ylim(spk_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
xlabel('Time (seconds)');%% ylabel('Spikes/second');
title('Flash Suppression','FontSize',16);
axis square
% legend('Downward moving grating','Upward moving grating','Location','NorthEast')

subplot(3,6,8)
spk_rasterplot_bfsgrad(SPKdata_fs_90,'r',[tim_window(1) tim_window(end)]);
xlim(t_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
ylabel('Trials');
% xlabel('Time');
axis square
title('Downward moving grating','FontSize',13);

subplot(3,6,14)
spk_rasterplot_bfsgrad(SPKdata_fs_270,'r',[tim_window(1) tim_window(end)]);
xlim(t_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
ylabel('Trials');
xlabel('Time (seconds)');
axis square
title('Upward moving grating','FontSize',13);


%% Get the most appropriate dominances for further analysis

% set temporal parameters

min_domDur = 1000;
max_domDur = 8000;

% get the idx and duration of valid dominances according to parameters

domDur = jMUDominances.data.domDur;
[valid_domIdx, valid_domDur] = get_dom_idx(domDur,min_domDur,max_domDur);

% get only the data with valid dominance periods
domData.dom90 = jMUDominances.data.dom90;
domData.dom270 = jMUDominances.data.dom270;

[spk_dom90, spk_dom270] = get_spk_dom(domData,valid_domIdx);


%% Generate PSTHs - Dominance Related

tim_window_Dominance = [-.5 min_domDur/1000+.5];
t_lim = [-0.2 1];
sigma = 0.040;


%% Go to the relevant directory for saving PSTHs

x_Ticks = cat(2,(-0.2),(0:0.5:t_lim(2)));
x_TicksLabel = cat(2,(-0.2),(0:0.5:t_lim(2)));

tim_window = tim_window_Dominance;

% stimulus - 90
dom_pa_90 = [spk_dom90{chan}{5}  spk_dom90{chan}{6}...
    spk_dom90{chan}{7}  spk_dom90{chan}{8}];

% stimulus - 270

dom_pa_270 = [spk_dom270{chan}{5}  spk_dom270{chan}{6}...
    spk_dom270{chan}{7}  spk_dom270{chan}{8}];

% percept - 90
dom_riv_90 = [spk_dom90{chan}{1}  spk_dom90{chan}{2}...
    spk_dom90{chan}{3}  spk_dom90{chan}{4}];

% percept - 270

dom_riv_270 = [spk_dom270{chan}{1}  spk_dom270{chan}{2}...
    spk_dom270{chan}{3}  spk_dom270{chan}{4}];

%% Convert the spike timing data into chronux format and smooth with chronux

% dominant stimulus - 90
[SPKdata_pa_90] = spikesSOAligned2ChrSpk(dom_pa_90);
[sdf_pa_90, t, err_pa_90] = psth(SPKdata_pa_90, sigma, 'n', tim_window);
[SPKdata_riv_90] = spikesSOAligned2ChrSpk(dom_riv_90);
[sdf_riv_90, t, err_riv_90] = psth(SPKdata_riv_90, sigma, 'n', tim_window);

% dominant stimulus - 270
[SPKdata_pa_270] = spikesSOAligned2ChrSpk(dom_pa_270);
[sdf_pa_270, t, err_pa_270] = psth(SPKdata_pa_270, sigma, 'n', tim_window);
[SPKdata_riv_270] = spikesSOAligned2ChrSpk(dom_riv_270);
[sdf_riv_270, t, err_riv_270] = psth(SPKdata_riv_270, sigma, 'n', tim_window);
   
%% Plot the required PSTH

subplot(3,6,3)
hold on;

%     errorbar(t,sdf_pa_90,err_pa_90,'k');
%     errorbar(t,sdf_riv_90,err_riv_90,'r');
%     errorbar(t,sdf_pa_270,err_pa_270,'b');
%     errorbar(t,sdf_riv_270,err_riv_270,'g');

plot(t,sdf_pa_270,'k','LineWidth',3)
plot(t,sdf_pa_90,'k:','LineWidth',3)
xlim(t_lim);ylim(spk_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
xlabel('Time (seconds)');% ylabel('Spikes/second');

title('Sensory Stimulation','FontSize',16);
axis square
% legend('Downward moving grating','Upward moving grating','Location','NorthEast')

subplot(3,6,9)
spk_rasterplot_bfsgrad(SPKdata_pa_270,'k',[tim_window(1) tim_window(end)]);
xlim(t_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
ylabel('Trials');
% xlabel('Time');
axis square
title('Downward moving grating','FontSize',13);

subplot(3,6,15)
spk_rasterplot_bfsgrad(SPKdata_pa_90,'k',[tim_window(1) tim_window(end)]);
xlim(t_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk([0]);
ylabel('Trials');
xlabel('Time (seconds)');
axis square
title('Upward moving grating','FontSize',13);
            
            
subplot(3,6,4)
hold on;
plot(t,sdf_riv_270,'r','LineWidth',3)
plot(t,sdf_riv_90,'r:','LineWidth',3)

xlim(t_lim);ylim(spk_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
xlabel('Time (seconds)');% ylabel('Spikes/second');
title('Perceptual Dominance','FontSize',16);
axis square
% legend('Downward moving grating','Upward moving grating','Location','NorthEast')

subplot(3,6,10)
spk_rasterplot_bfsgrad(SPKdata_riv_270,'r',[tim_window(1) tim_window(end)]);
xlim(t_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
ylabel('Trials');
% xlabel('Time');
axis square
title('Downward moving grating','FontSize',13);

subplot(3,6,16)
spk_rasterplot_bfsgrad(SPKdata_riv_90,'r',[tim_window(1) tim_window(end)]);
xlim(t_lim);
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk(0);
ylabel('Trials');
xlabel('Time (seconds)');
axis square
title('Upward moving grating','FontSize',13);


%% Plot the switches

tim_window_Switch = [-1.5 1.5];
t_lim = [-1 1];
sigma = 0.040;

x_Ticks = [-1 -0.5 0 0.5 1];
x_TicksLabel = [-1 -0.5 0 0.5 1];

    
tim_window = tim_window_Switch;

% stimulus change - 90 to 270
switch_pa_90to270 = [jMUSwitches.data.spikesByTime_90TO270{chan}{5}  jMUSwitches.data.spikesByTime_90TO270{chan}{6}...
    jMUSwitches.data.spikesByTime_90TO270{chan}{7}  jMUSwitches.data.spikesByTime_90TO270{chan}{8}];

% stimulus change - 270 to 90

switch_pa_270to90 = [jMUSwitches.data.spikesByTime_270TO90{chan}{5}  jMUSwitches.data.spikesByTime_270TO90{chan}{6}...
    jMUSwitches.data.spikesByTime_270TO90{chan}{7}  jMUSwitches.data.spikesByTime_270TO90{chan}{8}];


% stimulus change - 90 to 270
switch_fs_90to270 = [jMUSwitches.data.spikesByTime_90TO270{chan}{1}  jMUSwitches.data.spikesByTime_90TO270{chan}{2}...
    jMUSwitches.data.spikesByTime_90TO270{chan}{3}  jMUSwitches.data.spikesByTime_90TO270{chan}{4}];

% stimulus change - 270 to 90

switch_fs_270to90 = [jMUSwitches.data.spikesByTime_270TO90{chan}{1}  jMUSwitches.data.spikesByTime_270TO90{chan}{2}...
    jMUSwitches.data.spikesByTime_270TO90{chan}{3}  jMUSwitches.data.spikesByTime_270TO90{chan}{4}];
    
%% Convert the spike timing data into chronux format and smooth with chronux


% stimulus change - 90 to 270
[SPKdata_pa_90to270] = spikesSOAligned2ChrSpk(switch_pa_90to270);
[sdf_pa_90to270, t, err_pa_90to270] = psth(SPKdata_pa_90to270, sigma, 'n', tim_window);
[SPKdata_fs_90to270] = spikesSOAligned2ChrSpk(switch_fs_90to270);
[sdf_fs_90to270, t, err_fs_90to270] = psth(SPKdata_fs_90to270, sigma, 'n', tim_window);

% stimulus change - 270 to 90
[SPKdata_pa_270to90] = spikesSOAligned2ChrSpk(switch_pa_270to90);
[sdf_pa_270to90, t, err_pa_270to90] = psth(SPKdata_pa_270to90, sigma, 'n', tim_window);
[SPKdata_fs_270to90] = spikesSOAligned2ChrSpk(switch_fs_270to90);
[sdf_fs_270to90, t, err_fs_270to90] = psth(SPKdata_fs_270to90, sigma, 'n', tim_window);

%% Make Figure and save it

subplot(3,6,5)
hold on;

%     errorbar(t,sdf_pa_90,err_pa_90,'k');
%     errorbar(t,sdf_fs_90,err_fs_90,'r');
%     errorbar(t,sdf_pa_270,err_pa_270,'b');
%     errorbar(t,sdf_fs_270,err_fs_270,'g');

plot(t,sdf_pa_90to270,'k','LineWidth',3)
plot(t,sdf_pa_270to90,'k:','LineWidth',3)
xlim(t_lim); ylim(spk_lim);
vline_vk([0]);
xlabel('Time (seconds)'); ylabel('Spikes/second');
axis square
title('Sensory Switches','FontSize',16);
% legend('Up to Down','Down to Up','Location','NorthEast')

subplot(3,6,11)
spk_rasterplot_bfsgrad(SPKdata_pa_270to90,'k',[tim_window(1) tim_window(end)]);
xlim(t_lim); 
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk([0]);
ylabel('Trials');
axis square
% xlabel('Time');
title('Downward to Upward','FontSize',13);

subplot(3,6,17)
spk_rasterplot_bfsgrad(SPKdata_pa_90to270,'k',[tim_window(1) tim_window(end)]);
xlim(t_lim); 
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk([0]);
xlabel('Time (seconds)'); ylabel('Trials');
axis square
title('Upward to Downward','FontSize',13);

subplot(3,6,6)
hold on;
plot(t,sdf_fs_90to270,'r','LineWidth',3);
plot(t,sdf_fs_270to90,'r:','LineWidth',3);
xlim(t_lim); ylim(spk_lim);
vline_vk([0]);
xlabel('Time (seconds)'); ylabel('Spikes/second');
axis square
title('Perceptual Switches','FontSize',16);
% legend('Up to Down','Down to Up','Location','NorthEast')

subplot(3,6,12)
spk_rasterplot_bfsgrad(SPKdata_fs_270to90,'r',[tim_window(1) tim_window(end)]);
xlim(t_lim); 
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk([0]);
ylabel('Trials');
axis square
% xlabel('Time');
title('Downward to Upward','FontSize',13);

subplot(3,6,18)
spk_rasterplot_bfsgrad(SPKdata_fs_90to270,'r',[tim_window(1) tim_window(end)]);
xlim(t_lim); 
set(gca,'XTick',x_Ticks);
set(gca,'XTickLabel',x_TicksLabel);
vline_vk([0]);
xlabel('Time (seconds)'); ylabel('Trials');
axis square
title('Upward to Downward','FontSize',13);

saveas(gcf,strcat('SDF - site - ', num2str(chan)),'jpg')
saveas(gcf,strcat('SDF - site - ', num2str(chan)),'ai')
saveas(gcf,strcat('SDF- site - ', num2str(chan)),'fig')
close all
% 
% %     pause

% % saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'jpg')
% % saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'ai')
% % saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'fig')
% % 
% % %     pause
% % close all
% % 
% % 
% % saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'jpg')
% % saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'ai')
% % saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'fig')
% % 
% % %             pause
% % close all

end

