function [valid_idx,valid_dur] = get_flashdom_idx(domDur,min_domDur,max_domDur)

%% This code generates a list of valid_idx for the dominance duration.
% 
% Input: 
% 
% 1. domDur: a structure with dominance durations
% 2. min_domDur: minimum dominance duration
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/09/13



%% Get the dominance durations of minimum duration

for i = 1:length(domDur.flashDom)
    
    valid_idx{i} = find(cell2mat(domDur.flashDom{i})>min_domDur & cell2mat(domDur.flashDom{i})<max_domDur);
    valid_dur{i} = cell2mat(domDur.flashDom{i}(valid_idx{i}));

end  
  
