

tim_window_switch = [-1.5 1.5];
sigma = 0.040;

t_mov = t(31:384);

movdat_90TO270 = zeros(10,10,length(t_mov));
movdat_270TO90 = zeros(10,10,length(t_mov));
Nmovdat_90TO270 = zeros(10,10,length(t_mov));
Nmovdat_270TO90 = zeros(10,10,length(t_mov));

s_Nmovdat_90TO270 = zeros(10,10,length(t_mov));
s_Nmovdat_270TO90 = zeros(10,10,length(t_mov));

for chan = 1:length(jMUSwitches.data.spikesByTime_90TO270)
    %     chan = 29;
    tim_window = tim_window_switch;
    % stimulus change - 90 to 270
    switch_fs_90to270 = [jMUSwitches.data.spikesByTime_90TO270{chan}{1}  jMUSwitches.data.spikesByTime_90TO270{chan}{2}...
        jMUSwitches.data.spikesByTime_90TO270{chan}{3}  jMUSwitches.data.spikesByTime_90TO270{chan}{4}];
    % stimulus change - 270 to 90
    switch_fs_270to90 = [jMUSwitches.data.spikesByTime_270TO90{chan}{1}  jMUSwitches.data.spikesByTime_270TO90{chan}{2}...
        jMUSwitches.data.spikesByTime_270TO90{chan}{3}  jMUSwitches.data.spikesByTime_270TO90{chan}{4}];
    %% Convert the spike timing data into chronux format and smooth with chronux
    if ((sum(~cellfun('isempty',switch_fs_90to270))>0) && (sum(~cellfun('isempty',switch_fs_270to90))>0))
        % stimulus change - 90 to 270
        [SPKdata_fs_90to270] = spikesSOAligned2ChrSpk(switch_fs_90to270);
        [sdf_fs_90to270, t, err_fs_90to270] = psth(SPKdata_fs_90to270, sigma, 'n', tim_window);
        % stimulus change - 270 to 90
        [SPKdata_fs_270to90] = spikesSOAligned2ChrSpk(switch_fs_270to90);
        [sdf_fs_270to90, t, err_fs_270to90] = psth(SPKdata_fs_270to90, sigma, 'n', tim_window);
        elec = chan2elec(chan,2);
        %     figure
        [r(chan),c(chan)] = find(elec_map == elec);
        %     figure('units','normalized','outerposition',[0 0 1 1])
        tmp_sdf_90TO270 = sdf_fs_90to270(31:384);
        tmp_sdf_270TO90 = sdf_fs_270to90(31:384);
        movdat_90TO270(r(chan),c(chan),:) = (tmp_sdf_90TO270/max(tmp_sdf_90TO270));
        movdat_270TO90(r(chan),c(chan),:) = (tmp_sdf_270TO90/max(tmp_sdf_270TO90));
        Nmovdat_90TO270(r(chan),c(chan),:) = (tmp_sdf_90TO270-min(tmp_sdf_90TO270))/(max(tmp_sdf_90TO270)-min(tmp_sdf_90TO270));
        Nmovdat_270TO90(r(chan),c(chan),:) = (tmp_sdf_270TO90-min(tmp_sdf_270TO90))/(max(tmp_sdf_270TO90)-min(tmp_sdf_270TO90));
        if find(sig_mu(:) == chan)
            s_Nmovdat_90TO270(r(chan),c(chan),:) = (tmp_sdf_90TO270-min(tmp_sdf_90TO270))/(max(tmp_sdf_90TO270)-min(tmp_sdf_90TO270));
            s_Nmovdat_270TO90(r(chan),c(chan),:) = (tmp_sdf_270TO90-min(tmp_sdf_270TO90))/(max(tmp_sdf_270TO90)-min(tmp_sdf_270TO90));
        end
    end
end

v = VideoWriter('new_psth.avi');
open(v);
figure(23);
% h_tim = uicontrol('Style','slider','Position', [50 10 500 20], 'Min', 1, 'Max',length(t_mov),'Value',1);
colormap('gray');
for i = 1:length(t_mov)
    subplot(2,2,1)
    imagesc(Nmovdat_90TO270(:,:,i));
    title('90 to 270 - All Channels')
    subplot(2,2,2)
    imagesc(Nmovdat_270TO90(:,:,i));
    title('270 to 90 - All Channels')
    subplot(2,2,3)
    imagesc(s_Nmovdat_90TO270(:,:,i));
    title('90 to 270 - Sig. Channels')
    subplot(2,2,4)
    imagesc(s_Nmovdat_270TO90(:,:,i));
    title('270 to 90 - Sig. Channels')
    suplabel(num2str(t_mov(i)),'t');
    %     h_tim.Value = i;
    fig = gcf;
    f(i) = getframe(fig);
    writeVideo(v,f(i));
end
close(v);
