function [sdf] =  generate_psth_bfsgrad(jMUspikes, align_evt, sav_dir, sav_fig)


%% This code generates and saves the PSTH for given datasets of bfsgrad.
% 
% Input: 
% 
% 1. jMUspikes: the data structure with spikes
% 2. align_evt_soa: aligning event - SOA|MOA
% 3. sav_fig: 1 - save, 0 - don't save
% 
% Output: 
% sdf
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/06/15

see_fig = 0;
sigma = 0.040;

switch align_evt
    
    %% Create PSTHs - Stimulus Onset Aligned Data
    
    case 'SOA'
        
        tim_window_SOA = [-0.3 4];        
        [sdf_soa] = generate_psth_chan_pa_fs(jMUspikes, align_evt, tim_window_SOA, sigma, sav_dir, sav_fig, see_fig);
        
%         if an_info.sdf_soa_fil == 0
            cd(sav_dir);
            save('sdf_soa.mat', 'sdf_soa');
%         end
        
        sdf = sdf_soa;
        %% Create PSTHs - Mask Onset Aligned Data
        
    case 'MOA'
        
        tim_window_MOA = [-2.3 2];        
        [sdf_moa] = generate_psth_chan_pa_fs(jMUspikes, align_evt, tim_window_MOA, sigma, sav_dir,sav_fig,see_fig);
        
%         if an_info.sdf_moa_fil == 0
            cd(sav_dir);
            save('sdf_moa.mat', 'sdf_moa');
%         end
        
        sdf = sdf_moa;
        
        %% Generate PSTHs - Switch Related  
        
    case 'Switch'
        
        tim_window_Switch = [-1.5 1.5];        
        [sdf_switch] = generate_psth_switches_chan(jMUspikes, tim_window_Switch, sigma, sav_dir, sav_fig);
        
%         if an_info.sdf_switch_fil == 0
            cd(sav_dir_PsthSwitch);
            save('sdf_switch.mat', 'sdf_switch');
%         end
        
end
