function generate_pop_psth_mu_bfsgrad(res_mua_moa, pref_array, binWidth, sav_dir, ttl_suffix, sav_fig)


%% This code generates the population PSTHs.
% 
% Input: 
% 
% 1. res_mua_moa: spikesparse 
% 2. pref_array: preference arrays
% 3. binWidth: bin width
% 4. sav_dir: saving directory
% 5. ttl_suffix: title suffix
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/06/15


%% assign parameters

offset_maskon = -2300;
tWin_moa = 2000;
trl_dur = abs(offset_maskon)+tWin_moa;
tim_trl_dur = [binWidth:binWidth:trl_dur];
pop_psth_typ = 'BFS_MUA';

%% get the input for generating population psths

[pop_psth_BFS] = get_pop_psth_input(pop_psth_typ, pref_array, ttl_suffix);

%% prepare and save the population psths

for num_pop_psth = 1:length(pop_psth_BFS)
    
    [pop_psth_pa_fs(num_pop_psth)] = generate_population_mu_psth(res_mua_moa,pop_psth_BFS(num_pop_psth).mu2plot, ...
        pop_psth_BFS(num_pop_psth).units_typ, binWidth,tim_trl_dur, sav_dir, sav_fig, ...
        pop_psth_BFS(num_pop_psth).sav_nam);
    close all;
end
