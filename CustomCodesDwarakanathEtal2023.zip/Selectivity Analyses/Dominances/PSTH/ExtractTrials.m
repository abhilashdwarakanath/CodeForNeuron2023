function generate_psth_chan

cd cd V:\H07\12-06-2016\PFC\Bfsgrad1
load jMUSpikesByTime

cd L:\projects\Vishal\PSTH_Results_Bfsgrad

sigma = 0.040;

for chan = 1:length(data)

    tim_window = [-0.3 8.5];
    
    % stimulus change - 90 to 270
    cond_pa_90 = [jMUspikes.data{chan}.spikesSOAligned{5} jMUspikes.data{1}.spikesSOAligned{7}];
    cond_fs_90 = [jMUspikes.data{chan}.spikesSOAligned{1} jMUspikes.data{1}.spikesSOAligned{3}];

    % stimulus change - 270 to 90
    
    cond_pa_270 = [jMUspikes.data{chan}.spikesSOAligned{6} jMUspikes.data{1}.spikesSOAligned{8}];
    cond_fs_270 = [jMUspikes.data{chan}.spikesSOAligned{2} jMUspikes.data{1}.spikesSOAligned{4}];
    
    %% Convert the spike timing data into chronux format and smooth with chronux
    
    % stimulus change - 90 to 270
    [SPKdata_pa_90] = spikesSOAligned2ChrSpk(cond_pa_90);
    [SPKdata_fs_90] = spikesSOAligned2ChrSpk(cond_fs_90);
    [sdf_pa_90, t, err_pa_pf] = psth(SPKdata_pa_90, sigma, 'n', tim_window);
    [sdf_fs_90, t, err_fs_pf] = psth(SPKdata_fs_90, sigma, 'n', tim_window);
    
    % stimulus change - 270 to 90
    [SPKdata_pa_270] = spikesSOAligned2ChrSpk(cond_pa_270);
    [SPKdata_fs_270] = spikesSOAligned2ChrSpk(cond_fs_270);
    [sdf_pa_270, t, err_pa_pf] = psth(SPKdata_pa_270, sigma, 'n', tim_window);
    [sdf_fs_270, t, err_fs_pf] = psth(SPKdata_fs_270, sigma, 'n', tim_window);

    
    figure(chan)
    hold on;
    plot(t,sdf_pa_270)
    plot(t,sdf_fs_270,'r')
    plot(t,sdf_pa_90,'b--')
    plot(t,sdf_fs_90,'r--')
    
    saveas(gcf,strcat('PSTH - SOA - site - ', num2str(chan)),'jpg')
    
    
    tim_window = [-2.3 8.5];
    
    % stimulus change - 90 to 270
    cond_pa_90 = [jMUspikes.data{chan}.spikesMOAligned{5} jMUspikes.data{1}.spikesMOAligned{7}];
    cond_fs_90 = [jMUspikes.data{chan}.spikesMOAligned{1} jMUspikes.data{1}.spikesMOAligned{3}];

    % stimulus change - 270 to 90
    
    cond_pa_270 = [jMUspikes.data{chan}.spikesMOAligned{6} jMUspikes.data{1}.spikesMOAligned{8}];
    cond_fs_270 = [jMUspikes.data{chan}.spikesMOAligned{2} jMUspikes.data{1}.spikesMOAligned{4}];
    
    %% Convert the spike timing data into chronux format and smooth with chronux
    
    % stimulus change - 90 to 270
    [SPKdata_pa_90] = spikesSOAligned2ChrSpk(cond_pa_90);
    [SPKdata_fs_90] = spikesSOAligned2ChrSpk(cond_fs_90);
    [sdf_pa_90, t, err_pa_pf] = psth(SPKdata_pa_90, sigma, 'n', tim_window);
    [sdf_fs_90, t, err_fs_pf] = psth(SPKdata_fs_90, sigma, 'n', tim_window);
    
    % stimulus change - 270 to 90
    [SPKdata_pa_270] = spikesSOAligned2ChrSpk(cond_pa_270);
    [SPKdata_fs_270] = spikesSOAligned2ChrSpk(cond_fs_270);
    [sdf_pa_270, t, err_pa_pf] = psth(SPKdata_pa_270, sigma, 'n', tim_window);
    [sdf_fs_270, t, err_fs_pf] = psth(SPKdata_fs_270, sigma, 'n', tim_window);

    
    figure(chan+100)
    hold on;
    plot(t,sdf_pa_270)
    plot(t,sdf_fs_270,'r')
    plot(t,sdf_pa_90,'b--')
    plot(t,sdf_fs_90,'r--')
    
    saveas(gcf,strcat('PSTH - SOA - site - ', num2str(chan)),'jpg')

    close all
    
end
    
    