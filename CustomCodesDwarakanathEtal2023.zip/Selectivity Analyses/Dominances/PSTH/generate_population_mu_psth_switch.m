function [pop_psth] = generate_population_mu_psth_switch(res_mua_90TO270, res_mua_270TO90, pref_sim_mu,units_typ,binWidth,tim_trl_dur,calc_typ,sav_dir, sav_fig, sav_nam)

% The code for calculating the population MUA PSTHs around the switch for a given set of sites.
% Inputs are:
% 1. res_mua_90TO270, res_mua_270TO90 - spikeSparse Matrices of MUA 
% 2. pref_sim_mu - the set of sites for which to plot
% 3. units_typ - specifying the kind of units used as figure title 
% 4. binWidth - bin size of the spikeSparse Matrices
% 5. tim_trl_dur - the duration of the signal to plot
% 6. calc_typ - calculation type to implement, namely 'switch first' or '
% sites first'.
% 
% Usage: generate_population_mu_psth(res_mua_moa,pref_sim_mu,units_typ,binWidth,tim_trl_dur)
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de)
%    start : 2017/5/11



%% the scaling factor for multiplication and getting the spike rate in Hz.

scl_fr = 1000/binWidth;

%% Get the sites which prefer upward or downward moving grating

dwn_pref = pref_sim_mu((pref_sim_mu(:,2) == 1),3);
up_pref = pref_sim_mu((pref_sim_mu(:,2) == 2),3);

%% Get the psth and categorize them non-preferred to preferred and preferred to non-preferred.

% for the downward moving grating

if ~isempty(dwn_pref)
    
    for num_down = 1:length(dwn_pref)
        
        riv_psth_dwn_np2p(:,num_down,:) = full([res_mua_90TO270(dwn_pref(num_down)).muSpikesSparse{1} res_mua_90TO270(dwn_pref(num_down)).muSpikesSparse{2}...
            res_mua_90TO270(dwn_pref(num_down)).muSpikesSparse{3} res_mua_90TO270(dwn_pref(num_down)).muSpikesSparse{4}])';
        riv_psth_dwn_p2np(:,num_down,:) = full([res_mua_270TO90(dwn_pref(num_down)).muSpikesSparse{1} res_mua_270TO90(dwn_pref(num_down)).muSpikesSparse{2}...
            res_mua_270TO90(dwn_pref(num_down)).muSpikesSparse{3} res_mua_270TO90(dwn_pref(num_down)).muSpikesSparse{4}])';
        
        pa_psth_dwn_np2p(:,num_down,:) = full([res_mua_90TO270(dwn_pref(num_down)).muSpikesSparse{5} res_mua_90TO270(dwn_pref(num_down)).muSpikesSparse{6}...
            res_mua_90TO270(dwn_pref(num_down)).muSpikesSparse{7} res_mua_90TO270(dwn_pref(num_down)).muSpikesSparse{8}])';
        pa_psth_dwn_p2np(:,num_down,:) = full([res_mua_270TO90(dwn_pref(num_down)).muSpikesSparse{5} res_mua_270TO90(dwn_pref(num_down)).muSpikesSparse{6}...
            res_mua_270TO90(dwn_pref(num_down)).muSpikesSparse{7} res_mua_270TO90(dwn_pref(num_down)).muSpikesSparse{8}])';
        
    end
    
else
    
    riv_psth_dwn_np2p = NaN(1,1,length(res_mua_90TO270(1).muSpikesSparse{1}));
    riv_psth_dwn_p2np = NaN(1,1,length(res_mua_90TO270(1).muSpikesSparse{1}));
    
    pa_psth_dwn_np2p = NaN(1,1,length(res_mua_90TO270(1).muSpikesSparse{1}));
    pa_psth_dwn_p2np = NaN(1,1,length(res_mua_90TO270(1).muSpikesSparse{1}));
    
end

% for the upward moving grating

if ~isempty(up_pref)
    
    for num_up = 1:length(up_pref)
        
        riv_psth_up_np2p(:,num_up,:) = full([res_mua_270TO90(up_pref(num_up)).muSpikesSparse{1} res_mua_270TO90(up_pref(num_up)).muSpikesSparse{2}...
            res_mua_270TO90(up_pref(num_up)).muSpikesSparse{3} res_mua_270TO90(up_pref(num_up)).muSpikesSparse{4}])';
        riv_psth_up_p2np(:,num_up,:) = full([res_mua_90TO270(up_pref(num_up)).muSpikesSparse{1} res_mua_90TO270(up_pref(num_up)).muSpikesSparse{2}...
            res_mua_90TO270(up_pref(num_up)).muSpikesSparse{3} res_mua_90TO270(up_pref(num_up)).muSpikesSparse{4}])';
        
        pa_psth_up_np2p(:,num_up,:) = full([res_mua_270TO90(up_pref(num_up)).muSpikesSparse{5} res_mua_270TO90(up_pref(num_up)).muSpikesSparse{6}...
            res_mua_270TO90(up_pref(num_up)).muSpikesSparse{7} res_mua_270TO90(up_pref(num_up)).muSpikesSparse{8}])';
        pa_psth_up_p2np(:,num_up,:) = full([res_mua_90TO270(up_pref(num_up)).muSpikesSparse{5} res_mua_90TO270(up_pref(num_up)).muSpikesSparse{6}...
            res_mua_90TO270(up_pref(num_up)).muSpikesSparse{7} res_mua_90TO270(up_pref(num_up)).muSpikesSparse{8}])';
        
    end
    
else
    
    riv_psth_up_np2p = NaN(1,1,length(res_mua_90TO270(1).muSpikesSparse{1}));
    riv_psth_up_p2np = NaN(1,1,length(res_mua_90TO270(1).muSpikesSparse{1}));
    
    pa_psth_up_np2p = NaN(1,1,length(res_mua_90TO270(1).muSpikesSparse{1}));
    pa_psth_up_p2np = NaN(1,1,length(res_mua_90TO270(1).muSpikesSparse{1}));
    
end


% combine the two

if strcmp(calc_typ,'Switches_First')
    
    
% %     riv_psth_np2p = [squeeze(mean(riv_psth_dwn_np2p,1));squeeze(mean(riv_psth_up_np2p,1))];
% %     riv_psth_p2np = [squeeze(mean(riv_psth_dwn_p2np,1));squeeze(mean(riv_psth_up_p2np,1))];
% %     
% %     pa_psth_np2p = [squeeze(mean(pa_psth_dwn_np2p,1));squeeze(mean(pa_psth_up_np2p,1))];
% %     pa_psth_p2np = [squeeze(mean(pa_psth_dwn_p2np,1));squeeze(mean(pa_psth_up_p2np,1))];
    
    sz1 = size(riv_psth_dwn_np2p); sz2 = size(riv_psth_up_np2p);
    riv_psth_np2p = [reshape(nanmean(riv_psth_dwn_np2p,1),sz1(2),sz1(3)); ...
        reshape(nanmean(riv_psth_up_np2p,1),sz2(2),sz2(3))];
    
    sz1 = []; sz2 = [];
    sz1 = size(riv_psth_dwn_p2np); sz2 = size(riv_psth_up_p2np);
    riv_psth_p2np =  [reshape(nanmean(riv_psth_dwn_p2np,1),sz1(2),sz1(3)); ...
        reshape(nanmean(riv_psth_up_p2np,1),sz2(2),sz2(3))];  
 
    sz1 = []; sz2 = [];
    sz1 = size(pa_psth_dwn_np2p); sz2 = size(pa_psth_up_np2p);
    pa_psth_np2p = [reshape(nanmean(pa_psth_dwn_np2p,1),sz1(2),sz1(3)); ...
        reshape(nanmean(pa_psth_up_np2p,1),sz2(2),sz2(3))];
    
    sz1 = []; sz2 = [];
    sz1 = size(pa_psth_dwn_p2np); sz2 = size(pa_psth_up_p2np);
    pa_psth_p2np =  [reshape(nanmean(pa_psth_dwn_p2np,1),sz1(2),sz1(3)); ...
        reshape(nanmean(pa_psth_up_p2np,1),sz2(2),sz2(3))];      
    
    
elseif strcmp(calc_typ,'Sites_First')
    
% %     riv_psth_np2p = [squeeze(mean(riv_psth_dwn_np2p,2));squeeze(mean(riv_psth_up_np2p,2))];
% %     riv_psth_p2np = [squeeze(mean(riv_psth_dwn_p2np,2));squeeze(mean(riv_psth_up_p2np,2))];
% %     
% %     pa_psth_np2p = [squeeze(mean(pa_psth_dwn_np2p,2));squeeze(mean(pa_psth_up_np2p,2))];
% %     pa_psth_p2np = [squeeze(mean(pa_psth_dwn_p2np,2));squeeze(mean(pa_psth_up_p2np,2))]; 
    
    
        sz1 = size(riv_psth_dwn_np2p); sz2 = size(riv_psth_up_np2p);
    riv_psth_np2p = [reshape(nanmean(riv_psth_dwn_np2p,2),sz1(1),sz1(3)); ...
        reshape(nanmean(riv_psth_up_np2p,2),sz2(1),sz2(3))];
    
    sz1 = []; sz2 = [];
    sz1 = size(riv_psth_dwn_p2np); sz2 = size(riv_psth_up_p2np);
    riv_psth_p2np =  [reshape(nanmean(riv_psth_dwn_p2np,2),sz1(1),sz1(3)); ...
        reshape(nanmean(riv_psth_up_p2np,2),sz2(1),sz2(3))];  
 
    sz1 = []; sz2 = [];
    sz1 = size(pa_psth_dwn_np2p); sz2 = size(pa_psth_up_np2p);
    pa_psth_np2p = [reshape(nanmean(pa_psth_dwn_np2p,2),sz1(1),sz1(3)); ...
        reshape(nanmean(pa_psth_up_np2p,2),sz2(1),sz2(3))];
    
    sz1 = []; sz2 = [];
    sz1 = size(pa_psth_dwn_p2np); sz2 = size(pa_psth_up_p2np);
    pa_psth_p2np =  [reshape(nanmean(pa_psth_dwn_p2np,2),sz1(1),sz1(3)); ...
        reshape(nanmean(pa_psth_up_p2np,2),sz2(1),sz2(3))];                       
    
end

%% Calculate the population PSTHs

pop_riv_psth_np2p = nanmean(riv_psth_np2p)*scl_fr;
pop_riv_psth_p2np = nanmean(riv_psth_p2np)*scl_fr;

pop_pa_psth_np2p = nanmean(pa_psth_np2p)*scl_fr;
pop_pa_psth_p2np = nanmean(pa_psth_p2np)*scl_fr;

pop_psth.pa_np2p = pop_pa_psth_np2p;
pop_psth.pa_p2np = pop_pa_psth_p2np;
pop_psth.riv_np2p = pop_riv_psth_np2p;
pop_psth.riv_p2np = pop_riv_psth_p2np;

%% Plot the population PSTHs

figure
set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.

if strcmp(calc_typ,'Switches_First')
    
    % plot the psth in the pa condition
    
    subplot(1,2,1)
    plot(tim_trl_dur, pop_pa_psth_np2p,'k','LineWidth',3); hold on;
    plot(tim_trl_dur, pop_pa_psth_p2np,'r','LineWidth',3);
    vline_vk([0]);
    xlim([(tim_trl_dur(1)-binWidth) tim_trl_dur(end)]);
    xlabel('Time');
    ylabel('Spikes/second');
    title('Switches during Physical Alternation');
    legend('Non Preferred to Preferred','Preferred to Non preferred');
    
    % plot the psth in the rivalry condition
    
    subplot(1,2,2)
    plot(tim_trl_dur, pop_riv_psth_np2p,'k','LineWidth',3); hold on;
    plot(tim_trl_dur, pop_riv_psth_p2np,'r','LineWidth',3);
    vline_vk([0]);
    xlim([(tim_trl_dur(1)-binWidth) tim_trl_dur(end)]);
    xlabel('Time');
    ylabel('Spikes/second');
    title('Switches during Rivalry');
    legend('Non Preferred to Preferred','Preferred to Non preferred');
    
elseif strcmp(calc_typ,'Sites_First')
    
    % plot the psth in the pa condition - np2p
    
    subplot(2,2,1)
    plot(tim_trl_dur, (pa_psth_np2p*scl_fr)','r:'); hold on;
    plot(tim_trl_dur, pop_pa_psth_np2p,'k','LineWidth',3);
    vline_vk([0]);
    xlim([(tim_trl_dur(1)-binWidth) tim_trl_dur(end)]);
    xlabel('Time');
    ylabel('Spikes/second');
    title('Switches - PA - Non Preferred to Preferred');
    
    % plot the psth in the pa condition - p2np
    
    subplot(2,2,2)
    plot(tim_trl_dur, (pa_psth_p2np*scl_fr)','r:'); hold on;
    plot(tim_trl_dur, pop_pa_psth_p2np,'k','LineWidth',3);
    vline_vk([0]);
    xlim([(tim_trl_dur(1)-binWidth) tim_trl_dur(end)]);
    xlabel('Time');
    ylabel('Spikes/second');
    title('Switches - PA - Preferred to Non preferred');
    
    
    % plot the psth in the rivalry condition - np2p
    
    subplot(2,2,3)
    plot(tim_trl_dur, (riv_psth_np2p*scl_fr)','r:'); hold on;
    plot(tim_trl_dur, pop_riv_psth_np2p,'k','LineWidth',3);
    vline_vk([0]);
    xlim([(tim_trl_dur(1)-binWidth) tim_trl_dur(end)]);
    xlabel('Time');
    ylabel('Spikes/second');
    title('Switches - Rivalry - Non Preferred to Preferred');
    
    % plot the psth in the rivalry condition - p2np
    
    subplot(2,2,4)
    plot(tim_trl_dur, (riv_psth_p2np*scl_fr)','r:'); hold on;
    plot(tim_trl_dur, pop_riv_psth_p2np,'k','LineWidth',3);
    vline_vk([0]);
    xlim([(tim_trl_dur(1)-binWidth) tim_trl_dur(end)]);
    xlabel('Time');
    ylabel('Spikes/second');
    title('Switches - Rivalry - Preferred to Non preferred');
    
end

suplabel(units_typ,'t')

%% Save the figure

if sav_fig == 1
    
    cd(sav_dir)
    saveas(gcf,sav_nam,'ai')
    saveas(gcf,sav_nam,'fig')
    exportfig(gcf,sav_nam,'Format','jpeg','Color','cmyk')
    exportfig(gcf,sav_nam,'Format','eps','Color','cmyk')
    
end
