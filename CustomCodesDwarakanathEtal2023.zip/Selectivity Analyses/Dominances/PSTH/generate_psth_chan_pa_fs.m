function [sdf] = generate_psth_chan_pa_fs(jMUspikes, align_evt, tim_window, sigma, sav_dir_psth, sav_fig,see_fig)

% This code takes input as the jMUspikes, tim_window, sigma(the width
% of the kernel) and the directory to save the PSTHs.
% The PSTHs are generated using the psth function from chronux. Rasters are
% also plotted for the two different conditions. The 'spikesSOAligned' are
% used for generating the psths.
% 
% % Usage: generate_psth_chan_pa_fs
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2016/10/9
% 




%% Create the structure to save

sdf = struct;
sdf.params.align_evt = align_evt;
sdf.params.sigma = sigma;
sdf.params.tim_window = tim_window;

%% Assign appropriate marking events for the PSTHs

if strcmp(align_evt, 'SOA')    
    evt_marks = [0 2];    
elseif strcmp(align_evt, 'MOA')    
    evt_marks = [-2 0];    
end
        
% cd V:\H07\12-06-2016\PFC\Bfsnatur1\

% cd L:\projects\Vishal\PSTH_Results\H07_Bfsnatur

%% Go to the relevant directory for saving PSTHs
cd(sav_dir_psth)

% chans = [72 4 14 18 23 32 52 56 58 60 62 63 79 88 90 91 96];



for chan = 1:length(jMUspikes.data)
    
    disp(strcat('Working on channel number - ',num2str(chan),'...'))
%     if ~isnan(jMUspikes.data{chan})
    if strcmp(align_evt, 'SOA')
        
        % stimulus change - 90 to 270
        cond_pa_90 = [jMUspikes.data{chan}.spikesSOAligned{5} jMUspikes.data{chan}.spikesSOAligned{7}];
        cond_fs_90 = [jMUspikes.data{chan}.spikesSOAligned{1} jMUspikes.data{chan}.spikesSOAligned{3}];
        
        % stimulus change - 270 to 90
        
        cond_pa_270 = [jMUspikes.data{chan}.spikesSOAligned{6} jMUspikes.data{chan}.spikesSOAligned{8}];
        cond_fs_270 = [jMUspikes.data{chan}.spikesSOAligned{2} jMUspikes.data{chan}.spikesSOAligned{4}];
        
        x_Ticks = [-0.3 0 0.5 1 1.5 2 2.5 3 3.5 4];
        x_TicksLabel = [-0.3,0,0.5,1,1.5,2,2.5,3,3.5,4];
        
    elseif strcmp(align_evt, 'MOA')
        
        % stimulus change - 90 to 270
        cond_pa_90 = [jMUspikes.data{chan}.spikesMOAligned{5} jMUspikes.data{chan}.spikesMOAligned{7}];
        cond_fs_90 = [jMUspikes.data{chan}.spikesMOAligned{1} jMUspikes.data{chan}.spikesMOAligned{3}];
        
        % stimulus change - 270 to 90
        
        cond_pa_270 = [jMUspikes.data{chan}.spikesMOAligned{6} jMUspikes.data{chan}.spikesMOAligned{8}];
        cond_fs_270 = [jMUspikes.data{chan}.spikesMOAligned{2} jMUspikes.data{chan}.spikesMOAligned{4}];
        
        x_Ticks = [-2.3 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2];
        x_TicksLabel = [-2.3 -2 -1.5 -1 -0.5 0 0.5 1 1.5 2];
        
    end
    
    %% Convert the spike timing data into chronux format and smooth with chronux
    
    if ((sum(~cellfun('isempty',cond_pa_90))>0) && (sum(~cellfun('isempty',cond_fs_90))>0) && ...
            (sum(~cellfun('isempty',cond_pa_270))>0) && (sum(~cellfun('isempty',cond_fs_270))>0))
        
        
        % stimulus change - 90 to 270
        [SPKdata_pa_90] = spikesSOAligned2ChrSpk(cond_pa_90);
        [SPKdata_fs_90] = spikesSOAligned2ChrSpk(cond_fs_90);
        [sdf_pa_90, t, err_pa_90] = psth(SPKdata_pa_90, sigma, 'n', tim_window);
        [sdf_fs_90, t, err_fs_90] = psth(SPKdata_fs_90, sigma, 'n', tim_window);
        
        % stimulus change - 270 to 90
        [SPKdata_pa_270] = spikesSOAligned2ChrSpk(cond_pa_270);
        [SPKdata_fs_270] = spikesSOAligned2ChrSpk(cond_fs_270);
        [sdf_pa_270, t, err_pa_270] = psth(SPKdata_pa_270, sigma, 'n', tim_window);
        [sdf_fs_270, t, err_fs_270] = psth(SPKdata_fs_270, sigma, 'n', tim_window);
        
        %% Store the data for output
        
        sdf.chan(chan).pa_90 = sdf_pa_90; sdf.chan(chan).err_pa_90 = err_pa_90;
        sdf.chan(chan).fs_90 = sdf_fs_90; sdf.chan(chan).err_fs_90 = err_fs_90;
        
        sdf.chan(chan).pa_270 = sdf_pa_270; sdf.chan(chan).err_pa_270 = err_pa_270;
        sdf.chan(chan).fs_270 = sdf_fs_270; sdf.chan(chan).err_fs_270 = err_fs_270;
        
        %% Make Figure and save it
        if sav_fig == 1
            
            figure('units','normalized','outerposition',[0 0 1 1])
            if see_fig==0
                set(gcf,'Visible','off')
            end
            subplot(3,2,1)
            hold on;
            %     errorbar(t,sdf_pa_90,err_pa_90,'k');
            %     errorbar(t,sdf_fs_90,err_fs_90,'r');
            %     errorbar(t,sdf_pa_270,err_pa_270,'b');
            %     errorbar(t,sdf_fs_270,err_fs_270,'g');
            
            plot(t,sdf_pa_270,'k')
            plot(t,sdf_pa_90,'k:')
            vline_vk(evt_marks);
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            title(strcat('PSTH - Physical Alternation - channel number - ', num2str(chan)));
            legend('Physical Alternation - 270 - 90','Physical Alternation - 90 - 270','Location','NorthOutside')
            
            subplot(3,2,3)
            spk_rasterplot_bfsgrad(SPKdata_pa_270,'k',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk(evt_marks);
            ylabel('Trials');
            xlabel('Time');
            title('Grating Order - 270 - 90');
            
            subplot(3,2,5)
            spk_rasterplot_bfsgrad(SPKdata_pa_90,'k',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk(evt_marks);
            ylabel('Trials');
            xlabel('Time');
            title('Grating Order - 90 - 270');
            
            subplot(3,2,2)
            hold on;
            
            plot(t,sdf_fs_270,'r')
            plot(t,sdf_fs_90,'r:')
            vline_vk(evt_marks);
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            title(strcat('PSTH - Binocular Rivalry - channel number - ', num2str(chan)));
            legend('Flash Suppression - 270 - 90','Flash Suppression - 90 - 270','Location','NorthOutside')
            
            subplot(3,2,4)
            spk_rasterplot_bfsgrad(SPKdata_fs_270,'r',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk(evt_marks);
            ylabel('Trials');
            xlabel('Time');
            title('Grating Order - 270 - 90');
            
            subplot(3,2,6)
            spk_rasterplot_bfsgrad(SPKdata_fs_90,'r',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk(evt_marks);
            ylabel('Trials');
            xlabel('Time');
            title('Grating Order - 90 - 270');
            
            
            saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'jpg')
            saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'ai')
            saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'fig')
            
            %             pause
            close all
        end
    end
%     end
end

sdf.t = t;


    
    
    
    