function [pop_psth_pa_fs] = generate_population_mu_psth(res_mua_moa,pref_sim_mu,units_typ,binWidth,tim_trl_dur, sav_dir, sav_fig, sav_nam)

% The code for calculating the population MUA PSTHs for a given set of sites.
% Inputs are:
% 1. res_mua_moa - spikeSparse Matrices of MUA 
% 2. pref_sim_mu - the set of sites for which to plot
% 3. units_typ - specifying the kind of units used as figure title 
% 4. binWidth - bin size of the spikeSparse Matrices
% 5. tim_trl_dur - the duration of the signal to plot
% 
% Usage: generate_population_mu_psth(res_mua_moa,pref_sim_mu,units_typ,binWidth,tim_trl_dur)
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de)
%    start : 2017/5/11


%% the scaling factor for multiplication and getting the spike rate in Hz.

scl_fr = 1000/binWidth;

%% Get the sites which prefer upward or downward moving grating

dwn_pref = pref_sim_mu((pref_sim_mu(:,2) == 1),3);
up_pref = pref_sim_mu((pref_sim_mu(:,2) == 2),3);

%% Get the psth and categorize them non-preferred to preferred and preferred to non-preferred.

% for the downward moving grating

for num_down = 1:length(dwn_pref)
    
    pa_psth_dwn_np2p(num_down,:) = mean(full([res_mua_moa(dwn_pref(num_down)).muSpikesSparse{5} res_mua_moa(dwn_pref(num_down)).muSpikesSparse{7}])')*scl_fr;
    pa_psth_dwn_p2np(num_down,:) = mean(full([res_mua_moa(dwn_pref(num_down)).muSpikesSparse{6} res_mua_moa(dwn_pref(num_down)).muSpikesSparse{8}])')*scl_fr;    
    
    fs_psth_dwn_np2p(num_down,:) = mean(full([res_mua_moa(dwn_pref(num_down)).muSpikesSparse{1} res_mua_moa(dwn_pref(num_down)).muSpikesSparse{3}])')*scl_fr;
    fs_psth_dwn_p2np(num_down,:) = mean(full([res_mua_moa(dwn_pref(num_down)).muSpikesSparse{2} res_mua_moa(dwn_pref(num_down)).muSpikesSparse{4}])')*scl_fr;
    
end

% for the upward moving grating

for num_up = 1:length(up_pref)
    
    pa_psth_up_np2p(num_up,:) = mean(full([res_mua_moa(up_pref(num_up)).muSpikesSparse{6} res_mua_moa(up_pref(num_up)).muSpikesSparse{8}])')*scl_fr;  
    pa_psth_up_p2np(num_up,:) = mean(full([res_mua_moa(up_pref(num_up)).muSpikesSparse{5} res_mua_moa(up_pref(num_up)).muSpikesSparse{7}])')*scl_fr;  
    
    fs_psth_up_np2p(num_up,:) = mean(full([res_mua_moa(up_pref(num_up)).muSpikesSparse{2} res_mua_moa(up_pref(num_up)).muSpikesSparse{4}])')*scl_fr;  
    fs_psth_up_p2np(num_up,:) = mean(full([res_mua_moa(up_pref(num_up)).muSpikesSparse{1} res_mua_moa(up_pref(num_up)).muSpikesSparse{3}])')*scl_fr;  
    
end

% combine the two

pa_psth_np2p = [pa_psth_dwn_np2p;pa_psth_up_np2p];
pa_psth_p2np = [pa_psth_dwn_p2np;pa_psth_up_p2np];

fs_psth_np2p = [fs_psth_dwn_np2p;fs_psth_up_np2p];
fs_psth_p2np = [fs_psth_dwn_p2np;fs_psth_up_p2np];

%% Calculate the population PSTHs

pop_psth_pa_np2p = mean(pa_psth_np2p);
pop_psth_pa_p2np = mean(pa_psth_p2np);

pop_psth_fs_np2p = mean(fs_psth_np2p);
pop_psth_fs_p2np = mean(fs_psth_p2np);

pop_psth_pa_fs.pa_np2p = pop_psth_pa_np2p;
pop_psth_pa_fs.pa_p2np = pop_psth_pa_p2np;
pop_psth_pa_fs.fs_np2p = pop_psth_fs_np2p;
pop_psth_pa_fs.fs_p2np = pop_psth_fs_p2np;

%% Plot the population PSTHs

% plot the psth in the pa condition

figure
set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.
subplot(1,2,1)
plot(tim_trl_dur, pop_psth_pa_np2p,'k','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_pa_p2np,'r','LineWidth',3);
vline_vk([300 2300]);
xlim([0 tim_trl_dur(end)]);
xlabel('Time');
ylabel('Spikes/second');
title('Physical Alternation Condition');
legend('Non Preferred to Preferred','Preferred to Non preferred');

% plot the psth in the fs condition

subplot(1,2,2)
plot(tim_trl_dur, pop_psth_fs_np2p,'k','LineWidth',3); hold on;
plot(tim_trl_dur, pop_psth_fs_p2np,'r','LineWidth',3);
vline_vk([300 2300]);
xlim([0 tim_trl_dur(end)]);
xlabel('Time');
ylabel('Spikes/second');
title('Flash Suppression Condition');
legend('Non Preferred to Preferred','Preferred to Non preferred');

suplabel(units_typ,'t')

%% Save the figure

if sav_fig == 1
    
    cd(sav_dir)
    saveas(gcf,sav_nam,'ai')
    saveas(gcf,sav_nam,'fig')
    exportfig(gcf,sav_nam,'Format','jpeg','Color','rgb')
    exportfig(gcf,sav_nam,'Format','eps','Color','rgb')
    
end


