function [pop_psth] = get_pop_psth_input(pop_psth_typ, pref_array, ttl_suffix)

% This code generates the required input for plotting population PSTHs.
% It takes input as the pop_psth_typ(BFS_MUA, Switch_MUA, etc), pref_array,
% ttl_suffix(the title which could be added to figure properties which are 
% generated here).
% Also see generate_population_mu_psth,
% % Usage: [pop_psth] = get_pop_psth_input(pop_psth_typ, pref_array, ttl_suffix)
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/5/29
% 

%% Make the appropriate structure

pop_psth = struct;

%% Specific actions are taken for the different signal types

switch pop_psth_typ
    
%     Binocular Flash Suppression - MUA
    case 'BFS_MUA'                           
        
% Sites significantly modulated in the physical alternation condition.
       
        pop_psth(1).mu2plot = pref_array.pref_sim.pri_sig_u;
        pop_psth(1).units_typ = strcat('Mean of - ',num2str(size(pop_psth(1).mu2plot,1)), ...
            '- Sites significantly modulated in PA conditions',ttl_suffix);
        pop_psth(1).sav_nam = 'Population_PSTH_SignificantSites_PA';
        
% Sites significantly modulated in the flash suppression condition.

        pop_psth(2).mu2plot = pref_array.pref_sim.sec_sig_u;
        pop_psth(2).units_typ = strcat('Mean of - ',num2str(size(pop_psth(2).mu2plot,1)), ...
            '- Sites significantly modulated in FS conditions',ttl_suffix);
        pop_psth(2).sav_nam = 'Population_PSTH_SignificantSites_FS';   
                
% Sites significantly modulated in both conditions
        
        pop_psth(3).mu2plot = pref_array.pref_sim.com_sig_u;
        pop_psth(3).units_typ = strcat('Mean of - ',num2str(size(pop_psth(3).mu2plot,1)), ...
            '- Sites significantly modulated in both conditions',ttl_suffix);
        pop_psth(3).sav_nam = 'Population_PSTH_SignificantSites_PA_FS';
        
% Sites significantly modulated in only the physical alternation condition
% but not flash suppression condition
 
        pop_psth(4).mu2plot = pref_array.pref_sim.only_pri_sig_u;
        pop_psth(4).units_typ = strcat('Mean of - ',num2str(size(pop_psth(4).mu2plot,1)), ...
            '- Sites significantly modulated only in PA conditions',ttl_suffix);
        pop_psth(4).sav_nam = 'Population_PSTH_SignificantSites_OnlyPA';    

% Sites significantly modulated in only the flash suppression condition
% but not physical alternation condition        
        
        pop_psth(5).mu2plot = pref_array.pref_sim.only_sec_sig_u;
        pop_psth(5).units_typ = strcat('Mean of - ',num2str(size(pop_psth(5).mu2plot,1)), ...
           '- Sites significantly modulated only in FS conditions',ttl_suffix);
        pop_psth(5).sav_nam = 'Population_PSTH_SignificantSites_OnlyFS';            
    
%     Binocular Rivalry Dominance - MUA
    case 'Dom_MUA'                           
        
% Sites significantly modulated in the physical alternation condition.
       
        pop_psth(1).mu2plot = pref_array.pref_sim_Dom_PhyRiv.pri_sig_u;
        pop_psth(1).units_typ = strcat('Mean of - ',num2str(size(pop_psth(1).mu2plot,1)), ...
            '- Sites significantly modulated in PA conditions',ttl_suffix);
        pop_psth(1).sav_nam = 'Population_PSTH_SignificantSites_Phy';
        
% Sites significantly modulated in the flash suppression condition.

        pop_psth(2).mu2plot = pref_array.pref_sim_Dom_PhyRiv.sec_sig_u;
        pop_psth(2).units_typ = strcat('Mean of - ',num2str(size(pop_psth(2).mu2plot,1)), ...
            '- Sites significantly modulated in Rivalry conditions',ttl_suffix);
        pop_psth(2).sav_nam = 'Population_PSTH_SignificantSites_Riv';   
                
% Sites significantly modulated in both conditions
        
        pop_psth(3).mu2plot = pref_array.pref_sim_Dom_PhyRiv.com_sig_u;
        pop_psth(3).units_typ = strcat('Mean of - ',num2str(size(pop_psth(3).mu2plot,1)), ...
            '- Sites significantly modulated in both conditions',ttl_suffix);
        pop_psth(3).sav_nam = 'Population_PSTH_SignificantSites_Phy_Riv';
        
% Sites significantly modulated in only the physical alternation condition
% but not flash suppression condition
 
        pop_psth(4).mu2plot = pref_array.pref_sim_Dom_PhyRiv.only_pri_sig_u;
        pop_psth(4).units_typ = strcat('Mean of - ',num2str(size(pop_psth(4).mu2plot,1)), ...
            '- Sites significantly modulated only in PA conditions',ttl_suffix);
        pop_psth(4).sav_nam = 'Population_PSTH_SignificantSites_OnlyPhy';    

% Sites significantly modulated in only the flash suppression condition
% but not physical alternation condition        
        
        pop_psth(5).mu2plot = pref_array.pref_sim_Dom_PhyRiv.only_sec_sig_u;
        pop_psth(5).units_typ = strcat('Mean of - ',num2str(size(pop_psth(5).mu2plot,1)), ...
           '- Sites significantly modulated only in Rivalry conditions',ttl_suffix);
        pop_psth(5).sav_nam = 'Population_PSTH_SignificantSites_OnlyRiv';            
                
    case 'Switch_MUA'
        
% Sites significantly modulated in the physical alternation condition -
% before switch 

        pop_psth(1).mu2plot = pref_array.pref_sim_switch_Phy_BsAs.pri_sig_u;
        pop_psth(1).units_typ = strcat('Mean of - ',num2str(size(pop_psth(1).mu2plot,1)), ...
            '- Sites significantly modulated before switch in the physical alternation condition',ttl_suffix);
        pop_psth(1).sav_nam = 'Population_PSTH_SignificantSites_Phy_Switches_BS';
        
% Sites significantly modulated in the physical alternation condition -
% after switch 

        pop_psth(2).mu2plot = pref_array.pref_sim_switch_Phy_BsAs.sec_sig_u;
        pop_psth(2).units_typ = strcat('Mean of - ',num2str(size(pop_psth(2).mu2plot,1)), ...
            '- Sites significantly modulated after switch in the physical alternation condition',ttl_suffix);
        pop_psth(2).sav_nam = 'Population_PSTH_SignificantSites_Phy_Switches_AS';           
        
% Sites significantly modulated in the physical alternation condition -
% before and after switch 
        
        pop_psth(3).mu2plot = pref_array.pref_sim_switch_Phy_BsAs.com_sig_u;
        pop_psth(3).units_typ = strcat('Mean of - ',num2str(size(pop_psth(3).mu2plot,1)), ...
           '- Sites significantly modulated before and after switch in the physical alternation condition',ttl_suffix);
        pop_psth(3).sav_nam = 'Population_PSTH_SignificantSites_Phy_Switches_BSAS';                
       
% Sites significantly modulated in the physical alternation condition -
% before/after or both around the switch
        
        pop_psth(4).mu2plot = unique([pref_array.pref_sim_switch_Phy_BsAs.pri_sig_u; ...
            pref_array.pref_sim_switch_Phy_BsAs.sec_sig_u; ...
            pref_array.pref_sim_switch_Phy_BsAs.com_sig_u],'rows');
        pop_psth(4).units_typ = strcat('Mean of - ',num2str(size(pop_psth(4).mu2plot,1)), ...
            '- Sites significantly modulated before/after or both around the switch',ttl_suffix);
        pop_psth(4).sav_nam = 'Population_PSTH_SignificantSites_Phy_Switches_BS_AS_BSAS';
        
% Sites significantly modulated in the rivalry condition -
% before switch 

        pop_psth(5).mu2plot = pref_array.pref_sim_switch_Riv_BsAs.pri_sig_u;
        pop_psth(5).units_typ = strcat('Mean of - ',num2str(size(pop_psth(5).mu2plot,1)), ...
            '- Sites significantly modulated before switch in the rivalry condition',ttl_suffix);
        pop_psth(5).sav_nam = 'Population_PSTH_SignificantSites_Riv_Switches_BS';
        
% Sites significantly modulated in the rivalry condition -
% after switch 

        pop_psth(6).mu2plot = pref_array.pref_sim_switch_Riv_BsAs.sec_sig_u;
        pop_psth(6).units_typ = strcat('Mean of - ',num2str(size(pop_psth(6).mu2plot,1)), ...
            '- Sites significantly modulated after switch in the rivalry condition',ttl_suffix);
        pop_psth(6).sav_nam = 'Population_PSTH_SignificantSites_Riv_Switches_AS';                

% Sites significantly modulated in the rivalry condition -
% before and after switch         
        
        pop_psth(7).mu2plot = pref_array.pref_sim_switch_Riv_BsAs.com_sig_u;
        pop_psth(7).units_typ = strcat('Mean of - ',num2str(size(pop_psth(7).mu2plot,1)), ...
           '- Sites significantly modulated before and after switch in the rivalry condition',ttl_suffix);
        pop_psth(7).sav_nam = 'Population_PSTH_SignificantSites_Riv_Switches_BSAS';   
        
% Sites significantly modulated in the rivalry condition -
% before/after or both around the switch

        pop_psth(8).mu2plot = unique([pref_array.pref_sim_switch_Riv_BsAs.pri_sig_u; ...
            pref_array.pref_sim_switch_Riv_BsAs.sec_sig_u; ...
            pref_array.pref_sim_switch_Riv_BsAs.com_sig_u],'rows');
        pop_psth(8).units_typ = strcat('Mean of - ',num2str(size(pop_psth(8).mu2plot,1)), ...
            '- Sites significantly modulated before/after or both around the switch',ttl_suffix);
        pop_psth(8).sav_nam = 'Population_PSTH_SignificantSites_Riv_Switches_BS_AS_BSAS'; 
        
% Sites significantly modulated in the physical alternation and rivalry condition -
% before switch         

        pop_psth(9).mu2plot = pref_array.pref_sim_switch_PhyRiv_BsBs.com_sig_u;
        pop_psth(9).units_typ = strcat('Mean of - ',num2str(size(pop_psth(9).mu2plot,1)), ...
            '- Sites significantly modulated after switch in the physical alternation and rivalry condition',ttl_suffix);
        pop_psth(9).sav_nam = 'Population_PSTH_SignificantSites_PhyRiv_Switches_BS';     

% Sites significantly modulated in the physical alternation and rivalry condition -
% after switch 
         
        pop_psth(10).mu2plot =  pref_array.pref_sim_switch_PhyRiv_AsAs.com_sig_u;
        pop_psth(10).units_typ = strcat('Mean of - ',num2str(size(pop_psth(10).mu2plot,1)), ...
           '- Sites significantly modulated before and after switch in the rivalry condition',ttl_suffix);
        pop_psth(10).sav_nam = 'Population_PSTH_SignificantSites_PhyRiv_Switches_AS';           

        % Sites significantly modulated in the physical alternation and rivalry condition -
% before and after switch 
         
        pop_psth(11).mu2plot =  pref_array.pref_sim_switch_PhyRiv_BsAs.com_sig_u;
        pop_psth(11).units_typ = strcat('Mean of - ',num2str(size(pop_psth(11).mu2plot,1)), ...
           '- Sites significantly modulated before and after switch in the physical and rivalry condition',ttl_suffix);
        pop_psth(11).sav_nam = 'Population_PSTH_SignificantSites_PhyRiv_Switches_BSASBSAS';   
        
        
        
        
%     Rivalry Switches - MUA          
    case 'Riv_Switch_MUA'
        
  
        
        figProps.tim_window = dataIn.params.tim_window;        
        figProps.linTyp{1} = 'r';
        figProps.linTyp{2} = 'r:';
        figProps.v_line = [0];
        figProps.xlabel = 'Time (seconds)';
        figProps.ylabel = 'Spikes/second';
        figProps.suplabel = strcat('Rivalry-Switch-SDF Map',ttl_suffix);
        figProps.legend{1} = 'Rivalry - 270 - 90';
        figProps.legend{2} = 'Rivalry - 90 - 270';  
        figProps.legend{3} = 'Similarly significantly modulated in both conditions';       
        figProps.text_box = {'Bold Lines: Significantly modulated before/after switch', ...
            'Black Box: Stimulus preference mantained before/after switch'};
        figProps.figName = strcat('SDF_Map_Riv_Switch');        
        figProps.sig_typ = sig_typ;   
        figProps.patch_color = 'y';
        figProps.patch_EdgeColor = 'g';
        figProps.patch_LineStyle = '--';

% Local field potential - can be expanded by Abhilash        
%     case 'LFP'                            
        
        
        
end