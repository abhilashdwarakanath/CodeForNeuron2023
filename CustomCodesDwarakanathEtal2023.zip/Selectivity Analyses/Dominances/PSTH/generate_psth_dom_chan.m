function [sdf] = generate_psth_dom_chan(spk_dom90, spk_dom270, tim_window_Dominance, sigma, sav_dir_psth, sav_fig)

% This code takes input as the jMUSwitches, tim_window_Switch, sigma(the width
% of the kernel) and the directory to save the PSTHs.
% The PSTHs are generated using the psth function from chronux. Rasters are
% also plotted for the two different conditions. The 'spikesSOAligned' are
% used for generating the psths.
% 
% % Usage: generate_psth_switches_chan
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/7/3
% 


%% Create the structure to save

sdf = struct;
sdf.params.sigma = sigma;
sdf.params.tim_window = tim_window_Dominance;

%% Go to the relevant directory for saving PSTHs
cd(sav_dir_psth)

x_Ticks = cat(2,(-0.2),(0:0.5:tim_window_Dominance(2)));
x_TicksLabel = cat(2,(-0.2),(0:0.5:tim_window_Dominance(2)));

for chan = 1:length(spk_dom90)
    
    tim_window = tim_window_Dominance;
    
    % stimulus - 90
    dom_pa_90 = [spk_dom90{chan}{5}  spk_dom90{chan}{6}...
        spk_dom90{chan}{7}  spk_dom90{chan}{8}];
    
    % stimulus - 270
    
    dom_pa_270 = [spk_dom270{chan}{5}  spk_dom270{chan}{6}...
        spk_dom270{chan}{7}  spk_dom270{chan}{8}];    
    
    % percept - 90
    dom_riv_90 = [spk_dom90{chan}{1}  spk_dom90{chan}{2}...
        spk_dom90{chan}{3}  spk_dom90{chan}{4}];
    
    % percept - 270
    
    dom_riv_270 = [spk_dom270{chan}{1}  spk_dom270{chan}{2}...
        spk_dom270{chan}{3}  spk_dom270{chan}{4}];
    
    %% Convert the spike timing data into chronux format and smooth with chronux
    
    if ((sum(~cellfun('isempty',dom_riv_90))>0) && (sum(~cellfun('isempty',dom_riv_270))>0)) && ...
            (sum(~cellfun('isempty',dom_pa_90))>0) && (sum(~cellfun('isempty',dom_pa_270))>0)
        
        % dominant stimulus - 90 
        [SPKdata_pa_90] = spikesSOAligned2ChrSpk(dom_pa_90);
        [sdf_pa_90, t, err_pa_90] = psth(SPKdata_pa_90, sigma, 'n', tim_window);
        [SPKdata_riv_90] = spikesSOAligned2ChrSpk(dom_riv_90);
        [sdf_riv_90, t, err_riv_90] = psth(SPKdata_riv_90, sigma, 'n', tim_window);
        
        % dominant stimulus - 270
        [SPKdata_pa_270] = spikesSOAligned2ChrSpk(dom_pa_270);
        [sdf_pa_270, t, err_pa_270] = psth(SPKdata_pa_270, sigma, 'n', tim_window);
        [SPKdata_riv_270] = spikesSOAligned2ChrSpk(dom_riv_270);
        [sdf_riv_270, t, err_riv_270] = psth(SPKdata_riv_270, sigma, 'n', tim_window);
        
        %% Store the data for output
        
        sdf.chan(chan).pa_90 = sdf_pa_90; sdf.chan(chan).err_pa_90 = err_pa_90;
        sdf.chan(chan).pa_270 = sdf_pa_270; sdf.chan(chan).err_pa_270to90 = err_pa_270;
        sdf.chan(chan).riv_90 = sdf_riv_90; sdf.chan(chan).err_fs_90to270 = err_riv_90;
        sdf.chan(chan).riv_270 = sdf_riv_270; sdf.chan(chan).err_fs_270to90 = err_riv_270;
        
        %% Make Figure and save it
        
        if sav_fig == 1
            
            figure('units','normalized','outerposition',[0 0 1 1])
            set(gcf,'Visible','off');
            subplot(3,2,1)
            hold on;
            
            %     errorbar(t,sdf_pa_90,err_pa_90,'k');
            %     errorbar(t,sdf_riv_90,err_riv_90,'r');
            %     errorbar(t,sdf_pa_270,err_pa_270,'b');
            %     errorbar(t,sdf_riv_270,err_riv_270,'g');

            plot(t,sdf_pa_90,'k:')
            plot(t,sdf_pa_270,'k')            
            xlim([-0.2 tim_window_Dominance(2)]); xlabel('Time (seconds)'); ylabel('Spikes/second');
            vline_vk([0]);
            title(strcat('PSTH - Dominances (PA) - channel number - ', num2str(chan)));
            legend('90','270','Location','NorthEast')
            
            subplot(3,2,3)
            spk_rasterplot_bfsgrad(SPKdata_pa_270,'k',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk([0]);
            xlim([-0.2 tim_window_Dominance(2)]);
            ylabel('Trials');
            xlabel('Time');
            title('Sensory - 270');
            
            subplot(3,2,5)
            spk_rasterplot_bfsgrad(SPKdata_pa_90,'k',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk([0]);
            xlim([-0.2 tim_window_Dominance(2)]);            
            ylabel('Trials');
            xlabel('Time');
            title('Sensory - 90');
            
            subplot(3,2,2) 
            hold on;
            plot(t,sdf_riv_90,'r:')
            plot(t,sdf_riv_270,'r')            
            vline_vk([0]);
            xlim([-0.2 tim_window_Dominance(2)]); xlabel('Time (seconds)'); ylabel('Spikes/second');
            title(strcat('PSTH - Dominances (Rivalry) - channel number - ', num2str(chan)));
            legend('90','270','Location','NorthEast')
            
            subplot(3,2,4)
            spk_rasterplot_bfsgrad(SPKdata_riv_270,'r',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk([0]);
            xlim([-0.2 tim_window_Dominance(2)]);
            ylabel('Trials');
            xlabel('Time');
            title('Dominance - 270');
            
            subplot(3,2,6)
            spk_rasterplot_bfsgrad(SPKdata_riv_90,'r',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk([0]);
            xlim([-0.2 tim_window_Dominance(2)]); 
            ylabel('Trials');
            xlabel('Time');
            title('Dominance - 90');
            
            saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'jpg')
            saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'ai')
            saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'fig')
                        
            %     pause
            close all
        end
    end    
end

sdf.t = t;


