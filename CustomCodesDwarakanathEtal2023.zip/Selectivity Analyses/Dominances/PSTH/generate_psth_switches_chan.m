function [sdf] = generate_psth_switches_chan(jMUSwitches, tim_window_Switch, sigma, sav_dir_psth, sav_fig)

% This code takes input as the jMUSwitches, tim_window_Switch, sigma(the width
% of the kernel) and the directory to save the PSTHs.
% The PSTHs are generated using the psth function from chronux. Rasters are
% also plotted for the two different conditions. The 'spikesSOAligned' are
% used for generating the psths.
% 
% % Usage: generate_psth_switches_chan
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2016/10/9
% 


%% Create the structure to save

sdf = struct;
sdf.params.sigma = sigma;
sdf.params.tim_window = tim_window_Switch;

%% Go to the relevant directory for saving PSTHs
cd(sav_dir_psth)

x_Ticks = [-1.5 -1 -0.5 0 0.5 1 1.5];
x_TicksLabel = [-1.5 -1 -0.5 0 0.5 1 1.5];

for chan = 1:length(jMUSwitches.data.spikesByTime_90TO270)
    
    tim_window = tim_window_Switch;
    
    % stimulus change - 90 to 270
    switch_pa_90to270 = [jMUSwitches.data.spikesByTime_90TO270{chan}{5}  jMUSwitches.data.spikesByTime_90TO270{chan}{6}...
        jMUSwitches.data.spikesByTime_90TO270{chan}{7}  jMUSwitches.data.spikesByTime_90TO270{chan}{8}];
    
    % stimulus change - 270 to 90
    
    switch_pa_270to90 = [jMUSwitches.data.spikesByTime_270TO90{chan}{5}  jMUSwitches.data.spikesByTime_270TO90{chan}{6}...
        jMUSwitches.data.spikesByTime_270TO90{chan}{7}  jMUSwitches.data.spikesByTime_270TO90{chan}{8}];
    
    
    % stimulus change - 90 to 270
    switch_fs_90to270 = [jMUSwitches.data.spikesByTime_90TO270{chan}{1}  jMUSwitches.data.spikesByTime_90TO270{chan}{2}...
        jMUSwitches.data.spikesByTime_90TO270{chan}{3}  jMUSwitches.data.spikesByTime_90TO270{chan}{4}];
    
    % stimulus change - 270 to 90
    
    switch_fs_270to90 = [jMUSwitches.data.spikesByTime_270TO90{chan}{1}  jMUSwitches.data.spikesByTime_270TO90{chan}{2}...
        jMUSwitches.data.spikesByTime_270TO90{chan}{3}  jMUSwitches.data.spikesByTime_270TO90{chan}{4}];
    
    %% Convert the spike timing data into chronux format and smooth with chronux
    
    if ((sum(~cellfun('isempty',switch_fs_90to270))>0) && (sum(~cellfun('isempty',switch_fs_270to90))>0))
        
        % stimulus change - 90 to 270
        [SPKdata_pa_90to270] = spikesSOAligned2ChrSpk(switch_pa_90to270);
        [sdf_pa_90to270, t, err_pa_90to270] = psth(SPKdata_pa_90to270, sigma, 'n', tim_window);
        [SPKdata_fs_90to270] = spikesSOAligned2ChrSpk(switch_fs_90to270);
        [sdf_fs_90to270, t, err_fs_90to270] = psth(SPKdata_fs_90to270, sigma, 'n', tim_window);
        
        % stimulus change - 270 to 90
        [SPKdata_pa_270to90] = spikesSOAligned2ChrSpk(switch_pa_270to90);
        [sdf_pa_270to90, t, err_pa_270to90] = psth(SPKdata_pa_270to90, sigma, 'n', tim_window);
        [SPKdata_fs_270to90] = spikesSOAligned2ChrSpk(switch_fs_270to90);
        [sdf_fs_270to90, t, err_fs_270to90] = psth(SPKdata_fs_270to90, sigma, 'n', tim_window);
        
        %% Store the data for output
        
        sdf.chan(chan).pa_90to270 = sdf_pa_90to270; sdf.chan(chan).err_pa_90to270 = err_pa_90to270;
        sdf.chan(chan).pa_270to90 = sdf_pa_270to90; sdf.chan(chan).err_pa_270to90 = err_pa_270to90;
        sdf.chan(chan).fs_90to270 = sdf_fs_90to270; sdf.chan(chan).err_fs_90to270 = err_fs_90to270;
        sdf.chan(chan).fs_270to90 = sdf_fs_270to90; sdf.chan(chan).err_fs_270to90 = err_fs_270to90;
        
        %% Make Figure and save it
        
        if sav_fig == 1
            
            figure('units','normalized','outerposition',[0 0 1 1])
            set(gcf,'Visible','off');
            subplot(3,2,1)
            hold on;
            
            %     errorbar(t,sdf_pa_90,err_pa_90,'k');
            %     errorbar(t,sdf_fs_90,err_fs_90,'r');
            %     errorbar(t,sdf_pa_270,err_pa_270,'b');
            %     errorbar(t,sdf_fs_270,err_fs_270,'g');

            plot(t,sdf_pa_270to90,'k')
            plot(t,sdf_pa_90to270,'k:')            
            vline_vk([0]);
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            title(strcat('PSTH - Switches (PA) - channel number - ', num2str(chan)));
            legend('270 TO 90','90 TO 270','Location','NorthOutside')
            
            subplot(3,2,3)
            spk_rasterplot_bfsgrad(SPKdata_pa_270to90,'k',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk([0]);
            ylabel('Trials');
            xlabel('Time');
            title('Grating Order - 270 - 90');
            
            subplot(3,2,5)
            spk_rasterplot_bfsgrad(SPKdata_pa_90to270,'k',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk([0]);
            ylabel('Trials');
            xlabel('Time');
            title('Grating Order - 90 - 270');
            
            subplot(3,2,2) 
            hold on;
            plot(t,sdf_fs_270to90,'r')
            plot(t,sdf_fs_90to270,'r:')            
            vline_vk([0]);
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            title(strcat('PSTH - Switches (FS) - channel number - ', num2str(chan)));
            legend('270 TO 90','90 TO 270','Location','NorthOutside')
            
            subplot(3,2,4)
            spk_rasterplot_bfsgrad(SPKdata_fs_270to90,'r',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk([0]);
            ylabel('Trials');
            xlabel('Time');
            title('Grating Order - 270 - 90');
            
            subplot(3,2,6)
            spk_rasterplot_bfsgrad(SPKdata_fs_90to270,'r',[tim_window(1) tim_window(end)]);
            set(gca,'XTick',x_Ticks);
            set(gca,'XTickLabel',x_TicksLabel);
            vline_vk([0]);
            ylabel('Trials');
            xlabel('Time');
            title('Grating Order - 90 - 270');
            
            saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'jpg')
            saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'ai')
            saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'fig')
                        
            %     pause
            close all
        end
    end    
end

sdf.t = t;


