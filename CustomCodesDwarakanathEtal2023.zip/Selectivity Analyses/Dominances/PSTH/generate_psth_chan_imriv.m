function generate_psth_chan_imriv(jMUspikes, tim_window_SOA, sigma, sav_dir_psth,perceptInfo)

% This code takes input as the jMUspikes, tim_window_SOA, sigma(the width
% of the kernel) and the directory to save the PSTHs.
% The PSTHs are generated using the psth function from chronux. Rasters are
% also plotted for the two different conditions. The 'spikesS2OAligned' are
% used for generating the psths.
% 
% % Usage: generate_psth_chan_imriv
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2016/10/9
% 


% % % cd(sav_dir_psth)
% % % 
% % % cd B:\H07\20170323\PFC\ImRivRE50_1
% % % load jMUSpikesByTime
% % % % cd L:\projects\Vishal\PSTH_Results\H07_Bfsnatur
% % % % tim_window_SOA = [-0.3 2.3];
% % % % tim_window_MOA = [-1.3 1.3];
% % % tim_window_SOA = [-0.5 1;-0.75 1;-1.25 1];
% % % sigma = 0.050;
% chans = [72 4 14 18 23 32 52 56 58 60 62 63 79 88 90 91 96];

for chan = 1:length(jMUspikes.data)
               
    for bt = 1:3             
        
        tim_window = tim_window_SOA(bt,:);        
               
        cond_riv_AB = jMUspikes.data{chan}.trial.spikesS2OAligned{bt}{1}{1};        
        cond_riv_BA = jMUspikes.data{chan}.trial.spikesS2OAligned{bt}{1}{2};
                
        stb_trls = [];rev_trls = [];
        stb_trls = find(perceptInfo.trl{bt}{1}{1}==1);
        rev_trls = find(perceptInfo.trl{bt}{1}{1}==-1);                      
        cond_riv_AB_stb = jMUspikes.data{chan}.trial.spikesS2OAligned{bt}{1}{1}(stb_trls);
        cond_riv_AB_rev = jMUspikes.data{chan}.trial.spikesS2OAligned{bt}{1}{1}(rev_trls);                
                
        stb_trls = [];rev_trls = [];        
        stb_trls = find(perceptInfo.trl{bt}{1}{2}==1);
        rev_trls = find(perceptInfo.trl{bt}{1}{2}==-1);                      
        cond_riv_BA_stb = jMUspikes.data{chan}.trial.spikesS2OAligned{bt}{1}{2}(stb_trls);
        cond_riv_BA_rev = jMUspikes.data{chan}.trial.spikesS2OAligned{bt}{1}{2}(rev_trls);
        
        cond_riv_stb = [cond_riv_AB_stb cond_riv_BA_stb];
        cond_riv_rev = [cond_riv_AB_rev cond_riv_BA_rev];
        
        
        cond_phy_AA = jMUspikes.data{chan}.trial.spikesS2OAligned{bt}{1}{3};
        cond_phy_AB = jMUspikes.data{chan}.trial.spikesS2OAligned{bt}{1}{4};
        cond_phy_BB = jMUspikes.data{chan}.trial.spikesS2OAligned{bt}{1}{5};
        cond_phy_BA = jMUspikes.data{chan}.trial.spikesS2OAligned{bt}{1}{6};
         
        if (sum(~cellfun('isempty',cond_riv_AB))>0&& sum(~cellfun('isempty',cond_riv_BA))>0 ...
                && sum(~cellfun('isempty',cond_riv_AB_stb))>0&& sum(~cellfun('isempty',cond_riv_AB_rev))>0 ...
            && sum(~cellfun('isempty',cond_riv_BA_stb))>0&& sum(~cellfun('isempty',cond_riv_BA_rev))>0 ...
            && sum(~cellfun('isempty',cond_phy_AA))>0&& sum(~cellfun('isempty',cond_phy_AB))>0 ...
                && sum(~cellfun('isempty',cond_phy_BB))>0&& sum(~cellfun('isempty',cond_phy_BA))>0 ...
                && sum(~cellfun('isempty',cond_riv_stb))>0&& sum(~cellfun('isempty',cond_riv_rev))>0)
            
            %% Convert the spike timing data into chronux format and smooth with chronux
            
            % Rivalry Trials
            [SPKdata_riv_AB] = spikesSOAligned2ChrSpk(cond_riv_AB);
            [SPKdata_riv_BA] = spikesSOAligned2ChrSpk(cond_riv_BA);
            [sdf_riv_AB, t, err_riv_AB] = psth(SPKdata_riv_AB, sigma, 'n', tim_window);
            [sdf_riv_BA, t, err_riv_BA] = psth(SPKdata_riv_BA, sigma, 'n', tim_window);
            
            
            % Rivalry Trials - Stable or Perceptual reversal
            
            [SPKdata_riv_AB_stb] = spikesSOAligned2ChrSpk(cond_riv_AB_stb);
            [SPKdata_riv_AB_rev] = spikesSOAligned2ChrSpk(cond_riv_AB_rev);
            [sdf_riv_AB_stb, t, err_riv_AB_stb] = psth(SPKdata_riv_AB_stb, sigma, 'n', tim_window);
            [sdf_riv_AB_rev, t, err_riv_AB_rev] = psth(SPKdata_riv_AB_rev, sigma, 'n', tim_window);            
            
            [SPKdata_riv_BA_stb] = spikesSOAligned2ChrSpk(cond_riv_BA_stb);
            [SPKdata_riv_BA_rev] = spikesSOAligned2ChrSpk(cond_riv_BA_rev);
            [sdf_riv_BA_stb, t, err_riv_BA_stb] = psth(SPKdata_riv_BA_stb, sigma, 'n', tim_window);
            [sdf_riv_BA_rev, t, err_riv_BA_rev] = psth(SPKdata_riv_BA_rev, sigma, 'n', tim_window);  
            
            [SPKdata_riv_stb] = spikesSOAligned2ChrSpk(cond_riv_stb);
            [SPKdata_riv_rev] = spikesSOAligned2ChrSpk(cond_riv_rev);
            [sdf_riv_stb, t, err_riv_stb] = psth(SPKdata_riv_stb, sigma, 'n', tim_window);
            [sdf_riv_rev, t, err_riv_rev] = psth(SPKdata_riv_rev, sigma, 'n', tim_window);  
                        
            
            % Physical Trials
            [SPKdata_phy_AA] = spikesSOAligned2ChrSpk(cond_phy_AA);
            [SPKdata_phy_AB] = spikesSOAligned2ChrSpk(cond_phy_AB);
            [SPKdata_phy_BB] = spikesSOAligned2ChrSpk(cond_phy_BB);
            [SPKdata_phy_BA] = spikesSOAligned2ChrSpk(cond_phy_BA);
            
            [sdf_phy_AA, t, err_phy_AA] = psth(SPKdata_phy_AA, sigma, 'n', tim_window);
            [sdf_phy_AB, t, err_phy_AB] = psth(SPKdata_phy_AB, sigma, 'n', tim_window);
            [sdf_phy_BB, t, err_phy_BB] = psth(SPKdata_phy_BB, sigma, 'n', tim_window);
            [sdf_phy_BA, t, err_phy_BA] = psth(SPKdata_phy_BA, sigma, 'n', tim_window);
            
            
            %     figure
            
            figure('units','normalized','outerposition',[0+(bt-1)*0.33 0 0.33 1])
            
            subplot(2,4,1:2)
            plot(t,sdf_riv_AB,'b','LineWidth',3)
            vline_vk([0 (tim_window_SOA(bt,1)+0.25)]);
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            
            subplot(2,4,3:4)
            plot(t,sdf_riv_BA,'b','LineWidth',3)
            vline_vk([0 (tim_window_SOA(bt,1)+0.25)]);
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            
            subplot(2,4,5)
            plot(t,sdf_phy_AA, 'Color', [0.5 0 0.5],'LineWidth',3)
            vline_vk([0 (tim_window_SOA(bt,1)+0.25)]);
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            
            subplot(2,4,6)
            plot(t,sdf_phy_AB,'Color', [0.5 0 0.5],'LineWidth',3)
            vline_vk([0 (tim_window_SOA(bt,1)+0.25)]);
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            
            subplot(2,4,7)
            plot(t,sdf_phy_BB,'Color', [0.5 0 0.5],'LineWidth',3)
            vline_vk([0 (tim_window_SOA(bt,1)+0.25)]);
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            
            subplot(2,4,8)
            plot(t,sdf_phy_BA,'Color', [0.5 0 0.5],'LineWidth',3)
            vline_vk([0 (tim_window_SOA(bt,1)+0.25)]);
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            
            suplabel(strcat('PSTH - channel number - ', num2str(chan)),'t');
            
            H = figure(2);
            set(H,'units','normalized','outerposition',[0 0 1 1]); 
            subplot(1,3,bt); hold on;
            plot(t,sdf_riv_rev,'-r','LineWidth',3);
            plot(t,sdf_riv_stb,'-k','LineWidth',3);
            vline_vk([0 (tim_window_SOA(bt,1)+0.25)],{'k','k'},{'Blank End','Blank Start'});
            xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            
            
            %     subplot(3,2,3)
            %     spk_rasterplot_bfsgradPA(SPKdata_pa_270);
            %     ylabel('Trials');
            %     xlabel('Time');
            %     title('Grating Order - 270 - 90');
            %
            %
            %     subplot(3,2,5)
            %     spk_rasterplot_bfsgradPA(SPKdata_pa_90);
            %     ylabel('Trials');
            %     xlabel('Time');
            %     title('Grating Order - 90 - 270');
            %
            %     subplot(3,2,2)
            %     hold on;
            %
            %     plot(t,sdf_fs_270,'r')
            %     plot(t,sdf_fs_90,'r:')
            %     vline_vk([0 2]);
            %     xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
            %     title(strcat('PSTH - Binocular Rivalry - channel number - ', num2str(chan)));
            %     legend('Flash Suppression - 270 - 90','Flash Suppression - 90 - 270','Location','NorthOutside')
            %
            %     subplot(3,2,4)
            %     spk_rasterplot_bfsgradFS(SPKdata_fs_270);
            %     ylabel('Trials');
            %     xlabel('Time');
            %     title('Grating Order - 270 - 90');
            %
            %     subplot(3,2,6)
            %     spk_rasterplot_bfsgradFS(SPKdata_fs_90);
            %     ylabel('Trials');
            %     xlabel('Time');
            %     title('Grating Order - 90 - 270');
            
            
            %     saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'jpg')
            %     saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'ai')
            %     saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'fig')        
            
        end        
        
    end
    
    suplabel(strcat('PSTH - channel number - ', num2str(chan)),'t');
    
    pause
    delete(allchild(0))
    
end


    