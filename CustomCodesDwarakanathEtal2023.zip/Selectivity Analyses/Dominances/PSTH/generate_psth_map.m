function generate_psth_map(jMUspikes, tim_window_SOA, sigma, sav_dir_psth, chan2elec, elec_map, pa_sites, fs_sites, pa_fs_sites)

% This code takes input as the jMUspikes, tim_window_SOA, sigma(the width
% of the kernel), directory to save the PSTHs, chan2elec conversion, sites
% for which PSTH should be plotted in bold in PA or FS conditions.
% The PSTHs are generated using the psth function from chronux. Rasters are
% also plotted for the two different conditions. The 'spikesSOAligned' are
% used for generating the psths.
% 
% % Usage: generate_psth_map
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/4/19
% 

cd(sav_dir_psth)

for chan = 1:length(jMUspikes.data)
    
    tim_window = tim_window_SOA;
    
    % stimulus change - 90 to 270
    cond_pa_90 = [jMUspikes.data{chan}.spikesSOAligned{5} jMUspikes.data{chan}.spikesSOAligned{7}];
    cond_fs_90 = [jMUspikes.data{chan}.spikesSOAligned{1} jMUspikes.data{chan}.spikesSOAligned{3}];

    % stimulus change - 270 to 90
    
    cond_pa_270 = [jMUspikes.data{chan}.spikesSOAligned{6} jMUspikes.data{chan}.spikesSOAligned{8}];
    cond_fs_270 = [jMUspikes.data{chan}.spikesSOAligned{2} jMUspikes.data{chan}.spikesSOAligned{4}];

    
    %% Convert the spike timing data into chronux format and smooth with chronux
    
    % stimulus change - 90 to 270
    [SPKdata_pa_90] = spikesSOAligned2ChrSpk(cond_pa_90);
    [SPKdata_fs_90] = spikesSOAligned2ChrSpk(cond_fs_90);
    [sdf_pa_90, t, err_pa_90] = psth(SPKdata_pa_90, sigma, 'n', tim_window);
    [sdf_fs_90, t, err_fs_90] = psth(SPKdata_fs_90, sigma, 'n', tim_window);
    
    % stimulus change - 270 to 90
    [SPKdata_pa_270] = spikesSOAligned2ChrSpk(cond_pa_270);
    [SPKdata_fs_270] = spikesSOAligned2ChrSpk(cond_fs_270);
    [sdf_pa_270, t, err_pa_270] = psth(SPKdata_pa_270, sigma, 'n', tim_window);
    [sdf_fs_270, t, err_fs_270] = psth(SPKdata_fs_270, sigma, 'n', tim_window);

    elec = chan2elec(chan,2);
%     figure
    [r(chan),c(chan)] = find(elec_map == elec);
    figure(1)
%     figure('units','normalized','outerposition',[0 0 1 1])
    subplot2(10,10,r(chan),c(chan));
    hold on;
%     errorbar(t,sdf_pa_90,err_pa_90,'k');
%     errorbar(t,sdf_fs_90,err_fs_90,'r');
%     errorbar(t,sdf_pa_270,err_pa_270,'b');
%     errorbar(t,sdf_fs_270,err_fs_270,'g');

if find(pa_sites(:)==chan)
    plot(t,sdf_pa_270,'k','LineWidth',2)
    plot(t,sdf_pa_90,'k:','LineWidth',2) 
    vline_vk([0 2]);
    xlim(tim_window); 
    if find(pa_fs_sites(:)==chan)
        box on;
    end
else
    plot(t,sdf_pa_270,'k')
    plot(t,sdf_pa_90,'k:') 
    vline_vk([0 2]);
    xlim(tim_window); 
end
%     title(strcat('PSTH - Physical Alternation - channel number - ', num2str(chan)));
%     legend('Physical Alternation - 270 - 90','Physical Alternation - 90 - 270','Location','NorthOutside')
       
    figure(3)
    subplot2(10,10,r(chan),c(chan))
    hold on;
    
    if find(fs_sites(:)==chan)        
        plot(t,sdf_fs_270,'r','LineWidth',2)
        plot(t,sdf_fs_90,'r:','LineWidth',2)
        vline_vk([0 2]);
        xlim(tim_window);
        if find(pa_fs_sites(:)==chan)
            box on;
        end
    else
        plot(t,sdf_fs_270,'r')
        plot(t,sdf_fs_90,'r:')
        vline_vk([0 2]);
        xlim(tim_window);
    end
%     title(strcat('PSTH - Binocular Rivalry - channel number - ', num2str(chan)));
%     legend('Flash Suppression - 270 - 90','Flash Suppression - 90 - 270','Location','NorthOutside')     
    
%     pause
        
end

figure(1)
set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.
suplabel('Time (seconds)','x');
suplabel('Spikes/second','y');
suplabel('Physical Alternation','t');
pa_hl = legend('Physical Alternation - 270 - 90','Physical Alternation - 90 - 270');
set(pa_hl,'Position', [0.8487 0.9291 0.1172 0.0459]);

saveas(gcf,strcat('PSTH - MAP - Physical Alternation'),'jpg')
saveas(gcf,strcat('PSTH - MAP - Physical Alternation'),'ai')
saveas(gcf,strcat('PSTH - MAP - Physical Alternation'),'fig')

figure(3)
set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.
suplabel('Time (seconds)','x');
suplabel('Spikes/second','y');
suplabel('Flash Suppression','t');
fs_hl = legend('Physical Alternation - 270 - 90','Physical Alternation - 90 - 270');
set(fs_hl,'Position', [0.8487 0.9291 0.1172 0.0459]);

saveas(gcf,strcat('PSTH - MAP - Flash Suppression'),'jpg')
saveas(gcf,strcat('PSTH - MAP - Flash Suppression'),'ai')
saveas(gcf,strcat('PSTH - MAP - Flash Suppression'),'fig')

    