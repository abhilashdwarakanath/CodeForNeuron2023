function generate_psth_switches_map(jMUSwitches, tim_window_switch, sigma, sav_dir_psth, chan2elec,elec_map, bs_sites, as_sites, as_bs_sites)


% cd V:\H07\12-06-2016\PFC\Bfsgrad1\AbhiSwitches
% cd X:\H07\27-08-2016\PPC\Bfsgrad1\AbhiSwitches
% load jMUSwitchesByTimeVK

datadir = ('B:\H07\12-06-2016\PFC\Bfsgrad1\');
cd(datadir);

load('jMUSwitchesByTime');


cd('L:\projects\Vishal\PSTH_Results\H07\Bfsgrad\12-06-2016\PFC\PSTH_Switches\AbhiSwitches');

tim_window_switch = [-1.5 1.5];

sigma = 0.040;

% cd V:\H07\12-06-2016\PFC\Bfsnatur1\
% load jMUSpikesByTime
% cd L:\projects\Vishal\PSTH_Results\H07_Bfsnatur
% tim_window_SOA = [-0.3 2.3];
% tim_window_MOA = [-1.3 1.3];

for chan = 1:length(jMUSwitches.data.spikesByTime_90TO270)
    
    %     chan = 29;
    tim_window = tim_window_switch;
    
    % stimulus change - 90 to 270
    switch_fs_90to270 = [jMUSwitches.data.spikesByTime_90TO270{chan}{1}  jMUSwitches.data.spikesByTime_90TO270{chan}{2}...
        jMUSwitches.data.spikesByTime_90TO270{chan}{3}  jMUSwitches.data.spikesByTime_90TO270{chan}{4}];
    
    % stimulus change - 270 to 90
    
    switch_fs_270to90 = [jMUSwitches.data.spikesByTime_270TO90{chan}{1}  jMUSwitches.data.spikesByTime_270TO90{chan}{2}...
        jMUSwitches.data.spikesByTime_270TO90{chan}{3}  jMUSwitches.data.spikesByTime_270TO90{chan}{4}];
    
    
    %% Convert the spike timing data into chronux format and smooth with chronux
    
    if ((sum(~cellfun('isempty',switch_fs_90to270))>0) && (sum(~cellfun('isempty',switch_fs_270to90))>0))
        
        % stimulus change - 90 to 270
        [SPKdata_fs_90to270] = spikesSOAligned2ChrSpk(switch_fs_90to270);
        [sdf_fs_90to270, t, err_fs_90to270] = psth(SPKdata_fs_90to270, sigma, 'n', tim_window);
        
        % stimulus change - 270 to 90
        [SPKdata_fs_270to90] = spikesSOAligned2ChrSpk(switch_fs_270to90);
        [sdf_fs_270to90, t, err_fs_270to90] = psth(SPKdata_fs_270to90, sigma, 'n', tim_window);
        
        elec = chan2elec(chan,2);
        %     figure
        [r(chan),c(chan)] = find(elec_map == elec);
        figure(1)
        %     figure('units','normalized','outerposition',[0 0 1 1])
        subplot2(10,10,r(chan),c(chan));
        hold on;
        
        if find(bs_as_sites(:)==chan)
            %     if mod(length(t),2)
            plot(t,sdf_fs_90to270,'r:','LineWidth',2);
            plot(t,sdf_fs_270to90,'r','LineWidth',2);
            
        elseif find(bs_sites(:)==chan)
            
            plot(t(1:(length(t)/2)),sdf_fs_90to270(1:(length(t)/2)),'r:','LineWidth',2);
            plot(t((length(t)/2)+1:end),sdf_fs_90to270((length(t)/2)+1:end),'r:');
            plot(t(1:(length(t)/2)),sdf_fs_270to90(1:(length(t)/2)),'r','LineWidth',2);
            plot(t((length(t)/2)+1:end),sdf_fs_270to90((length(t)/2)+1:end),'r');
            
        elseif find(as_sites(:)==chan)
            
            plot(t(1:(length(t)/2)),sdf_fs_90to270(1:(length(t)/2)),'r:');
            plot(t((length(t)/2)+1:end),sdf_fs_90to270((length(t)/2)+1:end),'r:','LineWidth',2);
            plot(t(1:(length(t)/2)),sdf_fs_270to90(1:(length(t)/2)),'r');
            plot(t((length(t)/2)+1:end),sdf_fs_270to90((length(t)/2)+1:end),'r','LineWidth',2);
            
        else
            plot(t,sdf_fs_90to270,'k')
            plot(t,sdf_fs_270to90,'k:')
            
        end
        
        vline_vk([0]);
        xlim(tim_window);
        
        
    end
end
figure(1)
set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.
suplabel('Time (seconds)','x');
suplabel('Spikes/second','y');
suplabel('PSTH - Switches','t');
pa_hl = legend('90 TO 270','270 TO 90');
set(pa_hl,'Position', [0.8487 0.9291 0.1172 0.0459]);

saveas(gcf,strcat('PSTH - MAP - Physical Alternation'),'jpg')
saveas(gcf,strcat('PSTH - MAP - Physical Alternation'),'ai')
saveas(gcf,strcat('PSTH - MAP - Physical Alternation'),'fig')    
    