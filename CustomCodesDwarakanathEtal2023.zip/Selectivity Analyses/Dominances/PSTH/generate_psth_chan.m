function generate_psth_chan

% cd V:\H07\12-06-2016\PFC\Bfsgrad1
cd X:\H07\27-08-2016\PPC\Bfsgrad1
% cd V:\A11\22-07-2016\PFC\Bfsgrad1
load jMUSpikesByTime
% jMUspikes = jMUspikes_bessel;
cd L:\projects\Vishal\PSTH_Results\H07\Bfsgrad\27-08-2016\PPC\PSTH_SOA_MOA
% cd L:\projects\Vishal\PSTH_Results\H07_Bfsgrad_Bessel


tim_window_SOA = [-0.3 8.5];
tim_window_MOA = [-2.3 6.5];

sigma = 0.040;

% cd V:\H07\12-06-2016\PFC\Bfsnatur1\
% load jMUSpikesByTime
% cd L:\projects\Vishal\PSTH_Results\H07_Bfsnatur
% tim_window_SOA = [-0.3 2.3];
% tim_window_MOA = [-1.3 1.3];

for chan = 1:length(jMUspikes.data)
    
%     chan = 7;
    tim_window = tim_window_SOA;
    
    % stimulus change - 90 to 270
    cond_pa_90 = [jMUspikes.data{chan}.spikesSOAligned{5} jMUspikes.data{chan}.spikesSOAligned{7}];
    cond_fs_90 = [jMUspikes.data{chan}.spikesSOAligned{1} jMUspikes.data{chan}.spikesSOAligned{3}];

    % stimulus change - 270 to 90
    
    cond_pa_270 = [jMUspikes.data{chan}.spikesSOAligned{6} jMUspikes.data{chan}.spikesSOAligned{8}];
    cond_fs_270 = [jMUspikes.data{chan}.spikesSOAligned{2} jMUspikes.data{chan}.spikesSOAligned{4}];
    
    %% Convert the spike timing data into chronux format and smooth with chronux
    
    % stimulus change - 90 to 270
    [SPKdata_pa_90] = spikesSOAligned2ChrSpk(cond_pa_90);
    [SPKdata_fs_90] = spikesSOAligned2ChrSpk(cond_fs_90);
    [sdf_pa_90, t, err_pa_90] = psth(SPKdata_pa_90, sigma, 'n', tim_window);
    [sdf_fs_90, t, err_fs_90] = psth(SPKdata_fs_90, sigma, 'n', tim_window);
    
    % stimulus change - 270 to 90
    [SPKdata_pa_270] = spikesSOAligned2ChrSpk(cond_pa_270);
    [SPKdata_fs_270] = spikesSOAligned2ChrSpk(cond_fs_270);
    [sdf_pa_270, t, err_pa_270] = psth(SPKdata_pa_270, sigma, 'n', tim_window);
    [sdf_fs_270, t, err_fs_270] = psth(SPKdata_fs_270, sigma, 'n', tim_window);

    
%     figure(chan)
    figure('units','normalized','outerposition',[0 0 1 1])
    subplot(2,1,1)
    hold on;
%     errorbar(t,sdf_pa_90,err_pa_90,'k');
%     errorbar(t,sdf_fs_90,err_fs_90,'r');
%     errorbar(t,sdf_pa_270,err_pa_270,'b');
%     errorbar(t,sdf_fs_270,err_fs_270,'g');

    plot(t,sdf_pa_270,'k')
    plot(t,sdf_fs_270,'r')
    plot(t,sdf_pa_90,'k:')
    plot(t,sdf_fs_90,'r:')
    vline_vk([0 2]);
    xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
    title(strcat('PSTH - Stimulus Onset Aligned - channel number - ', num2str(chan)));
    legend('Physical Alternation - 270 - 90','Flash Suppression - 270 - 90','Physical Alternation - 90 - 270','Flash Suppression - 90 - 270')
    
%     saveas(gcf,strcat('PSTH - MOA - site - ', num2str(chan)),'jpg')
%     saveas(gcf,strcat('PSTH - MOA - site - ', num2str(chan)),'ai')
%     saveas(gcf,strcat('PSTH - MOA - site - ', num2str(chan)),'fig')
    
    %% Calculate the PSTH for spikes aligned to Mask Onset    
    
    tim_window = [];
    tim_window = tim_window_MOA;
    
    % stimulus change - 90 to 270
    cond_pa_90 = [jMUspikes.data{chan}.spikesMOAligned{5} jMUspikes.data{chan}.spikesMOAligned{7}];
    cond_fs_90 = [jMUspikes.data{chan}.spikesMOAligned{1} jMUspikes.data{chan}.spikesMOAligned{3}];

    % stimulus change - 270 to 90
    
    cond_pa_270 = [jMUspikes.data{chan}.spikesMOAligned{6} jMUspikes.data{chan}.spikesMOAligned{8}];
    cond_fs_270 = [jMUspikes.data{chan}.spikesMOAligned{2} jMUspikes.data{chan}.spikesMOAligned{4}];
    
    %% Convert the spike timing data into chronux format and smooth with chronux
    
    % stimulus change - 90 to 270
    [SPKdata_pa_90] = spikesSOAligned2ChrSpk(cond_pa_90);
    [SPKdata_fs_90] = spikesSOAligned2ChrSpk(cond_fs_90);
    [sdf_pa_90, t, err_pa_pf] = psth(SPKdata_pa_90, sigma, 'n', tim_window);
    [sdf_fs_90, t, err_fs_pf] = psth(SPKdata_fs_90, sigma, 'n', tim_window);
    
    % stimulus change - 270 to 90
    [SPKdata_pa_270] = spikesSOAligned2ChrSpk(cond_pa_270);
    [SPKdata_fs_270] = spikesSOAligned2ChrSpk(cond_fs_270);
    [sdf_pa_270, t, err_pa_pf] = psth(SPKdata_pa_270, sigma, 'n', tim_window);
    [sdf_fs_270, t, err_fs_pf] = psth(SPKdata_fs_270, sigma, 'n', tim_window);

    
%     figure(chan)
    subplot(2,1,2)
    hold on;
    plot(t,sdf_pa_270,'k')
    plot(t,sdf_fs_270,'r')
    plot(t,sdf_pa_90,'k:')
    plot(t,sdf_fs_90,'r:')
    vline_vk([-2 0]);
    xlim(tim_window); xlabel('Time (seconds)'); ylabel('Spikes/second');
    title(strcat('PSTH - Mask Onset Aligned - channel number - ', num2str(chan)));
    
    saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'jpg')
    saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'ai')
    saveas(gcf,strcat('PSTH - site - ', num2str(chan)),'fig')
    
%     pause
    close all
        
end
    
    