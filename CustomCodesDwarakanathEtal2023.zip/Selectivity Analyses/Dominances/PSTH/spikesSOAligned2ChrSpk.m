function [w] = spikesSOAligned2ChrSpk(data_spikesByTime)

for i = 1:size(data_spikesByTime,2)
    w(i).spiketime = data_spikesByTime{i}/1000;
end
    
    