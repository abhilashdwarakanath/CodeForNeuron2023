function [spk_dom90, spk_dom270] = get_spk_flashdom(domData,valid_idx)

%% This code puts gets the spiking activity based upon a list of valid_idx for the dominance duration.
% 
% Input: 
% 
% 1. dominances: a structure with spiking activity for all dominance durations
% 2. valid_idx: a list of valid idx for both 90 and 270 dominance
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/6/29


%% Get the spiking activity during dominance periods specified by valid_idx

for chan = 1:length(domData.dom90)
    
    for iCond = 1:length(valid_idx.dom90)
        
        spk_dom90{chan}{iCond} =  domData.dom90{chan}{iCond}(valid_idx.dom90{iCond});
        spk_dom270{chan}{iCond} = domData.dom270{chan}{iCond}(valid_idx.dom270{iCond});
        
    end
    
end