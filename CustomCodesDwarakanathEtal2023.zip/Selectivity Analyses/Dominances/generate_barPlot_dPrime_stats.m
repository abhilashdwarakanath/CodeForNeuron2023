function generate_barPlot_dPrime_stats(pref_sim, pa_dprime, ttl_suffix, sav_dir, sav_fig)



%% Get the various categories of units according to d-prime criterion

% all units without a d-prime criterion
prcnt_sel_both = (size(pref_sim.com_sig_u,1)/size(pref_sim.pri_sig_u,1))*100;
prcnt_sel_pri = ((size(pref_sim.only_pri_sig_u,1)+size(pref_sim.pri_diff_sig_u_mat,1))/... 
    size(pref_sim.pri_sig_u,1))*100;

% all units with a d-prime in the pri condition of > 1.

pri_dPrime_over1_u = pref_sim.pri_sig_u(find(pa_dprime(pref_sim.pri_sig_u(:,3))>=1),:);
[over1_pri_idx, over1_sec_idx] = ismember(pri_dPrime_over1_u,pref_sim.sec_sig_u,'rows');

prct_sel_both_dPrime_plus1_u = (size(pri_dPrime_over1_u(over1_pri_idx,:),1)/size(pri_dPrime_over1_u,1))*100;
prct_sel_pri_dPrime_plus1_u = (size(pri_dPrime_over1_u(~over1_pri_idx,:),1)/size(pri_dPrime_over1_u,1))*100;

% all units with a d-prime in the pri condition of > 1.

pri_dPrime_below1_u = pref_sim.pri_sig_u(find(pa_dprime(pref_sim.pri_sig_u(:,3))<1),:);
[below1_pri_idx, below1_sec_idx] = ismember(pri_dPrime_below1_u,pref_sim.sec_sig_u,'rows');

prct_sel_both_dPrime_below1_u = (size(pri_dPrime_below1_u(below1_pri_idx,:),1)/size(pri_dPrime_below1_u,1))*100;
prct_sel_pri_dPrime_below1_u = (size(pri_dPrime_below1_u(~below1_pri_idx,:),1)/size(pri_dPrime_below1_u,1))*100;

% prepare the bar data for plotting

bar_data = [prct_sel_both_dPrime_below1_u prct_sel_pri_dPrime_below1_u; ...
    prcnt_sel_both prcnt_sel_pri; ...
    prct_sel_both_dPrime_plus1_u prct_sel_pri_dPrime_plus1_u]


%% Generate the statistics figure

% prepare the appropriate text strings for the figure

txt_strings = {strcat(num2str(size(pri_dPrime_below1_u(below1_pri_idx,:),1)),'/',num2str(size(pri_dPrime_below1_u,1))); ...
    strcat(num2str(size(pref_sim.com_sig_u,1)),'/',num2str(size(pref_sim.pri_sig_u,1))); ...
    strcat(num2str(size(pri_dPrime_over1_u(over1_pri_idx,:),1)),'/',num2str(size(pri_dPrime_over1_u,1)))};


% make the bar plot

figure
B = bar(bar_data,'stacked');

C = ['g','r'];
for n = 1:length(B)
    set(B(n),'FaceColor',C(n),'LineWidth',2);
end
ylim([0 130]);
set(gca, 'XTickLabel',{'d-prime < 1','All sensory selective units','d-prime > 1'}, 'YTick',[0:20:100],'YTickLabel', [0:20:100]);
grid ON
xlabel('sensory selectivity - dprime');
ylabel('selective sites [%]');
legend({'sensory and perceptually modulated';'sensory and not perceptually modulated'})
title(strcat('d-Prime Statistics',ttl_suffix));

% add the text regarding the units

for nTxt = 1:size(txt_strings,1)
    text(nTxt,4,txt_strings(nTxt,:),'fontsize',13,'fontweight','bold',...
        'HorizontalAlignment','center','VerticalAlignment','bottom');
end

% save the figure

if sav_fig == 1
    
    cd(sav_dir)
    saveas(gcf,'d-Prime - Preference Statistics','ai')
    saveas(gcf,'d-Prime - Preference Statistics','fig');
    exportfig(gcf,'d-Prime - Preference Statistics','Format','jpeg','Color','rgb')
    exportfig(gcf,'d-Prime - Preference Statistics','Format','eps','Color','rgb')
    
end



    