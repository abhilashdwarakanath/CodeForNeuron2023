function generate_sdf_map_dom_bfsgrad(sdf_dom, pref_array_dom, jMUDominances, sav_dir, ttl_suffix, sav_fig)

%% This code generates SDF - Maps according to electrode's array location for bfsgrad
% 
% Input: 
% 
% 1. sdf_dom: the sdf data with psths
% 2. pref_array: preference arrays
% 3. jMUDominances: data structure with spikes
% 4. sav_dir: saving directory
% 5. ttl_suffix: title for the sdf maps
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/07/5


%% get the appropriate parameters necessary for plotting

tim_window = sdf_dom.t;
chan2elec = jMUDominances.chanElecs.electrodeInfo;
elec_map = jMUDominances.map;

%% physical alternation condition

sig_typ = 'Phy_Dom_MUA';
[dat,figProps] = generate_data4map(sig_typ, sdf_dom, ttl_suffix);

bold_sites = pref_array_dom.pref_sim_Dom_PhyRiv.pri_sig_u(:,3);
boxed_sites = pref_array_dom.pref_sim_Dom_PhyRiv.com_sig_u(:,3);

% sav_fig = saveOrNot(an_info.sdfMap_PA);
generate_dat_map(dat, tim_window, chan2elec, elec_map, bold_sites, boxed_sites, figProps, sav_dir, sav_fig)
bold_sites = []; boxed_sites = [];

%% rivalry condition

sig_typ = 'Riv_Dom_MUA';
[dat,figProps] = generate_data4map(sig_typ, sdf_dom, ttl_suffix);

bold_sites = pref_array_dom.pref_sim_Dom_PhyRiv.sec_sig_u(:,3);
boxed_sites = pref_array_dom.pref_sim_Dom_PhyRiv.com_sig_u(:,3);

% sav_fig = saveOrNot(an_info.sdfMap_PA);
generate_dat_map(dat, tim_window, chan2elec, elec_map, bold_sites, boxed_sites, figProps, sav_dir, sav_fig)
bold_sites = []; boxed_sites = [];









