%% Analysis Pipeline
% % function analyze_mua_bfsgrad(ds_info, an_info,array_idx)
datadir = ('B:\H07\12-06-2016\PFC\Bfsgrad1\');
cd(datadir);

%% Load jMUspikesbytime data

load('jMUSpikesByTime');

%% Generate PSTHs with rasters and store them 

tim_window_SOA = [-0.3 4];
sigma = 0.040;
% sav_dir_psth = ('L:\projects\Vishal\PSTH_Results\H07\Bfsgrad\12-06-2016\PFC\PSTH_Rasters');

% sav_dir_psth = strcat('B:\Results\',ds_info.monk,'\',ds_info.dataset,'\Bfsgrad\',ds_info.activeArray{array_idx},... 
%     '\MUA\PSTH_Sites\PSTH_MOAligned');

sav_dir_psth = ('B:\Results\H07\12-06-2016\Bfsgrad\PFC\MUA\PSTH_Sites\PSTH_SOAligned');

generate_psth_chan_pa_fs(jMUspikes, tim_window_SOA, sigma, sav_dir_psth)

%% convert mua data for further analysis

spkTyp = 'SOA';
[muadata_soa] = convMuaFormat(jMUspikes.data,spkTyp);

spkTyp = 'MOA';
[muadata_moa] = convMuaFormat(jMUspikes.data,spkTyp);

%% Get spikesparse matrices for a given time window

binWidth = 20;

offset_stimon = -300;
tWin_soa = 4000;
[res_mua_soa] = spkByTime2spkSparse(muadata_soa,binWidth,offset_stimon,tWin_soa);

offset_maskon = -2300;
tWin_moa = 2000;
[res_mua_moa] = spkByTime2spkSparse(muadata_moa,binWidth,offset_maskon,tWin_moa);


%% Check Preferences in PA/FS

% Assign parameters 

% Time Window for analysis; % Test type
tim_win = [0 1500]; tst_typ = ('spike count');

% Conditions for Physical Alternation condition/Flash Suppression Condition
cond_wanted_pa = {'PA_R90_L270';'PA_L90_R270';'PA_R270_L90';'PA_L270_R90'};
cond_wanted_fs = {'BR_R90_L270';'BR_L90_R270';'BR_R270_L90';'BR_L270_R90'}; 

% in PA condition

[pa_pref_array,pa_dprime] = check_preference_mua(tim_win, muadata_moa, cond_wanted_pa, tst_typ);

% in FS condition

[fs_pref_array,fs_dprime] = check_preference_mua(tim_win, muadata_moa, cond_wanted_fs, tst_typ);

%% Check if the preference is maintained across conditions

% PA and FS - same preference
[pref_sim] = check_pref_sim(pa_pref_array,fs_pref_array);
 
%  Make a bar plot with all the preferences

generate_barplot_stats(pref_sim);

%% Make a d-prime scatter of all the sites retaining preference and
% selectivity.

makefig_scatter_dprime(pref_sim, pa_dprime, fs_dprime);

%% Generate Population PSTHs

trl_dur = abs(offset_maskon)+tWin_moa;
tim_trl_dur = [binWidth:binWidth:trl_dur];

% Sites significantly modulated in both conditions

pref_com_sim_mu = pref_sim.com_sig_u;
units_typ = strcat('Mean of - ',num2str(length(pref_com_sim_mu)),'- Sites significantly modulated in both conditions');
generate_population_mu_psth(res_mua_moa,pref_com_sim_mu,units_typ,binWidth,tim_trl_dur);
units_typ = [];

% Sites significantly modulated in the physical alternation condition.

pref_pa_sig_mu = pref_sim.pri_sig_u;
units_typ = strcat('Mean of - ',num2str(length(pref_pa_sig_mu)),'- Sites significantly modulated in PA conditions');
generate_population_mu_psth(res_mua_moa,pref_pa_sig_mu,units_typ,binWidth,tim_trl_dur);
units_typ = [];

% Sites significantly modulated in the flash suppression condition.

pref_fs_sig_mu = pref_sim.sec_sig_u;
units_typ = strcat('Mean of - ',num2str(length(pref_fs_sig_mu)),'- Sites significantly modulated in FS conditions');
generate_population_mu_psth(res_mua_moa,pref_fs_sig_mu,units_typ,binWidth,tim_trl_dur);
units_typ = [];


% Sites significantly modulated in only the physical alternation condition
% but not flash suppression condition

pref_paOnly_sig_mu = pref_sim.only_pri_sig_u;
units_typ = strcat('Mean of - ',num2str(length(pref_paOnly_sig_mu)),'- Sites significantly modulated only in PA conditions');
generate_population_mu_psth(res_mua_moa,pref_paOnly_sig_mu,units_typ,binWidth,tim_trl_dur);
units_typ = [];


% Sites significantly modulated in only the flash suppression condition
% but not physical alternation condition


pref_fsOnly_sig_mu = pref_sim.only_sec_sig_u;
units_typ = strcat('Mean of - ',num2str(length(pref_fsOnly_sig_mu)),'- Sites significantly modulated only in FS conditions');
generate_population_mu_psth(res_mua_moa,pref_fsOnly_sig_mu,units_typ,binWidth,tim_trl_dur);
units_typ = [];


%% Check this again with another dataset before implementing.
% Sites with opposite preference in the physical alternation and flash
% suppression condition. 

% % % % pref_paOpp_sig_mu = pref_sim.pri_diff_sig_u_mat;
% % % % units_typ = strcat('Mean of - ',num2str(length(pref_paOpp_sig_mu)),'- Sites significantly modulated in the PA condition in the opposite direction');
% % % % generate_population_mu_psth(res_mua_moa,pref_paOpp_sig_mu,units_typ,binWidth,tim_trl_dur);
% % % % units_typ = [];
% % % % 
% % % % pref_fsOpp_sig_mu = pref_sim.sec_diff_sig_u_mat;
% % % % units_typ = strcat('Mean of - ',num2str(length(pref_fsOpp_sig_mu)),'- Sites significantly modulated in the FS condition in the opposite direction');
% % % % generate_population_mu_psth(res_mua_moa,pref_fsOpp_sig_mu,units_typ,binWidth,tim_trl_dur);
% % % % units_typ = [];

%% Load jMUSwitches data

load('jMUSwitchesByTime');

%% Generate switch related PSTHs and store them
tim_window_Switch = [-1.5 1.5];
sigma = 0.040;
sav_dir_psth = ('B:\Results\H07\12-06-2016\Bfsgrad\PFC\MUA\PSTH_Sites\PSTH_Switches');

generate_psth_switches_chan(jMUSwitches, tim_window_Switch, sigma, sav_dir_psth)


%% convert mua data for further analysis

muadata1 = jMUSwitches.data.spikesByTime_90TO270;
muadata2 = jMUSwitches.data.spikesByTime_270TO90;


%% Get spikesparse matrices for a given time window

offset_switch = -1500;
tWin_switch = 1500;
[res_mua_90TO270] = spkByTime2spkSparse(muadata1,binWidth,offset_switch,tWin_switch);

offset_switch = -1500;
tWin_switch = 1500;
[res_mua_270TO90] = spkByTime2spkSparse(muadata2,binWidth,offset_switch,tWin_switch);

%% Check Preferences related to switch

% Assign Parameters
tst_typ = ('spike count');
tst_cnd = ('rivalry');
tst_cnd = ('physical');

% before switch

tim_win = [-1500 0];
[bs_pref_array]=check_preference_switch_mua(tim_win, muadata1, muadata2, tst_typ,tst_cnd);

% after switch

tim_win = [0 1500];
[as_pref_array]=check_preference_switch_mua(tim_win, muadata1, muadata2, tst_typ,tst_cnd);


%% before switch and after switch

[pref_sim_switch] = check_pref_sim(bs_pref_array,as_pref_array);

%% Generate Population PSTHs

trl_dur = abs(offset_switch)+tWin_switch;
tim_trl_dur = [(offset_switch+binWidth):binWidth:tWin_switch];
calc_typ = 'switch_first';
calc_typ = 'site_first';


% Sites significantly modulated both before and after the switch

pref_com_sim_mu = pref_sim_switch.com_sig_u;
units_typ = strcat('Mean of - ',num2str(length(pref_com_sim_mu)),'- Sites significantly modulated before/after switch in the same direction');
generate_population_mu_psth_switch(res_mua_90TO270,res_mua_270TO90,pref_com_sim_mu,units_typ,binWidth,tim_trl_dur,calc_typ);
units_typ = [];

% All Sites significantly modulated before the switch.

pref_bs_sig_mu = pref_sim_switch.pri_sig_u;
units_typ = strcat('Mean of - ',num2str(length(pref_bs_sig_mu)),'- Sites significantly modulated before the switch');
generate_population_mu_psth_switch(res_mua_90TO270,res_mua_270TO90,pref_bs_sig_mu,units_typ,binWidth,tim_trl_dur,calc_typ);
units_typ = [];

% All Sites significantly modulated after the switch.

pref_as_sig_mu = pref_sim_switch.sec_sig_u;
units_typ = strcat('Mean of - ',num2str(length(pref_as_sig_mu)),'- Sites significantly modulated after the switch');
generate_population_mu_psth_switch(res_mua_90TO270,res_mua_270TO90,pref_as_sig_mu,units_typ,binWidth,tim_trl_dur,calc_typ);
units_typ = [];

% Sites significantly modulated before/after or both around the switch.

pref_ComBsAs_sig_mu = [pref_com_sim_mu;pref_bs_sig_mu;pref_as_sig_mu];
pref_ComBsAs_sig_mu = unique(pref_ComBsAs_sig_mu,'rows');

units_typ = strcat('Mean of - ',num2str(length(pref_ComBsAs_sig_mu)),'- Sites significantly modulated before/after or both around the switch');
generate_population_mu_psth_switch(res_mua_90TO270,res_mua_270TO90,pref_ComBsAs_sig_mu,units_typ,binWidth,tim_trl_dur,calc_typ);
units_typ = [];


% Sites significantly modulated in only before the switch but not after.

pref_bsOnly_sig_mu = pref_sim_switch.only_pri_sig_u;
units_typ = strcat('Mean of - ',num2str(length(pref_bsOnly_sig_mu)),'- Sites significantly modulated only after the switch');
generate_population_mu_psth_switch(res_mua_90TO270,res_mua_270TO90,pref_bsOnly_sig_mu,units_typ,binWidth,tim_trl_dur,calc_typ);
units_typ = [];

% Sites significantly modulated in only after the switch but not before.

pref_asOnly_sig_mu = pref_sim_switch.only_sec_sig_u;
units_typ = strcat('Mean of - ',num2str(length(pref_asOnly_sig_mu)),'- Sites significantly modulated only after the switch');
generate_population_mu_psth_switch(res_mua_90TO270,res_mua_270TO90,pref_asOnly_sig_mu,units_typ,binWidth,tim_trl_dur,calc_typ);
units_typ = [];

%% FS and rivalry - same preference



%% PA, FS and before switch - same preference


