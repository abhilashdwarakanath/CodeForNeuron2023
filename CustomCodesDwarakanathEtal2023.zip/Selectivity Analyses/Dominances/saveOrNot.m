function [sav_fig] = saveOrNot(info2check)

% This code takes input as the status if a certain figure was already saved or not.
% Helper function for various functions. Typical input an_info.'the figure type to check'
% 
% % Usage: saveOrNot(info2check)
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/5/10
% 


if info2check == 0
    sav_fig = 1;
else
    sav_fig = 0;
end