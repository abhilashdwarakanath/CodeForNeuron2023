function [flashDomPulse,spk_flashDom] = get_flashDom_paData(jMUspikes,jMUDominances)

%% This code generates a list of valid_idx for the dominance duration.
% 
% Input: 
% 
% 1. jMUspikes: the jMUspikes structure
% 2. jMUDominances: the jMUDominances structure
%
% Output:
% 
% 1. flashDomPulse: the duration of flash dominance
% 2. spk_flashDom: the spikes during the flash dominance (-1000 ms)
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/09/29
% 


%% Get all the required variables from the structures

evt_times = jMUspikes.data{1}.eventTimes;
evt_idx = jMUDominances.data.events;

flashDomPulse = jMUDominances.data.domDur.flashDomPulase;
spk_flashDom = jMUDominances.data.flashDomMOA;

%% Get the spikes and duration of the first dominance during physical alternation

for nChan = 1:length(jMUDominances.data.flashDomMOA)
    
    for pa_cond = 5:size(evt_idx,2)
        
        for iTrl = 1:size(evt_idx{pa_cond},2)
            
            tmp_evtIdx = find(evt_idx{pa_cond}{iTrl}==3)+1;
            tmp_evtTim = evt_times{pa_cond}{iTrl}(tmp_evtIdx);
            tmp_evtTim_MOA = evt_times{pa_cond}{iTrl}(tmp_evtIdx) - evt_times{pa_cond}{iTrl}(tmp_evtIdx-1);
            tmp_spks = jMUspikes.data{nChan}.spikesMOAligned{pa_cond}{iTrl};

            flashDomPulse{pa_cond}{iTrl} = tmp_evtTim_MOA*1000;
            spk_flashDom{nChan}{pa_cond}{iTrl} = tmp_spks(tmp_spks>-1000 & tmp_spks<flashDomPulse{pa_cond}{iTrl});            
            
            tmp_evtIdx = []; tmp_evtTim = []; tmp_evtTim_MOA = []; tmp_spks = [];
        end
        
    end
    
end
