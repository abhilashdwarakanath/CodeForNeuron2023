function generate_folder_structure(task,sig_typ,analysis_typ,ds_info,roi)

% This code takes in input as the task (Bfsgrad), the signal type (PSTH, LFP)
% analysis type (PSTH, Selectivity), and ds_info file and generates the
% appropriate folder structure for a given dataset, as provided in the
% ds_info.
% 
% % Usage: generate_folder_structure(task,sig_typ,analysis_typ,ds_info)
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/4/12
% 


%% Get into the parent directory
cd(strcat('E:/Data/Results/',ds_info.monk,'/'));

make_folder(ds_info.dataset,1);

%% Different experimental Types

switch task
    
    case 'Bfsgrad'
        
        make_folder(task,1);                
        make_folder(roi,1);        
        make_folder(sig_typ,1);
        
        %% Different Signal Types
        
        switch sig_typ
            
            case 'MUA'
                
                %% Different Analysis Types
                
                switch analysis_typ
                    
                    case 'PSTH'
                        
                        make_folder('PSTH_Sites',1);
                        make_folder('PSTH_SOAligned',0);
                        make_folder('PSTH_MOAligned',0);
                        make_folder('PSTH_Switches',0);
                        make_folder('PSTH_Dominances',0);
                        %                             make_folder('PSTH_Data',0);
                        
                        cd('..');
                        
                        make_folder('PSTH_Population',1);
                        
                        make_folder('PSTH_SOAligned',0);
                        make_folder('PSTH_MOAligned',0);
                        
                        make_folder('PSTH_Dominances',1);
                        make_folder('Switches_First',0);
                        make_folder('Sites_First',0);
                        
                        cd('..');
                        
                        make_folder('PSTH_Switches',1);
                        make_folder('Switches_First',0);
                        make_folder('Sites_First',0);
                        
                        cd('../..');
                        
                        make_folder('PSTH_Maps',0);
                        make_folder('PSTH_Movies',0);
                        
                        cd('..');
                        
                    case 'Selectivity'
                        
                        make_folder('Preference_Arrays',1);
                        make_folder('PA_FS',0);
                        make_folder('Switch',0);
                        make_folder('Dominance',0);
                        
                        cd('..');
                        
                        make_folder('Preference_Maps',0);
                        
                        make_folder('d_Prime',1);
                        make_folder('PA_FS',0);
                        make_folder('Switch',0); 
                        make_folder('Dominance',0);
                        
                end                
                
            case 'SUA'
                
                switch analysis_typ
                    
                    case 'PSTH'
                        
                        make_folder('PSTH_Sites',1);
                        make_folder('PSTH_SOAligned',0);
                        make_folder('PSTH_MOAligned',0);
                        make_folder('PSTH_Switches',0);
                        make_folder('PSTH_Dominances',0);
                        %                             make_folder('PSTH_Data',0);
                        
                        cd('..');
                        
                        make_folder('PSTH_Population',1);
                        
                        make_folder('PSTH_SOAligned',0);
                        make_folder('PSTH_MOAligned',0);
                        
                        make_folder('PSTH_Dominances',1);
                        make_folder('Switches_First',0);
                        make_folder('Sites_First',0);
                        
                        cd('..');
                        
                        make_folder('PSTH_Switches',1);
                        make_folder('Switches_First',0);
                        make_folder('Sites_First',0);
                        
                        cd('../..');
                        
                        make_folder('PSTH_Maps',0);
                        make_folder('PSTH_Movies',0);
                        
                        cd('..');
                        
                    case 'Selectivity'
                        
                        make_folder('Preference_Arrays',1);
                        make_folder('PA_FS',0);
                        make_folder('Switch',0);
                        make_folder('Dominance',0);
                        
                        cd('..');
                        
                        make_folder('Preference_Maps',0);
                        
                        make_folder('d_Prime',1);
                        make_folder('PA_FS',0);
                        make_folder('Switch',0); 
                        make_folder('Dominance',0);
                        
                        
                    case 'LFP'
                        
                        
                        
                        
                end
        end
end









