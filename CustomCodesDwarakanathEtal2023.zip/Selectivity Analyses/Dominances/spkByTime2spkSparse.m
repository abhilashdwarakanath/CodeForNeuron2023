function [res] = spkByTime2spkSparse(data,binWidth,Offset,tWin)

% Bins the spikes into bins of size 'binWidth' using sparse matrices.
%
% usage: res = spkByTime2spkSparse(data, binWidth, ,Offset, tWin);
% e.g:   res = a_muSpikesBinSparse(data, 10, 300, 4000);
%


trl_dur = abs(Offset)+tWin;
nChan = length(data);
% for d = 1 : nData

% 	 if isfield(data(d).exp,'trialTime')
%         B.trialTime = data(d).exp.trialTime;
%     else
%         B = a_trialTimes(data(d));
%      end
	nBins = ceil(trl_dur/binWidth);
	nCond = length(data{1});
%     [nChan,nCond] = size(data(d).muSpikesByTime);

	for n = 1 : nChan

		for c = 1 : nCond

			s = data{n}{c};
			nTrials = length(s);

			% create spikes matrix
			res(n).muSpikesSparse{c} = sparse(nBins,nTrials);

			for t = 1 : nTrials
                
                spk{t} = s{t}(s{t}>Offset & s{t}<tWin);
				bins = ceil((spk{t} - Offset) / binWidth);
				u = unique(bins);
                
				if length(u) > 1
					h = hist(bins,u);
					res(n).muSpikesSparse{c}(u,t) = h';
				else
					res(n).muSpikesSparse{c}(u,t) = length(bins);
                end
                
			end
		end
	end
end
