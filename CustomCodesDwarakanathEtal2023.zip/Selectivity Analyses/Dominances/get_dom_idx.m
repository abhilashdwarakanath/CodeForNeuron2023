function [valid_idx,valid_dur] = get_dom_idx(domDur,min_domDur,max_domDur)

%% This code generates a list of valid_idx for the dominance duration.
% 
% Input: 
% 
% 1. domDur: a structure with dominance durations
% 2. min_domDur: minimum dominance duration
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/6/29



%% Get the dominance durations of minimum duration

for i = 1:length(domDur.dom90)
    
    valid_idx.dom90{i} = find(cell2mat(domDur.dom90{i})>min_domDur & cell2mat(domDur.dom90{i})<max_domDur)+1;
    valid_idx.dom270{i} = find(cell2mat(domDur.dom270{i})>min_domDur & cell2mat(domDur.dom270{i})<max_domDur)+1;
    
    valid_dur.dom90{i} = cell2mat(domDur.dom90{i}(valid_idx.dom90{i}));
    valid_dur.dom270{i} = cell2mat(domDur.dom270{i}(valid_idx.dom270{i}));   

end  
  
