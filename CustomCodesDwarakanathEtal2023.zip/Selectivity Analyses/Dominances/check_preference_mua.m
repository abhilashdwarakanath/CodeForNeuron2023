function [pref_array, d_prime]=check_preference_mua(tim_win, muadata, cond_wanted, tst_typ)

%% This code assesses the preference across sites if they prefer the grating moving up or down, during the bfsgrad paradigm.
% It also calculates the d - prime.
% Input: 
% 
% 1. tim_win: Time window to use for assessing selectivity. Input should be a window
% in milliseconds
% 2. muadata: format - cell array (1*96). Each cell contains data from the
% eight different conditions.
% 3. cond_wanted: Conditions to use for assessing selecticity. When the input is more than two conditions, they should be put in order of the concatenation to take place.
% 4. tst_typ: 'spike count' OR 'mean psth'
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2016/10/20

%% Declare certain variables

[cond_to_compare, cond_to_compare_title] = get_conditions_bfsgrad(cond_wanted, 8);

%%

for num_chan = 1:size(muadata,2)
    
    temp_muadata_cond_one = []; temp_muadata_cond_two = [];
    spkCnt_cond1 = []; spkCnt_cond2 = [];
    cond_one_mean = []; cond_two_mean = [];
    
    pref_array{num_chan,5} = num_chan;
    
%% CASE: Spike Count
        
    if strcmp(tst_typ,'spike count')
        
        if length(cond_wanted) > 2
            
            temp_muadata_cond_one = [muadata{num_chan}{cond_to_compare(1)} muadata{num_chan}{cond_to_compare(2)}];
            temp_muadata_cond_two = [muadata{num_chan}{cond_to_compare(3)} muadata{num_chan}{cond_to_compare(4)}];
            
        else
            
            temp_muadata_cond_one = [muadata{num_chan}{cond_to_compare(1)}];
            temp_muadata_cond_two = [muadata{num_chan}{cond_to_compare(2)}];
            
        end
        
        for trl_cnd1 = 1:size(temp_muadata_cond_one,2)
            
            spkCnt_cond1(trl_cnd1) = length(find(temp_muadata_cond_one{trl_cnd1}>tim_win(1) & temp_muadata_cond_one{trl_cnd1}<tim_win(2)));
            
        end
        
        for trl_cnd2 = 1:size(temp_muadata_cond_two,2)
            
            spkCnt_cond2(trl_cnd2) = length(find(temp_muadata_cond_two{trl_cnd2}>tim_win(1) & temp_muadata_cond_two{trl_cnd2}<tim_win(2)));
            
        end
        
        cond_one_mean = mean(spkCnt_cond1);
        cond_two_mean = mean(spkCnt_cond2);
        
        p_val = [];
        [pref_array{num_chan,1}, p_val] = ranksum(spkCnt_cond1,spkCnt_cond2);
        pref_array{num_chan,2} = double(p_val);
                
        if  isnan(pref_array{num_chan,1})
            pref_array{num_chan,1} = 2;
            pref_array{num_chan,2} = 0;
        end
        
        
        if cond_one_mean > cond_two_mean
            
            pref_array{num_chan,3} = 1;
            
            d_prime(num_chan) = (cond_one_mean - cond_two_mean)/sqrt((var(spkCnt_cond1)+var(spkCnt_cond2))/2);
            
            if length(cond_wanted) > 2
                
                pref_array{num_chan,4} = {cond_to_compare_title(1,:);cond_to_compare_title(2,:)};
                
            else
                
                pref_array{num_chan,4} = {cond_to_compare_title(1,:)};
                
            end
            
        else
            
            pref_array{num_chan,3} = 2;
            
            d_prime(num_chan) = (cond_two_mean - cond_one_mean)/sqrt((var(spkCnt_cond2)+var(spkCnt_cond1))/2);
            
            if length(cond_wanted) > 2
                
                 pref_array{num_chan,4} = {cond_to_compare_title(3,:);cond_to_compare_title(4,:)};
                
            else
                
                 pref_array{num_chan,4} = {cond_to_compare_title(2,:)};
                
            end
            
        end
    
    end
    
end

