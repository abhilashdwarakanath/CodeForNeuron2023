function generate_barplot_stats(pref_sim, ttl_suffix, sav_dir, sav_fig, trl_phase)

%% A script to make a bar plot for the various statistics on the units.
% Usage: makefig_stats_pref(pref_sim,tit_suffix, sav_dir, sav_fig) or
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2016/10/25



%% Get the lengths of all the different unit types.

num_pa_sel = size(pref_sim.pri_sig_u,1); % selective during PA

num_fs_sel = size(pref_sim.sec_sig_u,1); % selective during FS

num_pa_fs_same_sel = size(pref_sim.com_sig_u,1); % selective for the same stimulus during PA & FS

prcnt_pa_fs_sel = (num_pa_fs_same_sel/num_pa_sel)*100; % Percentage selective in FS, similar to PA

num_pa_fs_opp_sel = size(pref_sim.pri_diff_sig_u_mat,1); % changing selectivity during PA and FS

num_only_pa_sel = size(pref_sim.only_pri_sig_u,1); % selective only in PA

num_only_fs_sel = size(pref_sim.only_sec_sig_u,1); % selective only in FS


%% Make and save the bar plot

figure('units','normalized','outerposition',[0 0 1 1])
bar([num_pa_sel;num_fs_sel;num_pa_fs_same_sel;prcnt_pa_fs_sel;num_pa_fs_opp_sel;num_only_pa_sel;num_only_fs_sel]);
xlabel('Unit Selection Criterion')
ylabel('Number or % of Units')
title(strcat('Preference statistics - data description',ttl_suffix));

if strcmp(trl_phase, 'BFS')
    
    set(gca, 'XTickLabel',{'PA selective','FS selective','Selective:PA and FS','% of PA, selective in FS','PA and FS - opposite preference','Only PA selective','Only FS selective'});
    
elseif strcmp(trl_phase, 'Dominance')
    
    set(gca, 'XTickLabel',{'PA selective','Riv selective','Selective:PA and Riv','% of PA, selective in Riv','PA and Riv - opposite preference','Only PA selective','Only Riv selective'});
    
end

if sav_fig ==1
    
    cd(sav_dir)
%    saveas(gcf,'Preference Statistics','ai')
    saveas(gcf,'Preference Statistics','fig')    
    exportfig(gcf,'Preference Statistics','Format','jpeg','Color','rgb')    
    exportfig(gcf,'Preference Statistics','Format','eps','Color','rgb')    

end