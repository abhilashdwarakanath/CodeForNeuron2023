function [pref_sim] = check_pref_sim(pri_pref_array,sec_pref_array,cnds)

%% This code assesses the similarity of preferences across units.
% 
% Input: 
% 
% 1. pri_pref_array: primary array with significant idx
% 2. sec_pref_array: secondary array with significant idx
% 3. cnds: the conditions
% 
% Output: 
% pref_sim
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2016/10/22


%% Get the significant units in the two conditions

if size((pri_pref_array),2)>3
    
    pri_sig_u = cell2mat(pri_pref_array(find([pri_pref_array{:,2}]==1),[2 3 5]));
    
    sec_sig_u = cell2mat(sec_pref_array(find([sec_pref_array{:,2}]==1),[2 3 5]));
    
else
    
    pri_sig_u = pri_pref_array;
    sec_sig_u = sec_pref_array;
end

%% Get the indices of the units with identical preference, and also significant in the two arrays.

% com_pref = find(sum([pri_pref_array{:,2};pri_pref_array{:,3}]'==[sec_pref_array{:,2};sec_pref_array{:,3}]',2)==2);

[pri_idx,sec_idx] = ismember(pri_sig_u,sec_sig_u,'rows');

com_pri_sig_u = pri_sig_u(pri_idx,:);
com_sec_sig_u = sec_sig_u(nonzeros(sec_idx),:);

%% Get the indices of the units with opposite preference and also significant.

% get the significant units in the pri condition, different from the sec
% condition.

[pri_diff,pri_diff_idx] = setdiff(pri_sig_u,sec_sig_u,'rows','stable');

% get all the unit numbers in the set of significant sec units, with identical channel number
[pri_diff_sig_u,h] = intersect(pri_diff(:,3),sec_sig_u(:,3));

% get the matrix of all the significant pri units, which are different from
% sec
pri_diff_sig_u_mat = pri_diff(h,:);

h = [];

% get the matrix of all the significant sec units, which are different from
% pre
[sec_diff_sig_u,h] = intersect(sec_sig_u(:,3),pri_diff_sig_u);
sec_diff_sig_u_mat = sec_sig_u(h,:);


%% Get the units which are significant only in the pri array

only_pri_sig_u = setdiff(pri_sig_u, union(com_pri_sig_u,pri_diff_sig_u_mat,'rows'),'rows','stable');

%% Get the units which are significant only in the sec array

only_sec_sig_u = setdiff(sec_sig_u, union(com_sec_sig_u,sec_diff_sig_u_mat,'rows'),'rows','stable');

pref_sim.pri_cond = cnds(1,:);
pref_sim.sec_cond = cnds(2,:);

pref_sim.pri_sig_u = pri_sig_u;
pref_sim.sec_sig_u = sec_sig_u;
pref_sim.com_sig_u = com_pri_sig_u;
pref_sim.pri_diff_sig_u_mat = pri_diff_sig_u_mat;
pref_sim.sec_diff_sig_u_mat = sec_diff_sig_u_mat;
pref_sim.only_pri_sig_u = only_pri_sig_u;
pref_sim.only_sec_sig_u = only_sec_sig_u;










