function [muadata] = convMuaFormat(spkByTimData,spkTyp)

%% The script converts the traditional spikes by time data to a different format. It converts only the spikesMOAligned.
% Usage: convMuaFormat
% Input:
% spkBYTimData: Data in traditional spikesByTim format: jMUspikes.data
% Output: Cell array of 1*(number of channels(96)), each containing the 8
% stimulus conditions.
% muadata: 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2016/10/19

%  It compares with the
% available conditions and then sends out indices for extraction of data.


if strcmp(spkTyp,'SOA')
    
    for i = 1:size(spkByTimData,2)
        
        muadata{i} = spkByTimData{i}.spikesSOAligned;
        
    end
       
elseif strcmp(spkTyp,'MOA')
    
    for i = 1:size(spkByTimData,2)
        
        muadata{i} = spkByTimData{i}.spikesMOAligned;
        
    end
    
end