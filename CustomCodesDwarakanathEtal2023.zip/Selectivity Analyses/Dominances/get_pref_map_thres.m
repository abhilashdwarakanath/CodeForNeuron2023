function get_pref_map_thres(pref_array_cond, chan2elec, elec_map, p_thres,ttl_pref_map, sav_dir, sav_fig)

% chan2elec = jMUspikes.chanElecs.electrodeInfo;
% elec_map = jMUspikes.map;
% p_thres = [0.05:0.1:0.95];

for i = 1:length(p_thres)

    pref_idx = cell2mat(pref_array_cond(find(cell2mat(pref_array_cond(:,1)) < p_thres(i)),[2 3 5]));
    [sel_map(:,:,i)] = get_pref_map(pref_idx,chan2elec,elec_map);
%     sel_map(:,:,i) = rot90(sel_map(:,:,i),2);
    
    figure(21);
    subplot(2,length(p_thres)/2,i);
    imagesc(sel_map(:,:,i));
    set(gca,'linewidth',2);
    title(strcat(num2str(length(pref_idx)), '-sites with p-value less than-',num2str(p_thres(i))));
    axis square
    pref_idx = [];

end

set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.

% map = [1,0.7,0.7;1,1,1;0.55,0.8,0];
map = [0.91,0.7,0.7;1,1,1;0.56,0.82,0.31];
colormap(map);

annotation('textbox',[0.04 0.9291 0.15 0.035], ...
    'String',{'Green pixels - Down preferring','Pink pixels - Up preferring'}, ...
    'FontSize', 10, ... 
    'LineWidth',2, ...
    'BackgroundColor',[1 1 1], ...
    'FitBoxToText','on')
suplabel(ttl_pref_map,'t')

if sav_fig ==1
    
    cd(sav_dir)    
%    saveas(gcf,ttl_pref_map,'ai')
    saveas(gcf,ttl_pref_map,'fig')
    exportfig(gcf,ttl_pref_map,'Format','jpeg','Color','rgb')
    exportfig(gcf,ttl_pref_map,'Format','eps','Color','rgb')

end