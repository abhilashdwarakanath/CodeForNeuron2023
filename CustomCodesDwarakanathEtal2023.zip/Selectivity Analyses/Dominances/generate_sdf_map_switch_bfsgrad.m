function generate_sdf_map_switch_bfsgrad(sdf_switch, pref_array_switch, jMUSwitches, sav_dir, ttl_suffix)

%% This code generates SDF - Maps according to electrode's array location for bfsgrad
% 
% Input: 
% 
% 1. sdf_switch: the sdf data with psths
% 2. pref_array: preference arrays
% 3. jMUspikes: data structure with spikes
% 4. sav_dir: saving directory
% 5. ttl_suffix: title for the sdf maps
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/06/15


%% get the appropriate parameters necessary for plotting

tim_window = sdf_switch.t;
chan2elec = jMUSwitches.chanElecs.electrodeInfo;
elec_map = jMUSwitches.map;

%% physical alternation condition

sig_typ = 'Phy_Switch_MUA';
[dat,figProps] = generate_data4map(sig_typ, sdf_switch, ttl_suffix);

bold_sites{1} = pref_array_switch.pref_sim_switch_Phy_BsAs.pri_sig_u(:,3);
bold_sites{2} = pref_array_switch.pref_sim_switch_Phy_BsAs.sec_sig_u(:,3);

boxed_sites{1} = pref_array_switch.pref_sim_switch_PhyRiv_BsBs.com_sig_u(:,3);
boxed_sites{2} = pref_array_switch.pref_sim_switch_PhyRiv_AsAs.com_sig_u(:,3);
boxed_sites{3} = pref_array_switch.pref_sim_switch_Phy_BsAs.com_sig_u(:,3);

sav_fig = saveOrNot(an_info.sdfMap_PA);
generate_dat_map(dat, tim_window, chan2elec, elec_map, bold_sites, boxed_sites, figProps, sav_dir, sav_fig)
bold_sites = []; boxed_sites = [];

%% rivalry condition

sig_typ = 'Riv_Switch_MUA';
[dat,figProps] = generate_data4map(sig_typ, sdf_switch, ttl_suffix);

bold_sites{1} = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,3);
bold_sites{2} = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,3);

boxed_sites{1} = pref_array_switch.pref_sim_switch_PhyRiv_BsBs.com_sig_u(:,3);
boxed_sites{2} = pref_array_switch.pref_sim_switch_PhyRiv_AsAs.com_sig_u(:,3);
boxed_sites{3} = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,3);

sav_fig = saveOrNot(an_info.sdfMap_PA);
generate_dat_map(dat, tim_window, chan2elec, elec_map, bold_sites, boxed_sites, figProps, sav_dir, sav_fig)
bold_sites = []; boxed_sites = [];









