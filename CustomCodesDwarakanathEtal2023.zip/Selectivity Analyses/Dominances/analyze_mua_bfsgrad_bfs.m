function analyze_mua_bfsgrad_bfs(ds_info, roi)


%% This code carries out all the basic MUA analysis for the bfsgrad paradigm for ONE dataset during the BFS phase.
% 
% Input: 
% 
% 1. ds_info: A file containing the appropriate directory and dataset
%   information.
% 
% 2. roi: region of interest - PFC or PPC.
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/08/09
% 

%% WORK ON BFS

trl_phase = 'BFS';

%% Load the data and check for region of interest

if strcmp(roi,'PFC')    
    cd(ds_info.jMUspikesPath.PFC);
    array_idx = 1;
    load('jMUSpikesByTime');
elseif strcmp(roi,'PPC')   
    cd(ds_info.jMUspikesPath.PPC);
    array_idx = 2;
    load('jMUSpikesByTime');    
end

%% Generate the appropriate folder structure for saving the results

generate_folder_structure('Bfsgrad','MUA','PSTH',ds_info,roi);

%% Main Results Directory

res_dir = strcat('E:\Data\Results\',ds_info.monk,'\',ds_info.dataset,'\Bfsgrad\',ds_info.activeArray{array_idx},'\MUA\');
ttl_suffix = strcat('-',ds_info.monk,'-',ds_info.activeArray{array_idx},'-', ds_info.dataset);

%% Physical Alternation and Flash Suppression Switch

%% Create PSTHs - Stimulus Onset Aligned Data

align_evt_soa = 'SOA';
sav_dir_PsthSoa = strcat(res_dir, 'PSTH_Sites\PSTH_SOAligned');
% sav_fig = saveOrNot(an_info.sdf_soa_fig);
sav_fig = 0;

[sdf_soa] = generate_psth_bfsgrad(jMUspikes,align_evt_soa, sav_dir_PsthSoa, sav_fig);

%% Create PSTHs - Mask Onset Aligned Data

align_evt_moa = 'MOA';
sav_dir_PsthSoa = strcat(res_dir, 'PSTH_Sites\PSTH_MOAligned');
% sav_fig = saveOrNot(an_info.sdf_soa_fig);
sav_fig = 0;

[sdf_moa] = generate_psth_bfsgrad(jMUspikes,align_evt_moa, sav_dir_PsthSoa, sav_fig);

%% Get spikesparse matrices for a given time window

% use a binwidth divisible by the temporal data below, or there might be issues in plotting after.
binWidth = 50; 

[res_mua_soa,muadata_soa] = get_spksparse_bfsgrad(jMUspikes,align_evt_soa,binWidth);
[res_mua_moa,muadata_moa] = get_spksparse_bfsgrad(jMUspikes,align_evt_moa,binWidth);

%% Generate the appropriate folder structure for saving the results

generate_folder_structure('Bfsgrad','MUA','Selectivity',ds_info,roi);

%% Check Preferences in Physical Alternation/Flash Suppression (for mask onset aligned data)

sav_dir_SelArray = strcat(res_dir, 'Preference_Arrays\PA_FS');
[pref_array] = get_pref_array_bfsgrad(muadata_moa, sav_dir_SelArray);

%%  Make and save the bar plot with all the preferences

% sav_fig = saveOrNot(an_info.barPlot_Pref);
sav_fig = 1;
generate_barplot_stats(pref_array.pref_sim,ttl_suffix,sav_dir_SelArray,sav_fig,trl_phase);

%% Generate SDF - Maps according to electrode's array location

sav_dir_SdfMap = strcat(res_dir, 'PSTH_Maps'); sav_fig = 1;
generate_sdf_map_bfsgrad(sdf_moa, pref_array, jMUspikes, sav_dir_SdfMap, ttl_suffix,sav_fig)

%% Make Preference Maps

sav_dir_PrefMap = strcat(res_dir, 'Preference_Maps'); sav_fig = 1;
% for the physical alternation condition
generate_pref_map_bfsgrad(pref_array, jMUspikes, sav_dir_PrefMap, ttl_suffix,'PA', sav_fig);
% for the flash suppression condition
generate_pref_map_bfsgrad(pref_array, jMUspikes, sav_dir_PrefMap, ttl_suffix,'FS', sav_fig);

%% Prepare figures related to d-Prime

sav_dir_dPrime = strcat(res_dir, '\d_Prime\PA_FS'); sav_fig = 1;
cond2comp = 'PA_FS';
generate_figs_dprime_bfsgrad(pref_array,sav_dir_dPrime, ttl_suffix, cond2comp, sav_fig)

%% Create Population PSTHs - Mask Onset Aligned Data

sav_dir_popPSTH = strcat(res_dir, 'PSTH_Population\PSTH_MOAligned'); sav_fig = 1;
generate_pop_psth_mu_bfsgrad(res_mua_moa, pref_array, binWidth, sav_dir_popPSTH, ttl_suffix, sav_fig)

%% Check this again with another dataset before implementing.
% Sites with opposite preference in the physical alternation and flash
% suppression condition. 

% % % % pref_paOpp_sig_mu = pref_sim.pri_diff_sig_u_mat;
% % % % units_typ = strcat('Mean of - ',num2str(length(pref_paOpp_sig_mu)),'- Sites significantly modulated in the PA condition in the opposite direction');
% % % % generate_population_mu_psth(res_mua_moa,pref_paOpp_sig_mu,units_typ,binWidth,tim_trl_dur);
% % % % units_typ = [];
% % % % 
% % % % pref_fsOpp_sig_mu = pref_sim.sec_diff_sig_u_mat;
% % % % units_typ = strcat('Mean of - ',num2str(length(pref_fsOpp_sig_mu)),'- Sites significantly modulated in the FS condition in the opposite direction');
% % % % generate_population_mu_psth(res_mua_moa,pref_fsOpp_sig_mu,units_typ,binWidth,tim_trl_dur);
% % % % units_typ = [];

