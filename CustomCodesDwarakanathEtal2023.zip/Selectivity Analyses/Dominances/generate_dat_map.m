function generate_dat_map(dat, tim_window, chan2elec, elec_map, bold_sites, boxed_sites, figProps, sav_dir, sav_fig)

% This code takes input as the dat (data), tim_window, directory to save the PSTHs, 
% chan2elec conversion, elec_map, sites
% for which the data should be plotted in bold and those which should be boxed.
% figProps are defined depending upon the input data in dat.
% Also see generate_data4map
% 
% % Usage: generate_dat_map
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/5/11
% 

t = tim_window;

for chan = 1:length(chan2elec)
    
    %     perform the channel transformation
    
    elec = chan2elec(chan,2);
    [r(chan),c(chan)] = find(elec_map == elec);
    
    %     plot the figure
    
    figure(2)
    subplot2(10,10,r(chan),c(chan));
    title(num2str(chan));
    
    hold on;
    
    %     plot certain sites with a bigger LineWidth    
    
    switch figProps.sig_typ
        
        case{'PA_MUA','FS_MUA','Phy_Dom_MUA','Riv_Dom_MUA'}
            
            if find(bold_sites(:)==chan)
                
                plot(t,dat(1).data2plot(chan,:),figProps.linTyp{1},'LineWidth',2)
                plot(t,dat(2).data2plot(chan,:),figProps.linTyp{2},'LineWidth',2)
                vline(figProps.v_line);
                xlim(figProps.tim_window);
                
                %         draw a box around certain sites
                if find(boxed_sites(:)==chan)
                    box on;
                    set(gca,'linewidth',2)
                end
                
            else
                plot(t,dat(1).data2plot(chan,:),figProps.linTyp{1})
                plot(t,dat(2).data2plot(chan,:),figProps.linTyp{2})
                vline(figProps.v_line);
                xlim(figProps.tim_window);
            end
            
            if strcmp(figProps.sig_typ,'Phy_Dom_MUA')||strcmp(figProps.sig_typ,'Riv_Dom_MUA')
                xlim(figProps.xlim);
            end
                
                
        case{'Phy_Switch_MUA','Riv_Switch_MUA'}
            
% % %             if find(bold_sites{3}==chan)
% % %                 
% % %                 plot(t,dat(1).data2plot(chan,:),figProps.linTyp{1},'LineWidth',2)
% % %                 plot(t,dat(2).data2plot(chan,:),figProps.linTyp{2},'LineWidth',2)
% % %                 vline(figProps.v_line);
% % %                 xlim(figProps.tim_window);
% % %                 
% % %                 if find(boxed_sites{1}==chan)
% % %                     yl = ylim;
% % %                     patch([figProps.tim_window(1) 0 0 figProps.tim_window(1)],[yl(1) yl(1) yl(2) yl(2)],figProps.patch_color, ...
% % %                         'FaceColor','none',...
% % %                         'LineWidth',2, ...
% % %                         'EdgeColor',figProps.patchEdge_color, ...
% % %                         'LineStyle','--');
% % %                     box on; set(gca,'linewidth',2);
% % %                 end
% % %                 if find(boxed_sites{2}==chan)
% % %                     yl = ylim;
% % %                     patch([figProps.tim_window(2) 0 0 figProps.tim_window(2)],[yl(1) yl(1) yl(2) yl(2)],figProps.patch_color, ...
% % %                         'FaceColor','none',...
% % %                         'LineWidth',2, ...
% % %                         'EdgeColor',figProps.patchEdge_color, ...
% % %                         'LineStyle','--');
% % %                     box on;
% % %                 end
% % %                                 
% % %                 
% % %             elseif find(bold_sites{1}==chan)
% % %                 
% % %                 plot(t(1:(length(t)/2)),dat(1).data2plot(chan,(1:(length(t)/2))),figProps.linTyp{1},'LineWidth',2);
% % %                 plot(t((length(t)/2)+1:end),dat(1).data2plot(chan,(length(t)/2)+1:end),figProps.linTyp{1});
% % %                 plot(t(1:(length(t)/2)),dat(2).data2plot(chan,(1:(length(t)/2))),figProps.linTyp{2},'LineWidth',2);
% % %                 plot(t((length(t)/2)+1:end),dat(2).data2plot(chan,(length(t)/2)+1:end),figProps.linTyp{2});
% % %                 vline(figProps.v_line);
% % %                 xlim(figProps.tim_window);
% % %                 
% % %                 if find(boxed_sites{1}==chan)
% % %                     yl = ylim;
% % %                     patch([figProps.tim_window(1) 0 0 figProps.tim_window(1)],[yl(1) yl(1) yl(2) yl(2)],figProps.patch_color, ...
% % %                         'FaceColor','none',...
% % %                         'LineWidth',2, ...
% % %                         'EdgeColor',figProps.patchEdge_color, ...
% % %                         'LineStyle','--');
% % %                     box on;
% % %                 end
% % %                 
% % %             elseif find(bold_sites{2}==chan)
% % %                 
% % %                 plot(t(1:(length(t)/2)),dat(1).data2plot(chan,(1:(length(t)/2))),figProps.linTyp{1});
% % %                 plot(t((length(t)/2)+1:end),dat(1).data2plot(chan,(length(t)/2)+1:end),figProps.linTyp{1},'LineWidth',2);
% % %                 plot(t(1:(length(t)/2)),dat(2).data2plot(chan,(1:(length(t)/2))),figProps.linTyp{2});
% % %                 plot(t((length(t)/2)+1:end),dat(2).data2plot(chan,(length(t)/2)+1:end),figProps.linTyp{2},'LineWidth',2);                
% % %                 vline(figProps.v_line);
% % %                 xlim(figProps.tim_window);
% % %                 
% % %                 if find(boxed_sites{2}==chan)
% % %                     yl = ylim;
% % %                     patch([figProps.tim_window(2) 0 0 figProps.tim_window(2)],[yl(1) yl(1) yl(2) yl(2)],'r', ...
% % %                         'FaceColor','none',...
% % %                         'LineWidth',2, ...
% % %                         'EdgeColor',figProps.patchEdge_color, ...
% % %                         'LineStyle','--');
% % %                     box on;
% % %                 end
% % %                 
% % %             else
% % %                 
% % %                 plot(t,dat(1).data2plot(chan,:),figProps.linTyp{1})
% % %                 plot(t,dat(2).data2plot(chan,:),figProps.linTyp{2})
% % %                 vline(figProps.v_line);
% % %                 xlim(figProps.tim_window);
% % %                 
% % %             end
            
             if ~isempty(find(bold_sites{1}==chan)) && ~isempty(find(bold_sites{2}==chan))
                
                plot(t,dat(1).data2plot(chan,:),figProps.linTyp{1},'LineWidth',2)
                plot(t,dat(2).data2plot(chan,:),figProps.linTyp{2},'LineWidth',2)
                vline(figProps.v_line);
                xlim(figProps.tim_window);
                
                if find(boxed_sites{3}==chan)
                    box on; set(gca,'linewidth',2);
                end
                    
                
                if find(boxed_sites{1}==chan)
                    yl = ylim;
                    patch([figProps.tim_window(1) 0 0 figProps.tim_window(1)],[yl(1) yl(1) yl(2) yl(2)],figProps.patch_color, ...
                        'FaceColor','none',...
                        'LineWidth',2, ...
                        'EdgeColor',figProps.patch_EdgeColor, ...
                        'LineStyle',figProps.patch_LineStyle);               
                end
                
                if find(boxed_sites{2}==chan)
                    yl = ylim;
                    patch([figProps.tim_window(2) 0 0 figProps.tim_window(2)],[yl(1) yl(1) yl(2) yl(2)],figProps.patch_color, ...
                        'FaceColor','none',...
                        'LineWidth',2, ...
                        'EdgeColor',figProps.patch_EdgeColor, ...
                        'LineStyle',figProps.patch_LineStyle);
                end
                                
                
            elseif find(bold_sites{1}==chan)
                
                plot(t(1:(length(t)/2)),dat(1).data2plot(chan,(1:(length(t)/2))),figProps.linTyp{1},'LineWidth',2);
                plot(t((length(t)/2)+1:end),dat(1).data2plot(chan,(length(t)/2)+1:end),figProps.linTyp{1});
                plot(t(1:(length(t)/2)),dat(2).data2plot(chan,(1:(length(t)/2))),figProps.linTyp{2},'LineWidth',2);
                plot(t((length(t)/2)+1:end),dat(2).data2plot(chan,(length(t)/2)+1:end),figProps.linTyp{2});
                vline(figProps.v_line);
                xlim(figProps.tim_window);
                
                if find(boxed_sites{1}==chan)
                    yl = ylim;
                    patch([figProps.tim_window(1) 0 0 figProps.tim_window(1)],[yl(1) yl(1) yl(2) yl(2)],figProps.patch_color, ...
                        'FaceColor','none',...
                        'LineWidth',2, ...
                        'EdgeColor',figProps.patch_EdgeColor, ...
                        'LineStyle',figProps.patch_LineStyle);
                end
                
            elseif find(bold_sites{2}==chan)
                
                plot(t(1:(length(t)/2)),dat(1).data2plot(chan,(1:(length(t)/2))),figProps.linTyp{1});
                plot(t((length(t)/2)+1:end),dat(1).data2plot(chan,(length(t)/2)+1:end),figProps.linTyp{1},'LineWidth',2);
                plot(t(1:(length(t)/2)),dat(2).data2plot(chan,(1:(length(t)/2))),figProps.linTyp{2});
                plot(t((length(t)/2)+1:end),dat(2).data2plot(chan,(length(t)/2)+1:end),figProps.linTyp{2},'LineWidth',2);                
                vline(figProps.v_line);
                xlim(figProps.tim_window);
                
                if find(boxed_sites{2}==chan)
                    yl = ylim;
                    patch([figProps.tim_window(2) 0 0 figProps.tim_window(2)],[yl(1) yl(1) yl(2) yl(2)],'r', ...
                        'FaceColor','none',...
                        'LineWidth',2, ...
                        'EdgeColor',figProps.patch_EdgeColor, ...
                        'LineStyle',figProps.patch_LineStyle);
                end
                
            else
                
                plot(t,dat(1).data2plot(chan,:),figProps.linTyp{1})
                plot(t,dat(2).data2plot(chan,:),figProps.linTyp{2})
                vline(figProps.v_line);
                xlim(figProps.tim_window);
                
            end           
            
            
        case{'PhyRivBS_Switch_MUA','PhyRivAS_Switch_MUA'}
            
            
            
            
            
    end
    
    
end

% Prepare the figure

figure(2)
set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.
subplot(10,10,9)

if strcmp(figProps.sig_typ,'PA_MUA')||strcmp(figProps.sig_typ,'FS_MUA')|| ...
        strcmp(figProps.sig_typ,'Phy_Dom_MUA')||strcmp(figProps.sig_typ,'Riv_Dom_MUA')
    
    pa_hl = legend(figProps.legend{1},figProps.legend{2});
    
elseif strcmp(figProps.sig_typ,'Phy_Switch_MUA')||strcmp(figProps.sig_typ,'Riv_Switch_MUA')
    
    pa_hl = legend(figProps.legend{1},figProps.legend{2},figProps.legend{3});    
    
end

suplabel(figProps.xlabel,'x');
suplabel(figProps.ylabel,'y');
suplabel(figProps.suplabel,'t');
set(pa_hl,'Position', [0.8487 0.9291 0.1172 0.0459]);
annotation('textbox',[0.04 0.9291 0.15 0.035], ...
    'String',figProps.text_box, ...
    'FontSize', 10, ... 
    'LineWidth',2, ...
    'BackgroundColor',[1 1 1], ...
    'FitBoxToText','on');



if sav_fig ==1
    
    cd(sav_dir)    
%    saveas(gcf,figProps.figName,'ai')
    saveas(gcf,figProps.figName,'fig')
    exportfig(gcf,figProps.figName,'Format','jpeg','Color','cmyk')
    exportfig(gcf,figProps.figName,'Format','eps','Color','cmyk')    

end
   


