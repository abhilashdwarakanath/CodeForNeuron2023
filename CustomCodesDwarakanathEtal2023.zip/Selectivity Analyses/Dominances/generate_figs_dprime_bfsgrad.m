function generate_figs_dprime_bfsgrad(pref_array,sav_dir, ttl_suffix, cond2comp, sav_fig)

%% This code generates figures related to d-prime.
% 
% Input: 
% 
% 1. pref_array: preference arrays
% 2. sav_dir: saving directory
% 
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/06/15



%% Make a d-prime scatter of all the sites retaining preference and selectivity

switch cond2comp
    
    case 'PA_FS'
                
        % sav_fig = saveOrNot(an_info.scatter_dPrime);
        sav_fig = 1;
        makefig_scatter_dprime(pref_array.pref_sim, pref_array.pa_dprime, pref_array.fs_dprime, sav_dir, sav_fig);
        
    case 'Phy_Riv'
        
        sav_fig = 1;
        makefig_scatter_dprime(pref_array.pref_sim_Dom_PhyRiv, pref_array.dom_Phy_dprime, pref_array.dom_Riv_dprime, sav_dir, sav_fig);
end

%% Make a barplot depicting proportion of perceptually modulated units as a function of d-prime.

switch cond2comp
    
    case 'PA_FS'
        
        % sav_fig = saveOrNot(an_info.stats_dPrime);
        sav_fig = 1;
        generate_barPlot_dPrime_stats(pref_array.pref_sim, pref_array.pa_dprime, ttl_suffix, sav_dir, sav_fig)
    case 'Phy_Riv'
        
        % sav_fig = saveOrNot(an_info.stats_dPrime);
        sav_fig = 1;
        generate_barPlot_dPrime_stats(pref_array.pref_sim_Dom_PhyRiv, pref_array.dom_Phy_dprime, ttl_suffix, sav_dir, sav_fig)
        
end