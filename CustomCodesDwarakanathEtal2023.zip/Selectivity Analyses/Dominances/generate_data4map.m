function [dat,figProps] = generate_data4map(sig_typ, dataIn, ttl_suffix)

% This code generates data required for plotting it as the map format.
% It takes input as the sig_typ(PA_MUA, LFP, etc), dataIn(the data itself),
% ttl_suffix(the title which could be added to figure properties which are 
% generated here).
% Also see generate_dat_map
% % Usage: generate_data4map(sig_typ, dataIn, ttl_suffix)
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/5/19
% 

%% Make the appropriate structure

dat = struct;

%% Specific actions are taken for the different signal types

switch sig_typ
    
%     Physical alternation - MUA
    case 'PA_MUA'
        
        for chn_num = 1:length(dataIn.chan)            
            if ~isempty(dataIn.chan(chn_num).pa_270)&&~isempty(dataIn.chan(chn_num).pa_90)                
                dat(1).data2plot(chn_num,:) = dataIn.chan(chn_num).pa_270;
                dat(2).data2plot(chn_num,:) = dataIn.chan(chn_num).pa_90;                
            else                
                dat(1).data2plot(chn_num,:) = zeros(1,length(dataIn.t));
                dat(2).data2plot(chn_num,:) = zeros(1,length(dataIn.t));                
            end            
        end
                       
        figProps.tim_window = dataIn.params.tim_window;
        figProps.linTyp{1} = 'k';
        figProps.linTyp{2} = 'k:';
        figProps.v_line = [-2 0];
        figProps.xlabel = 'Time (seconds)';
        figProps.ylabel = 'Spikes/second';
        figProps.suplabel = strcat('Physical Alternation-SDF Map',ttl_suffix);
        figProps.legend{1} = 'Physical Alternation - 270 - 90';
        figProps.legend{2} = 'Physical Alternation - 90 - 270';
        figProps.text_box = {'Bold Lines: Significantly selective in PA', ...
            'Box ON: Significantly selective in PA and FS'};
        figProps.figName = strcat('SDF_Map_PA');
        figProps.sig_typ = sig_typ;
 
%     Flash Suppression - MUA
    case 'FS_MUA'
        
        for chn_num = 1:length(dataIn.chan)                        
            if ~isempty(dataIn.chan(chn_num).pa_270)&&~isempty(dataIn.chan(chn_num).pa_90)                
                dat(1).data2plot(chn_num,:) = dataIn.chan(chn_num).fs_270;
                dat(2).data2plot(chn_num,:) = dataIn.chan(chn_num).fs_90;
            else                
                dat(1).data2plot(chn_num,:) = zeros(1,length(dataIn.t));
                dat(2).data2plot(chn_num,:) = zeros(1,length(dataIn.t));                
            end            
        end
        
        figProps.tim_window = dataIn.params.tim_window;        
        figProps.linTyp{1} = 'r';
        figProps.linTyp{2} = 'r:';
        figProps.v_line = [0 2];
        figProps.xlabel = 'Time (seconds)';
        figProps.ylabel = 'Spikes/second';
        figProps.suplabel = strcat('Flash Suppression-SDF Map',ttl_suffix);
        figProps.legend{1} = 'Flash Suppression - 270 - 90';
        figProps.legend{2} = 'Flash Suppression - 90 - 270';     
        figProps.text_box = {'Bold Lines: Significantly selective in FS', ...
            'Box ON: Significantly selective in PA and FS'};
        figProps.figName = strcat('SDF_Map_FS');
        figProps.sig_typ = sig_typ;
        
%     Physical Alternation Switches - MUA                                        
    case 'Phy_Switch_MUA'
        
        for chn_num = 1:length(dataIn.chan)
            if ~isempty(dataIn.chan(chn_num).pa_270to90)&&~isempty(dataIn.chan(chn_num).pa_90to270)
                dat(1).data2plot(chn_num,:) = dataIn.chan(chn_num).pa_270to90;
                dat(2).data2plot(chn_num,:) = dataIn.chan(chn_num).pa_90to270;
            else
                dat(1).data2plot(chn_num,:) = zeros(1,length(dataIn.t));
                dat(2).data2plot(chn_num,:) = zeros(1,length(dataIn.t));
            end
        end          
        
        figProps.tim_window = dataIn.params.tim_window;        
        figProps.linTyp{1} = 'k';
        figProps.linTyp{2} = 'k:';
        figProps.v_line = [0];
        figProps.xlabel = 'Time (seconds)';
        figProps.ylabel = 'Spikes/second';
        figProps.suplabel = strcat('Physical Alternation-Switch-SDF Map',ttl_suffix);
        figProps.legend{1} = 'Physical Alternation - 270 - 90';
        figProps.legend{2} = 'Physical Alternation - 90 - 270';   
        figProps.legend{3} = 'Similarly significantly modulated in both conditions';
        figProps.text_box = {'Bold Lines: Significantly modulated before/after switch', ...
            'Black Box: Stimulus preference mantained before/after switch'};
        figProps.figName = strcat('SDF_Map_Phy_Switch');        
        figProps.sig_typ = sig_typ;
        figProps.patch_color = 'y';        
        figProps.patch_EdgeColor = 'g'; 
        figProps.patch_LineStyle = '--';
        
%     Rivalry Switches - MUA          
    case 'Riv_Switch_MUA'
        
        for chn_num = 1:length(dataIn.chan)
            if ~isempty(dataIn.chan(chn_num).fs_270to90)&&~isempty(dataIn.chan(chn_num).fs_90to270)
                dat(1).data2plot(chn_num,:) = dataIn.chan(chn_num).fs_270to90;
                dat(2).data2plot(chn_num,:) = dataIn.chan(chn_num).fs_90to270;
            else
                dat(1).data2plot(chn_num,:) = zeros(1,length(dataIn.t));
                dat(2).data2plot(chn_num,:) = zeros(1,length(dataIn.t));
            end
        end          
        
        figProps.tim_window = dataIn.params.tim_window;        
        figProps.linTyp{1} = 'r';
        figProps.linTyp{2} = 'r:';
        figProps.v_line = [0];
        figProps.xlabel = 'Time (seconds)';
        figProps.ylabel = 'Spikes/second';
        figProps.suplabel = strcat('Rivalry-Switch-SDF Map',ttl_suffix);
        figProps.legend{1} = 'Rivalry - 270 - 90';
        figProps.legend{2} = 'Rivalry - 90 - 270';  
        figProps.legend{3} = 'Similarly significantly modulated in both conditions';       
        figProps.text_box = {'Bold Lines: Significantly modulated before/after switch', ...
            'Black Box: Stimulus preference mantained before/after switch'};
        figProps.figName = strcat('SDF_Map_Riv_Switch');        
        figProps.sig_typ = sig_typ;   
        figProps.patch_color = 'y';
        figProps.patch_EdgeColor = 'g';
        figProps.patch_LineStyle = '--';

        
%     Physical Alternation Switches - MUA                                        
    case 'Phy_Dom_MUA'
        
        for chn_num = 1:length(dataIn.chan)
            if ~isempty(dataIn.chan(chn_num).pa_270)&&~isempty(dataIn.chan(chn_num).pa_90)
                dat(1).data2plot(chn_num,:) = dataIn.chan(chn_num).pa_270;
                dat(2).data2plot(chn_num,:) = dataIn.chan(chn_num).pa_90;
            else
                dat(1).data2plot(chn_num,:) = zeros(1,length(dataIn.t));
                dat(2).data2plot(chn_num,:) = zeros(1,length(dataIn.t));
            end
        end          
        
        figProps.tim_window = dataIn.params.tim_window;        
        figProps.linTyp{1} = 'k';
        figProps.linTyp{2} = 'k:';
        figProps.v_line = [0];
        figProps.xlabel = 'Time (seconds)';
        figProps.ylabel = 'Spikes/second';
        figProps.suplabel = strcat('Physical Alternation-Dominance-SDF Map',ttl_suffix);
        figProps.legend{1} = 'Physical Alternation - 270';
        figProps.legend{2} = 'Physical Alternation - 90';   
        figProps.text_box = {'Bold Lines: Significantly selective in Phy', ...
            'Box ON: Significantly selective in Phy and Riv'};
        figProps.figName = strcat('SDF_Map_Phy_Dom');        
        figProps.sig_typ = sig_typ;
        figProps.xlim = [-0.2 1];
        
%     Rivalry Switches - MUA          
    case 'Riv_Dom_MUA'
        
        for chn_num = 1:length(dataIn.chan)
            if ~isempty(dataIn.chan(chn_num).riv_270)&&~isempty(dataIn.chan(chn_num).riv_90)
                dat(1).data2plot(chn_num,:) = dataIn.chan(chn_num).riv_270;
                dat(2).data2plot(chn_num,:) = dataIn.chan(chn_num).riv_90;
            else
                dat(1).data2plot(chn_num,:) = zeros(1,length(dataIn.t));
                dat(2).data2plot(chn_num,:) = zeros(1,length(dataIn.t));
            end
        end          
        
        figProps.tim_window = dataIn.params.tim_window;        
        figProps.linTyp{1} = 'r';
        figProps.linTyp{2} = 'r:';
        figProps.v_line = [0];
        figProps.xlabel = 'Time (seconds)';
        figProps.ylabel = 'Spikes/second';
        figProps.suplabel = strcat('Rivalry-Dominance-SDF Map',ttl_suffix);
        figProps.legend{1} = 'Rivalry - 270';
        figProps.legend{2} = 'Rivalry - 90';  
        figProps.text_box = {'Bold Lines: Significantly selective in Riv', ...
            'Box ON: Significantly selective in Phy and Riv'};
        figProps.figName = strcat('SDF_Map_Riv_Dom');        
        figProps.sig_typ = sig_typ; 
        figProps.xlim = [-0.2 1];
        
% Local field potential - can be expanded by Abhilash        
%     case 'LFP'                            
        
        
        
end