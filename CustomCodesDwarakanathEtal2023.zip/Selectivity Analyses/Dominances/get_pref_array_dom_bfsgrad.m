function [pref_array_dom] = get_pref_array_dom_bfsgrad(muadata_270, muadata_90, min_domDur, sav_dir)

%% This code gets the preference array for a given time window for datasets of bfsgrad.
% 
% Input: 
% 
% 1. muadata_90: the data structure with spikes
% 2. muadata_270: the data structure with spikes
% 3. sav_dir: saving directory
% 
% Output: 
% pref_array
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/07/5



%% Create a structure for storing preference related data

pref_array_dom = struct;
pref_array_dom.description = {'p_val';'h_val';'pref_stim_270_1_90_2';'pref_stim';'chan_number'};

% Assign Parameters

tst_typ = ('spike count'); % Test type
pref_array_dom.tst_typ = tst_typ;
tim_win_dom = [0 min_domDur];
pref_array_dom.tim_win_dom = tim_win_dom;

%% Check rivalry preferences

tst_cnd = 'rivalry';
pref_array_dom.tst_cnd_riv = tst_cnd;

% dominance - rivalry

[pref_array,dprime]=check_preference_switch_mua(tim_win_dom, muadata_270, muadata_90, tst_typ,tst_cnd);
pref_array_dom.dom_pref_array_Riv = pref_array;
pref_array_dom.dom_Riv_dprime = dprime;
pref_array_dom.dom_Riv_table = array2table(pref_array,'VariableNames',pref_array_dom.description);

pref_array = []; tst_cnd = [];

%% Check physical preferences

tst_cnd = 'physical';
pref_array_dom.tst_cnd_phy = tst_cnd;

% sensory - physical

[pref_array,dprime]=check_preference_switch_mua(tim_win_dom, muadata_270, muadata_90, tst_typ,tst_cnd);
pref_array_dom.dom_pref_array_Phy = pref_array;
pref_array_dom.dom_Phy_dprime = dprime;
pref_array_dom.dom_Phy_table = array2table(pref_array,'VariableNames',pref_array_dom.description);

pref_array = [];tst_cnd = [];

%% Check if the preference is maintained across conditions

% dominance - physical and rivalry

conds = {'Physical - After Switch';'Rivalry - After Switch'};
[pref_sim_Dom_PhyRiv] = check_pref_sim(pref_array_dom.dom_pref_array_Phy,pref_array_dom.dom_pref_array_Riv,conds);
pref_array_dom.pref_sim_Dom_PhyRiv = pref_sim_Dom_PhyRiv;

% % % if an_info.sdf_moa_fil == 0
% %     cd(sav_dir);
% %     save('pref_array_dom.mat', 'pref_array_dom');
% % % end








