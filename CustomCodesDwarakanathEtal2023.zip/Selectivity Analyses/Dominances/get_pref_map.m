function [sel_map] = get_pref_map(pref_idx,chan2elec,elec_map)


idx_270 = pref_idx(find(pref_idx(:,2)==1),3);
idx_90 = pref_idx(find(pref_idx(:,2)==2),3);

chan_270 = chan2elec(idx_270,2);
chan_90 = chan2elec(idx_90,2);

sel_map = zeros(10,10);

for i = 1:length(chan_270)
    
    [r_270(i),c_270(i)] = find(elec_map == chan_270(i));
    sel_map(r_270(i),c_270(i))= 1;
%     p_val(idx_270(i))
end


for i = 1:length(chan_90)
    
    [r_90(i),c_90(i)] = find(elec_map == chan_90(i));
    sel_map(r_90(i),c_90(i))= -1;
%     /p_val(idx_90(i))
end


% figure
% imagesc(sel_map);
% caxis([-20 20])





