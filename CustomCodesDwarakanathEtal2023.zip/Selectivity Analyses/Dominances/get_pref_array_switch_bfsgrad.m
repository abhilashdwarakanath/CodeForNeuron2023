function [pref_array_switch] = get_pref_array_switch_bfsgrad(muadata_90TO270, muadata_270TO90, sav_dir)

%% This code gets the preference array for a given time window for datasets of bfsgrad.
% 
% Input: 
% 
% 1. muadata_90TO270: the data structure with spikes
% 2. muadata_270TO90: the data structure with spikes
% 3. sav_dir: saving directory
% 
% Output: 
% pref_array
%   author : Vishal Kapoor (vishal.kapoor@tuebingen.mpg.de) 
%    start : 2017/06/15



%% Create a structure for storing preference related data

pref_array_switch = struct;
pref_array_switch.description = {'p_val';'h_val';'pref_stim_270_1_90_2';'pref_stim';'chan_number'};

% Assign Parameters

tst_typ = ('spike count'); % Test type
pref_array_switch.tst_typ = tst_typ;
tim_win_bs = [-1500 0];
pref_array_switch.tim_win_bs = [-1500 0];
tim_win_as = [0 1500];
pref_array_switch.tim_win_as = [0 1500];

%% Check rivalry preferences

tst_cnd = 'rivalry';
pref_array_switch.tst_cnd_riv = tst_cnd;

% before switch - rivalry

[pref_array]=check_preference_switch_mua(tim_win_bs, muadata_90TO270, muadata_270TO90, tst_typ,tst_cnd);
pref_array_switch.bs_pref_array_Riv = pref_array;
pref_array_switch.bs_Riv_table = array2table(pref_array,'VariableNames',pref_array_switch.description);

pref_array = []; 

% after switch - rivalry

[pref_array]=check_preference_switch_mua(tim_win_as, muadata_90TO270, muadata_270TO90, tst_typ,tst_cnd);
pref_array_switch.as_pref_array_Riv = pref_array;
pref_array_switch.as_Riv_table = array2table(pref_array,'VariableNames',pref_array_switch.description);

pref_array = []; tst_cnd = [];

%% Check physical preferences

tst_cnd = 'physical';
pref_array_switch.tst_cnd_phy = tst_cnd;

% before switch - physical

[pref_array]=check_preference_switch_mua(tim_win_bs, muadata_90TO270, muadata_270TO90, tst_typ,tst_cnd);
pref_array_switch.bs_pref_array_Phy = pref_array;
pref_array_switch.bs_Phy_table = array2table(pref_array,'VariableNames',pref_array_switch.description);

pref_array = [];

% after switch - physical

[pref_array]=check_preference_switch_mua(tim_win_as, muadata_90TO270, muadata_270TO90, tst_typ,tst_cnd);
pref_array_switch.as_pref_array_Phy = pref_array;
pref_array_switch.as_Phy_table = array2table(pref_array,'VariableNames',pref_array_switch.description);

pref_array = [];tst_cnd = [];


%% Check if the preference is maintained across conditions

% before switch and after switch - physical

conds = {'Physical - Before Switch';'Physical - After Switch'};
[pref_sim_switch_Phy_BsAs] = check_pref_sim(pref_array_switch.bs_pref_array_Phy,pref_array_switch.as_pref_array_Phy,conds);
pref_array_switch.pref_sim_switch_Phy_BsAs = pref_sim_switch_Phy_BsAs;

% before switch and after switch - rivalry

conds = {'Rivalry - Before Switch';'Rivalry - After Switch'};
[pref_sim_switch_Riv_BsAs] = check_pref_sim(pref_array_switch.bs_pref_array_Riv,pref_array_switch.as_pref_array_Riv,conds);
pref_array_switch.pref_sim_switch_Riv_BsAs = pref_sim_switch_Riv_BsAs;

% before switch - physical and rivalry

conds = {'Physical - Before Switch';'Rivalry - Before Switch'};
[pref_sim_switch_PhyRiv_BsBs] = check_pref_sim(pref_array_switch.bs_pref_array_Phy,pref_array_switch.bs_pref_array_Riv,conds);
pref_array_switch.pref_sim_switch_PhyRiv_BsBs = pref_sim_switch_PhyRiv_BsBs;

% after switch - physical and rivalry

conds = {'Physical - After Switch';'Rivalry - After Switch'};
[pref_sim_switch_PhyRiv_AsAs] = check_pref_sim(pref_array_switch.as_pref_array_Phy,pref_array_switch.as_pref_array_Riv,conds);
pref_array_switch.pref_sim_switch_PhyRiv_AsAs = pref_sim_switch_PhyRiv_AsAs;

% before switch and after switch - physical and rivalry

conds = {'Physical - Before and After Switch';'Rivalry - Before and After Switch'};
[pref_sim_switch_PhyRiv_BsAs] = check_pref_sim(pref_sim_switch_Phy_BsAs.com_sig_u,pref_sim_switch_Riv_BsAs.com_sig_u,conds);
pref_array_switch.pref_sim_switch_PhyRiv_BsAs = pref_sim_switch_PhyRiv_BsAs;


% % % 
% % % 
% % % % if an_info.sdf_moa_fil == 0
% % %     cd(sav_dir);
% % %     save('pref_array_switch.mat', 'pref_array_switch');
% % % % end
% % % 
% % % %  Make and save the bar plot with all the preferences
% % % %%% check this part again
% % % sav_fig = saveOrNot(an_info.barPlot_Pref);
% % % generate_barplot_stats(pref_sim_switch_Riv_BsAs,ttl_suffix,sav_dir,sav_fig);






