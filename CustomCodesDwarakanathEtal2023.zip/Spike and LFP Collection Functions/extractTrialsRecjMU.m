function [spikingActivity,times] = extractTrialsRecjMU(eventfile,spikeStruct,qnxfile,ss,es,chans,directories,type);

% Abhilash D. MPIBC 2016/17 for Fanis AG.

params.fs = 3e4;
%% Read the .clu file and separate the spikes into different single units

cluFileName = 'autoResult';

[cluing, ~, existnoise, existjunk] = clus_readClu(cluFileName, chans); % existnoise and existjunk are either 0 or 1. 0 means doesn't exist. 1 means exists.

switch type
    
    case{'jMU','jmu','JMU','jMUA','jmua','JMUA'}
        
        if existjunk
            cinds = 1:size(cluing,2)-1; % If junk exists, for jMU take MU+SUs leaving out the last column which is junk
        elseif existjunk==0
            cinds = 1:size(cluing,2); % If junk doesn't exist, take all columns.
        end
        
        
    case{'mu','MU','mua','MUA'}
        
        if existnoise % If noise exists, i.e. MU, take the first column
            cinds=1;
        elseif existnoise==0 % If no MU exists, then fuck it
            cinds = [];
        end
        
end

%% Load Timestamps and EM files

cd(directories.taskdirPFC)
load('NSX_TimeStamps.mat')

T=TimeStamps./1e3;
T = T.*30;

em = read_NC5('NSX130.NC5',1,length(TimeStamps));

%% Extract trials

if isempty(cinds)
    disp('no MUA found, skipping channel...')
    spikingActivity = NaN;
    times = NaN;
else
    disp('One or more units found! Collecting spikesByTime...')
    
    % Separate out spike indices belonging to each cluster
    for i = cinds
        clusSpks{i} = find(cluing(:,i)==1);
    end
    
    % Collect spike times belonging to each cluster, put them together in one long vector and sort the times.
    
    spikes = [];
    for i = 1:length(clusSpks)
        spikes = [spikes spikeStruct.times(clusSpks{i})];
    end
    
    spikes = sort(spikes);
    
    %% Read QNX file and get the timestamps of the pulses that matter
    
    cd(directories.taskdirPFC);
    
    [~, experimentInfo] = dg_read_eyeInfo_VK(qnxfile); %#ok<*ASGLU>
    
    exptType = experimentInfo.name;
    
    digtimes = eventfile.Data.SerialDigitalIO.TimeStamp(eventfile.Data.SerialDigitalIO.TimeStamp>ss&eventfile.Data.SerialDigitalIO.TimeStamp<es);
    digInds = find(eventfile.Data.SerialDigitalIO.TimeStamp>ss&eventfile.Data.SerialDigitalIO.TimeStamp<es);
    
    digpuls = eventfile.Data.SerialDigitalIO.UnparsedData(digInds(1):digInds(end));
    digtim = eventfile.Data.SerialDigitalIO.TimeStamp(digInds(1):digInds(end));
    
    %% Correct for recording reset. For some strange fucking reason, this seems to work.
    
    if isfield(eventfile,'timeCorr')==1
        d = diff(double(digtim));
        [idx idx] = find(d<0);
        digtim(idx+1:end) = digtim(idx+1:end)+eventfile.timeCorr;
    end
    %
    %% Extract pulses from the NEV file
    
    % Beginobs
    
    beginobstim = [];
    beginobstim(1) = 0;
    beginobspuls_id = [];
    j = 1;
    oldpuls = 0;
    
    % Find all the beginobstimes, trial start time.
    
    for i = 1:length(digpuls)
        
        %fprintf('%d %d \n', digpuls(i), oldpuls);
        
        if (bitand(digpuls(i),1) == 1 && oldpuls == 0)
            
            beginobstim(j) = digtim(i);
            beginobspuls_id(j) = i;
            
            j = j+1;
            
            %fprintf('found \n');
            
        end
        
        oldpuls = bitand(digpuls(i),1);
        
    end
    
    
    % Endobs
    
    endobstim = [];
    endobstim(1) = 0;
    endobspuls_id = [];
    j = 1;
    oldpuls = 0;
    
    % Find all the endobstimes, trial start time.
    
    for i = 1:length(digpuls)
        
        %fprintf('%d %d \n', bitand(digpuls(i),1), oldpuls);
        
        if (bitand(digpuls(i),1) == 0 && oldpuls == 1)
            
            endobstim(j) = digtim(i);
            endobspuls_id(j) = i;
            
            j = j+1;
            
            %fprintf('found \n');
            
        end
        
        oldpuls = bitand(digpuls(i),1);
        
    end
    
    %% Extract all which are correct trials
    if strcmp(exptType, 'im_riv')==1
        begobs_corrtrl = beginobspuls_id;
        endobs_corrtrl = endobspuls_id;
    else
        begobs_corrtrl = beginobspuls_id(experimentInfo.trl_outcome.corr_trl_idx);
        endobs_corrtrl = endobspuls_id(experimentInfo.trl_outcome.corr_trl_idx);
    end
    
    %% Get all the pulses in the correct trial and assign them to different conditions
    
    
    for i = 1:length(begobs_corrtrl)
        
        corrtrl_events_temp = (begobs_corrtrl(i):endobs_corrtrl(i));
        
        corrtrl_events{i} = corrtrl_events_temp;
        
        corrtrl_eventtim_temp = digtim(corrtrl_events_temp);
        
        corrtrl_event_tim{i} = corrtrl_eventtim_temp;
        
    end
    
    switch exptType
        
        case {'AuSeq'}
            
            conds = 6;
            
            habCnt = zeros(1,conds);
            devCnt = zeros(1,conds);
            
            % Collect times
            
            types = unique(experimentInfo.trialInfo);
            
            typesDev = types(types>0);
            
            for j = 1:length(corrtrl_events)
                trialType = experimentInfo.trialInfo(j);
                if trialType < 0
                    habCnt(abs(trialType)) = habCnt(abs(trialType))+1;
                    times.hab.beginObs{abs(trialType)}{habCnt(abs(trialType))} = corrtrl_event_tim{j}(1);
                    times.hab.stimON{abs(trialType)}{habCnt(abs(trialType))} = experimentInfo.times.stimON(j);
                    times.hab.endObs{abs(trialType)}{habCnt(abs(trialType))} = corrtrl_event_tim{j}(end);
                elseif types(7)<10
                    devCnt(abs(trialType-3)) = devCnt(abs(trialType-3))+1;
                    times.dev.beginObs{abs(trialType-3)}{devCnt(abs(trialType-3))} = corrtrl_event_tim{j}(1);
                    times.dev.stimON{abs(trialType-3)}{devCnt(abs(trialType-3))} = experimentInfo.times.stimON(j);
                    times.dev.endObs{abs(trialType-3)}{devCnt(abs(trialType-3))} = corrtrl_event_tim{j}(end);
                else
                    devCnt(abs(trialType-13)) = devCnt(abs(trialType-13))+1;
                    times.dev.beginObs{abs(trialType-13)}{devCnt(abs(trialType-13))} = corrtrl_event_tim{j}(1);
                    times.dev.stimON{abs(trialType-13)}{devCnt(abs(trialType-13))} = experimentInfo.times.stimON(j);
                    times.dev.endObs{abs(trialType-13)}{devCnt(abs(trialType-13))} = corrtrl_event_tim{j}(end);
                    
                end
            end
            
            % Combine the weird deviants
            
            if sum(typesDev > 10) < 1 && typesDev(3)==6
            
            for i = [4 6]
                
                    
                    for j = 1:length(times.dev.beginObs{i})
                        
                        times.dev.beginObs{i-1}{j+3} = times.dev.beginObs{i}{j};
                        
                        times.dev.stimON{i-1}{j+3} = times.dev.stimON{i}{j};
                        
                        times.dev.endObs{i-1}{j+3} = times.dev.endObs{i}{j};
                        
                        
                    end
                
            end
            
            times.dev.beginObs(4) = [];
            times.dev.beginObs(5) = [];
            
            times.dev.stimON(4) = [];
            times.dev.stimON(5) = [];
            
            times.dev.endObs(4) = [];
            times.dev.endObs(5) = [];
            
           
            
            elseif sum(typesDev > 10) < 1 && typesDev(3)==8
                
                times.dev.beginObs(3) = [];
                times.dev.beginObs(3) = [];
                
                times.dev.stimON(3) = [];
                times.dev.stimON(3) = [];
                
                times.dev.endObs(3) = [];
                times.dev.endObs(3) = [];
                
            end
                        
            
            % Extract Spikes
            
            for iCond = 1:conds
                
                for nTr = 1:length(times.hab.beginObs{iCond})
                    
                    spikesByTime.hab{iCond}{nTr} = (spikes(spikes>=(times.hab.beginObs{iCond}{nTr})&spikes<=times.hab.endObs{iCond}{nTr}));
                    
                end
                
            end
            
            for iCond = 1:conds-2
                
                for nTr = 1:length(times.dev.beginObs{iCond})
                    
                    spikesByTime.dev{iCond}{nTr} = (spikes(spikes>=(times.dev.beginObs{iCond}{nTr})&spikes<=times.dev.endObs{iCond}{nTr}));
                    
                end
                
            end
            
            %% Align to Trial start and Stim ON
            
            for iCond = 1:conds
                
                for nTr = 1:length(times.hab.beginObs{iCond})
                    
                    temp = spikesByTime.hab{iCond}{nTr};
                    s1 = times.hab.beginObs{iCond}{nTr};
                    spikesBySamples.hab{iCond}{nTr} = (temp-double(s1));
                    spikesByTime.hab{iCond}{nTr} = (temp-double(s1))./30;
                    spikesByTimeSOA.hab{iCond}{nTr} = spikesByTime.hab{iCond}{nTr} - times.hab.stimON{iCond}{nTr};
                    
                end
                
            end
            
            for iCond = 1:conds-2
                
                for nTr = 1:length(times.dev.beginObs{iCond})
                    
                    temp = spikesByTime.dev{iCond}{nTr};
                    s1 = times.dev.beginObs{iCond}{nTr};
                    spikesBySamples.dev{iCond}{nTr} = (temp-double(s1));
                    spikesByTime.dev{iCond}{nTr} = (temp-double(s1))./30;
                    spikesByTimeSOA.dev{iCond}{nTr} = spikesByTime.dev{iCond}{nTr} - times.dev.stimON{iCond}{nTr};
                    
                end
                
            end
            
            %% Collect
            
            spikingActivity.trial.spikesUnaligned = spikesByTime;
            spikingActivity.trial.spikesSOAligned = spikesByTimeSOA;
            spikingActivity.trial.hab = ['-1 -2 -3 -4 -5 -6'];
            spikingActivity.trial.dev = ['4 5 6 7 8 9'];
            
        case {'Bfsgrad','Bfsgrad1','Bfsnatur','Bfsnatur1'}
            
            for iCond = 1 : 8
                tmpInd = find(experimentInfo.trialLabel == iCond);
                for j = 1:length(tmpInd)
                    times.beginObs{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(1);
                    times.stimON{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(2);
                    times.maskON{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(3:end-2);
                    times.endObs{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(end-1); % Call it endobs but cut off at Reward!
                end
            end
            
            
            %% Extract spikes from the given channel
            
            for iCond = 1:8
                
                for nTr = 1:length(times.beginObs{iCond})
                    
                    spikesByTime{iCond}{nTr} = (spikes(spikes>=(times.stimON{iCond}{nTr}-(300*(params.fs/1000)))&spikes<=times.endObs{iCond}{nTr}));
                    rawBeginDom = double(times.beginObs{iCond}{nTr}/30);
                    tmpBegin = abs(T - rawBeginDom);
                    [OKNidxBegin OKNidxBegin] = min(tmpBegin);
                    rawEndDom = double(times.endObs{iCond}{nTr}/30);
                    tmpEnd = abs(T - rawEndDom);
                    [OKNidxEnd OKNidxEnd] = min(tmpEnd);
                    trialOKN.trace{iCond}{nTr} = em(OKNidxBegin:OKNidxEnd);
                    eventTimes{iCond}{nTr} = [0 (double(times.stimON{iCond}{nTr})-double(times.beginObs{iCond}{nTr}))/params.fs (double(times.maskON{iCond}{nTr})-double(times.beginObs{iCond}{nTr}))/params.fs (double(times.endObs{iCond}{nTr})-double(times.beginObs{iCond}{nTr}))/params.fs];
                    
                end
                
            end
            
            
            %% Align to Trial start
            for iCond = 1:8
                
                for nTr = 1:length(times.beginObs{iCond})
                    
                    temp = spikesByTime{iCond}{nTr};
                    s1 = times.beginObs{iCond}{nTr};
                    spikesBySamples{iCond}{nTr} = (temp-double(s1));
                    spikesByTime{iCond}{nTr} = (temp-double(s1))./30;
                    
                end
                
            end
            
            %% Align to stim ON
            
            for iCond = 1:8
                
                for nTr = 1:length(times.beginObs{iCond})
                    
                    temp = spikesBySamples{iCond}{nTr};
                    s1 = times.stimON{iCond}{nTr}(1)-times.beginObs{iCond}{nTr}(1);
                    spikesByTimeSOA{iCond}{nTr} = (temp-double(s1))./30;
                    
                end
                
            end
            
            
            %% Align to Mask ON
            
            for iCond = 1:8
                
                for nTr = 1:length(times.beginObs{iCond})
                    
                    temp = spikesBySamples{iCond}{nTr};
                    s1 = times.maskON{iCond}{nTr}(1)-times.beginObs{iCond}{nTr}(1);
                    spikesByTimeMOA{iCond}{nTr} = (temp-double(s1))./30;
                    
                end
                
            end
            
            
            %% Collect
            
            spikingActivity.spikesUnaligned = spikesByTime;
            spikingActivity.spikesSOAligned = spikesByTimeSOA;
            spikingActivity.spikesMOAligned = spikesByTimeMOA;
            spikingActivity.eventTimes = eventTimes;
            
        case{'OriDisk','OriDisk1','OriDiskfixoff','OriDiskfixoff1','OriDiskFixOn','OriDiskFixOff'}
            
            orisByTrial = experimentInfo.stimInfo;
            orisByTrial(experimentInfo.trl_outcome.iscorr_trl==0)=[];
            
            oris = unique(orisByTrial);
            
            for iCond = 1 : length(oris)
                tmpInd = find(orisByTrial == oris(iCond));
                for j = 1:length(tmpInd)
                    times.beginObs{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(1);
                    times.stimON{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(2);
                    times.endObs{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(end-1);
                end
            end
            
            %% Extract spikes from the given channel
            
            % StimON
            
            for iCond = 1:8
                
                for nTr = 1:length(times.beginObs{iCond})
                    
                    spikesByTime{iCond}{nTr} = (spikes(spikes>=(times.stimON{iCond}{nTr}-(300*(params.fs/1000)))&spikes<=times.endObs{iCond}{nTr}));
                    
                end
                
            end
            
            
            % Inter trial
            
            
            for iCond = 1:8
                
                for nTr = 1:length(times.beginObs{iCond})
                    
                    spikesByTimeIT{iCond}{nTr} = (spikes(spikes>=times.endObs{iCond}{nTr}&spikes<=(times.endObs{iCond}{nTr}+(1000*30))));
                    
                end
                
            end
            
            
            %% Align to Trial start
            
            for iCond = 1:8
                
                for nTr = 1:length(times.beginObs{iCond})
                    
                    temp = spikesByTime{iCond}{nTr};
                    s1 = times.beginObs{iCond}{nTr};
                    spikesBySamples{iCond}{nTr} = (temp-double(s1));
                    spikesByTime{iCond}{nTr} = (temp-double(s1))./30;
                    
                end
                
            end
            
            
            %% Align IT to endObs
            
            for iCond = 1:8
                
                for nTr = 1:length(times.beginObs{iCond})
                    
                    temp = spikesByTimeIT{iCond}{nTr};
                    s1 = times.endObs{iCond}{nTr};
                    spikesBySamplesIT{iCond}{nTr} = (temp-double(s1));
                    spikesByTimeIT{iCond}{nTr} = (temp-double(s1))./30;
                    
                end
                
            end
            
            
            %% Align to stim ON
            
            for iCond = 1:8
                
                for nTr = 1:length(times.beginObs{iCond})
                    
                    temp = spikesBySamples{iCond}{nTr};
                    s1 = times.stimON{iCond}{nTr}(1)-times.beginObs{iCond}{nTr}(1);
                    spikesByTimeSOA{iCond}{nTr} = (temp-double(s1))./30;
                    
                end
                
            end
            
            %% Collect
            
            spikingActivity.trial.spikesUnaligned = spikesByTime;
            spikingActivity.trial.spikesSOAligned = spikesByTimeSOA;
            spikingActivity.intertrial.spikesEOAligned = spikesByTimeIT;
            
        case{'ImRiv','im_riv'}
            
            nBlankTimes = length(experimentInfo.trial_types);
            oris = length(experimentInfo.trial_types{1});
            
            % Get times
            
            for iBlankTimes = 1:nBlankTimes
                for iOris = 1 : oris
                    for iCond = 1:6 % 1 & 2 and Rivalry, rest are PA (3 = AA, 4 = AB, 5 = BB, 6 = BA)
                        % Get nTrials here
                        for j = 1:length(experimentInfo.trial_types{iBlankTimes}{iOris}{iCond})
                            times.beginObs{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(1);
                            times.stim1ON{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(2);
                            times.blankON{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(3);
                            times.eyeInWin{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(4);
                            times.stim2ON{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(5);
                            times.endObs{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(end-1); % Reward
                            
                        end
                    end
                    
                end
            end
            
            % get spikes
            
            for iBlankTimes = 1:nBlankTimes
                for iOris = 1 : oris
                    for iCond = 1:6 % 1 & 2 and Rivalry, rest are PA (3 = AA, 4 = AB, 5 = BB, 6 = BA)
                        for nTr = 1:length(times.beginObs{iBlankTimes}{iOris}{iCond})
                            spikesByTime{iBlankTimes}{iOris}{iCond}{nTr} = (spikes(spikes>=(times.stim1ON{iBlankTimes}{iOris}{iCond}{nTr}-(300*(params.fs/1000)))&spikes<=times.endObs{iBlankTimes}{iOris}{iCond}{nTr}));
                        end
                    end
                end
            end
            
            %% Align to Trial start
            for iBlankTimes = 1:nBlankTimes
                for iOris = 1 : oris
                    for iCond = 1:6 % 1 & 2 and Rivalry, rest are PA (3 = AA, 4 = AB, 5 = BB, 6 = BA)
                        for nTr = 1:length(times.beginObs{iBlankTimes}{iOris}{iCond})
                            
                            temp = spikesByTime{iBlankTimes}{iOris}{iCond}{nTr};
                            s1 = times.beginObs{iBlankTimes}{iOris}{iCond}{nTr};
                            spikesBySamples{iBlankTimes}{iOris}{iCond}{nTr} = (temp-double(s1));
                            spikesByTime{iBlankTimes}{iOris}{iCond}{nTr} = (temp-double(s1))./30;
                            
                        end
                        
                    end
                    
                end
                
            end
            
            %% Align to stim1 ON
            
            for iBlankTimes = 1:nBlankTimes
                for iOris = 1 : oris
                    for iCond = 1:6 % 1 & 2 and Rivalry, rest are PA (3 = AA, 4 = AB, 5 = BB, 6 = BA)
                        for nTr = 1:length(times.beginObs{iBlankTimes}{iOris}{iCond})
                            
                            temp = spikesBySamples{iBlankTimes}{iOris}{iCond}{nTr};
                            s1 = times.stim1ON{iBlankTimes}{iOris}{iCond}{nTr}-times.beginObs{iBlankTimes}{iOris}{iCond}{nTr};
                            spikesByTimeS1OA{iCond}{nTr} = (temp-double(s1))./30;
                            
                        end
                        
                    end
                    
                end
                
            end
            
            %% Align to Blank ON
            
            for iBlankTimes = 1:nBlankTimes
                for iOris = 1 : oris
                    for iCond = 1:6 % 1 & 2 and Rivalry, rest are PA (3 = AA, 4 = AB, 5 = BB, 6 = BA)
                        for nTr = 1:length(times.beginObs{iBlankTimes}{iOris}{iCond})
                            
                            temp = spikesBySamples{iBlankTimes}{iOris}{iCond}{nTr};
                            s1 = times.blankON{iBlankTimes}{iOris}{iCond}{nTr}-times.beginObs{iBlankTimes}{iOris}{iCond}{nTr};
                            spikesByTimeBOA{iCond}{nTr} = (temp-double(s1))./30;
                            
                        end
                        
                    end
                    
                end
                
            end
            
            %% Align to stim2 ON
            
            for iBlankTimes = 1:nBlankTimes
                for iOris = 1 : oris
                    for iCond = 1:6 % 1 & 2 and Rivalry, rest are PA (3 = AA, 4 = AB, 5 = BB, 6 = BA)
                        for nTr = 1:length(times.beginObs{iBlankTimes}{iOris}{iCond})
                            
                            temp = spikesBySamples{iBlankTimes}{iOris}{iCond}{nTr};
                            s1 = times.stim2ON{iBlankTimes}{iOris}{iCond}{nTr}-times.beginObs{iBlankTimes}{iOris}{iCond}{nTr};
                            spikesByTimeS2OA{iCond}{nTr} = (temp-double(s1))./30;
                            
                        end
                        
                    end
                    
                end
                
            end
            
            %% Collect
            
            spikingActivity.trial.spikesUnaligned = spikesByTime;
            spikingActivity.trial.spikesS1OAligned = spikesByTimeS1OA;
            spikingActivity.trial.spikesS2OAligned = spikesByTimeS2OA;
            spikingActivity.trial.spikesBOAligned = spikesByTimeBOA;
            
    end
end
end