function [lfpByTrials,times] = extractTrialsLFP(params,recfile,eventfile,qnxfile,ss,es,directories);

%% Read the NC5 file

cd(directories.PFC)
if isfield(eventfile,'timeCorr')==1
    ess = es+eventfile.timeCorr+ss-1;
    LFPStruct = read_NC5(recfile,ss,ess);
else
    LFPStruct = read_NC5(recfile,ss,es);
end

%% Read QNX file and get the timestamps of the pulses that matter

cd(directories.taskdirPFC)
[~, experimentInfo] = dg_read_eyeInfo_VK(qnxfile); %#ok<*ASGLU>
exptType = experimentInfo.name;
digtimes = eventfile.Data.SerialDigitalIO.TimeStamp(eventfile.Data.SerialDigitalIO.TimeStamp>ss&eventfile.Data.SerialDigitalIO.TimeStamp<es);
digInds = find(eventfile.Data.SerialDigitalIO.TimeStamp>ss&eventfile.Data.SerialDigitalIO.TimeStamp<es);

digpuls = eventfile.Data.SerialDigitalIO.UnparsedData(digInds(1):digInds(end));
digtim = eventfile.Data.SerialDigitalIO.TimeStamp(digInds(1):digInds(end));

%% Correct for recording reset. For some strange fucking reason, this seems to work.

if isfield(eventfile,'timeCorr')==1
    d = diff(double(digtim));
    [idx idx] = find(d<0);
    digtim(idx+1:end) = digtim(idx+1:end)+eventfile.timeCorr;
end

%% Extract pulses from the NEV file

% Beginobs

beginobstim = [];
beginobstim(1) = 0;
beginobspuls_id = [];
j = 1;
oldpuls = 0;

% Find all the beginobstimes, trial start time.

for i = 1:length(digpuls)
    
    %fprintf('%d %d \n', digpuls(i), oldpuls);
    
    if (bitand(digpuls(i),1) == 1 && oldpuls == 0)
        
        beginobstim(j) = digtim(i);
        beginobspuls_id(j) = i;
        
        j = j+1;
        
        %fprintf('found \n');
        
    end
    
    oldpuls = bitand(digpuls(i),1);
    
end


% Endobs

endobstim = [];
endobstim(1) = 0;
endobspuls_id = [];
j = 1;
oldpuls = 0;

% Find all the endobstimes, trial start time.

for i = 1:length(digpuls)
    
    %fprintf('%d %d \n', bitand(digpuls(i),1), oldpuls);
    
    if (bitand(digpuls(i),1) == 0 && oldpuls == 1)
        
        endobstim(j) = digtim(i);
        endobspuls_id(j) = i;
        
        j = j+1;
        
        %fprintf('found \n');
        
    end
    
    oldpuls = bitand(digpuls(i),1);
    
end

%% Extract all which are correct trials

if strcmp(exptType,'im_riv')
    begobs_corrtrl = beginobspuls_id;
    endobs_corrtrl = endobspuls_id;
else
    begobs_corrtrl = beginobspuls_id(experimentInfo.trl_outcome.corr_trl_idx);
    endobs_corrtrl = endobspuls_id(experimentInfo.trl_outcome.corr_trl_idx);
end

%% Get all the pulses in the correct trial and assign them to different conditions


for i = 1:length(begobs_corrtrl)
    
    corrtrl_events_temp = (begobs_corrtrl(i):endobs_corrtrl(i));
    
    corrtrl_events{i} = corrtrl_events_temp;
    
    corrtrl_eventtim_temp = digtim(corrtrl_events_temp);
    
    corrtrl_event_tim{i} = corrtrl_eventtim_temp;
    
end

switch exptType
    
    case {'AuSeq'}
        
        conds = 6;
        
        habCnt = zeros(1,conds);
        devCnt = zeros(1,conds);
        
        types = unique(experimentInfo.trialInfo);
        
        typesDev = types(types>0);
        
        % Collect times
        
        for j = 1:length(corrtrl_events)
            trialType = experimentInfo.trialInfo(j);
            if trialType < 0 % Habituation types. Here they are all separately categorised. This can be changed to collapse all hab trials
                habCnt(abs(trialType)) = habCnt(abs(trialType))+1;
                times.hab.beginObs{abs(trialType)}{habCnt(abs(trialType))} = corrtrl_event_tim{j}(1);
                times.hab.stimON{abs(trialType)}{habCnt(abs(trialType))} = experimentInfo.times.stimON(j);
                times.hab.endObs{abs(trialType)}{habCnt(abs(trialType))} = corrtrl_event_tim{j}(end);
            elseif types(7)<10
                devCnt(abs(trialType-3)) = devCnt(abs(trialType-3))+1;
                times.dev.beginObs{abs(trialType-3)}{devCnt(abs(trialType-3))} = corrtrl_event_tim{j}(1);
                times.dev.stimON{abs(trialType-3)}{devCnt(abs(trialType-3))} = experimentInfo.times.stimON(j);
                times.dev.endObs{abs(trialType-3)}{devCnt(abs(trialType-3))} = corrtrl_event_tim{j}(end);
            else
                devCnt(abs(trialType-13)) = devCnt(abs(trialType-13))+1;
                times.dev.beginObs{abs(trialType-13)}{devCnt(abs(trialType-13))} = corrtrl_event_tim{j}(1);
                times.dev.stimON{abs(trialType-13)}{devCnt(abs(trialType-13))} = experimentInfo.times.stimON(j);
                times.dev.endObs{abs(trialType-13)}{devCnt(abs(trialType-13))} = corrtrl_event_tim{j}(end);
            end
        end
        
        % Combine the weird deviants
            
            if sum(typesDev > 10) < 1 && typesDev(3)==6
            
            for i = [4 6]
                
                    
                    for j = 1:length(times.dev.beginObs{i})
                        
                        times.dev.beginObs{i-1}{j+3} = times.dev.beginObs{i}{j};
                        
                        times.dev.stimON{i-1}{j+3} = times.dev.stimON{i}{j};
                        
                        times.dev.endObs{i-1}{j+3} = times.dev.endObs{i}{j};
                        
                        
                    end
                
            end
            
            times.dev.beginObs(4) = [];
            times.dev.beginObs(5) = [];
            
            times.dev.stimON(4) = [];
            times.dev.stimON(5) = [];
            
            times.dev.endObs(4) = [];
            times.dev.endObs(5) = [];
            
           
            
            elseif sum(typesDev > 10) < 1 && typesDev(3)==8
                
                times.dev.beginObs(3) = [];
                times.dev.beginObs(3) = [];
                
                times.dev.stimON(3) = [];
                times.dev.stimON(3) = [];
                
                times.dev.endObs(3) = [];
                times.dev.endObs(3) = [];
                
            end
        
        % Extract Spikes
        
        for iCond = 1:conds
            
            for nTr = 1:length(times.hab.beginObs{iCond})
                
                decimLFP = (LFPStruct(times.hab.beginObs{iCond}{nTr}-ss:times.hab.endObs{iCond}{nTr}-ss));
                
                for decs = 1:length(params.decimFacs)
                    
                    decimLFP = decimate(decimLFP,params.decimFacs(decs));
                    
                end
                
                lfpByTime.hab{iCond}{nTr} = decimLFP;
                
            end
            
        end
        
        for iCond = 1:conds-2
            
            for nTr = 1:length(times.dev.beginObs{iCond})
                
                decimLFP = (LFPStruct(times.dev.beginObs{iCond}{nTr}-ss:times.dev.endObs{iCond}{nTr}-ss));
                
                for decs = 1:length(params.decimFacs)
                    
                    decimLFP = decimate(decimLFP,params.decimFacs(decs));
                    
                end
                
                lfpByTime.dev{iCond}{nTr} = decimLFP;
                
                
            end
            
        end
        
        lfpByTrials.trial.lfps = lfpByTime;
        lfpByTrials.trial.hab = ['-1 -2 -3 -4 -5 -6'];
        lfpByTrials.trial.dev = ['4 5 6 7 8 9'];
        
    case {'Bfsgrad','Bfsgrad1','Bfsnatur','Bfsnatur1'}
        
        for iCond = 1 : 8
            tmpInd = find(experimentInfo.trialLabel == iCond);
            for j = 1:length(tmpInd)
                times.beginObs{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(1);
                times.stimON{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(2);
                times.maskON{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(3:end-2);
                times.endObs{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(end-1); % Call it endobs but cut off at Reward!
            end
        end
        
        
        %% Extract LFPs from the given channel
        
        for iCond = 1:8
            
            for nTr = 1:length(times.beginObs{iCond})
                
                %decimLFP = (LFPStruct((times.stimON{iCond}{nTr}-(300*(params.fs/1000)))-ss:times.endObs{iCond}{nTr}-ss));
                decimLFP = (LFPStruct((times.beginObs{iCond}{nTr})-ss:times.endObs{iCond}{nTr}-ss));
                
                for decs = 1:length(params.decimFacs)
                    
                    decimLFP = decimate(decimLFP,params.decimFacs(decs));
                    
                end
                
                lfpByTime{iCond}{nTr} = decimLFP;
                
            end
            
        end
        
        lfpByTrials = lfpByTime;
        
    case{'OriDisk','OriDisk1','OriDiskfixoff','OriDiskfixoff1','OriDiskFixOn','OriDiskFixOff'}
        
        orisByTrial = experimentInfo.stimInfo;
        orisByTrial(experimentInfo.trl_outcome.iscorr_trl==0)=[];
        
        oris = unique(orisByTrial);
        
        for iCond = 1 : length(oris)
            tmpInd = find(orisByTrial == oris(iCond));
            for j = 1:length(tmpInd)
                times.beginObs{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(1);
                times.stimON{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(2);
                times.endObs{iCond}{j} = corrtrl_event_tim{tmpInd(j)}(end-1);
            end
        end
        
        %% Extract LFPs from the given channel
        
        % StimON
        
        for iCond = 1:8
            
            for nTr = 1:length(times.beginObs{iCond})
                
                decimLFP = (LFPStruct((times.stimON{iCond}{nTr}-(300*(params.fs/1000)))-ss:times.endObs{iCond}{nTr}-ss));
                
                for decs = 1:length(params.decimFacs)
                    
                    decimLFP = decimate(decimLFP,params.decimFacs(decs));
                    
                end
                
                lfpByTime{iCond}{nTr} = decimLFP;
                
            end
            
        end
        
        
        lfpByTrials = lfpByTime;
        
    case{'ImRiv','im_riv'}
        
        nBlankTimes = length(experimentInfo.trial_types);
        oris = length(experimentInfo.trial_types{1});
        
        % Get times
        
        for iBlankTimes = 1:nBlankTimes
            for iOris = 1 : oris
                for iCond = 1:6 % 1 & 2 and Rivalry, rest are PA (3 = AA, 4 = AB, 5 = BB, 6 = BA)
                    % Get nTrials here
                    for j = 1:length(experimentInfo.trial_types{iBlankTimes}{iOris}{iCond})
                        times.beginObs{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(1);
                        times.stim1ON{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(2);
                        times.blankON{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(3);
                        times.eyeInWin{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(4);
                        times.stim2ON{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(5);
                        times.endObs{iBlankTimes}{iOris}{iCond}{j} = corrtrl_event_tim{experimentInfo.trial_types{iBlankTimes}{iOris}{iCond}(j)}(end-1); % Reward
                        
                    end
                end
                
            end
        end
        
        % get LFPs
        
        for iBlankTimes = 1:nBlankTimes
            for iOris = 1 : oris
                for iCond = 1:6 % 1 & 2 and Rivalry, rest are PA (3 = AA, 4 = AB, 5 = BB, 6 = BA)
                    for nTr = 1:length(times.beginObs{iBlankTimes}{iOris}{iCond})
                        
                        decimLFP = (LFPStruct((times.stim1ON{iBlankTimes}{iOris}{iCond}{nTr}-(300*(params.fs/1000)))-ss:times.endObs{iBlankTimes}{iOris}{iCond}{nTr}-ss));
                        
                        for decs = 1:length(params.decimFacs)
                            
                            decimLFP = decimate(decimLFP,params.decimFacs(decs));
                            
                        end
                        
                        lfpByTime{iBlankTimes}{iOris}{iCond}{nTr} = decimLFP;
                        
                    end
                end
            end
        end
        
        lfpByTrials = lfpByTime;
        
end
