function trialInformation = collectTrialInformationMM(params,qnxfile,eventfile,array,sigType,delay)

dbstop if error

%% Load data
[~,experimentInfo] = dg_read_eyeInfo_VK(qnxfile); % Read the DGZ from the experimental state system and extract the required experiment and trial information

load(eventfile,'events','colors','times_audio')
events = events; % This is some ridiculous assignment I had to do because MATLAB is fucked up
trEvents = events; % This trEvents will be used when we want to collect specifically marked good events.
for i = 1:size(events,1)
    if trEvents(i,1)>1000 % We introduced events 1000+ to denote trial numbers. So 1001 would be the 1st trial
        events(i,1) = 1;
    end
end
beginObs = find(events(:,1)==1); % EventID 1 denotes the beginning of a trial
endObs = find(events(:,1)==4); % EventID 4 denotes the end of a trial
for nTr = 1:length(endObs) % Here we sort trials into conditions
    trEventsByTrial{nTr} = trEvents(beginObs(nTr),1);
    eventsbyTrial{nTr} = events(beginObs(nTr):endObs(nTr),1);
    eventTimesByTrial{nTr} = events(beginObs(nTr):endObs(nTr),2);
end

%% Separate out trials according to condition

if strcmp(array,'pfc') == 1
    
    for iCond = 1:params.conditions
        
        [idx] = find(experimentInfo.trialLabel==iCond);
        
        for nTr = 1:length(idx)
            
            eventsByCondition{iCond}{nTr} = eventsbyTrial{idx(nTr)};
            trialNumbersByCondition{iCond}{nTr} = trEventsByTrial{idx(nTr)}-1000;
            eventTimesByCondition{iCond}{nTr} = ceil((eventTimesByTrial{idx(nTr)}/1000)*30)-ceil((eventTimesByTrial{idx(nTr)}(1)/1000)*30);
            RaweventTimesByCondition{iCond}{nTr} = eventTimesByTrial{idx(nTr)}./1e3;
            
        end
        
    end
    
elseif strcmp(array,'ppc') % The events are only recorded on the system recording from the PFC array. The PPC array leads so we shift the timestamps
    
    for iCond = 1:params.conditions
        
        [idx] = find(experimentInfo.trialLabel==iCond);
        
        for nTr = 1:length(idx)
            
            eventsByCondition{iCond}{nTr} = eventsbyTrial{idx(nTr)};
            trialNumbersByCondition{iCond}{nTr} = trEventsByTrial{idx(nTr)}-1000;
            eventTimesByCondition{iCond}{nTr} = ceil(((eventTimesByTrial{idx(nTr)}/1000)*30 + delay.beginObs(idx(nTr))*30))-ceil(((eventTimesByTrial{idx(nTr)}(1)/1000)*30 + delay.beginObs(idx(nTr))*30)); % The delays are negative so the "frame" is shifted backward in time
            RaweventTimesByCondition{iCond}{nTr} = eventTimesByTrial{idx(nTr)}./1e3;
            
        end
        
    end
    
end

%% Collect trial information for SPON switches

for iCond = 1:params.conditions-4
    
    [idx] = find(experimentInfo.trialLabel==iCond);
    
    for nTr = 1:length(idx)
        clear evtsTimes
        tempEvts = eventsByCondition{iCond}{nTr};
        if strcmp(sigType,'spikes')==1
            tempTimes = eventTimesByCondition{iCond}{nTr}/30;
            rawTempTimes = RaweventTimesByCondition{iCond}{nTr};
        elseif strcmp(sigType,'lfp')==1
            tempTimes = eventTimesByCondition{iCond}{nTr}/30; % ALWAYS KEEP THIS IN MS NOT SAMPLES OTHERWISE ITS A BUG!
            rawTempTimes = RaweventTimesByCondition{iCond}{nTr};
        else
            error('Invalid signal type!\n')
        end
        evtsTimes(:,1) = tempEvts;
        evtsTimes(:,2) = tempTimes;
        rawEvtsTimes = rawTempTimes;
        c = 0;
        
        if sum(ismember(tempEvts,13))==1
            startIdx = 4;
        else
            startIdx = 3;
        end
        
        Evts = startIdx:size(evtsTimes,1);
        
        for i = startIdx:size(evtsTimes,1)
            
            if length(Evts)< 3
                
                if evtsTimes(i,1) == 3 && evtsTimes(i+1,1) == 4
                    c=c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 34;
                    evtStart{iCond}{nTr}(c)=evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                end
                
            else
                
                if evtsTimes(i,1) == 3 && evtsTimes(i+2,1) == 12
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+2,2)-evtsTimes(i,2);
                    if ismember(iCond,[1 3])
                        domId{iCond}{nTr}(c) = 3912; % 270 Flash Dominance
                    elseif ismember(iCond,[2 4])
                        domId{iCond}{nTr}(c) = 3712; % 90 Flash Dominance
                    end
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+2,2);
                elseif evtsTimes(i,1) == 11 && evtsTimes(i+1,1) == 12
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    if ismember(iCond,[1 3])
                        domId{iCond}{nTr}(c) = 11912; % 270 Flash Dominance
                    elseif ismember(iCond,[2 4])
                        domId{iCond}{nTr}(c) = 11712; % 90 Flash Dominance
                    end
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 7 && evtsTimes(i+1,1) == 8
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 78; % 90 Dominance Good
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 7 && evtsTimes(i+1,1) == 4
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 74; % 90 Dominance Truncated
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 9 && evtsTimes(i+1,1) == 4
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 94; % 270 Dominance Truncated
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 11 && evtsTimes(i+1,1) == 4
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 114; % Only Flash, nothing else
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                    
                    %% code added by Vishal
                    % for the truncated flash dominance
                elseif evtsTimes(i-1,1) == 3 && evtsTimes(i,1) == 11 && evtsTimes(i+1,1) == 4
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i-1,2);
                    if ismember(iCond,[1 3])
                        domId{iCond}{nTr}(c) = 394; % 270 Flash Dominance
                    elseif ismember(iCond,[2 4])
                        domId{iCond}{nTr}(c) = 374; % 90 Flash Dominance
                    end
                    evtStart{iCond}{nTr}(c) = evtsTimes(i-1,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                    % % code from Vishal over.
                    
                    
                elseif evtsTimes(i,1) == 9 && evtsTimes(i+1,1) == 10
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 910; % 270 Dominance Good
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 8 && evtsTimes(i+1,1) == 9
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 89; % Switch 90 to 270
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 10 && evtsTimes(i+1,1) == 7
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 107; % Switch 270 to 90
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 8 && evtsTimes(i+1,1) == 7
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 87; % No Switch, 90 dom restarts
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 10 && evtsTimes(i+1,1) == 9
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 109; % No Switch, 270 Dom restarts
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 12 && evtsTimes(i+1,1) == 9
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 129; % Switch Flash to 270
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 12 && evtsTimes(i+1,1) == 7
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 127; % Switch Flash to 90
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 3 && evtsTimes(i+1,1) == 8
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 38; % No Flash, but binocular, 90 dom
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                elseif evtsTimes(i,1) == 3 && evtsTimes(i+1,1) == 10
                    c = c+1;
                    durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                    domId{iCond}{nTr}(c) = 310; % No flash, but binocular, 270 Dom
                    evtStart{iCond}{nTr}(c) = evtsTimes(i,2);
                    evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                    
                end
                
            end
            
        end
    end
    
end

%% Collect trial information for PA switches

for iCond = 5:params.conditions
    
    [idx] = find(experimentInfo.trialLabel==iCond);
    
    for nTr = 1:length(idx)
        clear evtsTimes
        tempEvts = eventsByCondition{iCond}{nTr};
        if strcmp(sigType,'spikes')==1
            tempTimes = eventTimesByCondition{iCond}{nTr}/30;
            rawTempTimes = RaweventTimesByCondition{iCond}{nTr};
        elseif strcmp(sigType,'lfp')==1
            tempTimes = eventTimesByCondition{iCond}{nTr}/30; % ALWAYS KEEP THIS IN MS NOT SAMPLES OTHERWISE ITS A BUG!
            rawTempTimes = RaweventTimesByCondition{iCond}{nTr};
        else
            error('Invalid signal type!\n')
        end
        evtsTimes(:,1) = tempEvts;
        evtsTimes(:,2) = tempTimes;
        rawEvtsTimes = rawTempTimes;
        c = 0;
        if sum(ismember(tempEvts,13))==1
            startIdx = 4;
        else
            startIdx = 3;
        end
        
        for i = startIdx:size(evtsTimes,1)
            if evtsTimes(i,1) == 14 && evtsTimes(i+1,1) == 6 % Because of #14 i.e. MM
                c = c+1;
                durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                domId{iCond}{nTr}(c) = 5; % 270 Dominance
                evtStart{iCond}{nTr}(c) = evtsTimes(i,2); 
                evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
            elseif evtsTimes(i,1) == 14 && evtsTimes(i+1,1) == 5
                c = c+1;
                durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                domId{iCond}{nTr}(c) = 6; % 90 Dominance
                evtStart{iCond}{nTr}(c) = evtsTimes(i,2); 
                evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
            elseif evtsTimes(i,1) == 3 && evtsTimes(i+1,1) == 5
                c = c+1;
                durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                domId{iCond}{nTr}(c) = 6; % 90 Dominance
                evtStart{iCond}{nTr}(c) = evtsTimes(i,2); evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
            elseif evtsTimes(i,1) == 3 && evtsTimes(i+1,1) == 6
                c = c+1;
                durations{iCond}{nTr}(c) = evtsTimes(i+1,2)-evtsTimes(i,2);
                domId{iCond}{nTr}(c) = 5; % 90 Dominance
                evtStart{iCond}{nTr}(c) = evtsTimes(i,2); evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
                evtEnd{iCond}{nTr}(c) = evtsTimes(i+1,2);
            end
        end
    end
end


%% Collect everything

trialInformation.durations = durations;
trialInformation.eventIDs = domId;
trialInformation.eventStart = evtStart;
trialInformation.eventEnd = evtEnd;

save('trialInformationMM.mat','trialInformation','-v7.3')
