function times = extractEvents(digpuls,digtim,experimentInfo)
%% Extract pulses from the NEV file

% Beginobs

beginobstim = [];
beginobstim(1) = 0;
beginobspuls_id = [];
j = 1;
oldpuls = 0;

% Find all the beginobstimes, trial start time.

for i = 1:length(digpuls)
    
    %fprintf('%d %d \n', digpuls(i), oldpuls);
    
    if (bitand(digpuls(i),1) == 1 && oldpuls == 0)
        
        beginobstim(j) = digtim(i);
        beginobspuls_id(j) = i;
        
        j = j+1;
        
        %fprintf('found \n');
        
    end
    
    oldpuls = bitand(digpuls(i),1);
    
end


% Endobs

endobstim = [];
endobstim(1) = 0;
endobspuls_id = [];
j = 1;
oldpuls = 0;

% Find all the endobstimes, trial start time.

for i = 1:length(digpuls)
    
    %fprintf('%d %d \n', bitand(digpuls(i),1), oldpuls);
    
    if (bitand(digpuls(i),1) == 0 && oldpuls == 1)
        
        endobstim(j) = digtim(i);
        endobspuls_id(j) = i;
        
        j = j+1;
        
        %fprintf('found \n');
        
    end
    
    oldpuls = bitand(digpuls(i),1);
    
end

%% Extract all which are correct trials

if strcmp(experimentInfo.name,'im_riv')==1
    
    times.beginObs = beginobstim;
    times.endObs = endobstim;
else
    times.beginObs = beginobstim(experimentInfo.trl_outcome.corr_trl_idx);
    times.endObs = endobstim(experimentInfo.trl_outcome.corr_trl_idx);
end