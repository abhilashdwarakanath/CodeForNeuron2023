function [spikesCleanDominances] = collectCleanDominancesSpikesMM(params,jMUspikes,durs)

load('trialInformationMM.mat')

pad = 500; % Because of filtering stuff

%% Collect LFP For SPON

for chans = 1:params.elecs
    
    for iCond = 1:params.conditions-4
        
        cDom90 = 0;
        cDom270 = 0;
        
        for iTr = 1:length(trialInformation.durations{iCond})
            
            if isempty(trialInformation.durations{iCond}{iTr})
                
                fprintf('This trial is empty, moving on...\n')
                
            else
                clear tinf
                tinf(:,1) = trialInformation.eventIDs{iCond}{iTr}; % Events
                tinf(:,2) = trialInformation.durations{iCond}{iTr}; % Durations
                tinf(:,3) = (trialInformation.eventStart{iCond}{iTr}); %Start time IN SAMPLES FOR LFP
                tinf(:,4) = (trialInformation.eventEnd{iCond}{iTr}); %End time IN SAMPLES FOR LFP
                tinf(:,5) = trialInformation.eventStart{iCond}{iTr}; %Start time IN SAMPLES FOR OKN
                tinf(:,6) = trialInformation.eventEnd{iCond}{iTr}; %End time IN SAMPLES FOR OKN
                
                % Look for 270TO90 Switches
                clear idx90
                [idx90]=find(tinf(:,1)==107 | tinf(:,1)==127);
                
                for iSwitch = 1:length(idx90)
                    
                    if tinf(idx90(iSwitch),2)<=durs.switch && tinf(idx90(iSwitch)-1,2)>=durs.domBehind && tinf(idx90(iSwitch)+1,2)>=durs.domForward
                        
                        cDom90 = cDom90+1;
                        beginDomBehind = tinf(idx90(iSwitch)-1,3);
                        beginDomForward = tinf(idx90(iSwitch)+1,3);
                        beginOknForward = tinf(idx90(iSwitch)+1,5);
                        endDomBehind = tinf(idx90(iSwitch)-1,4);
                        endDomForward = tinf(idx90(iSwitch)+1,4);
                        %lfpActivity.BR.data.dom90{chans}{iCond}{cDom90} = LFP.data{chans}{iCond}{iTr}(ceil(beginDomBehind):ceil(endDomForward));
                        endDomTimes.BR.data.endPrevDom.dom90{iCond}{cDom90} = (endDomBehind-beginDomForward);
                        spikes.BR.data.dom90{chans}{iCond}{cDom90} = (jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}(jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}>=(beginDomForward-durs.domBehind)&jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}<=(beginDomForward+durs.domForward)))-beginDomForward;
                        oknTraces.BR.data.dom90{iCond}{cDom90} = jMUspikes.data{chans}.okn.trace{iCond}{iTr}(ceil(beginOknForward-(durs.domBehind)):ceil(beginOknForward+(durs.domForward)));
                        spikingActivity.BR.data.trialDomInfo.dom90{iCond}{cDom90}(1,:) = iTr;
                        spikingActivity.BR.data.trialDomInfo.dom90{iCond}{cDom90}(2,:) = iSwitch;
                    end
                end
                
                % Look for 90TO270 Switches
                
                clear idx270
                [idx270]=find(tinf(:,1)==89 | tinf(:,1)==129);
                
                for iSwitch = 1:length(idx270)
                    
                    if tinf(idx270(iSwitch),2)<=durs.switch && tinf(idx270(iSwitch)-1,2)>=durs.domBehind && tinf(idx270(iSwitch)+1,2)>=durs.domForward
                        
                        cDom270 = cDom270+1;
                        beginDomBehind = tinf(idx270(iSwitch)-1,3);
                        beginDomForward = tinf(idx270(iSwitch)+1,3);
                        beginOknForward = tinf(idx270(iSwitch)+1,5);
                        endDomBehind = tinf(idx270(iSwitch)-1,4);
                        endDomForward = tinf(idx270(iSwitch)+1,4);
                        endDomTimes.BR.data.endPrevDom.dom270{iCond}{cDom270} = (endDomBehind-beginDomForward);
                        spikes.BR.data.dom270{chans}{iCond}{cDom270} = (jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}(jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}>=(beginDomForward-durs.domBehind)&jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}<=(beginDomForward+durs.domForward)))-beginDomForward;
                        oknTraces.BR.data.dom270{iCond}{cDom270} = jMUspikes.data{chans}.okn.trace{iCond}{iTr}(ceil(beginOknForward-(durs.domBehind)):ceil(beginOknForward+(durs.domForward)));
                        spikingActivity.BR.data.trialDomInfo.dom270{iCond}{cDom270}(1,:) = iTr;
                        spikingActivity.BR.data.trialDomInfo.dom270{iCond}{cDom270}(2,:) = iSwitch;
                    end
                end
                
            end
            
        end
        
    end
    
end

%% Collect LFP For PA

for chans = 1:params.elecs
    
    for iCond = [5 7]
        
        cDom90 = 0;
        cDom270 = 0;
        
        for iTr = 1:length(trialInformation.durations{iCond})
            
            if isempty(trialInformation.durations{iCond}{iTr})
                
                fprintf('This trial is empty, moving on...\n')
                
            else
                clear tinf
                tinf(:,1) = trialInformation.eventIDs{iCond}{iTr}; % Events
                tinf(:,2) = trialInformation.durations{iCond}{iTr}; % Durations
                tinf(:,3) = (trialInformation.eventStart{iCond}{iTr}); %Start time IN SAMPLES FOR LFP
                tinf(:,4) = (trialInformation.eventEnd{iCond}{iTr});
                tinf(:,5) = trialInformation.eventStart{iCond}{iTr}; %Start time IN SAMPLES FOR OKN
                tinf(:,6) = trialInformation.eventEnd{iCond}{iTr}; %End time IN SAMPLES FOR OKN
                
                % Look for 270TO90 Switches
                clear idx90
                [idx90]=find(tinf(:,1)== 6);
                [idx14] = find(tinf(:,1)==14);
                
                for iSwitch = 1:length(idx90)
                    
                    if tinf(idx90(iSwitch)-1,2)>=durs.domBehind && tinf(idx90(iSwitch),2)>=durs.domForward
                        
                        cDom90 = cDom90+1;
                        beginDomBehind = tinf(idx90(iSwitch)-1,3);
                        beginDomForward = tinf(idx90(iSwitch),3);
                        beginOknForward = tinf(idx90(iSwitch),5);
                        endDomBehind = tinf(idx90(iSwitch)-1,4);
                        endDomForward = tinf(idx90(iSwitch),4);
                       spikes.PA.data.dom90{chans}{iCond}{cDom90} = (jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}(jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}>=(beginDomForward-durs.domBehind)&jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}<=(beginDomForward+durs.domForward)))-beginDomForward;
                        %oknTraces.PA.data.dom90{iCond}{cDom90} = jMUspikes.data{chans}.okn.trace{iCond}{iTr}(ceil(beginOknForward-(durs.domBehind)):ceil(beginOknForward+(durs.domForward)));
                        spikingActivity.PA.data.trialDomInfo.dom90{iCond}{cDom90}(1,:) = iTr;
                        spikingActivity.PA.data.trialDomInfo.dom90{iCond}{cDom90}(2,:) = iSwitch;
                        spikingActivity.PA.data.trialDomInfo.dom90{iCond}{cDom90}(3,:) = beginDomForward;
                    end
                end
                
                % Look for 90TO270 Switches
                
                clear idx270
                [idx270]=find(tinf(:,1)==5);
                
                for iSwitch = 2:length(idx270)
                    
                    if tinf(idx270(iSwitch)-1,2)>=durs.domBehind && tinf(idx270(iSwitch),2)>=durs.domForward
                        
                        cDom270 = cDom270+1;
                        beginDomBehind = tinf(idx270(iSwitch)-1,3);
                        beginDomForward = tinf(idx270(iSwitch),3);
                        beginOknForward = tinf(idx270(iSwitch),5);
                        endDomBehind = tinf(idx270(iSwitch)-1,4);
                        endDomForward = tinf(idx270(iSwitch),4);
                        spikes.PA.data.dom270{chans}{iCond}{cDom270} = (jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}(jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}>=(beginDomForward-durs.domBehind)&jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}<=(beginDomForward+durs.domForward)))-beginDomForward;
                        %oknTraces.PA.data.dom270{iCond}{cDom270} = jMUspikes.data{chans}.okn.trace{iCond}{iTr}(ceil(beginOknForward-(durs.domBehind)):ceil(beginOknForward+(durs.domForward)));
                        spikingActivity.PA.data.trialDomInfo.dom270{iCond}{cDom270}(1,:) = iTr;
                        spikingActivity.PA.data.trialDomInfo.dom270{iCond}{cDom270}(2,:) = iSwitch;
                        spikingActivity.PA.data.trialDomInfo.dom90{iCond}{cDom270}(3,:) = beginDomForward;
                    end
                end
                
            end
            
        end
        
    end
    
    %% Another two conditions
    
    for iCond = [6 8]
        
        cDom90 = 0;
        cDom270 = 0;
        
        for iTr = 1:length(trialInformation.durations{iCond})
            
            if isempty(trialInformation.durations{iCond}{iTr})
                
                fprintf('This trial is empty, moving on...\n')
                
            else
                clear tinf
                tinf(:,1) = trialInformation.eventIDs{iCond}{iTr}; % Events
                tinf(:,2) = trialInformation.durations{iCond}{iTr}; % Durations
                tinf(:,3) = (trialInformation.eventStart{iCond}{iTr}); %Start time IN SAMPLES FOR LFP
                tinf(:,4) = (trialInformation.eventEnd{iCond}{iTr});
                tinf(:,5) = trialInformation.eventStart{iCond}{iTr}; %Start time IN SAMPLES FOR OKN
                tinf(:,6) = trialInformation.eventEnd{iCond}{iTr}; %End time IN SAMPLES FOR OKN
                
                % Look for 270TO90 Switches
                clear idx90
                [idx90]=find(tinf(:,1)== 6);
                
                for iSwitch = 2:length(idx90)
                    
                    if tinf(idx90(iSwitch)-1,2)>=durs.domBehind && tinf(idx90(iSwitch),2)>=durs.domForward
                        
                        cDom90 = cDom90+1;
                        beginDomBehind = tinf(idx90(iSwitch)-1,3);
                        beginDomForward = tinf(idx90(iSwitch),3);
                        beginOknForward = tinf(idx90(iSwitch),5);
                        endDomBehind = tinf(idx90(iSwitch)-1,4);
                        endDomForward = tinf(idx90(iSwitch),4);
                        spikes.PA.data.dom90{chans}{iCond}{cDom90} =(jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}(jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}>=(beginDomForward-durs.domBehind)&jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}<=(beginDomForward+durs.domForward)))-beginDomForward;
                        %oknTraces.PA.data.dom90{iCond}{cDom90} = jMUspikes.data{chans}.okn.trace{iCond}{iTr}(ceil(beginOknForward-(durs.domBehind)):ceil(beginOknForward+(durs.domForward)));
                        spikingActivity.PA.data.trialDomInfo.dom90{iCond}{cDom90}(1,:) = iTr;
                        spikingActivity.PA.data.trialDomInfo.dom90{iCond}{cDom90}(2,:) = iSwitch;
                        spikingActivity.PA.data.trialDomInfo.dom90{iCond}{cDom90}(3,:) = beginDomForward;
                    end
                end
                
                % Look for 90TO270 Switches
                
                clear idx270
                [idx270]=find(tinf(:,1)==5);
                
                for iSwitch = 1:length(idx270)
                    
                    if tinf(idx270(iSwitch)-1,2)>=durs.domBehind && tinf(idx270(iSwitch),2)>=durs.domForward
                        
                        cDom270 = cDom270+1;
                        beginDomBehind = tinf(idx270(iSwitch)-1,3);
                        beginDomForward = tinf(idx270(iSwitch),3);
                        beginOknForward = tinf(idx270(iSwitch),5);
                        endDomBehind = tinf(idx270(iSwitch)-1,4);
                        endDomForward = tinf(idx270(iSwitch),4);
                         spikes.PA.data.dom270{chans}{iCond}{cDom270} = (jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}(jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}>=(beginDomForward-durs.domBehind)&jMUspikes.data{chans}.spikesUnaligned{iCond}{iTr}<=(beginDomForward+durs.domForward)))-beginDomForward;
                        %oknTraces.PA.data.dom270{iCond}{cDom270} = jMUspikes.data{chans}.okn.trace{iCond}{iTr}(ceil(beginOknForward-(durs.domBehind)):ceil(beginOknForward+(durs.domForward)));
                        spikingActivity.PA.data.trialDomInfo.dom270{iCond}{cDom270}(1,:) = iTr;
                        spikingActivity.PA.data.trialDomInfo.dom270{iCond}{cDom270}(2,:) = iSwitch;
                        spikingActivity.PA.data.trialDomInfo.dom90{iCond}{cDom270}(3,:) = beginDomForward;
                    end
                end
                
            end
            
        end
        
    end
    
end

spikesCleanDominances.fullActivity = spikingActivity;
spikesCleanDominances.validSection = spikes;
%spikesCleanDominances.validOKN = oknTraces;
