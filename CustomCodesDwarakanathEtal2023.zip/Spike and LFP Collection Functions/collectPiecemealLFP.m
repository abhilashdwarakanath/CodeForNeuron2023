function [lfpCleanDominances] = collectPiecemealLFP(params,LFP,jMUspikes,durs)

load('trialInformationMM.mat')

pad = 500; % Because of filtering stuff

%% Collect LFP For SPON

for chans = 1:params.elecs
    
    for iCond = 1:params.conditions-4
        
        cDom90 = 0;
        cDom270 = 0;
        
        for iTr = 1:length(trialInformation.durations{iCond})
            
            if isempty(trialInformation.durations{iCond}{iTr})
                
                fprintf('This trial is empty, moving on...\n')
                
            else
                clear tinf
                tinf(:,1) = trialInformation.eventIDs{iCond}{iTr}; % Events
                tinf(:,2) = trialInformation.durations{iCond}{iTr}; % Durations
                tinf(:,3) = (trialInformation.eventStart{iCond}{iTr}/2)+250; %Start time IN SAMPLES FOR LFP
                tinf(:,4) = (trialInformation.eventEnd{iCond}{iTr}/2)+250; %End time IN SAMPLES FOR LFP
                tinf(:,5) = trialInformation.eventStart{iCond}{iTr}; %Start time IN SAMPLES FOR OKN
                tinf(:,6) = trialInformation.eventEnd{iCond}{iTr}; %End time IN SAMPLES FOR OKN
                
                % Look for piecemeal type 1
                clear idx90
                [idx90]=find(tinf(:,1)==107 | tinf(:,1)==127 | tinf(:,1)==87);
                
                for iSwitch = 1:length(idx90)
                    
                    if tinf(idx90(iSwitch),2)>=durs.switch && tinf(idx90(iSwitch)-1,2)>=durs.domBehind
                        
                        cDom90 = cDom90+1;
                        beginDomForward = tinf(idx90(iSwitch)+1,3);
                        beginOknForward = tinf(idx90(iSwitch)+1,5);
                        endOknBehind = tinf(idx90(iSwitch),5);
                        endDomBehind = tinf(idx90(iSwitch),4);
                        lfpTraces.BR.data.dom90{chans}{iCond}{cDom90} = [zeros(1,pad)';detrend(LFP.data{chans}{iCond}{iTr}(ceil((endDomBehind)-((durs.domBehind/2))):ceil(endDomBehind+durs.switch/2)));zeros(1,pad)'];
                        %lfpTraces.BR.data.dom90{chans}{iCond}{cDom90} = [zeros(1,pad)';detrend(LFP.data{chans}{iCond}{iTr}(ceil((beginDomForward)-((durs.domBehind/2+durs.switch/2))):ceil(beginDomForward+250)));zeros(1,pad)'];
                        %oknTraces.BR.data.dom90{iCond}{cDom90} = jMUspikes.data{chans}.okn.trace{iCond}{iTr}(ceil((beginOknForward)-(durs.domBehind+durs.switch)):ceil(beginOknForward));
                        oknTraces.BR.data.dom90{iCond}{cDom90} = jMUspikes.data{chans}.okn.trace{iCond}{iTr}(ceil((endOknBehind)-(durs.domBehind*2)):ceil(endOknBehind+durs.switch*2));
                        lfpActivity.BR.data.trialDomInfo.dom90{iCond}{cDom90}(1,:) = iTr;
                        lfpActivity.BR.data.trialDomInfo.dom90{iCond}{cDom90}(2,:) = iSwitch;
                    end
                end
                
                % Look for 90TO270 Switches
                
                clear idx270
                [idx270]=find(tinf(:,1)==89 | tinf(:,1)==129 | tinf(:,1)==109);
                
                for iSwitch = 1:length(idx270)
                    
                    if tinf(idx270(iSwitch),2)>=durs.switch && tinf(idx270(iSwitch)-1,2)>=durs.domBehind
                        
                        cDom270 = cDom270+1;
                        beginDomForward = tinf(idx270(iSwitch)+1,3);
                        beginOknForward = tinf(idx270(iSwitch)+1,5);
                        endOknBehind = tinf(idx270(iSwitch),5);
                        endDomBehind = tinf(idx270(iSwitch),4);
                        lfpTraces.BR.data.dom270{chans}{iCond}{cDom270} = [zeros(1,pad)';detrend(LFP.data{chans}{iCond}{iTr}(ceil((endDomBehind)-((durs.domBehind/2))):ceil(endDomBehind+durs.switch/2)));zeros(1,pad)'];
                        %lfpTraces.BR.data.dom90{chans}{iCond}{cDom90} = [zeros(1,pad)';detrend(LFP.data{chans}{iCond}{iTr}(ceil((beginDomForward)-((durs.domBehind/2+durs.switch/2))):ceil(beginDomForward+250)));zeros(1,pad)'];
                        %oknTraces.BR.data.dom90{iCond}{cDom90} = jMUspikes.data{chans}.okn.trace{iCond}{iTr}(ceil((beginOknForward)-(durs.domBehind+durs.switch)):ceil(beginOknForward));
                        oknTraces.BR.data.dom270{iCond}{cDom270} = jMUspikes.data{chans}.okn.trace{iCond}{iTr}(ceil((endOknBehind)-(durs.domBehind*2)):ceil(endOknBehind+durs.switch*2));                        
                        lfpActivity.BR.data.trialDomInfo.dom270{iCond}{cDom270}(1,:) = iTr;
                        lfpActivity.BR.data.trialDomInfo.dom270{iCond}{cDom270}(2,:) = iSwitch;
                    end
                end
                
            end
            
        end
        
    end
    
end

lfpCleanDominances.fullActivity = lfpActivity;
lfpCleanDominances.validSection = lfpTraces;
lfpCleanDominances.validOKN = oknTraces;
