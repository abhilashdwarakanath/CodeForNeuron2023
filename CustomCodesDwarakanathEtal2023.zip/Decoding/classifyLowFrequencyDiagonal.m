function [AUC_train, AUC_test, AUC_shuff, edges] = classifyLowFrequencyDiagonal(datasets,nPermutations,holdOut)

lowRate_sel90_BR_s270TO90 = [];
lowRate_sel90_BR_s90TO270 = [];
lowRate_sel270_BR_s270TO90 = [];
lowRate_sel270_BR_s90TO270 = [];

for iDataset = 1:length(datasets)

    load(datasets{iDataset})

    lowRate_sel90_BR_s270TO90 = [lowRate_sel90_BR_s270TO90;squeeze(nansum(spikingActivityPerTransition.sel90.lowRate.BR.s270TO90,2))];
    lowRate_sel90_BR_s90TO270 = [lowRate_sel90_BR_s90TO270;squeeze(nansum(spikingActivityPerTransition.sel90.lowRate.BR.s90TO270,2))];
    lowRate_sel270_BR_s270TO90 = [lowRate_sel270_BR_s270TO90;squeeze(nansum(spikingActivityPerTransition.sel270.lowRate.BR.s270TO90,2))];
    lowRate_sel270_BR_s90TO270 = [lowRate_sel270_BR_s90TO270;squeeze(nansum(spikingActivityPerTransition.sel270.lowRate.BR.s90TO270,2))];


end

% Normalise and collect labels

for iTr = 1:size(lowRate_sel90_BR_s270TO90,1)

    lowRate_sel90_BR_s270TO90(iTr,:) = normalise(smooth(lowRate_sel90_BR_s270TO90(iTr,:)));

end

lab11 = zeros(iTr,1); % NP2P gets 0

for iTr = 1:size(lowRate_sel90_BR_s90TO270,1)

    lowRate_sel90_BR_s90TO270(iTr,:) = normalise(smooth(lowRate_sel90_BR_s90TO270(iTr,:)));

end

lab12 = ones(iTr,1); % P2NP gets 1

for iTr = 1:size(lowRate_sel270_BR_s270TO90,1)

    lowRate_sel270_BR_s270TO90(iTr,:) = normalise(smooth(lowRate_sel270_BR_s270TO90(iTr,:)));

end

lab21 = ones(iTr,1); % P2NP gets 1

for iTr = 1:size(lowRate_sel270_BR_s90TO270,1)

    lowRate_sel270_BR_s90TO270(iTr,:) = normalise(smooth(lowRate_sel270_BR_s90TO270(iTr,:)));

end

lab22 = zeros(iTr,1); % NP2P gets 0

%% Concatenate predictors and labels

dataset = [lowRate_sel90_BR_s90TO270; lowRate_sel270_BR_s270TO90; lowRate_sel90_BR_s270TO90; lowRate_sel270_BR_s90TO270];
input_labels = [lab12;lab21;lab11;lab22];

% Replace nan rows with 0s otherwise the classifier will complain
nanTrials = find(all(isnan(dataset),2));

for iTrial = 1:length(nanTrials)
    dataset(nanTrials(iTrial),:) = zeros(1,size(dataset,2));
end

input_data = zscore(dataset,[],2); % Standardise already here across columns

nPosClass = sum(input_labels==0);

posClassData = input_data(1:nPosClass,:);
negClassData = input_data(nPosClass+1:end,:);

posClassLabels = input_labels(1:nPosClass);
negClassLabels = input_labels(nPosClass+1:end);

%% Run SVM classifier

c = 0;
for rows = 1:length(edges)
    for cols = 1:length(edges)
        if rows==cols
            c = c+1;
            diagonalIndices(c,1:2) = [rows cols];
        end
    end
end

nRuns = nPermutations;

AUC_train = zeros(nRuns,size(diagonalIndices,1));
AUC_test = zeros(nRuns,size(diagonalIndices,1));
AUC_shuff = zeros(nRuns,size(diagonalIndices,1));

for iTimeBin = 1:size(diagonalIndices,1)

    parfor iRun = 1:nRuns

        trainFracPosClassIdxs = randperm(length(posClassLabels),floor((1-holdOut)*(length(posClassLabels))));
        testFracPosClassIdxs = setdiff(1:length(posClassLabels),trainFracPosClassIdxs);

        trainFracNegClassIdxs = randperm(length(posClassLabels),ceil((1-holdOut)*(length(negClassLabels))));
        testFracNegClassIdxs = setdiff(1:length(posClassLabels),trainFracNegClassIdxs);

        tic;

        % Perform the split

        training_data = [posClassData(trainFracPosClassIdxs,diagonalIndices(iTimeBin,1:2)); negClassData(trainFracNegClassIdxs,diagonalIndices(iTimeBin,1:2))];
        training_labels = [posClassLabels(trainFracPosClassIdxs,:); negClassLabels(trainFracNegClassIdxs,:)];

        test_data = [posClassData(testFracPosClassIdxs,diagonalIndices(iTimeBin,1:2)); negClassData(testFracNegClassIdxs,diagonalIndices(iTimeBin,1:2))];
        test_labels = [posClassLabels(testFracPosClassIdxs,:); negClassLabels(testFracNegClassIdxs,:)];

        % Train the model

        CVSVMModel = fitcsvm(training_data,training_labels,'ClassNames',{'1','0'},...
            'Standardize',false,'CrossVal','on'); % Train cross-validated model with 20% partitioning for Test

        trainedMdl = CVSVMModel.Trained{1};
        % Do testing and shuffling

        [~,score] = predict(trainedMdl,test_data); % Do prediction for the test set
        [~,score2] = predict(trainedMdl,training_data); % Do "prediction" for the cross-validated training set.This is not really a prediction. Its the decision boundary fit, given the training data. OVERFITTING = 1. Random fit = 0.5.
        [~,score3] = predict(trainedMdl,test_data); % Do prediction for the test set, where each iteration is one shuffle in a permutation test further on in Line 127. TWO BIRDS WITH ONE STONE BABAY!

        %% Adjust samples here because of MATLAB SVM BULLSHIT where it excludes trials by itself. DID I ASK YOU TO??? NO!

        [~, ~, ~, AUC_train(iRun,iTimeBin)] = perfcurve(training_labels, score2(:,1), '1'); % Get ROC and AUCROC, TPR, FPR for the training set
        [~, ~, ~, AUC_test(iRun,iTimeBin)] = perfcurve(test_labels, score(:,1), '1'); % Get ROC and AUCROC, TPR, FPR for the test set
        [~, ~, ~, AUC_shuff(iRun,iTimeBin)] = perfcurve(test_labels(randperm(length(test_labels))), score3(:,1), '1');

        toc;

    end

end

end
