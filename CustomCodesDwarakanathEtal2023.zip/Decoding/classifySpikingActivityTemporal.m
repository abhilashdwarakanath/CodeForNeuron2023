function [AUC_train, AUC_test, AUC_shuff, edges] = classifySpikingActivityTemporal(datasets,nPermutations,holdOut)

sdf_sel90_BR_s270TO90 = [];
sdf_sel90_BR_s90TO270 = [];
sdf_sel270_BR_s270TO90 = [];
sdf_sel270_BR_s90TO270 = [];

for iDataset = 1:length(datasets)

    load(datasets{iDataset})

    sdf_sel90_BR_s270TO90 = [sdf_sel90_BR_s270TO90;squeeze(nansum(spikingActivityPerTransition.sel90.sdf.BR.s270TO90,2))];
    sdf_sel90_BR_s90TO270 = [sdf_sel90_BR_s90TO270;squeeze(nansum(spikingActivityPerTransition.sel90.sdf.BR.s90TO270,2))];
    sdf_sel270_BR_s270TO90 = [sdf_sel270_BR_s270TO90;squeeze(nansum(spikingActivityPerTransition.sel270.sdf.BR.s270TO90,2))];
    sdf_sel270_BR_s90TO270 = [sdf_sel270_BR_s90TO270;squeeze(nansum(spikingActivityPerTransition.sel270.sdf.BR.s90TO270,2))];


end

% Normalise and collect labels

for iTr = 1:size(sdf_sel90_BR_s270TO90,1)

    sdf_sel90_BR_s270TO90(iTr,:) = normalise(smooth(sdf_sel90_BR_s270TO90(iTr,:)));

end

lab11 = zeros(iTr,1); % NP2P gets 0

for iTr = 1:size(sdf_sel90_BR_s90TO270,1)

    sdf_sel90_BR_s90TO270(iTr,:) = normalise(smooth(sdf_sel90_BR_s90TO270(iTr,:)));

end

lab12 = ones(iTr,1); % P2NP gets 1

for iTr = 1:size(sdf_sel270_BR_s270TO90,1)

    sdf_sel270_BR_s270TO90(iTr,:) = normalise(smooth(sdf_sel270_BR_s270TO90(iTr,:)));

end

lab21 = ones(iTr,1); % P2NP gets 1

for iTr = 1:size(sdf_sel270_BR_s90TO270,1)

    sdf_sel270_BR_s90TO270(iTr,:) = normalise(smooth(sdf_sel270_BR_s90TO270(iTr,:)));

end

lab22 = zeros(iTr,1); % NP2P gets 0

%% Concatenate predictors and labels

dataset = [sdf_sel90_BR_s90TO270; sdf_sel270_BR_s270TO90; sdf_sel90_BR_s270TO90; sdf_sel270_BR_s90TO270];
input_labels = [lab12;lab21;lab11;lab22];

input_data = zscore(dataset,[],2); % Standardise already here across columns

nPosClass = sum(input_labels==0);

posClassData = input_data(1:nPosClass,:);
negClassData = input_data(nPosClass+1:end,:);

posClassLabels = input_labels(1:nPosClass);
negClassLabels = input_labels(nPosClass+1:end);

%% Run SVM classifier

nRuns = nPermutations;

iTimeBinC = 1:length(edges)-1;
iTimeBinR = 1:length(edges)-1;

AUC_train = zeros(nRuns,length(iTimeBinR),length(iTimeBinC));
AUC_test = zeros(nRuns,length(iTimeBinR),length(iTimeBinC));
AUC_shuff = zeros(nRuns,length(iTimeBinR),length(iTimeBinC));

for iTimeBinC = 1:length(edges)-1

    for iTimeBinR = 1:length(edges)-1

        parfor iRun = 1:nRuns

            trainFracPosClassIdxs = randperm(length(posClassLabels),floor((1-holdOut)*(length(posClassLabels))));
            testFracPosClassIdxs = setdiff(1:length(posClassLabels),trainFracPosClassIdxs);

            trainFracNegClassIdxs = randperm(length(posClassLabels),ceil((1-holdOut)*(length(negClassLabels))));
            testFracNegClassIdxs = setdiff(1:length(posClassLabels),trainFracNegClassIdxs);

            tic;

            % Perform the split

            training_data = ([posClassData(trainFracPosClassIdxs,iTimeBinR:iTimeBinR+1); negClassData(trainFracNegClassIdxs,iTimeBinR:iTimeBinR+1)]);
            training_labels = [posClassLabels(trainFracPosClassIdxs,:); negClassLabels(trainFracNegClassIdxs,:)];

            test_data = ([posClassData(testFracPosClassIdxs,iTimeBinC:iTimeBinC+1); negClassData(testFracNegClassIdxs,iTimeBinC:iTimeBinC+1)]);
            test_labels = [posClassLabels(testFracPosClassIdxs,:); negClassLabels(testFracNegClassIdxs,:)];

            % Train the model

            CVSVMModel = fitcsvm(training_data,training_labels,'ClassNames',{'1','0'},...
                'Standardize',false,'CrossVal','on'); % Train cross-validated model with 20% partitioning for Test

            trainedMdl = CVSVMModel.Trained{1};
            % Do testing and shuffling

            [~,score] = predict(trainedMdl,test_data); % Do prediction for the test set
            [~,score2] = predict(trainedMdl,training_data); % Do "prediction" for the cross-validated training set.This is not really a prediction. Its the decision boundary fit, given the training data. OVERFITTING = 1. Random fit = 0.5.
            [~,score3] = predict(trainedMdl,test_data); % Do prediction for the test set, where each iteration is one shuffle in a permutation test further on in Line 127. TWO BIRDS WITH ONE STONE BABAY!

            %% Adjust samples here because of MATLAB SVM BULLSHIT where it excludes trials by itself. DID I ASK YOU TO??? NO!

            [~, ~, ~, AUC_train(iRun,iTimeBinR,iTimeBinC)] = perfcurve(training_labels, score2(:,1), '1'); % Get ROC and AUCROC, TPR, FPR for the training set
            [~, ~, ~, AUC_test(iRun,iTimeBinR,iTimeBinC)] = perfcurve(test_labels, score(:,1), '1'); % Get ROC and AUCROC, TPR, FPR for the test set
            [~, ~, ~, AUC_shuff(iRun,iTimeBinR,iTimeBinC)] = perfcurve(test_labels(randperm(length(test_labels))), score3(:,1), '1');

            toc;

        end

    end

end

end
