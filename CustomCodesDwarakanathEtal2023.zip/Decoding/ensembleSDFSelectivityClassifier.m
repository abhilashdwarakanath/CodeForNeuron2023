function ensembleSDFSelectivityClassifier(nPermutations,switchRegion,holdOut)

% Classify stimulus selectivity using spikes, beta and low freq activity
% Abhilash Dwarakanath. 2022-08-31. NeuroSpin.

dbstop if error

%% Enumerate datasets

datasets{1} = 'C:\Users\AD263755\Documents\MATLAB\Data\1\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel_2.mat';
recDate{1} = '12062016';
fileID{1} = '12-06-2016';
subjID{1} = 'Hayo';
datasets{2} = 'C:\Users\AD263755\Documents\MATLAB\Data\2\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel_2.mat';
recDate{2} = '13072016';
fileID{2} = '13-07-2016';
subjID{2} = 'Hayo';
datasets{3} = 'C:\Users\AD263755\Documents\MATLAB\Data\3\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel_2.mat';
recDate{3} = '19102016';
fileID{3} = '20161019';
subjID{3} = 'Hayo';
datasets{4} = 'C:\Users\AD263755\Documents\MATLAB\Data\4\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel_2.mat';
recDate{4} = '25102016';
fileID{4} = '20161025';
subjID{4} = 'Hayo';
datasets{5} = 'C:\Users\AD263755\Documents\MATLAB\Data\5\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel_2.mat';
recDate{5} = '05032017';
fileID{5} = '20170305';
subjID{5} = 'Anton';
datasets{6} = 'C:\Users\AD263755\Documents\MATLAB\Data\6\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel_2.mat';
recDate{6} = '02032017';
fileID{6} = '20170302';
subjID{6} = 'Anton';


%% Run classification

% SDF

[trainSDFAUC, testSDFAUC, shuffledSDFAUC] = classifySpikingActivity(datasets,nPermutations,switchRegion,holdOut);

%LF

[trainLFAUC, testLFAUC, shuffledLFAUC] = classifyLowFrequency(datasets,nPermutations,switchRegion,holdOut);

% Beta

[trainBAAUC, testBAAUC, shuffledBAAUC] = classifyBetaActivity(datasets,nPermutations,switchRegion,holdOut);

%% Collect shit and plot

% Test statistics

meanTestSDFAUC = nanmean(testSDFAUC);
errTestSDFAUC = nanstd(testSDFAUC);%./sqrt(length(testSDFAUC));

meanTestLFAUC = nanmean(testLFAUC);
errTestLFAUC = nanstd(testLFAUC);%./sqrt(length(testLFAUC));

meanTestBAAUC = nanmean(testBAAUC);
errTestBAAUC = nanstd(testBAAUC);%./sqrt(length(testBAAUC));

% Train statistics

meanTrainSDFAUC = nanmean(trainSDFAUC);
errTrainSDFAUC = nanstd(trainSDFAUC);%./sqrt(length(trainSDFAUC));

meanTrainLFAUC = nanmean(trainLFAUC);
errTrainLFAUC = nanstd(trainLFAUC);%./sqrt(length(trainLFAUC));

meanTrainBAAUC = nanmean(trainBAAUC);
errTrainBAAUC = nanstd(trainBAAUC);%./sqrt(length(trainBAAUC));

% Shuffled statistics

meanShuffledSDFAUC = nanmean(shuffledSDFAUC);
errShuffledSDFAUC = nanstd(shuffledSDFAUC);%./sqrt(length(shuffledSDFAUC));

meanShuffledLFAUC = nanmean(shuffledLFAUC);
errShuffledLFAUC = nanstd(shuffledLFAUC);%./sqrt(length(shuffledLFAUC));

meanShuffledBAAUC = nanmean(shuffledBAAUC);
errShuffledBAAUC = nanstd(shuffledBAAUC);%./sqrt(length(shuffledBAAUC));

% Plot

figure()

groupNames = categorical({'Training','Testing','Shuffled'});
groupNames = reordercats(groupNames,{'Training','Testing','Shuffled'});
groups = [meanTrainSDFAUC meanTrainLFAUC meanTrainBAAUC; meanTestSDFAUC meanTestLFAUC meanTestBAAUC; meanShuffledSDFAUC meanShuffledLFAUC meanShuffledBAAUC];
errGroups = [errTrainSDFAUC errTrainLFAUC errTrainBAAUC; errTestSDFAUC errTestLFAUC errTestBAAUC; errShuffledSDFAUC errShuffledLFAUC errShuffledBAAUC];

b = bar(groupNames,groups,'grouped');
hold on
[nGroups,nBars] = size(groups);
% Get the x coordinate of the bars
x = nan(nBars, nGroups);
for iBar = 1:nBars
    x(iBar,:) = b(iBar).XEndPoints;
end
% Plot the errorbars
errorbar(x',groups,errGroups,'k','linestyle','none');
hold off
legend('Spiking Activity','1-9Hz Activity', '20-40Hz Activity')
hline(0.5,'-k')
ylim([0 1])
title(['AUCROC n = ' num2str(nPermutations)],'FontSize',16,'FontWeight','bold')
box off
