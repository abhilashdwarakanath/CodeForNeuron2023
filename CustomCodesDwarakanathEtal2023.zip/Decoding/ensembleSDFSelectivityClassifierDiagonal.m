function[testSDFAUC, testLFAUC, testBAAUC, edges] =  ensembleSDFSelectivityClassifierDiagonal(nPermutations,holdOut)

% Classify stimulus selectivity using spikes, beta and low freq activity
% Abhilash Dwarakanath. September 2022. NeuroSpin.

dbstop if error

%% Enumerate datasets

tic;

nDatasets = 6;

datasets = cell(nDatasets);

for iDataset = 1:nDatasets

    datasets{iDataset} = ['C:\Users\AD263755\Documents\MATLAB\Data\' num2str(iDataset) '\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel_2.mat'];

end

%% Run classification

% SDF

%[trainSDFAUC, testSDFAUC, shuffledSDFAUC, edges] = classifySpikingActivityDiagonal(datasets,nPermutations,holdOut);

%LF

[trainLFAUC, testLFAUC, shuffledLFAUC, edges] = classifyLowFrequencyDiagonal(datasets,nPermutations,holdOut);

% Beta

%[trainBAAUC, testBAAUC, shuffledBAAUC, edges] = classifyBetaActivityDiagonal(datasets,nPermutations,holdOut);

%% Compute change points for test SDF AUCROC
edges = edges./1e3;

t = edges(2:19);
testData = testSDFAUC(:,2:19);
for iRun = 1:size(testData,1)
    changePoints(iRun,:) = findchangepts(smooth(testData(iRun,:)),'MaxNumChanges',2);
end
earliestChangeTimes = t(changePoints(:,2));
meanChangePoint = nanmean(earliestChangeTimes);

%% Plot the diagonals and error bars

% Test statistics

meanTestSDFAUC = nanmean(testSDFAUC,1);
errTestSDFAUC = nanstd(testSDFAUC,[],1);%/sqrt(length(testSDFAUC));

meanTestLFAUC = nanmean(testLFAUC,1);
errTestLFAUC = nanstd(testLFAUC,[],1);%/sqrt(length(testLFAUC));

meanTestBAAUC = nanmean(testBAAUC,1);
errTestBAAUC = nanstd(testBAAUC,[],1);%/sqrt(length(testBAAUC));

% Plot

figure()
shadedErrorBar(edges(2:end-1),meanTestSDFAUC(2:end-1),errTestSDFAUC(2:end-1));
hold on
plot(edges(2:end-1),meanTestSDFAUC(2:end-1))
shadedErrorBar(edges(2:end-1),meanTestLFAUC(2:end-1),errTestLFAUC(2:end-1));
plot(edges(2:end-1),meanTestLFAUC(2:end-1));
shadedErrorBar(edges(2:end-1),meanTestBAAUC(2:end-1),errTestBAAUC(2:end-1));
plot(edges(2:end-1),meanTestBAAUC(2:end-1));
ylim([0 1])
hline(0.5,'--k')
vline(0,'--k')
vline(meanChangePoint,'-b')
box off

elapsed = toc;

fprintf('\nTotal time taken to classify spikes, LF and Beta is : %d s\n',elapsed)
