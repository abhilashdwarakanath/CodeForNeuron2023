function ensembleSDFSelectivityClassifierTemporal(nPermutations,holdOut)

% Classify stimulus selectivity using spikes, beta and low freq activity
% Abhilash Dwarakanath. 2022-08-31. NeuroSpin.

dbstop if error

%% Enumerate datasets

nDatasets = 6;

datasets = cell(nDatasets);

for iDataset = 1:nDatasets

    datasets{iDataset} = ['C:\Users\AD263755\Documents\MATLAB\Data\' num2str(iDataset) '\MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel_2.mat'];

end

%% Run classification

% SDF

[trainSDFAUC, testSDFAUC, shuffledSDFAUC, edges] = classifySpikingActivityDiagonal(datasets,nPermutations,holdOut);

%LF

[trainLFAUC, testLFAUC, shuffledLFAUC, edges] = classifyLowFrequencyDiagonal(datasets,nPermutations,holdOut);

% Beta

[trainBAAUC, testBAAUC, shuffledBAAUC, edges] = classifyBetaActivityDiagonal(datasets,nPermutations,holdOut);

%% Plot the diagonals and error bars

% Test statistics

meanTestSDFAUC = nanmean(testSDFAUC,1);
errTestSDFAUC = nanstd(testSDFAUC,[],1);%./sqrt(length(testSDFAUC));

meanTestLFAUC = nanmean(testLFAUC,1);
errTestLFAUC = nanstd(testLFAUC,[],1);%./sqrt(length(testLFAUC));

meanTestBAAUC = nanmean(testBAAUC,1);
errTestBAAUC = nanstd(testBAAUC,[],1);%./sqrt(length(testBAAUC));

% Plot


figure()
errorbar(t,meanTestSDFAUC,errTestSDFAUC);
hold on
errorbar(t,meanTestLFAUC,errTestLFAUC);
errorbar(t,meanTestBAAUC,errTestBAAUC);
legend('Spiking Activity','1-9Hz Activity', '20-40Hz Activity')
ylim([0 1])
hline(0.5,'--k')
vline(0,'--k')
box off

%% Plot the distributions as bar graphs

%Test
meanTestSDFAUC = nanmean(testSDFAUC);
errTestSDFAUC = nanstd(testSDFAUC);%./sqrt(length(testSDFAUC));
meanTestLFAUC = nanmean(testLFAUC);
errTestLFAUC = nanstd(testLFAUC);%./sqrt(length(testLFAUC));
meanTestBAAUC = nanmean(testBAAUC);
errTestBAAUC = nanstd(testBAAUC);%./sqrt(length(testBAAUC));

% Train statistics
meanTrainSDFAUC = nanmean(trainSDFAUC);
errTrainSDFAUC = nanstd(trainSDFAUC);%./sqrt(length(trainSDFAUC));
meanTrainLFAUC = nanmean(trainLFAUC);
errTrainLFAUC = nanstd(trainLFAUC);%./sqrt(length(trainLFAUC));
meanTrainBAAUC = nanmean(trainBAAUC);
errTrainBAAUC = nanstd(trainBAAUC);%./sqrt(length(trainBAAUC));

% Shuffled statistics
meanShuffledSDFAUC = nanmean(shuffledSDFAUC);
errShuffledSDFAUC = nanstd(shuffledSDFAUC);%./sqrt(length(shuffledSDFAUC));
meanShuffledLFAUC = nanmean(shuffledLFAUC);
errShuffledLFAUC = nanstd(shuffledLFAUC);%./sqrt(length(shuffledLFAUC));
meanShuffledBAAUC = nanmean(shuffledBAAUC);
errShuffledBAAUC = nanstd(shuffledBAAUC);%./sqrt(length(shuffledBAAUC));

% Plot
figure()
groupNames = categorical({'Training','Testing','Shuffled'});
groupNames = reordercats(groupNames,{'Training','Testing','Shuffled'});
groups = [meanTrainSDFAUC meanTrainLFAUC meanTrainBAAUC; meanTestSDFAUC meanTestLFAUC meanTestBAAUC; meanShuffledSDFAUC meanShuffledLFAUC meanShuffledBAAUC];
errGroups = [errTrainSDFAUC errTrainLFAUC errTrainBAAUC; errTestSDFAUC errTestLFAUC errTestBAAUC; errShuffledSDFAUC errShuffledLFAUC errShuffledBAAUC];
b = bar(groupNames,groups,'grouped');
hold on
[nGroups,nBars] = size(groups);
% Get the x coordinate of the bars
x = nan(nBars, nGroups);
for iBar = 1:nBars
x(iBar,:) = b(iBar).XEndPoints;
end
% Plot the errorbars
errorbar(x',groups,errGroups,'k','linestyle','none');
hold off
legend('Spiking Activity','1-9Hz Activity', '20-40Hz Activity')
hline(0.5,'-k')
ylim([0 1])
title(['AUCROC n = ' num2str(nPermutations)],'FontSize',16,'FontWeight','bold')
box off
xlabel('Conditions')
ylabel('AUCROC')
xlabel('Conditions','FontSize',14,'FontWeight','bold')
ylabel('AUCROC','FontSize',14,'FontWeight','bold')
