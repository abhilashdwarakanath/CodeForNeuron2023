function generateTbyTEnsemblePSTHsMUALFPRateForClassifier

dbstop if error

datasets{1} = 'E:\Data\H07\12-06-2016\PFC\Bfsgrad1';
recDate{1} = '12062016';
fileID{1} = '12-06-2016';
subjID{1} = 'Hayo';
datasets{2} = 'E:\Data\H07\13-07-2016\PFC\Bfsgrad1';
recDate{2} = '13072016';
fileID{2} = '13-07-2016';
subjID{2} = 'Hayo';
datasets{3} = 'E:\Data\H07\20161019\PFC\Bfsgrad1';
recDate{3} = '19102016';
fileID{3} = '20161019';
subjID{3} = 'Hayo';
datasets{4} = 'E:\Data\H07\20161025\PFC\Bfsgrad1';
recDate{4} = '25102016';
fileID{4} = '20161025';
subjID{4} = 'Hayo';
datasets{5} = 'E:\Data\A11\20170305\PFC\Bfsgrad1';
recDate{5} = '05032017';
fileID{5} = '20170305';
subjID{5} = 'Anton';
datasets{6} = 'E:\Data\A11\20170302\PFC\Bfsgrad1';
recDate{6} = '02032017';
fileID{6} = '20170302';
subjID{6} = 'Anton';

prefInfoPaths{1} = 'E:\Data\Results\H07\12-06-2016\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{2} = 'E:\Data\Results\H07\13-07-2016\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{3} = 'E:\Data\Results\H07\20161019\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{4} = 'E:\Data\Results\H07\20161025\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{5} = 'E:\Data\Results\A11\20170305\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';
prefInfoPaths{6} = 'E:\Data\Results\A11\20170302\Bfsgrad\PFC\MUA\Preference_Arrays\cSwitch';

%% Load SU Spikes By Time

for iDataset = 1:length(datasets)
    
    cd(datasets{iDataset})
    load jMUSpikesByTime.mat
    
    cd(prefInfoPaths{iDataset})
    load('1000_250_1000_DF_pref_array_switch.mat')
    
    pref90_br_bs = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==2);
    pref90_br_as = find(pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,2)==2);
    pref90_br_bsas = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==2);
    pref90_br_bs = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref90_br_bs,3);
    pref90_br_as = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(pref90_br_as,3);
    pref90_br_bsas = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref90_br_bsas,3);
    
    pref90_br = unique([pref90_br_bs;pref90_br_as;pref90_br_bsas]);
    
    
    pref270_br_bs = find(pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(:,2)==1);
    pref270_br_as = find(pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(:,2)==1);
    pref270_br_bsas = find(pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(:,2)==1);
    pref270_br_bs = pref_array_switch.pref_sim_switch_Riv_BsAs.pri_sig_u(pref270_br_bs,3);
    pref270_br_as = pref_array_switch.pref_sim_switch_Riv_BsAs.sec_sig_u(pref270_br_as,3);
    pref270_br_bsas = pref_array_switch.pref_sim_switch_Riv_BsAs.com_sig_u(pref270_br_bsas,3);
    
    pref270_br = unique([pref270_br_bs;pref270_br_as;pref270_br_bsas]);
    
    pad = 500;
    
    %% Collect clean dominances
    
    durs.switch = 250;
    durs.domForward = 1000;
    durs.domBehind = 1000;
    params.elecs = 96;
    params.conditions = 8;
    
    % Load relevant LFPs and Spikes
    cd(datasets{iDataset})
    
    eventfile = 'finalevents_audio.mat';
    spikeFile = 'jMUSpikesByTime.mat';
    qnxfile = [subjID{iDataset} '_' recDate{iDataset} '_' 'Bfsgrad1' '.dgz'];
    
    load('lfpByTrial.mat')
    
    fprintf('Processing Dataset %d of : %d \n',iDataset,length(datasets))
    
    % Compute Statistics and Spectrograms
    
    sav_dir = [datasets{iDataset} '\EnsemblePSTHs\MM'];
    mkdir(sav_dir)
    if strcmp(subjID{iDataset},'Hayo')==1
        monkID = 'H07';
    else
        monkID = 'A11';
    end
    
    trialInformation = collectTrialInformationMM(params,qnxfile,eventfile,'pfc','lfp');
    [lfpActivity] = collectCleanDominancesLFPMM(params,LFP,jMUspikes,durs);
    [spikingActivity] = collectCleanDominancesSpikesMM(params,jMUspikes,durs);
    
    %% Setup filters
    
    %[b1,a1] = cheby1(4,0.001,[1 9]/250); % low
    
    [b1,a1] = butter(4,[1 9]/250); % low
    evtDurL = 56;
    %[b2,a2] = cheby1(4,0.001,[20 40]/250); % beta
    [b2,a2] = butter(4,[20 40]/250); % beta
    evtDurB = 12;
    %% Collect BR
    
    tLFP = linspace(-1000,1000,1001);
    
    for iChan = 1:params.elecs
        c = 0;
        for iCond = 1:length(spikingActivity.validSection.BR.data.dom90{iChan})
            for iSwitch = 1:length(spikingActivity.validSection.BR.data.dom90{iChan}{iCond})
                c = c+1; clear spikesPiece; clear lowPiece; clear betaPiece; clear lowEvts; clear betaEvts;
                cleanSwitches.BR.s270TO90{iChan}{c} = spikingActivity.validSection.BR.data.dom90{iChan}{iCond}{iSwitch};
                piece = lfpActivity.validSection.BR.data.dom90{iChan}{iCond}{iSwitch};
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                betaPiece = abs(hilbert(filter(b2,a2,piece)));
                lowEvts = event_detection(lowPiece,4,'stdgauss',evtDurL);
                lowEvts(lowEvts<= pad+1 & lowEvts >= 2000-pad+1) = [];
                lowEvts = lowEvts - pad+1;
                betaEvts = event_detection(betaPiece,3.5,'stdgauss',evtDurB);
                betaEvts(betaEvts<= pad+1 & betaEvts >= 2000-pad+1) = [];
                betaEvts = betaEvts - pad+1;
                lfpSwitches.low.BR.s270TO90.instAmp(c,iChan,:) = lowPiece(pad+1:end-pad);
                lfpSwitches.beta.BR.s270TO90.instAmp(c,iChan,:) = betaPiece(pad+1:end-pad);
                temp = zeros(1,length(tLFP));
                temp(lowEvts) = 1;
                temp = temp(1:1001);
                lfpSwitches.low.BR.s270TO90.events(c,iChan,:) = temp; clear temp;
                temp = zeros(1,length(tLFP));
                betaEvts(betaEvts<=0) = []; betaEvts(betaEvts>=1001) = [];
                temp(betaEvts) = 1;
                temp = temp(1:1001);
                lfpSwitches.beta.BR.s270TO90.events(c,iChan,:) = temp; clear temp;
            end
        end
    end
    
    for iChan = 1:params.elecs
        c = 0;
        for iCond = 1:length(spikingActivity.validSection.BR.data.dom270{iChan})
            for iSwitch = 1:length(spikingActivity.validSection.BR.data.dom270{iChan}{iCond})
                c = c+1; clear spikesPiece; clear lowPiece; clear betaPiece; clear lowEvts; clear betaEvts;
                cleanSwitches.BR.s90TO270{iChan}{c} = spikingActivity.validSection.BR.data.dom270{iChan}{iCond}{iSwitch};
                piece = lfpActivity.validSection.BR.data.dom270{iChan}{iCond}{iSwitch};
                lowPiece = abs(hilbert(filtfilt(b1,a1,piece)));
                betaPiece = abs(hilbert(filter(b2,a2,piece)));
                lowEvts = event_detection(lowPiece,4,'stdgauss',evtDurL);
                lowEvts(lowEvts<= pad+1 & lowEvts >= 2000-pad+1) = [];
                lowEvts = lowEvts - pad;
                betaEvts = event_detection(betaPiece,3.5,'stdgauss',evtDurB);
                betaEvts(betaEvts<= pad+1 & betaEvts >= 2000-pad+1) = [];
                betaEvts = betaEvts - pad;
                lfpSwitches.low.BR.s90TO270.instAmp(c,iChan,:) = lowPiece(pad+1:end-pad);
                lfpSwitches.beta.BR.s90TO270.instAmp(c,iChan,:) = betaPiece(pad+1:end-pad);
                temp = zeros(1,length(tLFP));
                temp(lowEvts) = 1;
                temp = temp(1:1001);
                lfpSwitches.low.BR.s90TO270.events(c,iChan,:) = temp; clear temp;
                temp = zeros(1,length(tLFP));
                betaEvts(betaEvts<=0) = []; betaEvts(betaEvts>=1001) = [];
                temp(betaEvts) = 1;
                temp = temp(1:1001);
                lfpSwitches.beta.BR.s90TO270.events(c,iChan,:) = temp; clear temp;
            end
        end
    end
    
    %% Process SDFs and LFPs
    
    edges = -1000:50:1000;
    
    %BR
    % Sel 270, 270TO90
    
    for iSwitch = 1:length(cleanSwitches.BR.s270TO90{1})
        
        for iChan = 1:length(pref270_br)
            clear spikesPiece; clear lowPiece; clear betaPiece;
            spikesPiece = (cleanSwitches.BR.s270TO90{pref270_br(iChan)}{iSwitch});
            
            if ~isempty(spikesPiece)
                sdf_br_sel270_s270TO90(iSwitch,iChan,:) = histc(spikesPiece,edges);
                clear spikesPiece;
            else
                sdf_br_sel270_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
                clear spikesPiece;
            end
            
            lowEvts = squeeze(lfpSwitches.low.BR.s270TO90.events(iSwitch,pref270_br(iChan),:));
            if sum(lowEvts) > 0
                [idx] = find(lowEvts'==1);
                lowRate_br_sel270_s270TO90(iSwitch,iChan,:) = histc(tLFP(idx),edges);
                clear lowEvts;
            else
                lowRate_br_sel270_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
                clear lowEvts;
            end
            
            betaEvts = squeeze(lfpSwitches.beta.BR.s270TO90.events(iSwitch,pref270_br(iChan),:));
            if sum(betaEvts) > 0
                [idx] = find(betaEvts'==1);
                betaRate_br_sel270_s270TO90(iSwitch,iChan,:) = histc(tLFP(idx),edges);
                clear betaEvts;
            else
                betaRate_br_sel270_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
                clear betaEvts;
            end
            
        end
        
    end
    
    for iSwitch = 1:length(cleanSwitches.BR.s270TO90{1})
        
        for iChan = 1:length(pref90_br)
            clear spikesPiece; clear lowPiece; clear betaPiece;
            spikesPiece = (cleanSwitches.BR.s270TO90{pref90_br(iChan)}{iSwitch});
            
            if ~isempty(spikesPiece)
                sdf_br_sel90_s270TO90(iSwitch,iChan,:) = histc(spikesPiece,edges);
                clear spikesPiece;
            else
                sdf_br_sel90_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
                clear spikesPiece;
            end
            
            lowEvts = squeeze(lfpSwitches.low.BR.s270TO90.events(iSwitch,pref90_br(iChan),:));
            if sum(lowEvts) > 0
                [idx] = find(lowEvts'==1);
                lowRate_br_sel90_s270TO90(iSwitch,iChan,:) = histc(tLFP(idx),edges);
                clear lowEvts;
            else
                lowRate_br_sel90_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
                clear lowEvts;
            end
            
            betaEvts = squeeze(lfpSwitches.beta.BR.s270TO90.events(iSwitch,pref90_br(iChan),:));
            if sum(betaEvts) > 0
                [idx] = find(betaEvts'==1);
                betaRate_br_sel90_s270TO90(iSwitch,iChan,:) = histc(tLFP(idx),edges);
                clear betaEvts;
            else
                betaRate_br_sel90_s270TO90(iSwitch,iChan,:) = zeros(1,length(edges));
                clear betaEvts;
            end
            
        end
        
    end
    
    for iSwitch = 1:length(cleanSwitches.BR.s90TO270{1})
        
        for iChan = 1:length(pref270_br)
            clear spikesPiece; clear lowPiece; clear betaPiece;
            spikesPiece = (cleanSwitches.BR.s90TO270{pref270_br(iChan)}{iSwitch});
            
            if ~isempty(spikesPiece)
                sdf_br_sel270_s90TO270(iSwitch,iChan,:) = histc(spikesPiece,edges);
                clear spikesPiece;
            else
                sdf_br_sel270_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
                clear spikesPiece;
            end
            
            lowEvts = squeeze(lfpSwitches.low.BR.s90TO270.events(iSwitch,pref270_br(iChan),:));
            if sum(lowEvts) > 0
                [idx] = find(lowEvts'==1);
                lowRate_br_sel270_s90TO270(iSwitch,iChan,:) = histc(tLFP(idx),edges);
                clear lowEvts;
            else
                lowRate_br_sel270_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
                clear lowEvts;
            end
            
            betaEvts = squeeze(lfpSwitches.beta.BR.s90TO270.events(iSwitch,pref270_br(iChan),:));
            if sum(betaEvts) > 0
                [idx] = find(betaEvts'==1);
                betaRate_br_sel270_s90TO270(iSwitch,iChan,:) = histc(tLFP(idx),edges);
                clear betaEvts;
            else
                betaRate_br_sel270_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
                clear betaEvts;
            end
            
        end
        
    end
    
    
    for iSwitch = 1:length(cleanSwitches.BR.s90TO270{1})
        
        for iChan = 1:length(pref90_br)
            clear spikesPiece; clear lowPiece; clear betaPiece;
            spikesPiece = (cleanSwitches.BR.s90TO270{pref90_br(iChan)}{iSwitch});
            
            if ~isempty(spikesPiece)
                sdf_br_sel90_s90TO270(iSwitch,iChan,:) = histc(spikesPiece,edges);
                clear spikesPiece;
            else
                sdf_br_sel90_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
                clear spikesPiece;
            end
            
            lowEvts = squeeze(lfpSwitches.low.BR.s90TO270.events(iSwitch,pref90_br(iChan),:));
            if sum(lowEvts) > 0
                [idx] = find(lowEvts'==1);
                lowRate_br_sel90_s90TO270(iSwitch,iChan,:) = histc(tLFP(idx),edges);
                clear lowEvts;
            else
                lowRate_br_sel90_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
                clear lowEvts;
            end
            
            betaEvts = squeeze(lfpSwitches.beta.BR.s90TO270.events(iSwitch,pref90_br(iChan),:));
            if sum(betaEvts) > 0
                [idx] = find(betaEvts'==1);
                betaRate_br_sel90_s90TO270(iSwitch,iChan,:) = histc(tLFP(idx),edges);
                clear betaEvts;
            else
                betaRate_br_sel90_s90TO270(iSwitch,iChan,:) = zeros(1,length(edges));
                clear betaEvts;
            end
            
        end
        
    end
    
    %% Consolidate into a structure
    
    spikingActivityPerTransition.sel90.sdf.BR.s270TO90 = sdf_br_sel90_s270TO90;
    spikingActivityPerTransition.sel90.sdf.BR.s90TO270 = sdf_br_sel90_s90TO270;
    spikingActivityPerTransition.sel270.sdf.BR.s270TO90 = sdf_br_sel270_s270TO90;
    spikingActivityPerTransition.sel270.sdf.BR.s90TO270 = sdf_br_sel270_s90TO270;
    
    spikingActivityPerTransition.sel90.lowRate.BR.s270TO90 = lowRate_br_sel90_s270TO90;
    spikingActivityPerTransition.sel90.lowRate.BR.s90TO270 = lowRate_br_sel90_s90TO270;
    spikingActivityPerTransition.sel270.lowRate.BR.s270TO90 = lowRate_br_sel270_s270TO90;
    spikingActivityPerTransition.sel270.lowRate.BR.s90TO270 = lowRate_br_sel270_s90TO270;
    
    spikingActivityPerTransition.sel90.betaRate.BR.s270TO90 = betaRate_br_sel90_s270TO90;
    spikingActivityPerTransition.sel90.betaRate.BR.s90TO270 = betaRate_br_sel90_s90TO270;
    spikingActivityPerTransition.sel270.betaRate.BR.s270TO90 = betaRate_br_sel270_s270TO90;
    spikingActivityPerTransition.sel270.betaRate.BR.s90TO270 = betaRate_br_sel270_s90TO270;
    
    cd(sav_dir)
    save('MM_EnsemblePSTHs_MU_LFPTraces_1000ms_BSAS_BRPASel_2.mat','spikingActivityPerTransition','edges','-v7.3')
    
    clear sdf_br_sel270_s270TO90; clear sdf_br_sel270_s90TO270; clear sdf_br_sel90_s270TO90; clear sdf_br_sel90_s90TO270;
    clear lowRate_br_sel270_s270TO90; clear lowRate_br_sel270_s90TO270; clear lowRate_br_sel90_s270TO90; clear lowRate_br_sel90_s90TO270;
    clear betaRate_br_sel270_s270TO90; clear betaRate_br_sel270_s90TO270; clear betaRate_br_sel90_s270TO90; clear betaRate_br_sel90_s90TO270;
    clear spikingActivity; clear lfpSwitches; clear spikingActivityPerTransition; clear cleanSwitches; clear jMUspikes; clear lowPiece; clear spikesPiece; clear betaPiece;
    clear pref90_br; clear pref90_br_as; clear pref90_br_bs; clear pref90_br_bsas;
    clear pref270_br; clear pref270_br_as; clear pref270_br_bs; clear pref270_br_bsas;
end

end
