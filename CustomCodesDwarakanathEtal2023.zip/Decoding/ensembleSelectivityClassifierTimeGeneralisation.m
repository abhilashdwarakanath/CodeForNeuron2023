function [AUC_train, AUC_test, AUC_shuff] = ensembleSelectivityClassifierTimeGeneralisation(nPermutations,type,holdOut)

%% Check for type of signal input and load the data accordingly

switch type

    case {'low','Low','lowRate'}

        cd('C:\Users\Abhilash Dwarakanath\Documents\MATLAB')

        load lowRateBinned50ms.mat

    case {'beta','Beta','betaRate'}

        cd('C:\Users\Abhilash Dwarakanath\Documents\MATLAB')

        load betaRateBinned50ms.mat

    case {'spikes','sdf','Spikes'}

        cd('C:\Users\Abhilash Dwarakanath\Documents\MATLAB')

        load spikesBinned50ms_trans.mat

end

%% DO this dumb initialisation

dataset = input_data;
input_labels = input_labels;

nPosClass = sum(input_labels==0);
nNegClass = sum(input_labels==1);

%% Collect the input data

input_data = dataset(:,featureRange);

%% Run SVM classifier

nRuns = nPermutations; % Number of runs to fit the cross-validated model. ASK THIS AS A USER INPUT IN A FUTURE VERSION. AD.

for iRun = 1:nRuns

    tic;
    
    % Balance class labels and data equally for training

    posClassData = input_data(1:nPosClass,:);
    negClassData = input_data(nPosClass+1:end,:);

    posClassLabels = input_labels(1:nPosClass);
    negClassLabels = input_labels(nPosClass+1:end);

    trainFracPosClassIdxs = randperm(length(posClassLabels),floor((1-holdOut)*(length(posClassLabels))));
    testFracPosClassIdxs = setdiff(1:length(posClassLabels),trainFracPosClassIdxs);

    trainFracNegClassIdxs = randperm(length(posClassLabels),ceil((1-holdOut)*(length(negClassLabels))));
    testFracNegClassIdxs = setdiff(1:length(posClassLabels),trainFracNegClassIdxs);

    % Perform the split

    training_data = [posClassData(trainFracPosClassIdxs,:); negClassData(trainFracNegClassIdxs,:)];
    training_labels = [posClassLabels(trainFracPosClassIdxs,:); negClassLabels(trainFracNegClassIdxs,:)];

    test_data = [posClassData(testFracPosClassIdxs,:); negClassData(testFracNegClassIdxs,:)];
    test_labels = [posClassLabels(testFracPosClassIdxs,:); negClassLabels(testFracNegClassIdxs,:)];

    % Train the model

    CVSVMModel = fitcsvm(training_data,training_labels,'ClassNames',{'1','0'},...
        'Standardize',true,'CrossVal','on'); % Train cross-validated model with 20% partitioning for Test
    
    trainedMdl = CVSVMModel.Trained{10};
    % Do testing and shuffling

    [~,score] = predict(trainedMdl,test_data); % Do prediction for the test set
    [~,score2] = predict(trainedMdl,training_data); % Do "prediction" for the cross-validated training set.This is not really a prediction. Its the decision boundary fit, given the training data. OVERFITTING = 1. Random fit = 0.5.
    [~,score3] = predict(trainedMdl,test_data); % Do prediction for the test set, where each iteration is one shuffle in a permutation test further on in Line 127. TWO BIRDS WITH ONE STONE BABAY!

    % TPR = True Positive Rate. FPR = False Positive Rate. ROC = Reciever Operator Characteristic. AUC = Area Under the Curve, i.e. the integral of ROC
    
    [ROC_X_train(:,iRun), ROC_Y_train(:,iRun), ~, AUC_train(iRun)] = perfcurve(training_labels, score2(:,1), '1'); % Get ROC and AUCROC, TPR, FPR for the training set
    [ROC_X_test(:,iRun), ROC_Y_test(:,iRun), ~, AUC_test(iRun)] = perfcurve(test_labels, score(:,1), '1'); % Get ROC and AUCROC, TPR, FPR for the test set
    [ROC_X_shuff(:,iRun), ROC_Y_shuff(:,iRun), ~, AUC_shuff(iRun)] = perfcurve(test_labels(randperm(length(test_labels))), score3(:,1), '1'); % Get ROC and AUCROC, TPR, FPR for the shuffled test set

    %% Use this only if required

    %     rocObj1 = rocmetrics(YTest,score,CompactSVMModel.ClassNames);
    %     rocObj2 = rocmetrics(YTrain,score2,CompactSVMModel.ClassNames);
    %     rocObj3 = rocmetrics(YTest(randperm(length(YTest))),score,CompactSVMModel.ClassNames);
    %
    %     plot(rocObj1,AverageROCType="macro",ClassNames=[])
    %     hold on
    %     plot(rocObj2,AverageROCType="macro",ClassNames=[])
    %     plot(rocObj3,AverageROCType="macro",ClassNames=[])
    %     legend('Test','Train','Test Shuffled')

    toc;

end

figure()

subplot(1,2,1)
plot(nanmean(ROC_X_train,2),nanmean(ROC_Y_train,2),'-b','LineWidth',1.25)
hold on
plot(nanmean(ROC_X_test,2),nanmean(ROC_Y_test,2),'-r','LineWidth',1.25)
plot(nanmean(ROC_X_shuff,2),nanmean(ROC_Y_shuff,2),'-g','LineWidth',1.25)
plot([0:0.25:1],[0:0.25:1],'--k','LineWidth',2)
xlabel('FPR','FontSize',14,'FontWeight','bold')
ylabel('TPR','FontSize',14,'FontWeight','bold')
title('ROC n = 1000','FontSize',16,'FontWeight','bold')
legend('Training data', 'Test data', 'Test labels shuffled')
box off

subplot(1,2,2)
groups = [AUC_train' AUC_test' AUC_shuff'];
boxplot(groups)
hline(0.5,'-k')
ylim([0 1])
title('AUCROC n = 1000','FontSize',16,'FontWeight','bold')
box off


end