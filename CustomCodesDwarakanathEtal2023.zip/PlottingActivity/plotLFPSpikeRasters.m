clear all
close all
clc

% Plotting LFP-spike Rasters transitions

%% Load pre-selected big set

d2u = [31 34 35 37 38 40 46 47 48 55 57 59 66 78 87 88 93 95 96 99 103];

u2d = [3 4 11 12 15 17 18 19 23 25 28 32 33 34 35 37 39 40 44 45 47];

%% Flip through and check

for i = 1:length(d2u)
    openfig(['DownToUpTrans_' num2str(d2u(i)) '_InstAmp_PSTHs.fig'])
    openfig(['DownToUpTrans_' num2str(d2u(i)) '_InstAmp_Rasters.fig'])
    pause
    close all
end

for i = 1:length(u2d)
    openfig(['UpToDownTrans_' num2str(u2d(i)) '_InstAmp_PSTHs.fig'])
    openfig(['UpToDownTrans_' num2str(u2d(i)) '_InstAmp_Rasters.fig'])
    pause
    close all
end
