clear all
close all
clc

dbstop if error

% Collect negative, positive and low-frequency rectified events and compute some statistics and shit
% Comments will be added later. No really, I swear, I will add them.
%
%
%
% Abhilash Dwarakanath. NS. Last update - 20220111.

%% Load the master structure - go have a long walk or something while this loads. It is YUUUGE.

cd('C:\Users\AD263755\Documents\MATLAB\NeuronPaper_MasterStructure')
load('eventsData_BR_v9_1000ms.mat')

%% Setup some params and time shit

params.nDatasets = length(neuralEvents);
params.elecs = 96;

t = neuralEvents(1).t;
tEvt = neuralEvents(1).tEvt;

mkdir EvtRasters
cd EvtRasters\

%% Negative events

bins = -0.5:0.025:0;

binCountNegEvtsNP2P = zeros(1,length(bins)-1);
binCountNegEvtsP2NP = zeros(1,length(bins)-1);

for iDataset = 1:params.nDatasets

    pref90_br = neuralEvents(iDataset).selChans.upward;
    pref270_br = neuralEvents(iDataset).selChans.downward;

    % Down to Up Switch

    for iTransition = 1:size(neuralEvents(iDataset).lfp.bb.s270TO90.negEvents,1)

        for iChanP = 1:length(pref270_br)


            if ~isempty(neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref270_br(iChanP)).times)

                evtTimes = neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref270_br(iChanP)).times;
                evtTimes(evtTimes>0) = [];

                if ~isempty(evtTimes)

                    evtIdxs = evtTimes'<bins;

                    for iEvt = 1:size(evtIdxs,1)

                        idx = find(evtIdxs(iEvt,:),1,'first');

                        binCountNegEvtsP2NP(idx-1) = binCountNegEvtsP2NP(idx-1)+1;

                    end

                end

            end

        end

        for iChanNP = 1:length(pref90_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref90_br(iChanNP)).times)

                evtTimes = neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref90_br(iChanNP)).times;
                evtTimes(evtTimes>0) = [];

                if ~isempty(evtTimes)

                    evtIdxs = evtTimes'<bins;

                    for iEvt = 1:size(evtIdxs,1)

                        idx = find(evtIdxs(iEvt,:),1,'first');

                        binCountNegEvtsNP2P(idx-1) = binCountNegEvtsNP2P(idx-1)+1;

                    end

                end

            end

        end

    end

    % Up to Down Switch

    for iTransition = 1:size(neuralEvents(iDataset).lfp.bb.s90TO270.negEvents,1)

        for iChanNP = 1:length(pref270_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref270_br(iChanNP)).times)

                evtTimes = neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref270_br(iChanNP)).times;
                evtTimes(evtTimes>0) = [];

                if ~isempty(evtTimes)

                    evtIdxs = evtTimes'<bins;

                    for iEvt = 1:size(evtIdxs,1)

                        idx = find(evtIdxs(iEvt,:),1,'first');

                        binCountNegEvtsNP2P(idx-1) = binCountNegEvtsNP2P(idx-1)+1;

                    end

                end

            end

        end

        for iChanP = 1:length(pref90_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref90_br(iChanP)).times)

                evtTimes = neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref90_br(iChanP)).times;
                evtTimes(evtTimes>0) = [];

                if ~isempty(evtTimes)

                    evtIdxs = evtTimes'<bins;

                    for iEvt = 1:size(evtIdxs,1)

                        idx = find(evtIdxs(iEvt,:),1,'first');

                        binCountNegEvtsP2NP(idx-1) = binCountNegEvtsP2NP(idx-1)+1;

                    end

                end

            end

        end

    end

end


%% Positive

bins = -0.5:0.025:0;

binCountPosEvtsNP2P = zeros(1,length(bins)-1);
binCountPosEvtsP2NP = zeros(1,length(bins)-1);

for iDataset = 1:params.nDatasets

    pref90_br = neuralEvents(iDataset).selChans.upward;
    pref270_br = neuralEvents(iDataset).selChans.downward;

    % Down to Up Switch

    for iTransition = 1:size(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents,1)

        for iChanP = 1:length(pref270_br)


            if ~isempty(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).times)

                evtTimes = neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).times;
                evtTimes(evtTimes>0) = [];

                if ~isempty(evtTimes)

                    evtIdxs = evtTimes'<bins;

                    for iEvt = 1:size(evtIdxs,1)

                        idx = find(evtIdxs(iEvt,:),1,'first');

                        binCountPosEvtsP2NP(idx-1) = binCountPosEvtsP2NP(idx-1)+1;

                    end

                end

            end

        end

        for iChanNP = 1:length(pref90_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).times)

                evtTimes = neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).times;
                evtTimes(evtTimes>0) = [];

                 if ~isempty(evtTimes)

                    evtIdxs = evtTimes'<bins;

                    for iEvt = 1:size(evtIdxs,1)

                        idx = find(evtIdxs(iEvt,:),1,'first');

                        binCountPosEvtsNP2P(idx-1) = binCountPosEvtsNP2P(idx-1)+1;

                    end

                end

            end

        end

    end

    % Up to Down Switch

    for iTransition = 1:size(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents,1)

        for iChanNP = 1:length(pref270_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).times)

                evtTimes = neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).times;

                evtTimes(evtTimes>0) = [];

                if ~isempty(evtTimes)

                    evtIdxs = evtTimes'<bins;

                    for iEvt = 1:size(evtIdxs,1)

                        idx = find(evtIdxs(iEvt,:),1,'first');

                        binCountPosEvtsNP2P(idx-1) = binCountPosEvtsNP2P(idx-1)+1;

                    end

                end

            end

        end

        for iChanP = 1:length(pref90_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).times)

                evtTimes = neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).times;

                evtTimes(evtTimes>0) = [];

                if ~isempty(evtTimes)

                    evtIdxs = evtTimes'<bins;

                    for iEvt = 1:size(evtIdxs,1)

                        idx = find(evtIdxs(iEvt,:),1,'first');

                        binCountPosEvtsP2NP(idx-1) = binCountPosEvtsP2NP(idx-1)+1;

                    end

                end

            end

        end

    end

end

%% Plot shit

t = 1;
tBins = linspace(-0.45,-0.05,20);
normMax = max([binCountNegEvtsNP2P binCountNegEvtsP2NP binCountPosEvtsNP2P binCountPosEvtsP2NP]);
normMin = min([binCountNegEvtsNP2P binCountNegEvtsP2NP binCountPosEvtsNP2P binCountPosEvtsP2NP]);

plot(tBins,(binCountNegEvtsNP2P-normMin)./normMax)
hold on
plot(tBins,(binCountNegEvtsP2NP-normMin)./normMax)
plot(tBins,(binCountPosEvtsNP2P-normMin)./normMax)
plot(tBins,(binCountPosEvtsP2NP-normMin)./normMax)
box off
xlim([-0.5 0])
