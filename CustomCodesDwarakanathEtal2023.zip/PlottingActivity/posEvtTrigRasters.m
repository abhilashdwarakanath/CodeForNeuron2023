clear all
close all
clc

dbstop if error

% Collect posative, positive and low-frequency rectified events and compute some statistics and shit
% Comments will be added later. No really, I swear, I will add them.
%
%
%
% Abhilash Dwarakanath. NS. Last update - 20220111.

%% Load the master structure - go have a long walk or something while this loads. It is YUUUGE.

cd('C:\Users\AD263755\Documents\MATLAB\NeuronPaper_MasterStructure')
load('eventsData_BR_v8_500ms.mat')

%% Setup some params and time shit

params.nDatasets = length(neuralEvents);
params.elecs = 96;

t = neuralEvents(1).t;
tEvt = neuralEvents(1).tEvt;

mkdir EvtRasters
cd EvtRasters\

%% Negative events

c1 = 0;
c2 = 0;

pooledTrigTraceNP2P = [];
pooledTrigRasterNP2P = [];

pooledTrigTraceP2NP = [];
pooledTrigRasterP2NP = [];

for iDataset = 1:params.nDatasets

    pref90_br = neuralEvents(iDataset).selChans.upward;
    pref270_br = neuralEvents(iDataset).selChans.downward;

    % Down to Up Switch

    for iTransition = 1:size(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents,1)

        trigTraceP2NP = [];
        trigTraceNP2P = [];
        trigRasterP2NP = [];
        trigRasterNP2P = [];


        for iChanP = 1:length(pref270_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).times) && length(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).posEvtTrigSpikes{1}) %#ok<*ISMT> 

                trigTraceP2NP = [trigTraceP2NP;neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).posEvtTrigLFP];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).posEvtTrigSpikes{1});

                if abs(spkTimes(end)) > 1

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes-neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).times(1);

                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterP2NP = [trigRasterP2NP; st];

            else 
                
                trigTraceP2NP = [trigTraceP2NP; zeros(1,length(tEvt))];

                trigRasterP2NP = [trigRasterP2NP; zeros(1,length(tEvt))];

            end

        end

        for iChanNP = 1:length(pref90_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).times) && length(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).posEvtTrigSpikes{1}) == 1

                trigTraceNP2P = [trigTraceNP2P;neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).posEvtTrigLFP];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).posEvtTrigSpikes{1});
                
                if abs(spkTimes(end)) > 1

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes - neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).times(1);

                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterNP2P = [trigRasterNP2P; st];

            else 
                
                trigTraceNP2P = [trigTraceNP2P; zeros(1,length(tEvt))];

                trigRasterNP2P = [trigRasterNP2P; zeros(1,length(tEvt))];

            end

        end
        
        pooledTrigTraceNP2P = [pooledTrigTraceNP2P; trigTraceNP2P];
        pooledTrigTraceP2NP = [pooledTrigTraceP2NP; trigTraceP2NP];

        pooledTrigRasterNP2P = [pooledTrigRasterNP2P; trigRasterNP2P];
        pooledTrigRasterP2NP = [pooledTrigRasterP2NP; trigRasterP2NP];

    end

    % Up to Down Switch

    for iTransition = 1:size(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents,1)

        trigTraceNP2P = [];
        trigTraceP2NP = [];
        trigRasterNP2P = [];
        trigRasterP2NP = [];


        for iChanNP = 1:length(pref270_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).times) && length(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).posEvtTrigSpikes{1}) == 1

                trigTraceNP2P = [trigTraceNP2P;neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).posEvtTrigLFP];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).posEvtTrigSpikes{1});

                 if abs(spkTimes(end)) > 1

                    spkTimes = spkTimes./1e3;

                 end

                spkTimes = spkTimes - neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).times(1);
                
                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterNP2P = [trigRasterNP2P; st];

            else 
                
                trigTraceNP2P = [trigTraceNP2P; zeros(1,length(tEvt))];

                trigRasterNP2P = [trigRasterNP2P; zeros(1,length(tEvt))];

            end

        end

        for iChanP = 1:length(pref90_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).times) && length(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).posEvtTrigSpikes{1}) == 1

                trigTraceP2NP = [trigTraceP2NP;neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).posEvtTrigLFP];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).posEvtTrigSpikes{1});

                if abs(spkTimes(end)) > 1

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes - neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).times(1);
                
                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterP2NP = [trigRasterP2NP; st];

            else 
                
                trigTraceP2NP = [trigTraceP2NP; zeros(1,length(tEvt))];

                trigRasterP2NP = [trigRasterP2NP; zeros(1,length(tEvt))];

            end

        end
        
        pooledTrigTraceNP2P = [pooledTrigTraceNP2P; trigTraceNP2P];
        pooledTrigTraceP2NP = [pooledTrigTraceP2NP; trigTraceP2NP];

        pooledTrigRasterNP2P = [pooledTrigRasterNP2P; trigRasterNP2P];
        pooledTrigRasterP2NP = [pooledTrigRasterP2NP; trigRasterP2NP];


    end


end

%% Plot pooled

sigPooledTrigRasterNP2P = pooledTrigRasterNP2P;
sigPooledTrigRasterNP2P(all(~sigPooledTrigRasterNP2P,2), : ) = [];
sigPooledTrigRasterP2NP = pooledTrigRasterP2NP;
sigPooledTrigRasterP2NP(all(~sigPooledTrigRasterP2NP,2), : ) = [];

sigPooledTrigTraceNP2P = pooledTrigTraceNP2P;
sigPooledTrigTraceNP2P(all(~sigPooledTrigTraceNP2P,2), : ) = [];
sigPooledTrigTraceP2NP = pooledTrigTraceP2NP;
sigPooledTrigTraceP2NP(all(~sigPooledTrigTraceP2NP,2), : ) = [];

errSigPooledTrigTraceNP2P = std(sigPooledTrigTraceNP2P,[],1);%./sqrt(size(sigPooledTrigTraceNP2P,1));
errSigPooledTrigTraceP2NP = std(sigPooledTrigTraceP2NP,[],1);%./sqrt(size(sigPooledTrigTraceP2NP,1));

% Create firing rates

[~,kernel] = smoothingkernel(0.3,500,0.005,'gaussian');

sigPooledFRNP2P = zeros(size(sigPooledTrigRasterNP2P,1),length(tEvt));
sigPooledFRP2NP = zeros(size(sigPooledTrigRasterP2NP,1),length(tEvt));

tic;
for iSpikeTrain = 1:size(sigPooledTrigRasterNP2P,1)

    sigPooledFRNP2P(iSpikeTrain,:) = conv(sigPooledTrigRasterNP2P(iSpikeTrain,:),kernel,'same');

end

for iSpikeTrain = 1:size(sigPooledTrigRasterP2NP,1)

    sigPooledFRP2NP(iSpikeTrain,:) = conv(sigPooledTrigRasterP2NP(iSpikeTrain,:),kernel,'same');

end
toc;

errFRNP2P = std(sigPooledFRNP2P,[],1)./sqrt(size(sigPooledFRNP2P,1));
errFRP2NP = std(sigPooledFRP2NP,[],1)./sqrt(size(sigPooledFRP2NP,1));


% Plot

figure

sgtitle('Positive Broadband Deflections and aligned Spike Rasters','FontSize',16,'FontWeight','bold')

subplot(6,2,1)
shadedErrorBar(tEvt,nanmean(sigPooledTrigTraceNP2P,1),errSigPooledTrigTraceNP2P)
hold on
plot(tEvt,nanmean(sigPooledTrigTraceNP2P,1),'LineWidth',1)
ylabel('event amplitude [a.u.]','FontSize',14,'FontWeight','bold')
%grid on
box off
title('Non-preferred to Preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); %ylim([-125 25]); 
vline(0,'--r')

subplot(6,2,2)
shadedErrorBar(tEvt,nanmean(sigPooledTrigTraceP2NP,1),errSigPooledTrigTraceP2NP)
hold on
plot(tEvt,nanmean(sigPooledTrigTraceP2NP,1),'LineWidth',1)
%grid on
box off
title('Preferred to non-preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); %ylim([-125 25]); 
vline(0,'--r')

subplot(6,2,[3 5 7 9])
imagesc(tEvt,1:size(sigPooledTrigRasterNP2P,1),~sigPooledTrigRasterNP2P)
colormap gray
box off
vline(0,'--r')
xlim([-0.165 0.165])

subplot(6,2,[4 6 8 10])
imagesc(tEvt,1:size(sigPooledTrigRasterP2NP,1),~sigPooledTrigRasterP2NP)
colormap gray
box off
vline(0,'--r')
xlim([-0.165 0.165])

subplot(6,2,11)
shadedErrorBar(tEvt(5:end-4),nanmean(sigPooledFRNP2P(:,5:end-4),1),errFRNP2P(5:end-4))
hold on
plot(tEvt(5:end-4),nanmean(sigPooledFRNP2P(:,5:end-4),1),'LineWidth',1)
ylabel('firing rate [spikes/s]','FontSize',14,'FontWeight','bold')
%grid on
box off
title('Non-preferred to Preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); %ylim([12 40]); 
vline(0,'--r')
xlabel('time relative to event [s]','FontSize',14,'FontWeight','bold')

subplot(6,2,12)
shadedErrorBar(tEvt(5:end-4),nanmean(sigPooledFRP2NP(:,5:end-4),1),errFRP2NP(5:end-4))
hold on
plot(tEvt(5:end-4),nanmean(sigPooledFRP2NP(:,5:end-4),1),'LineWidth',1)
%grid on
box off
title('Preferred to non-preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); %ylim([12 40]); 
vline(0,'--r')
xlabel('time relative to event [s]','FontSize',14,'FontWeight','bold')

