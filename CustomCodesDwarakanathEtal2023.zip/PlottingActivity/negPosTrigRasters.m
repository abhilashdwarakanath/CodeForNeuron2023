clear all
close all
clc

dbstop if error

% Collect negative, positive and low-frequency rectified events and compute some statistics and shit
% Comments will be added later. No really, I swear, I will add them.
%
%
%
% Abhilash Dwarakanath. NS. Last update - 20220111.

%% Load the master structure - go have a long walk or something while this loads. It is YUUUGE.

cd('C:\Users\AD263755\Documents\MATLAB\NeuronPaper_MasterStructure')
load('eventsData_BR_v9_500ms.mat')

%% Setup some params and time shit

params.nDatasets = length(neuralEvents);
params.elecs = 96;

t = neuralEvents(1).t;
tEvt = neuralEvents(1).tEvt;

mkdir EvtRasters
cd EvtRasters\

%% Negative events

pooledTrigTraceNP2P = [];
pooledTrigRasterNP2P = [];

pooledTrigTraceP2NP = [];
pooledTrigRasterP2NP = [];

pooledTrigPhaseNP2P = [];
pooledTrigLowPhaseNP2P = [];

pooledTrigPhaseP2NP = [];
pooledTrigLowPhaseP2NP = [];

for iDataset = 1:params.nDatasets

    pref90_br = neuralEvents(iDataset).selChans.upward;
    pref270_br = neuralEvents(iDataset).selChans.downward;

    % Down to Up Switch

    for iTransition = 1:size(neuralEvents(iDataset).lfp.bb.s270TO90.negEvents,1)

        trigTraceP2NP = [];
        trigTraceNP2P = [];
        trigRasterP2NP = [];
        trigRasterNP2P = [];
        trigPhaseNP2P = [];
        trigPhaseP2NP = [];
        trigLowPhaseNP2P = [];
        trigLowPhaseP2NP = [];

        for iChanP = 1:length(pref270_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref270_br(iChanP)).times) && length(neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref270_br(iChanP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s270TO90.negEvents(iTransition,pref270_br(iChanP)).negEvtTrigSpikes{1}) %#ok<*ISMT> 

                trigTraceP2NP = [trigTraceP2NP;neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref270_br(iChanP)).negEvtTrigLFP];
                trigPhaseP2NP = [trigPhaseP2NP; neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref270_br(iChanP)).negEvtTrigPhase];
                trigLowPhaseP2NP = [trigLowPhaseP2NP; neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref270_br(iChanP)).negEvtTrigLowPhase];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s270TO90.negEvents(iTransition,pref270_br(iChanP)).negEvtTrigSpikes{1});

                if any(abs(spkTimes) > 1)

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes-neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref270_br(iChanP)).times(1);

                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterP2NP = [trigRasterP2NP; st];

            else 
                
                trigTraceP2NP = [trigTraceP2NP; zeros(1,length(tEvt))];

                trigRasterP2NP = [trigRasterP2NP; zeros(1,length(tEvt))];

            end

        end

        for iChanNP = 1:length(pref90_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref90_br(iChanNP)).times) && length(neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref90_br(iChanNP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s270TO90.negEvents(iTransition,pref90_br(iChanNP)).negEvtTrigSpikes{1}) == 1

                trigTraceNP2P = [trigTraceNP2P;neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref90_br(iChanNP)).negEvtTrigLFP];
                trigPhaseNP2P = [trigPhaseNP2P;neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref90_br(iChanNP)).negEvtTrigPhase];
                trigLowPhaseNP2P = [trigLowPhaseNP2P;neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref90_br(iChanNP)).negEvtTrigLowPhase];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s270TO90.negEvents(iTransition,pref90_br(iChanNP)).negEvtTrigSpikes{1});
                
                if any(abs(spkTimes) > 1)

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes - neuralEvents(iDataset).lfp.bb.s270TO90.negEvents(iTransition,pref90_br(iChanNP)).times(1);

                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterNP2P = [trigRasterNP2P; st];

            else 
                
                trigTraceNP2P = [trigTraceNP2P; zeros(1,length(tEvt))];

                trigRasterNP2P = [trigRasterNP2P; zeros(1,length(tEvt))];

            end

        end

        pooledTrigTraceNP2P = [pooledTrigTraceNP2P; trigTraceNP2P];
        pooledTrigTraceP2NP = [pooledTrigTraceP2NP; trigTraceP2NP];

        pooledTrigRasterNP2P = [pooledTrigRasterNP2P; trigRasterNP2P];
        pooledTrigRasterP2NP = [pooledTrigRasterP2NP; trigRasterP2NP];

        pooledTrigPhaseNP2P = [pooledTrigPhaseNP2P; trigPhaseNP2P];
        pooledTrigPhaseP2NP = [pooledTrigPhaseP2NP; trigPhaseP2NP];

        pooledTrigLowPhaseNP2P = [pooledTrigLowPhaseNP2P; trigLowPhaseNP2P];
        pooledTrigLowPhaseP2NP = [pooledTrigLowPhaseP2NP; trigLowPhaseP2NP];

    end

    % Up to Down Switch

    for iTransition = 1:size(neuralEvents(iDataset).lfp.bb.s90TO270.negEvents,1)

        trigTraceP2NP = [];
        trigTraceNP2P = [];
        trigRasterP2NP = [];
        trigRasterNP2P = [];
        trigPhaseNP2P = [];
        trigPhaseP2NP = [];
        trigLowPhaseNP2P = [];
        trigLowPhaseP2NP = [];


        for iChanNP = 1:length(pref270_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref270_br(iChanNP)).times) && length(neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref270_br(iChanNP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s90TO270.negEvents(iTransition,pref270_br(iChanNP)).negEvtTrigSpikes{1}) == 1

                trigTraceNP2P = [trigTraceNP2P;neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref270_br(iChanNP)).negEvtTrigLFP];
                trigPhaseNP2P = [trigPhaseNP2P;neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref270_br(iChanNP)).negEvtTrigPhase];
                trigLowPhaseNP2P = [trigLowPhaseNP2P;neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref270_br(iChanNP)).negEvtTrigLowPhase];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s90TO270.negEvents(iTransition,pref270_br(iChanNP)).negEvtTrigSpikes{1});

                 if any(abs(spkTimes) > 1)

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes - neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref270_br(iChanNP)).times(1);
                
                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterNP2P = [trigRasterNP2P; st];

            else 
                
                trigTraceNP2P = [trigTraceNP2P; zeros(1,length(tEvt))];

                trigRasterNP2P = [trigRasterNP2P; zeros(1,length(tEvt))];

            end

        end

        for iChanP = 1:length(pref90_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref90_br(iChanP)).times) && length(neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref90_br(iChanP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s90TO270.negEvents(iTransition,pref90_br(iChanP)).negEvtTrigSpikes{1}) == 1

                trigTraceP2NP = [trigTraceP2NP;neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref90_br(iChanP)).negEvtTrigLFP];
                trigPhaseP2NP = [trigPhaseP2NP;neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref90_br(iChanP)).negEvtTrigPhase];
                trigLowPhaseP2NP = [trigLowPhaseP2NP;neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref90_br(iChanP)).negEvtTrigLowPhase];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s90TO270.negEvents(iTransition,pref90_br(iChanP)).negEvtTrigSpikes{1});

                if any(abs(spkTimes) > 1)

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes - neuralEvents(iDataset).lfp.bb.s90TO270.negEvents(iTransition,pref90_br(iChanP)).times(1);
                
                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterP2NP = [trigRasterP2NP; st];

            else 
                
                trigTraceP2NP = [trigTraceP2NP; zeros(1,length(tEvt))];

                trigRasterP2NP = [trigRasterP2NP; zeros(1,length(tEvt))];

            end

        end
        
        pooledTrigTraceNP2P = [pooledTrigTraceNP2P; trigTraceNP2P];
        pooledTrigTraceP2NP = [pooledTrigTraceP2NP; trigTraceP2NP];

        pooledTrigRasterNP2P = [pooledTrigRasterNP2P; trigRasterNP2P];
        pooledTrigRasterP2NP = [pooledTrigRasterP2NP; trigRasterP2NP];

        pooledTrigPhaseNP2P = [pooledTrigPhaseNP2P; trigPhaseNP2P];
        pooledTrigPhaseP2NP = [pooledTrigPhaseP2NP; trigPhaseP2NP];

        pooledTrigLowPhaseNP2P = [pooledTrigLowPhaseNP2P; trigLowPhaseNP2P];
        pooledTrigLowPhaseP2NP = [pooledTrigLowPhaseP2NP; trigLowPhaseP2NP];


    end


end

% Plot pooled

sigPooledTrigRasterNP2P = pooledTrigRasterNP2P;
sigPooledTrigRasterNP2P(all(~sigPooledTrigRasterNP2P,2), : ) = [];
sigPooledTrigRasterP2NP = pooledTrigRasterP2NP;
sigPooledTrigRasterP2NP(all(~sigPooledTrigRasterP2NP,2), : ) = [];

sigPooledTrigTraceNP2P = pooledTrigTraceNP2P;
sigPooledTrigTraceNP2P(all(~sigPooledTrigTraceNP2P,2), : ) = [];
sigPooledTrigTraceP2NP = pooledTrigTraceP2NP;
sigPooledTrigTraceP2NP(all(~sigPooledTrigTraceP2NP,2), : ) = [];

sigPooledTrigPhaseNP2P = pooledTrigPhaseNP2P;
sigPooledTrigPhaseNP2P(all(~sigPooledTrigPhaseNP2P,2), : ) = [];
sigPooledTrigPhaseP2NP = pooledTrigPhaseP2NP;
sigPooledTrigPhaseP2NP(all(~sigPooledTrigPhaseP2NP,2), : ) = [];

sigPooledTrigLowPhaseNP2P = pooledTrigLowPhaseNP2P;
sigPooledTrigLowPhaseNP2P(all(~sigPooledTrigLowPhaseNP2P,2), : ) = [];
sigPooledTrigLowPhaseP2NP = pooledTrigLowPhaseP2NP;
sigPooledTrigLowPhaseP2NP(all(~sigPooledTrigLowPhaseP2NP,2), : ) = [];

errSigPooledTrigTraceNP2P = std(sigPooledTrigTraceNP2P,[],1);%./sqrt(size(sigPooledTrigTraceNP2P,1));
errSigPooledTrigTraceP2NP = std(sigPooledTrigTraceP2NP,[],1);%./sqrt(size(sigPooledTrigTraceP2NP,1));

errSigPooledTrigPhaseNP2P = circ_std(sigPooledTrigPhaseNP2P,[],1)./sqrt(size(sigPooledTrigPhaseNP2P,1));
errSigPooledTrigPhaseP2NP = circ_std(sigPooledTrigPhaseP2NP,[],1)./sqrt(size(sigPooledTrigPhaseP2NP,1));

errSigPooledTrigLowPhaseNP2P = circ_std(sigPooledTrigLowPhaseNP2P,[],1)./sqrt(size(sigPooledTrigLowPhaseNP2P,1));
errSigPooledTrigLowPhaseP2NP = circ_std(sigPooledTrigLowPhaseP2NP,[],1)./sqrt(size(sigPooledTrigLowPhaseP2NP,1));

% Create firing rates

[~,kernel] = smoothingkernel(0.3,500,0.005,'alpha');

sigPooledFRNP2P = zeros(size(sigPooledTrigRasterNP2P,1),length(tEvt));
sigPooledFRP2NP = zeros(size(sigPooledTrigRasterP2NP,1),length(tEvt));

tic;
for iSpikeTrain = 1:size(sigPooledTrigRasterNP2P,1)

    sigPooledFRNP2P(iSpikeTrain,:) = conv(sigPooledTrigRasterNP2P(iSpikeTrain,:),kernel,'same');

end

for iSpikeTrain = 1:size(sigPooledTrigRasterP2NP,1)

    sigPooledFRP2NP(iSpikeTrain,:) = conv(sigPooledTrigRasterP2NP(iSpikeTrain,:),kernel,'same');

end
toc;

errFRNP2P = std(sigPooledFRNP2P,[],1)./sqrt(size(sigPooledFRNP2P,1));
errFRP2NP = std(sigPooledFRP2NP,[],1)./sqrt(size(sigPooledFRP2NP,1));


% Plot

figure(1)

sgtitle('Negative Broadband Deflections and aligned Spike Rasters','FontSize',16,'FontWeight','bold')

subplot(6,2,1)
shadedErrorBar(tEvt,nanmean(sigPooledTrigTraceNP2P,1),errSigPooledTrigTraceNP2P)
hold on
plot(tEvt,nanmean(sigPooledTrigTraceNP2P,1),'LineWidth',1)
ylabel('event amplitude [a.u.]','FontSize',14,'FontWeight','bold')
%grid on
box off
title('Non-preferred to Preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')

subplot(6,2,2)
shadedErrorBar(tEvt,nanmean(sigPooledTrigTraceP2NP,1),errSigPooledTrigTraceP2NP)
hold on
plot(tEvt,nanmean(sigPooledTrigTraceP2NP,1),'LineWidth',1)
%grid on
box off
title('Preferred to non-preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')

subplot(6,2,[3 5 7])
imagesc(tEvt,1:size(sigPooledTrigRasterNP2P,1),~sigPooledTrigRasterNP2P)
colormap gray
box off
vline(0,'--r')
xlim([-0.165 0.165])

subplot(6,2,[4 6 8])
imagesc(tEvt,1:size(sigPooledTrigRasterP2NP,1),~sigPooledTrigRasterP2NP)
colormap gray
box off
vline(0,'--r')
xlim([-0.165 0.165])

subplot(6,2,9)
shadedErrorBar(tEvt(5:end-4),circ_mean(sigPooledTrigPhaseNP2P(:,5:end-4),[],1),errSigPooledTrigPhaseNP2P(5:end-4))
hold on
plot(tEvt(5:end-4),circ_mean(sigPooledTrigPhaseNP2P(:,5:end-4),[],1),'LineWidth',1)
shadedErrorBar(tEvt(5:end-4),circ_mean(sigPooledTrigLowPhaseNP2P(:,5:end-4),[],1),errSigPooledTrigLowPhaseNP2P(5:end-4))
hold on
plot(tEvt(5:end-4),circ_mean(sigPooledTrigLowPhaseNP2P(:,5:end-4),[],1),'LineWidth',1)
ylabel('firing rate [spikes/s]','FontSize',14,'FontWeight','bold')
%grid on
box off
title('Non-preferred to Preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')
xlabel('time relative to event [s]','FontSize',14,'FontWeight','bold')
ylabel('phase angle [rad]')

subplot(6,2,10)
shadedErrorBar(tEvt(5:end-4),circ_mean(sigPooledTrigPhaseP2NP(:,5:end-4),[],1),errSigPooledTrigPhaseP2NP(5:end-4))
hold on
plot(tEvt(5:end-4),circ_mean(sigPooledTrigPhaseP2NP(:,5:end-4),[],1),'LineWidth',1)
shadedErrorBar(tEvt(5:end-4),circ_mean(sigPooledTrigLowPhaseP2NP(:,5:end-4),[],1),errSigPooledTrigLowPhaseP2NP(5:end-4))
hold on
plot(tEvt(5:end-4),circ_mean(sigPooledTrigLowPhaseP2NP(:,5:end-4),[],1),'LineWidth',1)
%grid on
box off
title('Preferred to non-preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')
xlabel('time relative to event [s]','FontSize',14,'FontWeight','bold')

subplot(6,2,11)
shadedErrorBar(tEvt(5:end-4),nanmean(sigPooledFRNP2P(:,5:end-4),1),errFRNP2P(5:end-4))
hold on
plot(tEvt(5:end-4),nanmean(sigPooledFRNP2P(:,5:end-4),1),'LineWidth',1)
ylabel('firing rate [spikes/s]','FontSize',14,'FontWeight','bold')
%grid on
box off
title('Non-preferred to Preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')
xlabel('time relative to event [s]','FontSize',14,'FontWeight','bold')

subplot(6,2,12)
shadedErrorBar(tEvt(5:end-4),nanmean(sigPooledFRP2NP(:,5:end-4),1),errFRP2NP(5:end-4))
hold on
plot(tEvt(5:end-4),nanmean(sigPooledFRP2NP(:,5:end-4),1),'LineWidth',1)
%grid on
box off
title('Preferred to non-preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')
xlabel('time relative to event [s]','FontSize',14,'FontWeight','bold')



%% Positive events

pooledTrigTraceNP2P = [];
pooledTrigRasterNP2P = [];

pooledTrigTraceP2NP = [];
pooledTrigRasterP2NP = [];

pooledTrigPhaseNP2P = [];
pooledTrigLowPhaseNP2P = [];

pooledTrigPhaseP2NP = [];
pooledTrigLowPhaseP2NP = [];

for iDataset = 1:params.nDatasets

    pref90_br = neuralEvents(iDataset).selChans.upward;
    pref270_br = neuralEvents(iDataset).selChans.downward;

    % Down to Up Switch

    for iTransition = 1:size(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents,1)

        trigTraceP2NP = [];
        trigTraceNP2P = [];
        trigRasterP2NP = [];
        trigRasterNP2P = [];
        trigPhaseNP2P = [];
        trigPhaseP2NP = [];
        trigLowPhaseNP2P = [];
        trigLowPhaseP2NP = [];

        for iChanP = 1:length(pref270_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).times) && length(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).posEvtTrigSpikes{1}) %#ok<*ISMT> 

                trigTraceP2NP = [trigTraceP2NP;neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).posEvtTrigLFP];
                trigPhaseP2NP = [trigPhaseP2NP; neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).posEvtTrigPhase];
                trigLowPhaseP2NP = [trigLowPhaseP2NP; neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).posEvtTrigLowPhase];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).posEvtTrigSpikes{1});

                if any(abs(spkTimes) > 1)

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes-neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref270_br(iChanP)).times(1);

                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterP2NP = [trigRasterP2NP; st];

            else 
                
                trigTraceP2NP = [trigTraceP2NP; zeros(1,length(tEvt))];

                trigRasterP2NP = [trigRasterP2NP; zeros(1,length(tEvt))];

            end

        end

        for iChanNP = 1:length(pref90_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).times) && length(neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).posEvtTrigSpikes{1}) == 1

                trigTraceNP2P = [trigTraceNP2P;neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).posEvtTrigLFP];
                trigPhaseNP2P = [trigPhaseNP2P;neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).posEvtTrigPhase];
                trigLowPhaseNP2P = [trigLowPhaseNP2P;neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).posEvtTrigLowPhase];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).posEvtTrigSpikes{1});
                
                if any(abs(spkTimes) > 1)

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes - neuralEvents(iDataset).lfp.bb.s270TO90.posEvents(iTransition,pref90_br(iChanNP)).times(1);

                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterNP2P = [trigRasterNP2P; st];

            else 
                
                trigTraceNP2P = [trigTraceNP2P; zeros(1,length(tEvt))];

                trigRasterNP2P = [trigRasterNP2P; zeros(1,length(tEvt))];

            end

        end

        pooledTrigTraceNP2P = [pooledTrigTraceNP2P; trigTraceNP2P];
        pooledTrigTraceP2NP = [pooledTrigTraceP2NP; trigTraceP2NP];

        pooledTrigRasterNP2P = [pooledTrigRasterNP2P; trigRasterNP2P];
        pooledTrigRasterP2NP = [pooledTrigRasterP2NP; trigRasterP2NP];

        pooledTrigPhaseNP2P = [pooledTrigPhaseNP2P; trigPhaseNP2P];
        pooledTrigPhaseP2NP = [pooledTrigPhaseP2NP; trigPhaseP2NP];

        pooledTrigLowPhaseNP2P = [pooledTrigLowPhaseNP2P; trigLowPhaseNP2P];
        pooledTrigLowPhaseP2NP = [pooledTrigLowPhaseP2NP; trigLowPhaseP2NP];

    end

    % Up to Down Switch

    for iTransition = 1:size(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents,1)

        trigTraceP2NP = [];
        trigTraceNP2P = [];
        trigRasterP2NP = [];
        trigRasterNP2P = [];
        trigPhaseNP2P = [];
        trigPhaseP2NP = [];
        trigLowPhaseNP2P = [];
        trigLowPhaseP2NP = [];


        for iChanNP = 1:length(pref270_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).times) && length(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).posEvtTrigSpikes{1}) == 1

                trigTraceNP2P = [trigTraceNP2P;neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).posEvtTrigLFP];
                trigPhaseNP2P = [trigPhaseNP2P;neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).posEvtTrigPhase];
                trigLowPhaseNP2P = [trigLowPhaseNP2P;neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).posEvtTrigLowPhase];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).posEvtTrigSpikes{1});

                if any(abs(spkTimes) > 1)

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes - neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref270_br(iChanNP)).times(1);
                
                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterNP2P = [trigRasterNP2P; st];

            else 
                
                trigTraceNP2P = [trigTraceNP2P; zeros(1,length(tEvt))];

                trigRasterNP2P = [trigRasterNP2P; zeros(1,length(tEvt))];

            end

        end

        for iChanP = 1:length(pref90_br)

            if ~isempty(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).times) && length(neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).times) == 1 && ~isempty(neuralEvents(iDataset).spikes.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).posEvtTrigSpikes{1}) == 1

                trigTraceP2NP = [trigTraceP2NP;neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).posEvtTrigLFP];
                trigPhaseP2NP = [trigPhaseP2NP;neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).posEvtTrigPhase];
                trigLowPhaseP2NP = [trigLowPhaseP2NP;neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).posEvtTrigLowPhase];

                spkTimes = (neuralEvents(iDataset).spikes.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).posEvtTrigSpikes{1});

                if any(abs(spkTimes) > 1)

                    spkTimes = spkTimes./1e3;

                end

                spkTimes = spkTimes - neuralEvents(iDataset).lfp.bb.s90TO270.posEvents(iTransition,pref90_br(iChanP)).times(1);
                
                st = zeros(1,length(tEvt));

                [idx] = interp1(tEvt,1:length(tEvt),spkTimes,'nearest');

                st(idx) = 1;

                trigRasterP2NP = [trigRasterP2NP; st];

            else 
                
                trigTraceP2NP = [trigTraceP2NP; zeros(1,length(tEvt))];

                trigRasterP2NP = [trigRasterP2NP; zeros(1,length(tEvt))];

            end

        end
        
        pooledTrigTraceNP2P = [pooledTrigTraceNP2P; trigTraceNP2P];
        pooledTrigTraceP2NP = [pooledTrigTraceP2NP; trigTraceP2NP];

        pooledTrigRasterNP2P = [pooledTrigRasterNP2P; trigRasterNP2P];
        pooledTrigRasterP2NP = [pooledTrigRasterP2NP; trigRasterP2NP];

        pooledTrigPhaseNP2P = [pooledTrigPhaseNP2P; trigPhaseNP2P];
        pooledTrigPhaseP2NP = [pooledTrigPhaseP2NP; trigPhaseP2NP];

        pooledTrigLowPhaseNP2P = [pooledTrigLowPhaseNP2P; trigLowPhaseNP2P];
        pooledTrigLowPhaseP2NP = [pooledTrigLowPhaseP2NP; trigLowPhaseP2NP];


    end


end

% Plot pooled

sigPooledTrigRasterNP2P = pooledTrigRasterNP2P;
sigPooledTrigRasterNP2P(all(~sigPooledTrigRasterNP2P,2), : ) = [];
sigPooledTrigRasterP2NP = pooledTrigRasterP2NP;
sigPooledTrigRasterP2NP(all(~sigPooledTrigRasterP2NP,2), : ) = [];

sigPooledTrigTraceNP2P = pooledTrigTraceNP2P;
sigPooledTrigTraceNP2P(all(~sigPooledTrigTraceNP2P,2), : ) = [];
sigPooledTrigTraceP2NP = pooledTrigTraceP2NP;
sigPooledTrigTraceP2NP(all(~sigPooledTrigTraceP2NP,2), : ) = [];

sigPooledTrigPhaseNP2P = pooledTrigPhaseNP2P;
sigPooledTrigPhaseNP2P(all(~sigPooledTrigPhaseNP2P,2), : ) = [];
sigPooledTrigPhaseP2NP = pooledTrigPhaseP2NP;
sigPooledTrigPhaseP2NP(all(~sigPooledTrigPhaseP2NP,2), : ) = [];

sigPooledTrigLowPhaseNP2P = pooledTrigLowPhaseNP2P;
sigPooledTrigLowPhaseNP2P(all(~sigPooledTrigLowPhaseNP2P,2), : ) = [];
sigPooledTrigLowPhaseP2NP = pooledTrigLowPhaseP2NP;
sigPooledTrigLowPhaseP2NP(all(~sigPooledTrigLowPhaseP2NP,2), : ) = [];

errSigPooledTrigTraceNP2P = std(sigPooledTrigTraceNP2P,[],1);%./sqrt(size(sigPooledTrigTraceNP2P,1));
errSigPooledTrigTraceP2NP = std(sigPooledTrigTraceP2NP,[],1);%./sqrt(size(sigPooledTrigTraceP2NP,1));

errSigPooledTrigPhaseNP2P = circ_std(sigPooledTrigPhaseNP2P,[],1)./sqrt(size(sigPooledTrigPhaseNP2P,1));
errSigPooledTrigPhaseP2NP = circ_std(sigPooledTrigPhaseP2NP,[],1)./sqrt(size(sigPooledTrigPhaseP2NP,1));

errSigPooledTrigLowPhaseNP2P = circ_std(sigPooledTrigLowPhaseNP2P,[],1)./sqrt(size(sigPooledTrigLowPhaseNP2P,1));
errSigPooledTrigLowPhaseP2NP = circ_std(sigPooledTrigLowPhaseP2NP,[],1)./sqrt(size(sigPooledTrigLowPhaseP2NP,1));

% Create firing rates

[~,kernel] = smoothingkernel(0.3,500,0.005,'alpha');

sigPooledFRNP2P = zeros(size(sigPooledTrigRasterNP2P,1),length(tEvt));
sigPooledFRP2NP = zeros(size(sigPooledTrigRasterP2NP,1),length(tEvt));

tic;
for iSpikeTrain = 1:size(sigPooledTrigRasterNP2P,1)

    sigPooledFRNP2P(iSpikeTrain,:) = conv(sigPooledTrigRasterNP2P(iSpikeTrain,:),kernel,'same');

end

for iSpikeTrain = 1:size(sigPooledTrigRasterP2NP,1)

    sigPooledFRP2NP(iSpikeTrain,:) = conv(sigPooledTrigRasterP2NP(iSpikeTrain,:),kernel,'same');

end
toc;

errFRNP2P = std(sigPooledFRNP2P,[],1)./sqrt(size(sigPooledFRNP2P,1));
errFRP2NP = std(sigPooledFRP2NP,[],1)./sqrt(size(sigPooledFRP2NP,1));


% Plot

figure(2)

sgtitle('Positive Broadband Deflections and aligned Spike Rasters','FontSize',16,'FontWeight','bold')

subplot(6,2,1)
shadedErrorBar(tEvt,nanmean(sigPooledTrigTraceNP2P,1),errSigPooledTrigTraceNP2P)
hold on
plot(tEvt,nanmean(sigPooledTrigTraceNP2P,1),'LineWidth',1)
ylabel('event amplitude [a.u.]','FontSize',14,'FontWeight','bold')
%grid on
box off
title('Non-preferred to Preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')

subplot(6,2,2)
shadedErrorBar(tEvt,nanmean(sigPooledTrigTraceP2NP,1),errSigPooledTrigTraceP2NP)
hold on
plot(tEvt,nanmean(sigPooledTrigTraceP2NP,1),'LineWidth',1)
%grid on
box off
title('Preferred to non-preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')

subplot(6,2,[3 5 7])
imagesc(tEvt,1:size(sigPooledTrigRasterNP2P,1),~sigPooledTrigRasterNP2P)
colormap gray
box off
vline(0,'--r')
xlim([-0.165 0.165])

subplot(6,2,[4 6 8])
imagesc(tEvt,1:size(sigPooledTrigRasterP2NP,1),~sigPooledTrigRasterP2NP)
colormap gray
box off
vline(0,'--r')
xlim([-0.165 0.165])

subplot(6,2,9)
shadedErrorBar(tEvt(5:end-4),circ_mean(sigPooledTrigPhaseNP2P(:,5:end-4),[],1),errSigPooledTrigPhaseNP2P(5:end-4))
hold on
plot(tEvt(5:end-4),circ_mean(sigPooledTrigPhaseNP2P(:,5:end-4),[],1),'LineWidth',1)
shadedErrorBar(tEvt(5:end-4),circ_mean(sigPooledTrigLowPhaseNP2P(:,5:end-4),[],1),errSigPooledTrigLowPhaseNP2P(5:end-4))
hold on
plot(tEvt(5:end-4),circ_mean(sigPooledTrigLowPhaseNP2P(:,5:end-4),[],1),'LineWidth',1)
ylabel('firing rate [spikes/s]','FontSize',14,'FontWeight','bold')
%grid on
box off
title('Non-preferred to Preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')
xlabel('time relative to event [s]','FontSize',14,'FontWeight','bold')
ylabel('phase angle [rad]')

subplot(6,2,10)
shadedErrorBar(tEvt(5:end-4),circ_mean(sigPooledTrigPhaseP2NP(:,5:end-4),[],1),errSigPooledTrigPhaseP2NP(5:end-4))
hold on
plot(tEvt(5:end-4),circ_mean(sigPooledTrigPhaseP2NP(:,5:end-4),[],1),'LineWidth',1)
shadedErrorBar(tEvt(5:end-4),circ_mean(sigPooledTrigLowPhaseP2NP(:,5:end-4),[],1),errSigPooledTrigLowPhaseP2NP(5:end-4))
hold on
plot(tEvt(5:end-4),circ_mean(sigPooledTrigLowPhaseP2NP(:,5:end-4),[],1),'LineWidth',1)
%grid on
box off
title('Preferred to non-preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')
xlabel('time relative to event [s]','FontSize',14,'FontWeight','bold')

subplot(6,2,11)
shadedErrorBar(tEvt(5:end-4),nanmean(sigPooledFRNP2P(:,5:end-4),1),errFRNP2P(5:end-4))
hold on
plot(tEvt(5:end-4),nanmean(sigPooledFRNP2P(:,5:end-4),1),'LineWidth',1)
ylabel('firing rate [spikes/s]','FontSize',14,'FontWeight','bold')
%grid on
box off
title('Non-preferred to Preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')
xlabel('time relative to event [s]','FontSize',14,'FontWeight','bold')

subplot(6,2,12)
shadedErrorBar(tEvt(5:end-4),nanmean(sigPooledFRP2NP(:,5:end-4),1),errFRP2NP(5:end-4))
hold on
plot(tEvt(5:end-4),nanmean(sigPooledFRP2NP(:,5:end-4),1),'LineWidth',1)
%grid on
box off
title('Preferred to non-preferred','FontSize',14,'FontWeight','bold')
xlim([-0.165 0.165]); vline(0,'--r')
xlabel('time relative to event [s]','FontSize',14,'FontWeight','bold')


%% Save shit

t = 1;
