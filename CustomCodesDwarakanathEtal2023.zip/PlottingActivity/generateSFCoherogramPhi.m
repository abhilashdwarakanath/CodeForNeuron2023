function generateSFCoherogramPhi

%% Load shit

cd('C:\Users\AD263755\Documents\MATLAB\SFCoherogramData\SFCoherogramData')


%% COllect shit

sfcohgram = [];
sfcphi = [];

for iDataset = 1:6

    cd(['C:\Users\AD263755\Documents\MATLAB\SFCoherogramData\SFCoherogramData\' num2str(iDataset) '\'])

    load('MM_SFCohgram_MUASel_1000ms_GlobalLFP_EnsembleSpiking.mat')

    sfcSel90 = cat(1,SFC.sfc_BR_sel90_90TO270,SFC.sfc_BR_sel90_270TO90);
    sfcSel270 = cat(1,SFC.sfc_BR_sel270_90TO270,SFC.sfc_BR_sel270_270TO90);

    phiSel90 = cat(1,SFC.phi_BR_sel90_90TO270,SFC.phi_BR_sel90_270TO90);
    phiSel270 = cat(1,SFC.phi_BR_sel270_90TO270,SFC.phi_BR_sel270_270TO90);

    sfcohgram = cat(1,sfcohgram,sfcSel90,sfcSel270);
    sfcphi = cat(1,sfcphi,phiSel90,phiSel270);

end


%% Plot shit

f = f_BR.freqs;
t = linspace(-1,1,129);
imagesc(t,f,squeeze(nanmean(sfcohgram,1))')
