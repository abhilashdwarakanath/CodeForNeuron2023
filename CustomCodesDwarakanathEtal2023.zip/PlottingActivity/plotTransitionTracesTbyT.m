function plotTransitionTracesTbyT

%% Enumerate the datasets

nDatasets = 6;
datasets{1} = 'B:\H07\12-06-2016\PFC\Bfsgrad1\CriticalSlowingDown\MMstd4_TbyT_forAutoCov_500ms.mat';
datasets{2} = 'B:\H07\13-07-2016\PFC\Bfsgrad1\CriticalSlowingDown\MMstd4_TbyT_forAutoCov_500ms.mat';
datasets{3} = 'B:\H07\20161019\PFC\Bfsgrad1\CriticalSlowingDown\MMstd4_TbyT_forAutoCov_500ms.mat';
datasets{4} = 'B:\H07\20161025\PFC\Bfsgrad1\CriticalSlowingDown\MMstd4_TbyT_forAutoCov_500ms.mat';
datasets{5} = 'B:\A11\20170305\PFC\Bfsgrad1\CriticalSlowingDown\MMstd4_TbyT_forAutoCov_500ms.mat';
datasets{6} = 'B:\A11\20170302\PFC\Bfsgrad1\CriticalSlowingDown\MMstd4_TbyT_forAutoCov_500ms.mat';

%% Load and collect

t = linspace(-0.5,0.5,501);

noNorm_traces_BR_90 = [];
noNorm_traces_PA_90 = [];
noNorm_traces_BR_270 = [];
noNorm_traces_PA_270 = [];

for iDataset = 1:nDatasets
    
    load(datasets{iDataset})
    
    noNorm_traces_BR_90 = [noNorm_traces_BR_90; traces.BR90];
    noNorm_traces_BR_270 = [noNorm_traces_BR_270; traces.BR270];
    
    noNorm_traces_PA_90 = [noNorm_traces_PA_90; traces.PA90];
    noNorm_traces_PA_270 = [noNorm_traces_PA_270; traces.PA270];
    
end

%%

figure(1)
subplot(2,2,1)
[r,c] = size(noNorm_traces_BR_90);
data = noNorm_traces_BR_90;
Y = data-mean(mean(data));
Y = data/ sqrt(c-1);
cwaveforms = cov(Y);
dBR1 = diag(cwaveforms);

%[PC,~] = eigs(cwaveforms,3);
imagesc(t,t,cwaveforms-mean(mean(cwaveforms)))
colormap jet
vline(0,'--w')
hline(0,'--w')
set(gca,'xtick',[])
%ylabel('duration [s]')
colormap jet
%colorbar
title('BR 270TO90')

subplot(2,2,2)
[r,c] = size(noNorm_traces_BR_270);
data = noNorm_traces_BR_270;
Y = data-mean(mean(data));
Y = data/ sqrt(c-1);
cwaveforms = cov(Y);
dBR2 = diag(cwaveforms);

%[PC,~] = eigs(cwaveforms,3);
imagesc(t,t,cwaveforms-mean(mean(cwaveforms)))
colormap jet
vline(0,'--w')
hline(0,'--w')
set(gca,'xtick',[])
set(gca,'ytick',[])
colormap jet
%colorbar
title('BR 90TO270')

subplot(2,2,3)
[r,c] = size(noNorm_traces_PA_90);
data = noNorm_traces_PA_90;
Y = data-mean(mean(data));
Y = data/ sqrt(c-1);
cwaveforms = cov(Y);
dPA1 = diag(cwaveforms);

%[PC,~] = eigs(cwaveforms,3);
imagesc(t,t,cwaveforms-mean(mean(cwaveforms)))
colormap jet
vline(0,'--w')
hline(0,'--w')
%ylabel('duration [s]')
%xlabel('duration [s]')
colormap jet
%colorbar
title('PA 270TO90')

subplot(2,2,4)
[r,c] = size(noNorm_traces_PA_270);
data = noNorm_traces_PA_270;
Y = data-mean(mean(data));
Y = data/ sqrt(c-1);
cwaveforms = cov(Y);
dPA2 = diag(cwaveforms);

%[PC,~] = eigs(cwaveforms,3);
imagesc(t,t,cwaveforms-mean(mean(cwaveforms)))
colormap jet
vline(0,'--w')
hline(0,'--w')
set(gca,'ytick',[])
colormap jet
%colorbar
%xlabel('duration [s]')
title('PA 90TO270')

%% Collapse across transition types and plot

figure(2)
subplot(1,2,1)
data = [noNorm_traces_BR_90; noNorm_traces_BR_270];
[r,c] = size(data);
Y = data-mean(mean(data));
Y = data/ sqrt(c-1);
cwaveforms = cov(Y);
diagBR = diag(cwaveforms);
%[PC,~] = eigs(cwaveforms,3);
imagesc(t,t,cwaveforms-mean(mean(cwaveforms)))
colormap jet
vline(0,'--w')
hline(0,'--w')
%ylabel('duration [s]')
%xlabel('duration [s]')
colormap jet
%colorbar
title('BR')

subplot(1,2,2)
data = [noNorm_traces_PA_90; noNorm_traces_PA_270];
[r,c] = size(data);
Y = data-mean(mean(data));
Y = data/ sqrt(c-1);
cwaveforms = cov(Y);
diagPA = diag(cwaveforms);
%[PC,~] = eigs(cwaveforms,3);
imagesc(t,t,cwaveforms-mean(mean(cwaveforms)))
colormap jet
vline(0,'--w')
hline(0,'--w')
%xlabel('duration [s]')
set(gca,'ytick',[])
colormap jet
%colorbar
title('PA')

%% Plot the jitter matrix

subplot(1,2,1)
imagesc(t,1:size(brSwitches,1),brSwitches-mean(mean(brSwitches)))
xlabel('time relative to switch [s]')
ylabel('switch number')
vline(0,'--w')
title('Clean Switches BR')
colormap jet

subplot(1,2,2)
imagesc(t,1:size(paSwitches,1),paSwitches-mean(mean(paSwitches)))
xlabel('time relative to switch [s]')
ylabel('switch number')
vline(0,'--w')
title('Clean Switches PA')
colormap jet

