function par=par_av_gui() 
 
 
par.mode = 'a'; % or 'v' 
par.folder_base = []; % [] for pwd 
par.tbeg = 1; 
par.rec_length = 'end'; % or number of seconds from tbeg 
par.folder_resus = []; % place to save the results. [] for pwd 
par.frame_len = 20; % max chunk of data ploted in seconds 
 
par.channels = []; 
par.show_lfp = false; %only for single channel 
 
 
par.video_file = 'HIMYM_S03E05.mp4'; 
 
 
%Firing rate parameters 
par.show_fr = false; 
par.sigma_gauss = 49.42; 
par.alpha_gauss = 3.035; %last value of gaussian 0.01 0.025 
% lenght of gaussian window = 2* alpha_gauss * sigma_gauss 
par.show_raster = false; 
par.classes = 'mu'; % or 'mu' for multi unit, 'all' for all classes. only for single channel 
 
par.nrows = 1;  %number of rows in the matrix of frames in video mode 
par.fr_prev = 25; 
end 
 
%Shortcuts 
%========= 
 
% numerical minus('-'): max timescal, all the chunck (zoom out icon) 
% space bar:  pause/resume (||) 
% right_arrow: next chunk (>>) 
% left_arrow: prev chunck (<<) 
% return: Add mark 
% 1-9: choose that event 
 
 
 
 
