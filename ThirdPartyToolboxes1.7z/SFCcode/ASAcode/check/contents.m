% ARMASA directory
%   
%   Type 'help ARMASA' to view the contents of the ARMASA toolbox.
