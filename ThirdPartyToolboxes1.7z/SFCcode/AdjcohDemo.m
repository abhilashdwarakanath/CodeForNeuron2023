% This code will demonstrate the function adjcoherencypt.m, which uses
% structured arrays of spike times analogous to coherencypt.m from Chronux.
% Also inlcuded in this package is adjcoherencycpb.m, which uses binned 
% spike trains.  

% This code is in support of
%
% Aoi et al. Rate-adjusted spike-LFP coherence comparisons from spike-train
% statistics. J Neurosci Meth. In Press 2014.
%
% Use of these functions may require functions in the chronux matlab
% package available at http://www.chrosnux.org/
%
% Many of the tools used for simulating data (but are included with this
% demo) are from the ARMASA package developed by Piet T. Broersen and are
% freely available at
% http://www.mathworks.com/matlabcentral/fileexchange/1330-armasa

clear all;
%% =============Recording conditions=============
Fs  = 2e3;%sampling frequency in samples/sec. !Read comments below before changing!
Ts  = 1.5;%sampling period (sec)
dt  = 1/Fs;
ts  = [0:dt:Ts];%sampling time
Nts = numel(ts);%number of time steps in sample
NT  = 100;%number of trials
%==============================================

%% Simulate LFP

% An easy way to determine the parmaeters of a AR(2) process is to 
% specify reflection coefficients that give the LFP spectrum that you want.
% The first RF shoudl be 1 RF's should be on (-1 1).  Note that the
% resulting coeffs will be sensitive to the sampling rate that you specify,
% so if you want to change the sampling rate then you must adjust the RF's.

K = [1 -.99 .97];
ARcoeffs = rc2arset(K);%Determine AR coefficients from RC's
%%%%% Uncomment this code to view LFP spectrum defined by your AR coeffs%%%
% [psd,f] = arma2psd(ARcoeffs,1,Nts/2);figure;plot(f,psd)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y = zeros(Nts,NT);
for i = 1:NT
    y(:,i) = simuarma(ARcoeffs,1,Nts);
end

%% Simulate spikes
rates = [40 60];
Nrates = length(rates);
lambda1 = exp(y/2)/mean(mean(exp(y/2)));%normalized intensity with rate = 1
filestr = 'simoutAdj/PoisLogLin_AR2_rate';
delta   = 1e-6;%Sets numerical lower limit on rate function for the interpolation step
spikeT = struct('times',[]);
for i=1:Nrates
    lambda = max(rates(i)*lambda1,delta);
    for j = 1:NT
        
        %initialize data arrays
        Lamb = cumsum(lambda(:,j))*dt;    Lamb(1) = 0;
        tk = exprnd(1);  uk = [];
        
        
        while tk<Lamb(end)%loop until reaching end of trial period
            uk = [uk interp1(Lamb,ts,tk)];
            tk = tk + exprnd(1);
        end
        
        spikeT(j).times = uk';
        
    end
    savestring = [filestr num2str(rates(i))];
    save(savestring,'spikeT','y','dt','Ts');
end
%% ==========Chronux parameters==========
W  = 10/Fs;%
N  = Ts*Fs;
K  = 2*N*W-1;%number of Slepians
params.tapers   = [W*N K];
params.fpass    = [0 Fs/2];
params.Fs       = Fs;
params.pad      = 0;
params.err      = [0 .05];%2=generate jackknife error bars
params.trialave = 1;%1 = average over trials
fscorr          = 1;%finite size corrections
%========================================

%% Estimate spectra and related quantities

tic
for i = 1:Nrates
    loadstring = [filestr num2str(rates(i))];   load(loadstring);
    
    %     [C,phi,Syn,Syy,Snn,fc,zerosp,confC,phistd,Cerr]=...
    [C,phi,Syn,Syy,Snn,fc,zerosp]=...
        coherencycpt(y,spikeT,params,fscorr);
    
    savestr = [filestr num2str(rates(i)) '_spec'];
    save(savestr,'C','phi','Syn','Syy','Snn','fc','zerosp');
    toc
end

%% plot
M = reshape(1:Nrates*3,3,Nrates)';
figure(1);
for i = 1:Nrates
    savestr = [filestr num2str(rates(i)) '_spec'];
    load(savestr)
    subplot(Nrates,3,M(i,1));plot(fc,Syy);ylabel('LFP spec')
    subplot(Nrates,3,M(i,2));plot(fc,Snn);ylabel('Spike spec')
    subplot(Nrates,3,M(i,3));plot(fc,C);ylabel('SFC')
end

%% Adjusted coherence

for j = 1:Nrates
    adjrates    = rates;    adjrates(j) = [];
    for AdjRate = adjrates
        
        % Here we use mean spike rate estimates to perform the adjustment.
        % Realizations will have variable adjustment quality depending on
        % the accuracy of the rate estimate.
        ldstr       = [filestr num2str(AdjRate)];  load(ldstr);
        AdjRateEst     = numel(cat(1,spikeT.times))/NT/Ts;
        ldstr       = [filestr num2str(rates(j))];  load(ldstr);
        RateEst     = numel(cat(1,spikeT.times))/NT/Ts;
        
        %         [CA,phiA,SynA,SyyA,SnnA,fcA,zerospA,confCA,phistdA,CerrA]=...
        [CA,phiA,SynA,SyyA,SnnA,fcA,zerospA]=...
            Adjcoherencycpt(y,spikeT,params,fscorr,[],AdjRateEst,RateEst);
        savestr = [filestr num2str(rates(j)) 'to' num2str(AdjRate)];
        save(savestr,'CA','phiA','SynA','SyyA','SnnA','fcA','zerospA');
        fprintf(['Rate ' num2str(rates(j)) ', adjust to ' num2str(AdjRate) '.\n'])
        toc
    end
end

%% plot
load([filestr num2str(rates(1)) '_spec']);
figure;plot(fc,C,'r');hold on
load([filestr num2str(rates(2)) '_spec']);
plot(fc,C,'b');hold on
plot(fcA,CA,'b--');hold off;xlim([0 300])
legend('low','high','adjusted')